﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Utils;
using System.IO;
using System.Reflection;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// DataTable 与 Xml 的转换
    /// 必需设置好XmlPath路径及NewDataTable
   /// </summary>
    public class DataTableXml
    {
        /// <summary>
        /// 读取配置文件
        /// </summary>
        /// <returns></returns>
        public static List<T> LoadXml<T>(string xmlPath, DataTable NewDataTable)
        {
            xmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, xmlPath);

            DataTable dt = new DataTable();
            if (!ParseFile.FileExists(xmlPath)) { return new List<T>(); }

            dt.ReadXml(xmlPath);
            if (dt.Columns.Count != NewDataTable.Columns.Count) { return  new List<T>(); }

            return ParseDataTable.ToList<T>(dt);
            
        }

        /// <summary>
        /// 保存配置文件
        /// </summary>
        public static void SaveXml<T>(string xmlPath,DataTable NewDataTable, List<T> lst)
        {
            xmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, xmlPath);

            DataTable dt = NewDataTable.Clone();
            object[] obj;

            foreach (T t in lst)
            {
                //获取该类的所有public属性
                List<PropertyInfo> lstPropertyInfo = ParseClass.GetProperties(t.GetType());
                obj = new object[dt.Columns.Count];
                
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    for (int j = 0; j < lstPropertyInfo.Count; j++) 
                    {
                        if (string.Compare(dt.Columns[i].Caption, lstPropertyInfo[j].Name,false) == 0 ) 
                        { 
                            obj[i] = lstPropertyInfo[j].GetValue(t, null);
                            break;
                        }
                    }
                }
                dt.Rows.Add(obj);
            }

            dt.WriteXml(xmlPath, XmlWriteMode.WriteSchema);
        }
    }
}
