﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// Microsoft.Excel
    /// </summary>
    public class Excel
    {
        /// <summary>
        /// 生成Excel文件
        /// </summary>
        /// <param name="dt">数据源</param>
        /// <param name="fileName">保存的文件名</param>
        public static void CreateExcel(DataTable dt, string fileName)
        {
            HttpResponse response = HttpContext.Current.Response;

            response.ContentEncoding = System.Text.Encoding.GetEncoding("gb2312");
            response.AppendHeader("content-disposition", "attachment;filename=\"" + System.Web.HttpUtility.UrlEncode(fileName, System.Text.Encoding.UTF8) + ".xls\"");
            response.ContentType = "application/ms-excel";

            StringPlus DataItem = new StringPlus();
            DataItem.Append("<table border='1' cellspacing='0' cellpadding='0'>");

            DataItem.Append("<tr>");
            foreach (DataColumn item in dt.Columns)
            {
                DataItem.AppendFormat("<td style='font-size: 12px;text-align:center;background-color: #DCE0E2; font-weight:bold;' height='20'>{0}</td>", item.ToString());
            }
            DataItem.Append("</tr>");


            //定义表对象与行对像，同时用DataSet对其值进行初始化 
            foreach (DataRow row in dt.Rows)
            {
                DataItem.Append("<tr>");

                //在当前行中，逐列获得数据，数据之间以\t分割，结束时加回车符\n 
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    DataItem.AppendFormat("<td style='background-color: #E9ECED;font-size: 12px;'>{0}</td>", row[i].ToString());
                }
                DataItem.Append("</tr>");
            }

            DataItem.Append("</table>");
            response.Write(DataItem);
            response.End();

        }

        /// <summary>
        /// datagrid生成 
        /// </summary>
        /// <param name="ctl"></param>
        public static void ToExcel(System.Web.UI.Control ctl)
        {
            HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment;filename=Excel.xls");
            HttpContext.Current.Response.Charset = "UTF-8";
            HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Default;
            HttpContext.Current.Response.ContentType = "application/ms-excel";//image/JPEG;text/HTML;image/GIF;vnd.ms-excel/msword 
            ctl.Page.EnableViewState = false;
            System.IO.StringWriter tw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            ctl.RenderControl(hw);
            HttpContext.Current.Response.Write(tw.ToString());
            HttpContext.Current.Response.End();
        }

    }
}
