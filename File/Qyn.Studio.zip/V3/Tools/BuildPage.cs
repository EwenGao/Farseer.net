﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// 页面生成工具
    /// </summary>
    public class BuildPage
    {

        /// <summary>
        /// 生成静态HTML页面,无模版,不分页
        /// </summary>
        /// <param name="webPath">网站根目录路径</param>
        /// <param name="savePagePathName">要保存的文件路径(不带根目录路径,带文件名)</param>
        /// <param name="loadPagePathName">源文件网页路径(不带根目录路径,带文件名)</param>
        /// <param name="isUrl">true:loadPagePath为网页Url, false:loadPagePath为文件地址</param>
        /// <param name="readCode">读取源文件所使用的编码</param>
        /// <param name="writeCode">生成HTML文件所使用的编码</param>
        public static bool MakeHtml(string webPath, string savePagePathName, string loadPagePathName, bool isUrl, string readCode, string writeCode)
        {
            string pageContent;                                                                                 //源文件网页内容

            try
            {
                #region 对路径进行判断

                #region 网站根目录判断
                if (webPath == null || webPath.Trim().Length == 0)
                {
                    webPath = "/";
                }
                #endregion

                #region 源文件路径判断
                if (loadPagePathName == null || loadPagePathName.Trim().Length == 0)
                {
                    if (isUrl)
                    {
                        new Tools.Terminator().Throw("无效的 源文件 URI: 此 URI 为空。");
                        return false;
                    }
                    else
                    {
                        new Tools.Terminator().Throw("无效的 源文件 Path: 此 Path 为空。");
                        return false;
                    }
                }
                else
                {
                    if (!isUrl)
                    {
                        if (!Utils.ParseFile.FileExists(Path.Combine(Utils.ParseUrl.GetMapPath(webPath), loadPagePathName)))
                        {
                            new Tools.Terminator().Throw(Path.Combine(Utils.ParseUrl.GetMapPath(webPath), loadPagePathName) + "路径不存在");
                            return false;
                        }
                    }
                }
                #endregion;

                #endregion;

                #region 获取源文件html内容
                pageContent = (isUrl) ?
                                                ParseHtml.GetUrlToHtml(loadPagePathName, readCode) :
                                                ParseHtml.GetFileToHtml(webPath, loadPagePathName, readCode);                               //源文件网页内容
                if (pageContent == null)
                {
                    return false;
                }

                #endregion

                #region 生成静态文件
                return ParseFile.WriteFile(Path.Combine(webPath,savePagePathName), writeCode, pageContent);
                #endregion
            }
            catch (Exception oExcept)
            {
                new Tools.Terminator().Throw(oExcept.Message);
                return false;
            }
        }

        /// <summary>
        /// 生成静态HTML页面,带模版,自动分页
        /// </summary>
        /// <param name="webPath">网站根目录路径</param>
        /// <param name="savePagePath">要保存的文件路径(不带根目录路径,不带文件名,由系统自动生成)</param>
        /// <param name="templatePathName">源文件网页路径(不带根目录路径,带文件名)</param>
        /// <param name="isUrl">true:loadPagePath为网页Url, false:loadPagePath为文件地址</param>
        /// <param name="readCode">读取源文件所使用的编码</param>
        /// <param name="writeCode">生成HTML文件所使用的编码</param>
        public static bool MakeHtml(
                                    string webPath, string savePagePath, string templatePathName,
                                    bool isUrl, string readCode, string writeCode, string[] contents,
                                    string[,] orderContents, int saveType, string pageFileExtension,
                                    string pageContexnt, string lastPage, string nextPage, string pageIndex
                                    )
        {
            string temContent;                                                                                 //模板文件内容
            int conLength = 0;                                                                                  //数组的上限
            string strNumber = "";                                                                              //数字分页1，2，3……
            string pageFilePath = "";                                                                           //文件相对路径
            string pageFileDir = "";                                                                            //文件夹名
            string pageFileName = "";                                                                           //文件名
            string pageFileNameWithoutExtension = "";                                                           //文件名前缀

            #region 生成文件名

            pageFileExtension = pageFileExtension.Trim().Replace(".", "");
            if (pageFileExtension == null || pageFileExtension.Length == 0)
            {
                new Tools.Terminator().Throw("生成的文件后缀名不能为空");
                return false;
            }

            if (saveType == 0)                                                                                  //080926/20080926034050.html
            {
                pageFileDir = DateTime.Now.ToString("yyMMdd");
                pageFileNameWithoutExtension = DateTime.Now.ToString("yyyymmddhhmmss").ToString();
                pageFileName = pageFileNameWithoutExtension + "." + pageFileExtension;
            }
            else if (saveType == 1)                                                                             //20080926034050.html
            {
                pageFileDir = "";
                pageFileNameWithoutExtension = DateTime.Now.ToString("yyyymmddhhmmss").ToString();
                pageFileName = pageFileNameWithoutExtension + "." + pageFileExtension;
            }
            else
            {
                new Tools.Terminator().Throw("不存在此保存方式");
                return false;
            }

            #endregion

            try
            {
                #region 对路径进行判断

                #region 网站根目录判断
                if (webPath == null || webPath.Trim().Length == 0)
                {
                    webPath = "/";
                }
                #endregion

                #region 模板路径判断
                if (templatePathName == null || templatePathName.Trim().Length == 0)
                {
                    if (isUrl)
                    {
                        new Tools.Terminator().Throw("无效的 模板URI: 此 URI 为空。");
                        return false;
                    }
                    else
                    {
                        new Tools.Terminator().Throw("无效的 模板 Path: 此 Path 为空。");
                        return false;
                    }
                }
                else
                {
                    if (!isUrl)
                    {
                        if (!Utils.ParseFile.FileExists(Path.Combine(Utils.ParseUrl.GetMapPath(webPath), templatePathName)))
                        {
                            new Tools.Terminator().Throw(Path.Combine(Utils.ParseUrl.GetMapPath(webPath), templatePathName) + "路径不存在");
                            return false;
                        }
                    }
                }

                #endregion;

                #endregion

                #region 获取模板文件html内容
                temContent = (isUrl) ?
                                                ParseHtml.GetUrlToHtml(templatePathName, readCode) :
                                               ParseHtml.GetFileToHtml(webPath, templatePathName, readCode);                               //模板文件网页内容
                if (temContent == null)
                {
                    return false;
                }

                #endregion

                #region 对模板符号进行判断
                if (pageContexnt == null || pageContexnt.Trim().Length == 0)
                {
                    new Tools.Terminator().Throw("内容模板符号没有填写");
                    return false;
                }
                if (lastPage == null || lastPage.Trim().Length == 0)
                {
                    new Tools.Terminator().Throw("上一页模板符号没有填写");
                    return false;
                }
                if (nextPage == null || nextPage.Trim().Length == 0)
                {
                    new Tools.Terminator().Throw("下一页模板符号没有填写");
                    return false;
                }
                if (pageIndex == null || pageIndex.Trim().Length == 0)
                {
                    new Tools.Terminator().Throw("页码模板符号没有填写");
                    return false;
                }
                pageContexnt = pageContexnt.Trim();
                lastPage = lastPage.Trim();
                nextPage = nextPage.Trim();
                pageIndex = pageIndex.Trim();
                #endregion

                #region 对正文内容进行判断
                if (contents == null)
                {
                    new Tools.Terminator().Throw("内容没有填写");
                    return false;
                }
                #endregion

                conLength = contents.Length;                                                                    //数组的上限
                for (int i = 0; i < contents.Length; i++)
                {
                    string templateContent = temContent;                                                        //存放临时模版内容

                    #region 替换模版内容
                    if (orderContents != null)
                    {
                        for (int ocIndex = 0; ocIndex < orderContents.GetLength(0); ocIndex++)
                        {
                            if (orderContents[ocIndex, 0] != null && orderContents[ocIndex, 1] != null)
                            {
                                templateContent = templateContent.Replace(orderContents[ocIndex, 0], orderContents[ocIndex, 1]);
                            }
                        }
                    }
                    templateContent = templateContent.Replace(pageContexnt, contents[i]);
                    #endregion

                    #region 生成分页超连接
                    strNumber = "";
                    for (int m = 1; m <= conLength; m++)
                    {
                        //如果是第一页就显示成：20080926.html而不是20080906_1.html
                        //第三页的连接应该是20080906_2.html，以此类推

                        strNumber += " [" + "<a href=" + pageFileNameWithoutExtension +
                                    ((m == 1) ? "" : "_" + Convert.ToString(m - 1))
                                    + "." + pageFileExtension + ">" + m + "</a>" + "] ";

                    }
                    #endregion

                    #region 文件保存路径及上下页处理

                    pageFilePath = System.IO.Path.Combine(savePagePath, pageFileDir);
                    if (conLength == 0)//如果没有分页，就直接按日期时间保存
                    {
                        pageFilePath = System.IO.Path.Combine(pageFilePath, pageFileName);

                        templateContent = templateContent.Replace(lastPage, "");
                        templateContent = templateContent.Replace(nextPage, "");
                        templateContent = templateContent.Replace(pageIndex, "");
                    }
                    else//否则按20070524.shtml、20070524_1.shtml 这种效果保存
                    {
                        pageFilePath = System.IO.Path.Combine(pageFilePath, pageFileNameWithoutExtension) + ((i == 0) ? "" : "_" + i.ToString()) + "." + pageFileExtension;

                        #region 上一页超连接处理
                        if (i == 0)                                             //当前为第一页时,不显示上一页
                        {
                            templateContent = templateContent.Replace(lastPage, "");
                        }
                        else if (i == 1)//上一页分页
                        {
                            templateContent = templateContent.Replace(lastPage, "<a href=" + pageFileName + ">上一页</a>");
                        }
                        else
                        {
                            int p = i - 1;
                            templateContent = templateContent.Replace(lastPage, "<a href=" + pageFileNameWithoutExtension + "_" + p.ToString() + "." + pageFileExtension + ">上一页</a>");
                        }
                        #endregion

                        #region 页码显示处理

                        templateContent = templateContent.Replace(pageIndex, (conLength == 1) ? "" : strNumber);                  //如果只有一页，则不显示页码
                        #endregion

                        #region 下一页超连接处理
                        if (i == conLength - 1)//最后一页不显示下一页
                        {
                            templateContent = templateContent.Replace(nextPage, "");
                        }
                        else if (i != conLength - 1)//下一页分页
                        {
                            int q = i + 1;
                            templateContent = templateContent.Replace(nextPage, "<a href=" + pageFileNameWithoutExtension + "_" + q + "." + pageFileExtension + ">下一页</a>");
                        }
                        else
                        {
                            int j = conLength - 1;
                            templateContent = templateContent.Replace(nextPage, "<a href=" + pageFileNameWithoutExtension + "_" + j + "." + pageFileExtension + ">下一页</a>");
                        }
                        #endregion

                    }
                    #endregion

                    #region 生成页面

                    Utils.ParseFile.CreateDirs(Path.Combine(webPath, pageFilePath));

                    if (!ParseFile.WriteFile(Path.Combine(webPath, pageFilePath), writeCode, templateContent))
                    {
                        new Tools.Terminator().Throw("生成失败");
                        return false;
                    }
                    #endregion
                }
                return true;
            }
            catch (Exception oExcept)
            {
                new Tools.Terminator().Throw(oExcept.Message);
                return false;
            }
        }

    }
}
