﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// 对StringBuilder再封装
    /// </summary>
    public class StringPlus
    {
        // Fields
        private StringBuilder str = new StringBuilder();

        /// <summary>
        /// 添加字符串
        /// </summary>
        public void Append(string Text)
        {
            Append(0, Text);
        }

        /// <summary>
        /// 添加行
        /// </summary>
        public void AppendLine()
        {
            Append("\r\n");
        }

        /// <summary>
        /// 添加字符串，并向下添加一行
        /// </summary>
        public void AppendLine(string Text)
        {
            Append(Text);
            AppendLine();
        }

        /// <summary>
        /// 添加字符串
        /// </summary>
        public void Append(int SpaceNum, string Text)
        {
            this.str.Append(this.Space(SpaceNum) + Text);
        }

        /// <summary>
        /// 添加字符串
        /// </summary>
        public void AppendLine(int SpaceNum, string Text)
        {
            Append(SpaceNum, Text);
            AppendLine();
        }

        /// <summary>
        /// 添加字符串
        /// </summary>
        /// <param name="format"></param>
        /// <param name="args"></param>
        public void AppendFormat(string format, params object[] args)
        {
            AppendFormat(0, format, args);
        }
        /// <summary>
        /// 添加字符串
        /// </summary>
        /// <param name="format"></param>
        /// <param name="args"></param>
        public void AppendFormatLine(string format, params object[] args)
        {
            AppendFormat(0, format, args);
            AppendLine();
        }
        /// <summary>
        /// 添加字符串
        /// </summary>
        /// <param name="SpaceNum"></param>
        /// <param name="format"></param>
        /// <param name="args"></param>
        public void AppendFormat(int SpaceNum, string format, params object[] args)
        {
            try
            {
                if (args == null || args.Length == 0)
                { Append(SpaceNum, format); }
                else { Append(SpaceNum, string.Format(format, args)); }
            }
            catch
            {
                new Terminator().Alert(format); 
            }
        }

        /// <summary>
        /// 添加字符串
        /// </summary>
        /// <param name="SpaceNum"></param>
        /// <param name="format"></param>
        /// <param name="args"></param>
        public void AppendFormatLine(int SpaceNum, string format, params object[] args)
        {
            AppendFormat(SpaceNum, format, args);
            AppendLine();
        }

        /// <summary>
        /// 删除指定最后的字符串
        /// </summary>
        public string DelLastChar(string strChar)
        {
            string str = this.str.ToString();
            int length = str.LastIndexOf(strChar);
            if (length > 0)
            {
                this.str = new StringBuilder();
                this.str.Append(str.Substring(0, length));
            }
            return this.str.ToString();
        }

        /// <summary>
        /// 移出指定数量的字符串
        /// </summary>
        /// <param name="Start"></param>
        /// <param name="Num"></param>
        public void Remove(int Start, int Num)
        {
            this.str.Remove(Start, Num);
        }

        /// <summary>
        /// 制表符
        /// </summary>
        public string Space(int SpaceNum)
        {
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < SpaceNum; i++)
            {
                builder.Append("\t");
            }
            return builder.ToString();
        }

        /// <summary>
        /// 转换为String类型
        /// </summary>
        public override string ToString()
        {
            return this.str.ToString();
        }

        public string Value
        {
            get
            {
                return this.str.ToString();
            }
        }

        public void Clear()
        {
            this.str = new StringBuilder();
        }
    }

}
