﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// 解压缩文件
    /// </summary>
    public class WinRAR
    {
        /// <summary>
        /// 解压文件
        /// </summary>
        public static bool OutRar(string rarPath, string filePath, string toPath)
        {
            //取得系统临时目录
            //string sysTempDir = Path.GetTempPath();

            //要解压的文件路径，请自行设置
            //string rarFilePath = @"d:\test.rar";

            //确定要解压到的目录，是系统临时文件夹下，与原压缩文件同名的目录里
            // string unrarDestPath = Path.Combine(sysTempDir,
            //     Path.GetFileNameWithoutExtension(rarFilePath));

            //组合出需要shell的完整格式
            //string shellArguments = string.Format("x -o+ \"{0}\" \"{1}\\\"",
            //    rarFilePath, unrarDestPath);

            filePath = ParseUrl.GetMapPath(filePath);
            toPath = ParseUrl.GetMapPath(toPath);
            ParseFile.CreateDirs(toPath);

            string shellArguments = string.Format("x -o+ \"{0}\" \"{1}\\\"",
                filePath, toPath);

            try
            {
                //用Process调用
                using (Process unrar = new Process())
                {
                    unrar.StartInfo.FileName = rarPath;
                    unrar.StartInfo.Arguments = shellArguments;
                    //隐藏rar本身的窗口
                    unrar.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    unrar.Start();
                    //等待解压完成
                    unrar.WaitForExit();
                    unrar.Close();
                }
                return true;
            }
            catch (Exception e)
            {
                new Terminator().Throw(e.Message);
                return false;
            }



            //统计解压后的目录和文件数
            //DirectoryInfo di = new DirectoryInfo(unrarDestPath);

            //MessageBox.Show(string.Format("解压完成，共解压出：{0}个目录，{1}个文件",
            //    di.GetDirectories().Length, di.GetFiles().Length));

        }
    }
}
