﻿using System;
using System.Text;
using System.Collections;
using System.Net.Sockets;
using System.Web.Mail;
using System.Net;

using Qyn.Studio.Tools;
using Qyn.Studio.Utils;
using System.Collections.Generic;
using System.Net.Mail;
using Qyn.Config;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// E-Mail工具
    /// </summary>
    public class SmtpMail
    {
        /// <summary>
        /// 将字符串编码为Base64字符串
        /// </summary>
        private static string Base64Encode(string str)
        {
            byte[] barray;
            barray = Encoding.Default.GetBytes(str);
            return Convert.ToBase64String(barray);
        }

        /// <summary>
        /// 发送电子邮件
        /// </summary>
        /// <param name="mail">Email配置</param>
        /// <param name="lstAddress">收件人地址</param>
        /// <param name="subject">邮件的标题</param>
        /// <param name="body">邮件的正文</param>
        /// <param name="fileName">邮件附件路径名</param>
        public static bool Send(EmailList mail, List<string> lstAddress, string subject, string body, string fileName)
        {
            try
            {
                if (lstAddress.Count > mail.RecipientMaxNum) { new Terminator().Throw("收件人地址数量不能超过" + mail.RecipientMaxNum); return false; }

                SmtpClient ObjSmtpClient = new SmtpClient(mail.MailDomain, mail.Port);
                ObjSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                ObjSmtpClient.Credentials = new System.Net.NetworkCredential(mail.LoginName, mail.LoginPwd);

                System.Net.Mail.MailMessage ObjMailMessage = new System.Net.Mail.MailMessage();
                ObjMailMessage.From = new MailAddress(mail.SendMail,mail.SendUserName);
                foreach (string item in lstAddress)
                {
                    ObjMailMessage.To.Add(new MailAddress(item));
                }

                ObjMailMessage.Subject = subject;                                    //发送邮件主题
                ObjMailMessage.Body = body;                                          //发送邮件内容
                ObjMailMessage.BodyEncoding = System.Text.Encoding.Default;             //发送邮件正文编码
                ObjMailMessage.IsBodyHtml = true;                                       //设置为HTML格式
                ObjMailMessage.Priority = System.Net.Mail.MailPriority.High;            //优先级
                if (!string.IsNullOrEmpty(fileName)) ObjMailMessage.Attachments.Add(new Attachment(fileName));  //邮件的附件

                ObjSmtpClient.Send(ObjMailMessage);
                return true;
            }
            catch(Exception e)
            {
                new Terminator().Throw(e.Message);
                return false;
            }
        }

        /// <summary>
        /// 发送电子邮件
        /// </summary>
        /// <param name="mail">Email配置</param>
        /// <param name="lstAddress">收件人地址</param>
        /// <param name="StrSubject">邮件的标题</param>
        /// <param name="StrBody">邮件的正文</param>
        /// <param name="StrFileName">邮件附件路径名</param>
        public static bool Send(EmailList mail, List<string> lstAddress, string subject, string body)
        {
            return Send(mail, lstAddress, subject, body, null);
        }
    }
}