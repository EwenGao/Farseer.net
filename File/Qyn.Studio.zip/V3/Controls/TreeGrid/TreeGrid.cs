﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Drawing;
using Qyn.Studio.Tools;
using System.Web;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 树表格控件
    /// </summary>
    [
     ToolboxData("<{0}:TreeGrid runat=server />")
    ]
    public class TreeGrid : Control
    {
        #region Table样式
        #region TableWidth
        private int tableWidth = 0;
        /// <summary>
        /// 表格宽度
        /// </summary>
        [
        Category("Table"),
        DefaultValue(0),
        Description("表格宽度"),
        Browsable(true)
        ]
        public int TableWidth
        {
            get { return tableWidth; }
            set { tableWidth = value; }
        }
        #endregion

        #region TableOnOverColor
        private string tableOnOverColor = "#CCCCCC";
        /// <summary>
        /// 鼠标活动颜色
        /// </summary>
        [
        Category("Table"),
        DefaultValue("#CCCCCC"),
        Description("鼠标活动颜色"),
        Browsable(true)
        ]
        public string TableOnOverColor
        {
            get { return tableOnOverColor; }
            set { tableOnOverColor = value; }
        }
        #endregion

        #region TableBorder
        private int tableBorder = 0;
        /// <summary>
        /// 表格宽度
        /// </summary>
        [
        Category("Table"),
        DefaultValue(0),
        Description("表格宽度"),
        Browsable(true)
        ]
        public int TableBorder
        {
            get { return tableBorder; }
            set { tableBorder = value; }
        }
        #endregion

        #region TableCellPadding
        private int tableCellPadding = 0;
        /// <summary>
        /// 表格Padding
        /// </summary>
        [
        Category("Table"),
        DefaultValue(0),
        Description("表格Padding"),
        Browsable(true)
        ]
        public int TableCellPadding
        {
            get { return tableCellPadding; }
            set { tableCellPadding = value; }
        }
        #endregion

        #region TableCellSpacing
        private int tableCellSpacing = 0;
        /// <summary>
        /// 表格单元格宽度
        /// </summary>
        [
        Category("Table"),
        DefaultValue(0),
        Description("表格单元格宽度"),
        Browsable(true)
        ]
        public int TableCellSpacing
        {
            get { return tableCellSpacing; }
            set { tableCellSpacing = value; }
        }
        #endregion

        #region TableBgColor
        private string tableBgColor = "#FFFFFF";
        /// <summary>
        /// 表格背景颜色
        /// </summary>
        [
        Category("Table"),
        DefaultValue("#FFFFFF"),
        Description("表格背景颜色"),
        Browsable(true)
        ]
        public string TableBgColor
        {
            get { return tableBgColor; }
            set { tableBgColor = value; }
        }
        #endregion

        #region TableClass
        private string tableClass = "";
        /// <summary>
        /// 表格CSS
        /// </summary>
        [
        Category("Table"),
        DefaultValue(""),
        Description("表格CSS"),
        Browsable(true)
        ]
        public string TableClass
        {
            get { return tableClass; }
            set { tableClass = value; }
        }
        #endregion

        #region TableStyle
        private string tableStyle = "";
        /// <summary>
        /// 表格样式
        /// </summary>
        [
        Category("Table"),
        DefaultValue(""),
        Description("表格样式"),
        Browsable(true)
        ]
        public string TableStyle
        {
            get { return tableStyle; }
            set { tableStyle = value; }
        }
        #endregion

        #region TableAlign
        private emAlign tableAlign = emAlign.center;
        /// <summary>
        /// 表格排列方式
        /// </summary>
        [
        Category("Table"),
        DefaultValue("Center"),
        Description("表格排列方式"),
        Browsable(true)
        ]
        public emAlign TableAlign
        {
            get { return tableAlign; }
            set { tableAlign = value; }
        }
        #endregion

        #region TableID
        private string tableID = "QynTreeGrid";
        /// <summary>
        /// 表格ID
        /// </summary>
        [
        Category("Table"),
        DefaultValue("QynTreeGrid"),
        Description("表格ID"),
        Browsable(true)
        ]
        public string TableID
        {
            get { return tableID; }
            set { tableID = value; }
        }
        #endregion

        #region TableFontColor
        private string tableFontColor = "";
        /// <summary>
        /// 表格字体颜色
        /// </summary>
        [
        Category("Table"),
        DefaultValue(""),
        Description("表格字体颜色"),
        Browsable(true)
        ]
        public string TableFontColor
        {
            get { return tableFontColor; }
            set { tableFontColor = value; }
        }
        #endregion

        #region TableFontSize
        private string tableFontSize = "";
        /// <summary>
        /// 表格字体大小
        /// </summary>
        [
        Category("Table"),
        DefaultValue(""),
        Description("表格字体大小"),
        Browsable(true)
        ]
        public string TableFontSize
        {
            get { return tableFontSize; }
            set { tableFontSize = value; }
        }
        #endregion
        #endregion

        #region Tr样式
        #region TrBgColor
        private string trBgColor = "";
        /// <summary>
        /// Tr背景颜色
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(""),
        Description("Tr背景颜色"),
        Browsable(true)
        ]
        public string TrBgColor
        {
            get { return trBgColor; }
            set { trBgColor = value; }
        }
        #endregion

        #region TrClass
        private string trClass = "";
        /// <summary>
        /// TrCSS
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(""),
        Description("TrCSS"),
        Browsable(true)
        ]
        public string TrClass
        {
            get { return trClass; }
            set { trClass = value; }
        }
        #endregion

        #region TrStyle
        private string trStyle = "";
        /// <summary>
        /// Tr样式
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(""),
        Description("Tr样式"),
        Browsable(true)
        ]
        public string TrStyle
        {
            get { return trStyle; }
            set { trStyle = value; }
        }
        #endregion

        #region TrAlign
        private emAlign trAlign = emAlign.center;
        /// <summary>
        /// Tr排列方式
        /// </summary>
        [
        Category("Tr"),
        DefaultValue("Center"),
        Description("Tr排列方式"),
        Browsable(true)
        ]
        public emAlign TrAlign
        {
            get { return trAlign; }
            set { trAlign = value; }
        }
        #endregion

        #region TrHeight
        private int trHeight = 22;
        /// <summary>
        /// Tr高度
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(22),
        Description("Tr高度"),
        Browsable(true)
        ]
        public int TrHeight
        {
            get { return trHeight; }
            set { trHeight = value; }
        }
        #endregion

        #region TrFontColor
        private string trFontColor = "";
        /// <summary>
        /// tr字体颜色
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(""),
        Description("tr字体颜色"),
        Browsable(true)
        ]
        public string TrFontColor
        {
            get { return trFontColor; }
            set { trFontColor = value; }
        }
        #endregion

        #region TrFontSize
        private string trFontSize = "";
        /// <summary>
        /// Tr字体大小
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(""),
        Description("Tr字体大小"),
        Browsable(true)
        ]
        public string TrFontSize
        {
            get { return trFontSize; }
            set { trFontSize = value; }
        }
        #endregion

        #region TrFontBold
        private bool trFontBold = false;
        /// <summary>
        /// Tr字体粗体
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(false),
        Description("Tr字体粗体"),
        Browsable(true)
        ]
        public bool TrFontBold
        {
            get { return trFontBold; }
            set { trFontBold = value; }
        }
        #endregion

        #region TrFontItalic
        private bool trFontItalic = false;
        /// <summary>
        /// Tr字体斜体
        /// </summary>
        [
        Category("Tr"),
        DefaultValue(false),
        Description("Tr字体斜体"),
        Browsable(true)
        ]
        public bool TrFontItalic
        {
            get { return trFontItalic; }
            set { trFontItalic = value; }
        }
        #endregion

        #endregion

        #region ColumnTr样式
        #region ColumnTrBgColor
        private string columnTrBgColor = "";
        /// <summary>
        /// ColumnTr背景颜色
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(""),
        Description("ColumnTr背景颜色"),
        Browsable(true)
        ]
        public string ColumnTrBgColor
        {
            get { return columnTrBgColor; }
            set { columnTrBgColor = value; }
        }
        #endregion

        #region ColumnTrClass
        private string columnTrClass = "";
        /// <summary>
        /// ColumnTrCSS
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(""),
        Description("ColumnTrCSS"),
        Browsable(true)
        ]
        public string ColumnTrClass
        {
            get { return columnTrClass; }
            set { columnTrClass = value; }
        }
        #endregion

        #region ColumnTrStyle
        private string columnTrStyle = "";
        /// <summary>
        /// ColumnTr样式
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(""),
        Description("ColumnTr样式"),
        Browsable(true)
        ]
        public string ColumnTrStyle
        {
            get { return columnTrStyle; }
            set { columnTrStyle = value; }
        }
        #endregion

        #region ColumnTrAlign
        private emAlign columnTrAlign = emAlign.center;
        /// <summary>
        /// ColumnTr排列方式
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue("Center"),
        Description("ColumnTr排列方式"),
        Browsable(true)
        ]
        public emAlign ColumnTrAlign
        {
            get { return columnTrAlign; }
            set { columnTrAlign = value; }
        }
        #endregion

        #region ColumnTrHeight
        private int columnTrHeight = 22;
        /// <summary>
        /// ColumnTr高度
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(22),
        Description("ColumnTr高度"),
        Browsable(true)
        ]
        public int ColumnTrHeight
        {
            get { return columnTrHeight; }
            set { columnTrHeight = value; }
        }
        #endregion

        #region ColumnTrFontColor
        private string columnTrFontColor = "";
        /// <summary>
        /// columnTr字体颜色
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(""),
        Description("columnTr字体颜色"),
        Browsable(true)
        ]
        public string ColumnTrFontColor
        {
            get { return columnTrFontColor; }
            set { columnTrFontColor = value; }
        }
        #endregion

        #region ColumnTrFontSize
        private string columnTrFontSize = "";
        /// <summary>
        /// ColumnTr字体大小
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(""),
        Description("ColumnTr字体大小"),
        Browsable(true)
        ]
        public string ColumnTrFontSize
        {
            get { return columnTrFontSize; }
            set { columnTrFontSize = value; }
        }
        #endregion

        #region ColumnTrFontBold
        private bool columnTrFontBold = true;
        /// <summary>
        /// ColumnTr字体粗体
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(true),
        Description("ColumnTr字体粗体"),
        Browsable(true)
        ]
        public bool ColumnTrFontBold
        {
            get { return columnTrFontBold; }
            set { columnTrFontBold = value; }
        }
        #endregion

        #region ColumnTrFontItalic
        private bool columnTrFontItalic = false;
        /// <summary>
        /// ColumnTr字体斜体
        /// </summary>
        [
        Category("ColumnTr"),
        DefaultValue(false),
        Description("ColumnTr字体斜体"),
        Browsable(true)
        ]
        public bool ColumnTrFontItalic
        {
            get { return columnTrFontItalic; }
            set { columnTrFontItalic = value; }
        }
        #endregion
        #endregion

        #region 列内容
        private List<stuColumns> columns = new List<stuColumns>();
        /// <summary>
        /// 列内容
        /// </summary>
        [
        Category("列"),
        Description("列内容"),
        Browsable(true)
        ]
        public List<stuColumns> Columns
        {
            get { return columns; }
            set { columns = value; }
        }

        /// <summary>
        /// 数据列结构
        /// </summary>
        public struct stuColumns
        {
            /// <summary>
            /// 内容
            /// </summary>
            public string Caption { get; set; }
            /// <summary>
            /// 宽度
            /// </summary>
            public int Width { get; set; }
            /// <summary>
            /// CSS
            /// </summary>
            public string CssClass { get; set; }
            /// <summary>
            /// Style
            /// </summary>
            public string Style { get; set; }
            /// <summary>
            /// 背景颜色
            /// </summary>
            public string BgColor { get; set; }
            /// <summary>
            /// 字体颜色
            /// </summary>
            public string FontColor { get; set; }
            /// <summary>
            /// 字体大小
            /// </summary>
            public string FontSize { get; set; }
            /// <summary>
            /// 是否粗体
            /// </summary>
            public bool FontBold { get; set; }
            /// <summary>
            /// 是否斜体
            /// </summary>
            public bool FontItalic { get; set; }
            /// <summary>
            /// 排列方式
            /// </summary>
            public emAlign Align { get; set; }
        }

        /// <summary>
        /// 排列方式
        /// </summary>
        public enum emAlign
        {
            center,
            left,
            right,
            justify
        }
        #endregion

        #region 行内容
        private List<csItems> items = new List<csItems>();
        [
        Bindable(true),
        Category("行"),
        Description("行内容"),
        Browsable(true)
        ]
        public List<csItems> Items
        {
            get { return items; }
            set { items = value; }
        }

        /// <summary>
        /// 数据行结构
        /// </summary>
        public class csItems
        {
            /// <summary>
            /// 标题
            /// </summary>
            public List<string> Caption = new List<string>();
            /// <summary>
            /// 链接
            /// </summary>
            public List<string> Links = new List<string>();

            /// <summary>
            /// 打开方式
            /// </summary>
            public List<emTarget> Target = new List<emTarget>();
            /// <summary>
            /// CSS
            /// </summary>
            public List<string> CssClass = new List<string>();
            /// <summary>
            /// Style
            /// </summary>
            public List<string> Style = new List<string>();
            /// <summary>
            /// 背景颜色
            /// </summary>
            public List<string> BgColor = new List<string>();
            /// <summary>
            /// 排列方式
            /// </summary>
            public List<emAlign> Align = new List<emAlign>();
            /// <summary>
            /// 字体颜色
            /// </summary>
            public List<string> FontColor = new List<string>();
            /// <summary>
            /// 字体大小
            /// </summary>
            public List<string> FontSize = new List<string>();
            /// <summary>
            /// 是否粗体
            /// </summary>
            public List<bool> FontBold = new List<bool>();
            /// <summary>
            /// 是否斜体
            /// </summary>
            public List<bool> FontItalic = new List<bool>();
            /// <summary>
            /// 子列
            /// </summary>
            public List<csItems> Items = new List<csItems>();
        }

        /// <summary>
        /// 链接打开方式
        /// </summary>
        public enum emTarget : byte
        {
            /// <summary>
            /// 本窗口打开
            /// </summary>
            _self,
            /// <summary>
            /// 新窗口打开
            /// </summary>
            _blank,
            /// <summary>
            /// 父窗口打开
            /// </summary>
            _parent,
            /// <summary>
            /// 同时打开搜索窗口
            /// </summary>
            _search,
            /// <summary>
            /// 在上层窗体中打开
            /// </summary>
            _top
        }
        #endregion

        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);
            HttpContext context = HttpContext.Current;
            StringPlus str = new StringPlus();
            str.AppendLine();
            if (context == null)
            {
                str.AppendLine(2, string.Format("<table width=\"{0}\">", TableWidth));
                str.AppendLine(3, "<tr>");
                foreach (stuColumns item in Columns)
                {
                    str.AppendLine(4, string.Format("<td width=\"{0}\">{1}</td>", item.Width, item.Caption));
                }
                str.AppendLine(3, "</tr>");
                str.AppendLine(2, "</table>");
                writer.WriteLine(string.Format("<table><tr></tr></table>"));
                writer.WriteLine(str.Value);
                return;
            }

            //脚本开始
            str.AppendLine(2, "<script>");
            str.AppendLine(2, "<!--");
            //创建实例
            str.AppendLine(3, "treeGrid = new TreeGrid();");
            //设置宽度、鼠标活动颜色
            str.AppendLine(3, string.Format("treeGrid.initializeDocument({0}, \"{1}\",{2},{3},{4}, \"{5}\", \"{6}\", \"{7}\", \"{8}\", \"{9}\", \"{10}\", \"{11}\", \"{12}\", \"{13}\",\"{14}\", \"{15}\", {16}, \"{17}\", \"{18}\",{19},{20}, \"{21}\", \"{22}\",\"{23}\", \"{24}\", {25}, \"{26}\", \"{27}\",{28},{29});",
                              TableWidth, TableOnOverColor, TableBorder, TableCellPadding, TableCellSpacing, TableBgColor, TableClass, TableStyle, TableAlign.ToString(), TableID, TableFontColor, TableFontSize,
                              TrClass, TrStyle, TrAlign, TrBgColor, TrHeight, TrFontColor, TrFontSize, TrFontBold.ToString().ToLower(), TrFontItalic.ToString().ToLower(),
                              ColumnTrClass, ColumnTrStyle, ColumnTrAlign, ColumnTrBgColor, ColumnTrHeight, ColumnTrFontColor, ColumnTrFontSize, ColumnTrFontBold.ToString().ToLower(), ColumnTrFontItalic.ToString().ToLower()));
            //设置列
            foreach (stuColumns item in Columns)
            {
                str.AppendLine(3, string.Format("treeGrid.InsColumns(\"{0}\", {1}, \"{2}\", \"{3}\", \"{4}\", \"{5}\", \"{6}\", \"{7}\", {8}, {9});", item.Caption, item.Width, item.CssClass, item.Style, item.BgColor, item.Align, item.FontColor, item.FontSize, item.FontBold.ToString().ToLower(), item.FontItalic.ToString().ToLower()));
            }
            //设置行内容
            //str.AppendLine(3, "var iItem;");
            //循环获取所有子节点
            ForColumns(Items, str, false, 0);

            str.AppendLine(3, "treeGrid.GenerateCode();");
            str.AppendLine(3, "treeGrid.RecudeAllTree();");

            str.AppendLine(2, "//-->");
            str.AppendLine(2, "</script>");
            writer.WriteLine(str.Value);
        }

        private int index = 0;
        /// <summary>
        /// 循环列内容
        /// </summary>
        protected void ForColumns(List<csItems> subItems, StringPlus str, bool isSub, int parentID)
        {
            string strItems = string.Empty;
            string caption = string.Empty;
            string links = string.Empty;
            string target = string.Empty;

            foreach (csItems item in subItems)
            {
                //for (int i = item.Target.Count; i < Columns.Count - 1; i++) { item.Target.Add(emTarget._self); }

                //for (int i = item.Align.Count; i < Columns.Count - 1; i++) { item.Align.Add(emAlign.center); }

                //for (int i = item.Caption.Count; i < Columns.Count - 1; i++) { item.Caption.Add(""); }

                //for (int i = item.Links.Count; i < Columns.Count - 1; i++) { item.Links.Add(""); }

                //for (int i = item.CssClass.Count; i < Columns.Count - 1; i++) { item.CssClass.Add(""); }

                //for (int i = item.Style.Count; i < Columns.Count - 1; i++) { item.Style.Add(""); }

                //for (int i = item.BgColor.Count; i < Columns.Count - 1; i++) { item.BgColor.Add(""); }

                //for (int i = item.FontColor.Count; i < Columns.Count - 1; i++) { item.FontColor.Add(""); }

                //for (int i = item.FontSize.Count; i < Columns.Count - 1; i++) { item.FontSize.Add(""); }

                //for (int i = item.FontBold.Count; i < Columns.Count - 1; i++) { item.FontBold.Add(false); }

                //for (int i = item.FontItalic.Count; i < Columns.Count - 1; i++) { item.FontItalic.Add(false); }


                //判断是否有子节点
                strItems = isSub ? string.Format("iItem_{0}", parentID) : "null";

                index++;

                //获取行内容
                str.AppendLine(3, string.Format("var iItem_{0} = treeGrid.InsItems({1}, \"{2}|\", \"{3}|\", \"{4}|\", \"{5}|\", \"{6}|\", \"{7}|\", \"{8}|\", \"{9}|\", \"{10}|\", \"{11}|\", \"{12}|\");"
                    , index, strItems, item.Caption.ToString("|"), item.Links.ToString("|"), item.Target.ToString("|"), item.CssClass.ToString("|"), item.Style.ToString("|"), item.BgColor.ToString("|"), item.Align.ToString("|"), item.FontColor.ToString("|"), item.FontSize.ToString("|"), item.FontBold.ToString("|").ToLower(), item.FontItalic.ToString("|").ToLower()));
                if (item.Items != null) { ForColumns(item.Items, str, true, index); }
            }
        }

        /// <summary>
        /// 添加列
        /// </summary>
        public void AddColumns(string caption, int width, emAlign align, string cssClass, string bgColor, string style)
        {
            if (string.IsNullOrEmpty(caption)) { caption = "&nbsp;"; }
            Columns.Add(new stuColumns() { Align = align, BgColor = bgColor, Caption = caption, CssClass = cssClass, Style = style, Width = width });
        }

        /// <summary>
        /// 添加列
        /// </summary>
        public void AddColumns()
        {
            AddColumns("&nbsp;", 0, ColumnTrAlign, ColumnTrClass, ColumnTrBgColor, ColumnTrStyle);
        }

        /// <summary>
        /// 添加列
        /// </summary>
        public void AddColumns(string caption, int width)
        {
            AddColumns(caption, width, ColumnTrAlign, ColumnTrClass, ColumnTrBgColor, ColumnTrStyle);
        }

        /// <summary>
        /// 添加列
        /// </summary>
        public void AddColumns(string caption, int width, emAlign align)
        {
            AddColumns(caption, width, align, ColumnTrClass, ColumnTrBgColor, ColumnTrStyle);
        }

        /// <summary>
        /// 添加列
        /// </summary>
        public void AddColumns(string caption, int width, string cssClass)
        {
            AddColumns(caption, width, ColumnTrAlign, cssClass, ColumnTrBgColor, ColumnTrStyle);
        }

        /// <summary>
        /// 添加节点
        /// </summary>
        //public void AddItems(string caption, string links, emTarget target, string cssClass, string style, string bgColor, emAlign align, List<csItems> items)
        //{
        //    Items.Add(new csItems() { Caption = caption, Links = links, Target = target, CssClass = cssClass, Style = style, BgColor = bgColor, Align = align, Items = items });
        //}

        ///// <summary>
        ///// 添加节点
        ///// </summary>
        //public void AddItems(string caption, string links, List<csItems> items)
        //{
        //    Items.Add(new csItems() { Caption = caption, Links = links, Items = items });
        //}
    }
}
