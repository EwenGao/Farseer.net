﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using System.Drawing;
using Qyn.Studio.Utils;
using Qyn.Studio.Configs;
using System.IO;


namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    public partial class UpLoadFile : CompositeControl
    {
        /// <summary>
        /// 事件Key
        /// </summary>
        private static readonly object EventUpLoadKey = new object();

        /// <summary>
        /// 上传文件事件
        /// </summary>
        public event EventHandler OnUpLoadFile
        {
            add { Events.AddHandler(EventUpLoadKey, value); }
            remove { Events.RemoveHandler(EventUpLoadKey, value); }
        }

        /// <summary>
        /// 事件Key
        /// </summary>
        private static readonly object EventUpLoadCompleteKey = new object();

        /// <summary>
        /// 上传文件成功事件
        /// </summary>
        public event EventHandler OnUpLoadFileComplete
        {
            add { Events.AddHandler(EventUpLoadCompleteKey, value); }
            remove { Events.RemoveHandler(EventUpLoadCompleteKey, value); }
        }

        /// <summary>
        /// 上传事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnUpLoad(object sender, EventArgs e)
        {
            //获取已注册的事件
            EventHandler uploadHandler = (EventHandler)Events[EventUpLoadKey];

            //外部注册事件时调用
            if (uploadHandler != null)
            {
                //执行外部事件
                uploadHandler(this, e);
            }
            else
            {
                if (IsShowImage && string.IsNullOrEmpty(DoMainUrl)) { lblMessage.Text = "开启图片预览时，请填写图片根"; return; }
                if (string.IsNullOrEmpty(DoMainPath)) { lblMessage.Text = "传入服务器的物理路径不能为空"; return; }
                if (chkIsBuildThumbnail.Checked && pnlThumbnai.Visible)
                {
                    if (txtThumbnailHeight.Text.ConvertType(0) < 1) { lblMessage.Text = "小图高度必需为数字类型，且不能小于0"; return; }
                    if (txtThumbnailWidth.Text.ConvertType(0) < 1) { lblMessage.Text = "小图宽度必需为数字类型，且不能小于0"; return; }
                }
                if (chkIsZipped.Checked && pnlZipped.Visible)
                {
                    if (txtZippedHeight.Text.ConvertType(0) < 1) { lblMessage.Text = "压缩图片高度必需为数字类型，且不能小于0"; return; }
                    if (txtZippedWidth.Text.ConvertType(0) < 1) { lblMessage.Text = "压缩图片宽度必需为数字类型，且不能小于0"; return; }
                }
                Qyn.Studio.Tools.UpLoadFile uploadFile = new Qyn.Studio.Tools.UpLoadFile();
                Qyn.Studio.Tools.UpLoadFile.stuUpLoadFile result = uploadFile.Upload(file.PostedFile, Path.Combine(DoMainPath, FilePath), SaveType, UpLoadFileTypeList);

                lblMessage.Text = uploadFile.ErrorMessage;

                if (string.IsNullOrEmpty(lblMessage.Text))
                {
                    SavePath = result.FilePath + result.FileName;
                    
                    //生成缩略图
                    if (chkIsBuildThumbnail.Checked && pnlThumbnai.Visible)
                    {
                        SaveThumbnailPath = result.FileName.Substring(0, result.FileName.LastIndexOf(".")) + "_" + result.FileName.Substring(result.FileName.LastIndexOf("."));
                        SaveThumbnailPath = result.FilePath + SaveThumbnailPath;

                        ParseThumbnail.MakeThumbnailImage(SavePath, SaveThumbnailPath, txtThumbnailWidth.Text.ConvertType(0), txtThumbnailHeight.Text.ConvertType(0));
                        SaveThumbnailPath = SaveThumbnailPath.ClearString(ParseFile.ConvertPath(DoMainPath));
                    }

                    //压缩图片
                    if (chkIsZipped.Checked && pnlZipped.Visible)
                    {
                        ParseThumbnail.MakeThumbnailImage(SavePath, SavePath, txtZippedWidth.Text.ConvertType(0), txtZippedHeight.Text.ConvertType(0));
                    }

                    SavePath = SavePath.ClearString(ParseFile.ConvertPath(DoMainPath));
                    

                    //获取已注册的事件
                    EventHandler upLoadCompleteHandler = (EventHandler)Events[EventUpLoadCompleteKey];
                    if (upLoadCompleteHandler != null)
                    {
                        //执行外部事件
                        upLoadCompleteHandler(this, e);
                    }
                }

            }
        }

        /// <summary>
        /// 冒泡事件
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected override bool OnBubbleEvent(object source, EventArgs e)
        {
            bool handled = false;
            if (e is CommandEventArgs)
            {
                CommandEventArgs ce = (CommandEventArgs)e;
                if (ce.CommandName == "OnUpLoad")
                {
                    OnUpLoad(source, EventArgs.Empty);
                    handled = true;
                }
                else if (ce.CommandName == "btnReturn")
                {
                    lblMessage.Text = "";
                    handled = true;
                }
            }
            return handled;
        }
    }
}
