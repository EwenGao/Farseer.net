﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using System.Drawing;
using Qyn.Studio.Utils;
using Qyn.Studio.Configs;
using System.IO;


namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    public partial class UpLoadFile : CompositeControl
    {
        /// <summary>
        /// 文件上传后，保存的路径
        /// </summary>
        public TextBox txtFilePath { get; set; }
        /// <summary>
        /// 文件上传控件
        /// </summary>
        public FileUpload file { get; set; }
        /// <summary>
        /// 图片显示控件
        /// </summary>
        public System.Web.UI.WebControls.Image img { get; set; }
        /// <summary>
        /// 上传按扭
        /// </summary>
        public Button btnUpLoad { get; set; }

        /// <summary>
        /// 提示信息
        /// </summary>
        public Label lblMessage { get; set; }

        /// <summary>
        /// 是否启用生成缩略图
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue("false"),
        Description("是否启用生成缩略图"),
        Browsable(true)
        ]
        public bool IsShowThumbnail { get { return pnlThumbnai.Visible; } set { pnlThumbnai.Visible = value; } }
        public CheckBox chkIsBuildThumbnail { get; set; }
        public Label lblThumbnailWidth { get; set; }
        public TextBox txtThumbnailWidth { get; set; }
        public Label lblThumbnailHeight { get; set; }
        public TextBox txtThumbnailHeight { get; set; }
        public Panel pnlThumbnai { get; set; }

        /// <summary>
        /// 是否启用压缩
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue("false"),
        Description("是否启用压缩"),
        Browsable(true)
        ]
        public bool IsShowZipped { get { return pnlZipped.Visible; } set { pnlZipped.Visible = value; } }
        public CheckBox chkIsZipped { get; set; }
        public Label lblZippedWidth { get; set; }
        public TextBox txtZippedWidth { get; set; }
        public Label lblZippedHeight { get; set; }
        public TextBox txtZippedHeight { get; set; }
        public Panel pnlZipped { get; set; }

        /// <summary>
        /// 初始化
        /// </summary>
        public UpLoadFile()
        {
            EnsureChildControls();
            DoMainUrl = SysPathConfigs.ConfigInfo.DoMainUrl;
            DoMainPath = SysPathConfigs.ConfigInfo.DoMainPath;
            FilePath = SysPathConfigs.ConfigInfo.UpLoadFilePath;
            
        }

        #region Div
        #region Height
        private string divHeight = string.Empty;
        /// <summary>
        /// Div高度
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div高度"),
        Browsable(true)
        ]
        public string DivHeight
        {
            get { return divHeight; }
            set { divHeight = value; }
        }
        #endregion

        #region Width
        private string divWidth = string.Empty;
        /// <summary>
        /// Div宽度
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div宽度"),
        Browsable(true)
        ]
        public string DivWidth
        {
            get { return divWidth; }
            set { divWidth = value; }
        }
        #endregion

        #region Color
        private string divColor = string.Empty;
        /// <summary>
        /// Div前景色
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div前景色"),
        Browsable(true)
        ]
        public string DivColor
        {
            get { return divColor; }
            set { divColor = value; }
        }
        #endregion

        #region BackgroundColor
        private string divBackgroundColor = string.Empty;
        /// <summary>
        /// Div背景色
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div背景色"),
        Browsable(true)
        ]
        public string DivBackgroundColor
        {
            get { return divBackgroundColor; }
            set { divBackgroundColor = value; }
        }
        #endregion

        #region BorderWidth
        private string divBorderWidth = string.Empty;
        /// <summary>
        /// Div边框宽度
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div边框宽度"),
        Browsable(true)
        ]
        public string DivBorderWidth
        {
            get { return divBorderWidth; }
            set { divBorderWidth = value; }
        }
        #endregion

        #region FontSize
        private string divFontSize = string.Empty;
        /// <summary>
        /// Div字体大小
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div字体大小"),
        Browsable(true)
        ]
        public string DivFontSize
        {
            get { return divFontSize; }
            set { divFontSize = value; }
        }
        #endregion

        #region FontFamily
        private string divFontFamily = string.Empty;
        /// <summary>
        /// Div字体样式
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div字体样式"),
        Browsable(true)
        ]
        public string DivFontFamily
        {
            get { return divFontFamily; }
            set { divFontFamily = value; }
        }
        #endregion

        #region Class
        private string divClass = string.Empty;
        /// <summary>
        /// DivClassName
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivClassName"),
        Browsable(true)
        ]
        public string DivClass
        {
            get { return divClass; }
            set { divClass = value; }
        }
        #endregion

        #region Style
        private string divStyle = string.Empty;
        /// <summary>
        /// DivStyle
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivStyle"),
        Browsable(true)
        ]
        public string DivStyle
        {
            get { return divStyle; }
            set { divStyle = value; }
        }
        #endregion

        #region ID
        private string divID = string.Empty;
        /// <summary>
        /// DivID
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivID"),
        Browsable(true)
        ]
        public string DivID
        {
            get { return divID; }
            set { divID = value; }
        }
        #endregion

        #region Name
        private string divName = string.Empty;
        /// <summary>
        /// DivName
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivName"),
        Browsable(true)
        ]
        public string DivName
        {
            get { return divName; }
            set { divName = value; }
        }
        #endregion
        #endregion

        /// <summary>
        /// 保存到数据库的缩略图路径
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("保存到数据库的缩略图路径"),
        Browsable(true)
        ]
        public string SaveThumbnailPath 
        {
            get { return ViewState["SaveThumbnailPath"].ToString(); }
            set { ViewState["SaveThumbnailPath"] = value; }
        }

        /// <summary>
        /// 保存到数据库的路径
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("保存到数据库的路径"),
        Browsable(true)
        ]
        public string SavePath
        {
            get { return txtFilePath.Text; }
            set { txtFilePath.Text = value; }
        }

        /// <summary>
        /// 图片显示根
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("图片显示根"),
        Browsable(true)
        ]
        public string DoMainUrl { get; set; }

        /// <summary>
        /// 传入服务器的物理路径
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("传入服务器的物理路径"),
        Browsable(true)
        ]
        public string DoMainPath { get; set; }

        /// <summary>
        /// 传入服务器的根文件夹
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("传入服务器的根文件夹"),
        Browsable(true)
        ]
        public string FilePath { get; set; }

        /// <summary>
        /// 是否显示图片预览
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("是否显示图片预览"),
        Browsable(true)
        ]
        public bool IsShowImage
        {
            get { return img.Visible; }
            set { img.Visible = value; }
        }

        /// <summary>
        /// 是否显示图片预览
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("是否显示图片预览"),
        Browsable(true)
        ]
        public bool IsShowFilePath
        {
            get { return txtFilePath.Visible; }
            set { txtFilePath.Visible = value; }
        }

        /// <summary>
        /// 保存方式
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("保存方式"),
        Browsable(true)
        ]
        public Qyn.Studio.Tools.UpLoadFile.SaveType SaveType { get; set; }

        /// <summary>
        /// 上传的文件权限
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("上传的文件权限"),
        Browsable(true)
        ]
        public List<Qyn.Studio.Tools.UpLoadFile.stuUpLoadFileType> UpLoadFileTypeList { get; set; }
    }
}
