﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using System.Drawing;
using Qyn.Studio.Utils;
using Qyn.Studio.Configs;
using System.IO;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    [
     DefaultProperty("PageSize"),
     ToolboxData("<{0}:UpLoadFile runat=server />")
    ]
    public partial class UpLoadFile : CompositeControl
    {

        /// <summary>
        /// 输出控件视图
        /// </summary>
        /// <param name="writer"></param>
        protected override void RenderContents(HtmlTextWriter writer)
        {
            img.ImageUrl = DoMainUrl + SavePath;        //显示图片

            if (!string.IsNullOrEmpty(DivWidth)) { writer.AddStyleAttribute(HtmlTextWriterStyle.Width, DivWidth); }
            if (!string.IsNullOrEmpty(DivHeight)) { writer.AddStyleAttribute(HtmlTextWriterStyle.Height, DivHeight); }
            if (!string.IsNullOrEmpty(DivColor)) { writer.AddStyleAttribute(HtmlTextWriterStyle.Color, DivColor); }
            if (!string.IsNullOrEmpty(DivBackgroundColor)) { writer.AddStyleAttribute(HtmlTextWriterStyle.BackgroundColor, DivBackgroundColor); }
            if (!string.IsNullOrEmpty(DivBorderWidth)) { writer.AddStyleAttribute(HtmlTextWriterStyle.BorderWidth, DivBorderWidth); }
            if (!string.IsNullOrEmpty(DivFontSize)) { writer.AddStyleAttribute(HtmlTextWriterStyle.FontSize, DivFontSize); }
            if (!string.IsNullOrEmpty(DivFontFamily)) { writer.AddStyleAttribute(HtmlTextWriterStyle.FontFamily, DivFontFamily); }

            if (!string.IsNullOrEmpty(DivStyle)) { writer.AddAttribute(HtmlTextWriterAttribute.Style, DivStyle); }
            if (!string.IsNullOrEmpty(DivID)) { writer.AddAttribute(HtmlTextWriterAttribute.Id, DivID); }
            if (!string.IsNullOrEmpty(DivName)) { writer.AddAttribute(HtmlTextWriterAttribute.Name, DivName); }
            if (!string.IsNullOrEmpty(DivClass)) { writer.AddAttribute(HtmlTextWriterAttribute.Class, DivClass); }

            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            if (pnlThumbnai.Visible)
            {
                pnlThumbnai.RenderControl(writer);
            }
            if (pnlZipped.Visible)
            {
                pnlZipped.RenderControl(writer);
            }
            txtFilePath.RenderControl(writer);
            file.RenderControl(writer);
            if (img.Visible)
            {
                img.RenderControl(writer);
            }
            btnUpLoad.RenderControl(writer);

            if (!string.IsNullOrEmpty(lblMessage.Text)) { lblMessage.RenderControl(writer); }

            writer.RenderEndTag();
        }

        /// <summary>
        /// 初始化控件
        /// </summary>
        protected override void CreateChildControls()
        {
            Controls.Clear();

            #region 生成缩略图
            pnlThumbnai = new Panel();
            pnlThumbnai.ID = "pnlThumbnai";
            Controls.Add(pnlThumbnai);

            chkIsBuildThumbnail = new CheckBox();
            chkIsBuildThumbnail.ID = "chkIsBuildThumbnail";
            chkIsBuildThumbnail.Text = "生成小图";
            pnlThumbnai.Controls.Add(chkIsBuildThumbnail);

            lblThumbnailWidth = new Label();
            lblThumbnailWidth.ID = "lblThumbnailWidth";
            lblThumbnailWidth.Text = "   宽度：";
            pnlThumbnai.Controls.Add(lblThumbnailWidth);

            txtThumbnailWidth = new TextBox();
            txtThumbnailWidth.ID = "txtThumbnailWidth";
            txtThumbnailWidth.Text = "0";
            txtThumbnailWidth.Width = 40;
            pnlThumbnai.Controls.Add(txtThumbnailWidth);

            lblThumbnailHeight = new Label();
            lblThumbnailHeight.ID = "lblThumbnailHeight";
            lblThumbnailHeight.Text = "   高度：";
            pnlThumbnai.Controls.Add(lblThumbnailHeight);

            txtThumbnailHeight = new TextBox();
            txtThumbnailHeight.ID = "txtThumbnailHeight";
            txtThumbnailHeight.Text = "0";
            txtThumbnailHeight.Width = 40;
            pnlThumbnai.Controls.Add(txtThumbnailHeight);

            #endregion

            pnlZipped = new Panel();
            pnlZipped.ID = "pnlZipped";
            Controls.Add(pnlZipped);

            chkIsZipped = new CheckBox();
            chkIsZipped.ID = "chkIsZipped";
            chkIsZipped.Text = "压缩图片";
            pnlZipped.Controls.Add(chkIsZipped);

            lblZippedWidth = new Label();
            lblZippedWidth.ID = "lblZippedWidth";
            lblZippedWidth.Text = "   宽度：";
            pnlZipped.Controls.Add(lblZippedWidth);

            txtZippedWidth = new TextBox();
            txtZippedWidth.ID = "txtZippedWidth";
            txtZippedWidth.Text = "0";
            txtZippedWidth.Width = 40;
            pnlZipped.Controls.Add(txtZippedWidth);

            lblZippedHeight = new Label();
            lblZippedHeight.ID = "lblZippedHeight";
            lblZippedHeight.Text = "   高度：";
            pnlZipped.Controls.Add(lblZippedHeight);

            txtZippedHeight = new TextBox();
            txtZippedHeight.ID = "txtZippedHeight";
            txtZippedHeight.Text = "0";
            txtZippedHeight.Width = 40;
            pnlZipped.Controls.Add(txtZippedHeight);

            txtFilePath = new TextBox();
            txtFilePath.ID = "txtSavePath";
            txtFilePath.Width = 250;
            Controls.Add(txtFilePath);

            file = new FileUpload();
            file.ID = "filePath";
            Controls.Add(file);

            img = new System.Web.UI.WebControls.Image();
            img.ID = "imgPath";
            Controls.Add(img);

            btnUpLoad = new Button();
            btnUpLoad.ID = "btnUpLoad";
            btnUpLoad.Text = "上传";
            btnUpLoad.CommandName = "OnUpLoad";
            Controls.Add(btnUpLoad);

            lblMessage = new Label();
            lblMessage.ID = "lblMessage";
            Controls.Add(lblMessage);

            //告诉编译器，控件已经初始化了
            ChildControlsCreated = true;


        }

       
    }
}