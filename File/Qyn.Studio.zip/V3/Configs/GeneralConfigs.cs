﻿using System;
using Qyn.Config;
using System.Windows.Forms;
using System.IO;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 全局
    /// </summary>
    public class GeneralConfigs : DefaultConfigFileManager<GeneralConfig>
    {
        /// <summary> 
        /// 刷新计时器
        /// </summary>
        private static System.Timers.Timer m_GeneralConfigTimer;

        /// <summary>
        /// 配置变量
        /// </summary>
        private static GeneralConfig m_ConfigInfo;

        /// <summary>
        /// Config修改时间
        /// </summary>
        public static DateTime FileOldChange;

        /// <summary>
        /// 配置变量
        /// </summary>
        public static GeneralConfig ConfigInfo
        {
            get
            {
                if (m_ConfigInfo == null) { ResetConfig(); }
                return m_ConfigInfo;
            }
        }

        /// <summary>
        /// 静态构造函数初始化相应实例和定时器
        /// </summary>
        static GeneralConfigs()
        {
            m_GeneralConfigTimer = new System.Timers.Timer();
            m_GeneralConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);            //委托Timer_Elapsed事件          //读取Config文件.
            AutoResetOpen(true, 1);
            ResetConfig();
        }

        /// <summary>
        /// Timer_Elapsed
        /// </summary>
        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }

        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            m_ConfigInfo = LoadConfig(new GeneralConfig(), ref FileOldChange, true);
        }

        /// <summary>
        /// 保存配置实例
        /// </summary>
        public static bool SaveConfig(GeneralConfig GeneralConfig)
        {
            bool result = Serializable(GeneralConfig);
            ResetConfig();
            return result;
        }

        /// <summary>
        /// 开启自动检测Config
        /// </summary>
        /// <param name="isOpen">true：开启,false:关闭</param>
        /// <param name="time">单位：分</param>
        public static void AutoResetOpen(bool isOpen, int time)
        {
            time = time * 1000 * 60;
            if (isOpen)
            {
                m_GeneralConfigTimer = new System.Timers.Timer(time);
                m_GeneralConfigTimer.AutoReset = true;                                                           //连续运行Time
                m_GeneralConfigTimer.Enabled = true;                                                             //激活事件
                m_GeneralConfigTimer.Start();
            }
            else
            {
                if (m_GeneralConfigTimer != null)
                {
                    m_GeneralConfigTimer.AutoReset = false;
                    m_GeneralConfigTimer.Enabled = false;
                    m_GeneralConfigTimer.Close();
                }
            }
        }

    }
}
