﻿using System;
using Qyn.Config;
using System.Windows.Forms;
using System.IO;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 全局
    /// </summary>
    public class SessionConfigs : DefaultConfigFileManager<SessionConfig>
    {
        /// <summary> 
        /// 刷新计时器
        /// </summary>
        private static System.Timers.Timer m_SessionConfigTimer;

        /// <summary>
        /// 配置变量
        /// </summary>
        private static SessionConfig m_ConfigInfo;

        /// <summary>
        /// Config修改时间
        /// </summary>
        public static DateTime FileOldChange;

        /// <summary>
        /// 配置变量
        /// </summary>
        public static SessionConfig ConfigInfo
        {
            get
            {
                if (m_ConfigInfo == null || GeneralConfigs.ConfigInfo.DeBug) { ResetConfig(); }
                return m_ConfigInfo;
            }
        }

        /// <summary>
        /// 静态构造函数初始化相应实例和定时器
        /// </summary>
        static SessionConfigs()
        {
            m_SessionConfigTimer = new System.Timers.Timer();
            m_SessionConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);   //委托Timer_Elapsed事件    //读取Config文件.
            AutoResetOpen(true, 1);
            ResetConfig();
        }

        /// <summary>
        /// Timer_Elapsed
        /// </summary>
        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }

        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            m_ConfigInfo = LoadConfig(new SessionConfig(), ref FileOldChange, true);
        }

        /// <summary>
        /// 保存配置实例
        /// </summary>
        public static bool SaveConfig(SessionConfig SessionConfig)
        {
            bool result = Serializable(SessionConfig);
            ResetConfig();
            return result;
        }

        /// <summary>
        /// 开启自动检测Config
        /// </summary>
        /// <param name="isOpen">true：开启,false:关闭</param>
        /// <param name="time">单位：分</param>
        public static void AutoResetOpen(bool isOpen, int time)
        {
            time = time * 1000 * 60;
            if (isOpen)
            {
                m_SessionConfigTimer = new System.Timers.Timer(time);
                m_SessionConfigTimer.AutoReset = true;                                                           //连续运行Time
                m_SessionConfigTimer.Enabled = true;                                                             //激活事件
                m_SessionConfigTimer.Start();
            }
            else
            {
                if (m_SessionConfigTimer != null)
                {
                    m_SessionConfigTimer.AutoReset = false;
                    m_SessionConfigTimer.Enabled = false;
                    m_SessionConfigTimer.Close();
                }
            }
        }

    }
}
