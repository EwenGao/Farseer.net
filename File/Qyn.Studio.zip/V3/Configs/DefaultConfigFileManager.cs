﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Text;
using System.Web;

using Qyn.Studio.Utils;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Configs
{

    /// <summary>
    /// 文件配置管理基类
    /// </summary>
    public class DefaultConfigFileManager<T>
    {
        /// <summary>
        /// 锁对象
        /// </summary>
        private static object m_LockHelper = new object();

        /// <summary>
        /// 加载(反序列化)指定对象类型的配置对象
        /// </summary>
        /// <param name="t">实体类</param>
        /// <param name="fileOldChange">文件使用时间</param>
        /// <param name="checkTime">是否检查并更新传递进来的"文件加载时间"变量</param>
        protected static T LoadConfig(T t ,ref DateTime fileOldChange, bool checkTime)
        {
            //不存在自直接创建
            if (!File.Exists(FilePath())) 
            { 
                Serializable(t);
                fileOldChange = DateTime.Now;
                return t;
            }

            if (checkTime) { fileOldChange = File.GetLastWriteTime(FilePath()); }

            lock (m_LockHelper) {return SerializationHelper<T>.Load(t, FilePath()); }

        }

        /// <summary>
        /// 保存(序列化)指定路径下的配置文件
        /// </summary>
        protected static bool Serializable(T t)
        {
            return SerializationHelper<T>.Save(t, FilePath());
        }

        /// <summary>
        /// 获取配置文件所在路径
        /// </summary>
        protected static string FilePath()
        {
            string fileName = string.Format("{0}.config", typeof(T).Name.EndsWith("Config", true, null) ? typeof(T).Name.Substring(0,typeof(T).Name.Length - 6): typeof(T).Name);

            if (HttpContext.Current != null) { fileName = HttpContext.Current.Server.MapPath("~/App_Data/" + fileName); }
            else { fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data/" + fileName); }

            return ParseFile.ConvertPath(fileName);
        }

    }
}
