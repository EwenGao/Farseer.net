﻿using System;
using System.Windows.Forms;
using System.IO;
using Qyn.Config;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 全局
    /// </summary>
    public class CookiesConfigs : DefaultConfigFileManager<CookiesConfig>
    {
        /// <summary> 
        /// 刷新计时器
        /// </summary>
        private static System.Timers.Timer m_CookiesConfigTimer;

        /// <summary>
        /// 配置变量
        /// </summary>
        private static CookiesConfig m_ConfigInfo;

        /// <summary>
        /// Config修改时间
        /// </summary>
        public static DateTime FileOldChange;

        /// <summary>
        /// 配置变量
        /// </summary>
        public static CookiesConfig ConfigInfo
        {
            get
            {
                if (m_ConfigInfo == null || GeneralConfigs.ConfigInfo.DeBug) { ResetConfig(); }
                return m_ConfigInfo;
            }
        }

        /// <summary>
        /// 静态构造函数初始化相应实例和定时器
        /// </summary>
        static CookiesConfigs()
        {
            m_CookiesConfigTimer = new System.Timers.Timer();
            m_CookiesConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);            //委托Timer_Elapsed事件          //读取Config文件.
            AutoResetOpen(true, 1);
            ResetConfig();
        }

        /// <summary>
        /// Timer_Elapsed
        /// </summary>
        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }

        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            m_ConfigInfo = LoadConfig(new CookiesConfig(), ref FileOldChange, true);
        }

        /// <summary>
        /// 保存配置实例
        /// </summary>
        public static bool SaveConfig(CookiesConfig CookiesConfig)
        {
            bool result = Serializable(CookiesConfig);
            ResetConfig();
            return result;
        }

        /// <summary>
        /// 开启自动检测Config
        /// </summary>
        /// <param name="isOpen">true：开启,false:关闭</param>
        /// <param name="time">单位：分</param>
        public static void AutoResetOpen(bool isOpen, int time)
        {
            time = time * 1000 * 60;
            if (isOpen)
            {
                m_CookiesConfigTimer = new System.Timers.Timer(time);
                m_CookiesConfigTimer.AutoReset = true;                                                           //连续运行Time
                m_CookiesConfigTimer.Enabled = true;                                                             //激活事件
                m_CookiesConfigTimer.Start();
            }
            else
            {
                if (m_CookiesConfigTimer != null)
                {
                    m_CookiesConfigTimer.AutoReset = false;
                    m_CookiesConfigTimer.Enabled = false;
                    m_CookiesConfigTimer.Close();
                }
            }
        }

    }
}
