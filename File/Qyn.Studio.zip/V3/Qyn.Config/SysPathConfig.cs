﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Config
{
    /// <summary>
    /// 系统所有路径定义
    /// </summary>
    [Serializable]
    public class SysPathConfig
    {
        /// <summary>
        /// 网站平台根目录
        /// </summary>
        public string WebPath = "/";

        /// <summary>
        /// 网站登陆页面
        /// </summary>
        public string WebLoginUrl = "/Login.aspx";

        /// <summary>
        /// 网站退出页面
        /// </summary>
        public string WebLogoutUrl = "/Logout.ashx";



        /// <summary>
        /// 管理平台根目录
        /// </summary>
        public string AdminPath = "/Admin/";

        /// <summary>
        /// 管理员登陆页面
        /// </summary>
        public string AdminLoginUrl = "/Admin/Login.aspx";

        /// <summary>
        /// 管理员退出页面
        /// </summary>
        public string AdminLogoutUrl = "/Admin/Logout.ashx";


        /// <summary>
        /// 友情链接上传的路径
        /// </summary>
        public string LinkFilePath = "UpLoadFiles/LinkFile/";

        /// <summary>
        /// 文件上传的路径
        /// </summary>
        public string UpLoadFilePath = "UpLoad/UpLoadFile/";

        /// <summary>
        /// 证书上传的路径
        /// </summary>
        public string MineLicenseFilePath = "UpLoad/MineLicenseFile/";

        /// <summary>
        /// 专题上传的路径
        /// </summary>
        public string SpecialFilePath = "UpLoad/SpecialFile/";

        /// <summary>
        /// 企业上传的路径
        /// </summary>
        public string EnterprisePath = "UpLoad/EnterprisePath/";

        /// <summary>
        /// 广告上传的路径
        /// </summary>
        public string AdvertiseFilePath = "UpLoad/AdvertiseFile/";

        /// <summary>
        /// 周刊上传的路径
        /// </summary>
        public string WeeklyFilePath = "UpLoad/Weekly/";

        /// <summary>
        /// 文件上传根目录
        /// </summary>
        public string DoMainPath = "E:/MyCode/qqkqw/qqkqw.V3/WebSite/File/";

        /// <summary>
        /// 文件上传根URL
        /// </summary>
        public string DoMainUrl = "http://file.qqkqw.com/";
    }
}
