﻿using System;

namespace Qyn.Config
{
	/// <summary>
	/// Cookies Key
	/// </summary>
	[Serializable]
    public class CookiesConfig
    {
        #region 用户Cookies
        /// <summary>
        /// 用户ID
        /// </summary>
        public string UserID = "UserID";

        /// <summary>
        /// 用户名
        /// </summary>
        public string UserName = "UserName";

        /// <summary>
        /// 用户在线超时时间
        /// </summary>
        public int UserTimeOut = 20;

        /// <summary>
        /// 用户组ID
        /// </summary>
        public string UserRoleID = "UserGroupID";

        /// <summary>
        /// VIP组ID
        /// </summary>
        public string VipRoleID = "VipRoleID";
        #endregion

        #region 管理员Cookies
        /// <summary>
        /// 管理员ID的Cookies
        /// </summary>
        public string AdminID = "AdminID";

        /// <summary>
        /// 管理员名称的Cookies
        /// </summary>
        public string AdminName = "AdminName";

        /// <summary>
        /// 管理员组ID
        /// </summary>
        public string AdminGroupID = "AdminGroupID";

        /// <summary>
        /// 管理员组名称
        /// </summary>
        public string AdminGroupName = "AdminGroupName";

        /// <summary>
        /// 权限字符串
        /// </summary>
        public string AdminPurview = "AdminPurview";

        /// <summary>
        /// 管理员在线超时时间
        /// </summary>
        public int AdminTimeOut = 40;

        /// <summary>
        /// 管理员后台主题
        /// </summary>
        public string AdminThemes = "AdminDefaultTheme";
        #endregion
    }
}
