﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Config.General
{
    /// <summary>
    /// 枚举字典
    /// </summary>
   public class EnumGeneral
   {
       public static Dictionary<string, string> dicEmun;

       static EnumGeneral()
       {
           dicEmun = new Dictionary<string, string>();
           dicEmun.Add("None", "没有");
           dicEmun.Add("OnlyMe", "仅仅是我");
           dicEmun.Add("All", "所有");
           dicEmun.Add("OnlyMeUnaudited", "仅仅是我（未审核）");
           dicEmun.Add("OnlyMeAudited", "仅仅是我（已审核）");
           dicEmun.Add("AllUnaudited", "所有（未审核）");
           dicEmun.Add("AllAudited", "所有（已审核）");
           dicEmun.Add("common", "普通会员");
           dicEmun.Add("vip", "Vip会员");
           dicEmun.Add("gold", "黄金会员");
           dicEmun.Add("platina", "白金会员");
           dicEmun.Add("diamond", "钻石会员");
           dicEmun.Add("Article", "文章");
           dicEmun.Add("Mine", "矿权");
           dicEmun.Add("Login", "登陆");
           dicEmun.Add("Exit", "退出");
           dicEmun.Add("Add", "增加");
           dicEmun.Add("Edit", "修改");
           dicEmun.Add("Delete", "删除");
           

       }

       /// <summary>
       /// 获取枚举对应的中文
       /// </summary>
       public static string GetName(string key)
       {
           if (EnumGeneral.dicEmun.ContainsKey(key)) { return EnumGeneral.dicEmun[key]; }
           return key;
       }
   }
}
