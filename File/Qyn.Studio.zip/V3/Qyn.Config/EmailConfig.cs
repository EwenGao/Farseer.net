﻿using System;
using System.Collections.Generic;

namespace Qyn.Config
{
    /// <summary>
    /// Email配置信息类
    /// </summary>
    [Serializable]
    public class EmailConfig
    {
        public List<EmailList> EmailList= new List<EmailList>();
    }

    public class EmailList
    {
        /// <summary>
        /// 发件人姓名
        /// </summary>
        public string SendUserName = "";

        /// <summary>
        /// 发件人E-Mail地址
        /// </summary>
        public string SendMail = "";

        /// <summary>
        /// 登陆用户名
        /// </summary>
        public string LoginName = "";

        /// <summary>
        /// 登陆密码
        /// </summary>
        public string LoginPwd = "";

        /// <summary>
        /// 端口号
        /// </summary>
        public int Port = 25;

        /// <summary>
        /// 邮件服务器域名和验证信息
        /// 形如：Smtp.server.com"
        /// </summary>	
        public string MailDomain = "";

        /// <summary>
        /// 最多收件人数量
        /// </summary>
        public int RecipientMaxNum = 5;

        /// <summary>
        /// 是否Html邮件
        /// </summary>		
        public bool IsHtml = false;
    }
}
