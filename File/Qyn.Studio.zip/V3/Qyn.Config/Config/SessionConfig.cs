﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Config
{
    /// <summary>
    /// Session Key
    /// </summary>
    [Serializable]
    public class SessionConfig
    {
        /// <summary>
        /// 用户登陆验证码的Session
        /// </summary>
        public string UserVerifyCode = "UserCode";

        /// <summary>
        /// 管理员登陆验证码的Session
        /// </summary>
        public string AdminVerifyCode = "AdminCode";
    }
}
