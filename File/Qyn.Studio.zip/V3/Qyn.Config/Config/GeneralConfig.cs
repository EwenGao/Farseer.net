﻿using System;

namespace Qyn.Config
{
	/// <summary>
	/// 网站基本设置描述类, 加[Serializable]标记为可序列化
	/// </summary>
	[Serializable]
    public class GeneralConfig
    {
        /// <summary>
        /// 是否调试
        /// </summary>
        public bool DeBug = true;

        /// <summary>
        /// 网站标题
        /// </summary>
        public string WebTitle = "全球矿权网";
    }
}
