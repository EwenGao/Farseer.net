﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Config
{
    /// <summary>
    /// 系统所有路径定义
    /// </summary>
    [Serializable]
    public class SysPathConfig
    {
        /// <summary>
        /// 网站路径(相对于IIS根目录)
        /// </summary>
        public string WebSitePath = "/";

        /// <summary>
        /// 管理平台根目录
        /// </summary>
        public string AdminPath = "Admin/";

        /// <summary>
        /// 管理员登陆入口页面
        /// </summary>
        public string AdminLoginUrl = "Login.aspx";

        /// <summary>
        /// 证书上传的路径
        /// </summary>
        public string MineLicenseFilePath = "MineLicense/";

        /// <summary>
        /// 文件上传路径
        /// </summary>
        public string UploadFilePath = "E:/MyCode/qqkqw/qqkqw.V3/Qyn.Page/File/";

        /// <summary>
        /// 文件站点
        /// </summary>
        public string DomainFile = "http://localhost:8802/";
    }
}
