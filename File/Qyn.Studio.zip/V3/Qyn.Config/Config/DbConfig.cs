﻿using System;

namespace Qyn.Config
{
    /// <summary>
    /// 默认数据库路径
    /// </summary>
    [Serializable]
    public class DbConfig
    {
        public DbList[] DataBaseList = { new DbList() };

        public DbConfig()
        {
        }
    }

    public class DbList
    {
        /// <summary>
        /// 数据库连接串
        /// </summary>
        public string Server = ".";

        /// <summary>
        /// 数据库帐号
        /// </summary>
        public string UserID = "sa";

        /// <summary>
        /// 数据库密码
        /// </summary>
        public string PassWord = "123456";

        /// <summary>
        /// 数据库类型
        /// </summary>
        public string Type = "SqlServer";

        /// <summary>
        /// 数据库版本
        /// </summary>
        public string Ver = "2005";

        /// <summary>
        /// 数据库目录
        /// </summary>
        public string Catalog = "";

        /// <summary>
        /// 数据库表前缀
        /// </summary>
        public string TablePrefix = "";
    }
}
