﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// DataRow扩展工具
    /// </summary>
    public static class DataRowExtend
    {
        /// <summary>
        /// 将DataRowCollection转成List[DataRow]
        /// </summary>
        /// <param name="drc">DataRowCollection</param>
        /// <returns></returns>
        public static List<DataRow> ToRows(this DataRowCollection drc)
        {
            List<DataRow> lstRow = new List<DataRow>();

            if (drc == null) { return lstRow; }

            foreach (DataRow dr in drc)
            {
                lstRow.Add(dr);
            }

            return lstRow;
        }

        /// <summary>
        /// 将DataRowCollection转成实体类
        /// </summary>
        /// <typeparam name="T">实体类</typeparam>
        /// <param name="drc">DataRowCollection</param>
        /// <returns></returns>
        public static T ToInfo<T>(this DataRowCollection drc)
        {
            Type ht = typeof(T);
            return (T)Activator.CreateInstance(ht, drc);
        }

        /// <summary>
        /// 将DataRow转成实体类
        /// </summary>
        /// <typeparam name="T">实体类</typeparam>
        /// <param name="dr">DataRow</param>
        /// <returns></returns>
        public static T ToInfo<T>(this DataRow dr)
        {
            Type ht = typeof(T);
            return  (T)Activator.CreateInstance(ht, dr);
        }
    }
}
