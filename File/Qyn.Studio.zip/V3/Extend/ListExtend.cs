﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.Utils;
using System.Collections;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// List扩展工具
    /// </summary>
    public static class ListExtend
    {
        /// <summary>
        /// 将List转换成字符串
        /// </summary>
        /// <param name="lst">要拼接的LIST</param>
        /// <param name="sign">分隔符</param>
        /// <returns></returns>
        public static string ToString(this IList lst,string sign)
        {
            return ParseList.ToString(lst, sign);
        }
    }
}
