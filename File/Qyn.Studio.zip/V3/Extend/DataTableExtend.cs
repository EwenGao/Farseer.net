﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using Qyn.Studio.Utils;
using System.Reflection;
using Qyn.Studio.Base;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// DataTable扩展工具
    /// </summary>
    public static class DataTableExtend
    {
        /// <summary>
        /// 对DataTable排序
        /// </summary>
        /// <param name="dt">要排序的表</param>
        /// <param name="sort">要排序的字段</param>
        public static DataTable Sort(this DataTable dt, string sort)
        {
            return ParseDataTable.Sort(dt, sort);
        }

        /// <summary>
        /// 返回已分页的表
        /// </summary>
        /// <param name="dt">源表</param>
        /// <param name="pageSize">每页显示的记录数</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static DataTable Pagination(this DataTable dt, int pageSize, int pageIndex)
        {
            return ParseDataTable.Pagination(dt, pageSize, pageIndex);
        }

        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(this DataTable dt)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            foreach (DataRow dr in dt.Rows)
            {
                object obj = Activator.CreateInstance(ht, dr);
                list.Add((T)obj);
            }
            dt.Dispose();
            return list;
        }

        /// <summary>
        /// 倒序
        /// </summary>
        public static DataTable Reverse(this DataTable dt)
        {
            return ParseDataTable.Reverse(dt);
        }
    }
}
