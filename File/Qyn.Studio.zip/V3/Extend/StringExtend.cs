﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// String扩展工具
    /// </summary>
    public static class StringExtend
    {
        /// <summary>
        /// 是否为ip
        /// </summary>
        public static bool IsIP(this string str)
        {
            return ParseIsType.IsIP(str);

        }

        /// <summary>
        /// 指定清除标签的内容
        /// </summary>
        /// <param name="str">内容</param>
        /// <param name="tag">标签</param>
        /// <returns></returns>
        public static string ClearString(this string str, string tag)
        {
            return ParseString.ClearString(str, tag);
        }

        /// <summary>
        /// 将字符串转换成List型
        /// </summary>
        /// <param name="str">要转换的字符串</param>
        /// <param name="splitString">分隔符为NullOrEmpty时，则直接拆份为Char</param>
        /// <param name="defValue">默认值(单项转换失败时，默认值为NullOrEmpty时，则不添加，否则替换为默认值)</param>
        public static List<T> ToList<T>(this string str, string splitString, T defValue)
        {
            return ParseString.ToList<T>(str, splitString, defValue);
        }

        /// <summary>
        /// 将字符串转换成List型
        /// </summary>
        /// <param name="str">要转换的字符串</param>
        /// <param name="splitString">分隔符为NullOrEmpty时，则直接拆份为Char</param>
        /// <param name="defValue">默认值(单项转换失败时，默认值为NullOrEmpty时，则不添加，否则替换为默认值)</param>
        public static T[] ToArray<T>(this string str, string splitString, T defValue)
        {
            return ParseString.ToArray<T>(str, splitString, defValue);
        }

        /// <summary>
        /// 删除指定最后的字符串
        /// </summary>
        public static string DelLastOf(this string str, string strChar)
        {
            return ParseString.DelLastOf(str, strChar);
        }

        /// <summary>
        /// 删除指定最后的字符串
        /// </summary>
        public static string DelEndOf(this string str, string strChar)
        {
            return ParseString.DelEndOf(str, strChar);
        }

        /// <summary>
        /// 从字符串的指定位置截取指定长度的子字符串
        /// </summary>
        /// <param name="str">原字符串</param>
        /// <param name="startIndex">子字符串的起始位置</param>
        /// <param name="length">子字符串的长度(负数，则获取全部)</param>
        public static string SubString(this string str, int startIndex, int length)
        {
            return ParseString.SubString(str, startIndex, length);

        }

        /// <summary>
        /// 截取到tag字符串
        /// </summary>
        /// <param name="str"></param>
        /// <param name="tag"></param>
        /// <returns></returns>
        public static string SubString(this string str, string tag)
        {
            return ParseString.SubString(str, tag);
        }

        /// <summary>
        /// 比较两者是否相等，不考虑大小写
        /// </summary>
        /// <param name="str">对比一</param>
        /// <param name="str2">对比二</param>
        /// <returns></returns>
        public static bool IsEquals(this string str, string str2)
        {
            return ParseString.IsEquals(str, str2);
        }

        /// <summary>
        /// 是否为Null或者Empty
        /// </summary>
        /// <param name="str">要判断的字符串</param>
        /// <returns></returns>
        public static bool IsNullOrEmpty(this string str)
        {
            if (str != null) { str = str.Trim(); }
            return string.IsNullOrEmpty(str);
        }
    }
}