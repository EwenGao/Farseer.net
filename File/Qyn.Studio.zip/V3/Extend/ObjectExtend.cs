﻿using System;
using System.Collections.Generic;
using System.Text;

using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Object扩展工具
    /// </summary>
    public static class ObjectExtend
    {
        /// <summary>
        /// 将对像转换为T类型
        /// </summary>
        public static T ConvertType<T>(this object obj, T defValue)
        {
            return ParseType.ConvertType<T>(obj, defValue);
        }

        /// <summary>
        /// 判断是否T类型
        /// </summary>
        public static bool IsType<T>(this object obj)
        {
            return ParseIsType.IsType<T>(obj);
        }
        /// <summary>
        /// 获取枚举中文
        /// </summary>
        public static string GetName(this Enum eum)
        {
            return ParseEnum.GetDescription(eum.GetType(), eum.ToString());
        }

        /// <summary>
        /// 条件相等，输出字符串
        /// </summary>
        public static string ToString(this bool b, bool result, string str)
        {
            return ParseString.BoolToString(b, result, str);
        }
    }
}