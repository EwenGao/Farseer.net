﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using System.Web.UI.WebControls;
using Qyn.Studio.Tools;


namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存分类逻辑层
    /// </summary>
    /// <typeparam name="TInfo"></typeparam>
    /// <typeparam name="TProvider"></typeparam>
    public class BaseCateLogic<TInfo, TProvider> : BaseCacheLogic<TInfo, TProvider>
        where TInfo : BaseCateInfo
        where TProvider : new()
    {

        private static string Key = typeof(TProvider).FullName;

        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>返回新标识ID</returns>
        public new static int AddInfo(TInfo info)
        {
            if (info.ParentID == 0)
            {
                info.CateLevel = 1;
                info.ParentIDPath = "";
            }
            else
            {
                TInfo parentInfo = GetInfo(o => o.ID == info.ParentID);
                info.CateLevel = parentInfo.CateLevel + 1;
                info.ParentIDPath = string.Format("{0}{1}", string.IsNullOrEmpty(parentInfo.ParentIDPath).ToString(false, parentInfo.ParentIDPath + ","), parentInfo.ID);
            }

            int ID = Provider.AddInfo(info);
            if (ID > 0)
            {
                List<TInfo> lst = GetList();
                if (info.ID == 0) { info.ID = ID; }
                lst.Add(info);
                ParseCache.Add<List<TInfo>>(Key, lst);
            }
            //GetTrueList();
            return ID;
        }

        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>成功：True，失败：False</returns>
        public new static bool ModifyInfo(TInfo info)
        {
            bool result = Provider.ModifyInfo(info);

            List<TInfo> lstInfo = GetList();
            TInfo oldInfo = lstInfo.Find(o => o.ID == info.ID);
            if (oldInfo != null) { lstInfo.Remove(oldInfo); lstInfo.Add(info); ParseCache.Add<List<TInfo>>(Key, lstInfo); }
            else { GetTrueList(); }

            Reset(info.ParentID);
            return result;
        }

        /// <summary>
        /// 重新计算深度、路径等
        /// </summary>
        /// <param name="ID"></param>
        public static void Reset(int ID)
        {
            List<TInfo> lst = GetList(o => o.ParentID == ID);
            foreach (TInfo info in lst)
            {
                if (info.ParentID == 0)
                {
                    info.CateLevel = 1;
                    info.ParentIDPath = "";
                }
                else
                {
                    TInfo parentInfo = GetInfo(o => o.ID == info.ParentID);
                    info.CateLevel = parentInfo.CateLevel + 1;
                    info.ParentIDPath = string.Format("{0}{1}", string.IsNullOrEmpty(parentInfo.ParentIDPath).ToString(false, parentInfo.ParentIDPath + ","), parentInfo.ID);
                }

                Provider.ModifyInfo(info);
                List<TInfo> lstInfo = GetList();
                TInfo oldInfo = lstInfo.Find(o => o.ID == info.ID);
                if (oldInfo != null) { lstInfo.Remove(oldInfo); lstInfo.Add(info); ParseCache.Add<List<TInfo>>(Key, lstInfo); }
                else { GetTrueList(); }

                Reset(info.ID);
            }
        }

        /// <summary>
        /// 获取指定ParentID的ID列表
        /// </summary>
        /// <param name="isContainsSub">是否获取子节点</param>
        /// <param name="parentID"></param>
        public static List<int> GetSubIDList(int parentID, bool isContainsSub)
        {
            List<int> lst = new List<int>();
            foreach (int i in GetList(o => o.ParentID == parentID).Select(o => o.ID).ToList())
            {
                lst.Add(i);
                if (!isContainsSub) { continue; }
                lst.AddRange(GetSubIDList(i, isContainsSub));
            }
            return lst;
        }

        /// <summary>
        /// 获取根节点ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static int GetFirstID(int ID)
        {
            int parentID = -1;
            TInfo info = GetInfo(o => o.ID == ID);
            if (info != null)
            {
                if (info.ParentID > 0)
                {
                    parentID = GetFirstID(info.ParentID);
                }
                else { parentID = info.ID; }
            }
            return parentID;
        }

        /// <summary>
        /// 获取上一级ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static int GetParentID(int ID)
        {
            TInfo info = GetInfo(o => o.ID == ID);
            if (info != null) { return info.ParentID; }
            return 0;
        }

        /// <summary>
        /// 获取所有上级ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static List<int> GetParentIDList(int ID)
        {
            List<int> lst = new List<int>();
            TInfo info = GetInfo(o => o.ID == ID);
            if (info == null) { return lst; }

            lst.AddRange(GetParentIDList(info.ParentID));

            return lst;
        }

        /// <summary>
        /// 绑定到DropDownList
        /// </summary>
        /// <param name="ddl">要绑定的ddl控件</param>
        /// <param name="selectedValue">默认选则值</param>
        /// <param name="RemoveID">不加载的节点（包括子节点）</param>
        public static void Bind(DropDownList ddl, int selectedValue, int RemoveID)
        {
            Bind(ddl, selectedValue, RemoveID, null);
        }

        /// <summary>
        /// 绑定到DropDownList
        /// </summary>
        /// <param name="ddl">要绑定的ddl控件</param>
        /// <param name="selectedValue">默认选则值</param>
        /// <param name="RemoveID">不加载的节点（包括子节点）</param>
        /// <param name="match">筛选条件</param>
        public static void Bind(DropDownList ddl, int selectedValue, int RemoveID, Predicate<TInfo> match)
        {
            ddl.Items.Clear();

            BindFor(ddl, 0, 0, RemoveID, match);

            if (selectedValue > 0) { ParseBind.WebControlSelectedItem(ddl, selectedValue); }
        }

        /// <summary>
        /// 递归绑定
        /// </summary>
        private static void BindFor(DropDownList ddl, int parentID, int tagNum, int RemoveID, Predicate<TInfo> match)
        {
            List<TInfo> lst = GetList(match); if (lst == null || lst.Count == 0) { return; }
            lst = lst.FindAll(o => o.ParentID == parentID); if (lst == null || lst.Count == 0) { return; }

            foreach (TInfo info in lst)
            {
                if (info.ID == RemoveID) { continue; }
                ddl.Items.Add(new ListItem() { Value = info.ID.ToString(), Text = ParseString.FillTag(tagNum, "　") + "├─" + info.Caption });
                BindFor(ddl, info.ID, tagNum + 1, RemoveID, match);
            }
        }

    }
}
