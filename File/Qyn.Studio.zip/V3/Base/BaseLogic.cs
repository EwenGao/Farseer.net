﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.Extend;
using System.Data;
using Qyn.Studio.Controls;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 逻辑层基类工具
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    /// <typeparam name="TProvider">DAL层</typeparam>
    public class BaseLogic<TInfo, TProvider>
        where TInfo : BaseInfo
        where TProvider : new()
    {
        private static IProvider<TInfo> Provider = (IProvider<TInfo>)new TProvider();

        #region AddInfo
        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>返回新标识ID</returns>
        public static int AddInfo(TInfo info)
        {
            return Provider.AddInfo(info);
        }
        #endregion

        #region AddList
        /// <summary>
        /// 添加数据批量
        /// </summary>
        /// <param name="lst">实体类批量</param>
        /// <returns>返回新标识ID</returns>
        public static void AddList(List<TInfo> lst)
        {
            foreach (TInfo info in lst)
            {
                AddInfo(info);
            }
        }
        #endregion

        #region DropInfo
        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ID">主键标识</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(int ID)
        {
            return Provider.DropInfo("ID", ID);
        }

        /// <summary>
        /// 删除数据批量
        /// </summary>
        /// <param name="lst">IN 列表</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(List<int> lst)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, "ID", lst);
            return Provider.DropInfo(condition);
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="ID">主键标识</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(string conditionFieldName, object ID)
        {
            return Provider.DropInfo(conditionFieldName, ID);
        }

        /// <summary>
        /// 删除数据批量
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="lst">IN 列表</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(string conditionFieldName, List<int> lst)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, conditionFieldName, lst);
            return Provider.DropInfo(condition);
        }

        /// <summary>
        /// 删除单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(string condition)
        {
            return Provider.DropInfo(condition);
        }
        #endregion

        #region ModifyInfo
        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool ModifyInfo(TInfo info)
        {
            return Provider.ModifyInfo(info);
        }
        #endregion

        #region GetInfo
        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="ID">主键标识</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(int ID)
        {
            return Provider.GetInfo("ID", ID);
        }

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetInfo(conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(string condition)
        {
            return Provider.GetInfo(condition);
        }
        #endregion

        #region GetInfoByLike
        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <returns></returns>
        public static TInfo GetInfoByLike(string conditionFieldName, string conditionFieldValue, string condition)
        {
            return Provider.GetInfoByLike(conditionFieldName, conditionFieldValue, condition);
        }
        #endregion

        #region GetCount

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public static int GetCount(string condition)
        {
            return Provider.GetCount(condition);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static int GetCount(string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetCount(conditionFieldName, conditionFieldValue);
        }

        #endregion

        #region GetLikeList
        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">分页大小</param>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <param name="sort">排序</param>
        /// <param name="recordCount">记录</param>
        /// <returns></returns>
        public static List<TInfo> GetListByLike(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string condition, string sort, out int recordCount)
        {
            return Provider.GetLikeList(pageIndex, pageSize, conditionFieldName, conditionFieldValue, condition, sort, out recordCount).ToList<TInfo>();
        }

        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <param name="sort">排序</param>
        /// <returns></returns>
        public static List<TInfo> GetListByLike(Repeater rpt, string conditionFieldName, object conditionFieldValue, string condition, string sort)
        {
            int recordCount;
            List<TInfo> lst = Provider.GetLikeList(rpt.PageIndex, rpt.PageSize, conditionFieldName, conditionFieldValue, condition, sort, out recordCount).ToList<TInfo>();
            rpt.PageCount = recordCount;
            return lst;
        }
        #endregion


        #region GetDataTable
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        public static DataTable GetDataTable(Repeater rpt, string condition, string sort)
        {
            int recordCount = GetCount(condition);
            int pageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            int pageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            rpt.PageCount = recordCount;

            if (rpt.PageCount < pageIndex * pageSize)
            {
                pageIndex = rpt.PageCount / pageSize;
            }

            DataTable dt = Provider.GetDataTable(rpt.PageIndex, rpt.PageSize, condition, sort, out recordCount);
            rpt.PageCount = recordCount;
            return dt;
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        public static DataTable GetDataTable(Repeater rpt, string conditionFieldName, object conditionFieldValue, string sort)
        {
            int recordCount = GetCount(conditionFieldName, conditionFieldValue);
            int pageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            int pageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            rpt.PageCount = recordCount;

            if (rpt.PageCount < pageIndex * pageSize)
            {
                pageIndex = rpt.PageCount / pageSize;
            }
            DataTable dt = Provider.GetDataTable(rpt.PageIndex, rpt.PageSize, conditionFieldName, conditionFieldValue, sort, out recordCount);
            rpt.PageCount = recordCount;
            return dt;
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public static DataTable GetDataTable(int top, string[] fieldNames, string condition, string sort)
        {
            return Provider.GetDataTable(top, fieldNames, condition, sort);
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public static DataTable GetDataTable(int top, string[] fieldNames, string conditionFieldName, object conditionFieldValue, string sort)
        {
            return Provider.GetDataTable(top, fieldNames, conditionFieldName, conditionFieldValue, sort);
        }
        #endregion

        #region Modify
        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="lst">IN 列表</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, List<int> lst)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, "ID", lst);
            return Provider.Modify(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="lst">IN 列表</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, string conditionFieldName, List<int> lst)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, conditionFieldName, lst);
            return Provider.Modify(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, string condition)
        {
            return Provider.Modify(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.Modify(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, int ID)
        {
            return Provider.Modify(fieldName, fieldValue, "ID", ID);
        }
        #endregion

        #region ModifyAdd
        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string condition)
        {
            return Provider.ModifyAdd(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.ModifyAdd(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, int ID)
        {
            return Provider.ModifyAdd(fieldName, fieldValue, "ID", ID);
        }
        #endregion

        #region GetSum
        /// <summary>
        /// 统计某个字段的累加值
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        public static decimal GetSum(string filedName)
        {
            return Provider.GetSum(filedName);
        }

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="condition">SQL条件语句</param>
        public static decimal GetSum(string filedName, string condition)
        {
            return Provider.GetSum(filedName, condition);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static decimal GetSum(string filedName, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetSum(filedName, conditionFieldName, conditionFieldValue);
        }
        #endregion

        #region GetValue<T>
        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        public static T GetValue<T>(string fieldName, int ID)
        {
            return Provider.GetValue<T>(fieldName, "ID", ID);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        public static T GetValue<T>(string fieldName, string condition)
        {
            return Provider.GetValue<T>(fieldName, condition);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static T GetValue<T>(string fieldName, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetValue<T>(fieldName, conditionFieldName, conditionFieldValue);
        }
        #endregion

        #region Caption
        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="ID">主键标识</param>
        public static string Caption(int ID)
        {
            return Provider.GetValue<string>("Caption", "ID", ID);
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="ID">主键标识</param>
        public static string Caption(string conditionFieldName, object ID)
        {
            return Provider.GetValue<string>("Caption", conditionFieldName, ID);
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public static string Caption(string condition)
        {
            return Provider.GetValue<string>("Caption", condition);
        }
        #endregion

        #region GetList
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        public static List<TInfo> GetList(Repeater rpt, string condition, string sort)
        {
            return GetDataTable(rpt, condition, sort).ToList<TInfo>();
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="Repeater">Repeater带分页控件</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        public static List<TInfo> GetList(Repeater rpt, string conditionFieldName, object conditionFieldValue, string sort)
        {
            return GetDataTable(rpt, conditionFieldName, conditionFieldValue, sort).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(string condition, string sort)
        {
            return GetDataTable(0, null, condition, sort).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(string conditionFieldName, object conditionFieldValue, string sort)
        {
            return GetDataTable(0, null, conditionFieldName, conditionFieldValue, sort).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(string[] fieldNames, string condition, string sort)
        {
            DataTable dt = GetDataTable(1, null, "1!=1", string.Empty);
            DataTable dt2 = GetDataTable(0, fieldNames, condition, sort);

            foreach (DataRow dr in dt2.Rows) { dt.ImportRow(dr); }

            return dt.ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(string[] fieldNames, string conditionFieldName, object conditionFieldValue, string sort)
        {
            DataTable dt = GetDataTable(1, null, "1!=1", string.Empty);
            DataTable dt2 = GetDataTable(0, fieldNames, conditionFieldName, conditionFieldValue, sort);

            foreach (DataRow dr in dt2.Rows) { dt.ImportRow(dr); }

            return dt.ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(int top, string condition, string sort)
        {
            return GetDataTable(top, null, condition, sort).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(int top, string conditionFieldName, object conditionFieldValue, string sort)
        {
            return GetDataTable(top, null, conditionFieldName, conditionFieldValue, sort).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(int top, string[] fieldNames, string condition, string sort)
        {
            DataTable dt = GetDataTable(1, null, "1!=1", string.Empty);
            DataTable dt2 = GetDataTable(top, fieldNames, condition, sort);

            foreach (DataRow dr in dt2.Rows) { dt.ImportRow(dr); }

            return dt.ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(int top, string[] fieldNames, string conditionFieldName, object conditionFieldValue, string sort)
        {
            DataTable dt = GetDataTable(1, null, "1!=1", string.Empty);
            DataTable dt2 = GetDataTable(top, fieldNames, conditionFieldName, conditionFieldValue, sort);

            foreach (DataRow dr in dt2.Rows) { dt.ImportRow(dr); }

            return dt.ToList<TInfo>();
        }
        #endregion

        #region GetListByID
        /// <summary>
        /// 获取ID列表
        /// </summary>
        public static List<int> GetListByID(string condition)
        {
            List<int> ids = new List<int>();
            List<TInfo> lst = GetList(new string[] { "ID" }, condition, string.Empty);
            if (lst != null)
            {
                ids = lst.Select(o => o.ID).ToList();
            }
            return ids;

        }

        /// <summary>
        /// 获取ID列表
        /// </summary>
        public static List<int> GetListByID(string fieldName, object value)
        {
            List<int> ids = new List<int>();
            List<TInfo> lst = GetList(new string[] { "ID" }, fieldName, value, string.Empty);
            if (lst != null)
            {
                ids = lst.Select(o => o.ID).ToList();
            }
            return ids;

        }
        #endregion

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetNextInfo(string conditionFieldName, int conditionFieldValue, string condition)
        {
            return Provider.GetNextInfo<TInfo>(conditionFieldName, conditionFieldValue, condition);
        }

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="ID">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetNextInfo(int ID, string condition)
        {
            return Provider.GetNextInfo<TInfo>("ID", ID, condition);
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetPreviousInfo(string conditionFieldName, int conditionFieldValue, string condition)
        {
            return Provider.GetPreviousInfo<TInfo>(conditionFieldName, conditionFieldValue, condition);
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="ID">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetPreviousInfo(int ID, string condition)
        {
            return Provider.GetPreviousInfo<TInfo>("ID", ID, condition);
        }

        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        public static List<TInfo> GetListByIndex(int pageIndex, int pageSize, string containsFieldName, object containsFieldValue, string condition, string sort, out int recordCount)
        {
            return Provider.GetListByIndex<TInfo>(pageIndex, pageSize, containsFieldName, containsFieldValue, condition, sort, out  recordCount);
        }
    }
}
