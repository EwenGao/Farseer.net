﻿using System.Collections.Generic;
using System.Data;
using Qyn.Config;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// Provider基类
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    public abstract class BaseProvider<TInfo> : ORM, IProvider<TInfo> where TInfo : BaseInfo
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="tableName">表名</param>
        protected BaseProvider(string tableName) : base(tableName) { }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="dbList">数据库配置</param>
        protected BaseProvider(string tableName, DbList dbList) : base(tableName, dbList) { }
        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="connetionString">数据库连接字符串</param>
        /// <param name="type">数据库类型</param>
        /// <param name="dataVer">数据库版本</param>
        protected BaseProvider(string tableName, string connetionString, DataBaseType type, string dataVer) : base(tableName, connetionString, type, dataVer) { }

        #region AddInfo
        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>返回新标识ID</returns>
        public abstract int AddInfo(TInfo info);

        #endregion

        #region DropInfo

        /// <summary>
        /// 删除单条记录(单条件)
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：True，失败：False</returns>
        public virtual bool DropInfo(string conditionFieldName, object conditionFieldValue)
        {
            return base.Delete(conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 删除单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：True，失败：False</returns>
        public virtual bool DropInfo(string condition)
        {
            return base.Delete(condition);
        }

        #endregion

        #region ModifyInfo

        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>成功：True，失败：False</returns>
        public abstract bool ModifyInfo(TInfo info);

        #endregion

        #region GetInfo

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public virtual TInfo GetInfo(string conditionFieldName, object conditionFieldValue)
        {
            return base.Get<TInfo>(conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public virtual TInfo GetInfo(string condition)
        {
            return base.Get<TInfo>(condition);
        }

        #endregion

        #region GetInfoByLike
        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <returns></returns>
        public virtual TInfo GetInfoByLike(string conditionFieldName, string conditionFieldValue, string condition)
        {
            return base.GetByLike<TInfo>(conditionFieldName, conditionFieldValue, condition);
        }
        #endregion

        #region GetCount

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public virtual int GetCount(string condition)
        {
            return base.Count(condition);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public virtual int GetCount(string conditionFieldName, object conditionFieldValue)
        {
            return base.Count(conditionFieldName, conditionFieldValue);

        }

        #endregion

        #region GetLikeList
        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">分页大小</param>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <param name="sort">排序</param>
        /// <param name="recordCount">记录</param>
        /// <returns></returns>
        public virtual List<TInfo> GetLikeList(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string condition, string sort, out int recordCount)
        {
            return base.ListByLike(pageIndex, pageSize, conditionFieldName, conditionFieldValue, condition, sort, out recordCount).ToList<TInfo>();
        }
        #endregion

        #region GetDataTable

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        public virtual DataTable GetDataTable(int pageIndex, int pageSize, string condition, string sort, out int recordCount)
        {
            return base.List(pageIndex, pageSize, condition, sort, out recordCount);
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        public virtual DataTable GetDataTable(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string sort, out int recordCount)
        {
            return base.List(pageIndex, pageSize, conditionFieldName, conditionFieldValue, sort, out recordCount);
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public virtual DataTable GetDataTable(int top, string[] fieldNames, string condition, string sort)
        {
            return base.List(top, fieldNames, condition, sort);
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public virtual DataTable GetDataTable(int top, string[] fieldNames, string conditionFieldName, object conditionFieldValue, string sort)
        {
            return base.List(top, fieldNames, conditionFieldName, conditionFieldValue, sort);
        }
        #endregion

        #region Modify

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public virtual bool Modify(string fieldName, object fieldValue, string condition)
        {
            return base.Update(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public virtual bool Modify(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            return base.Update(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
        }

        #endregion

        #region ModifyAdd

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public virtual bool ModifyAdd(string fieldName, int fieldValue, string condition)
        {
            return base.UpdateAdd(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public virtual bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            return base.UpdateAdd(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
        }

        #endregion

        #region GetSum

        /// <summary>
        /// 统计某个字段的累加值
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        public virtual decimal GetSum(string filedName)
        {
            return base.Sum(filedName);
        }

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="condition">SQL条件语句</param>
        public virtual decimal GetSum(string filedName, string condition)
        {
            return base.Sum(filedName, condition);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public virtual decimal GetSum(string filedName, string conditionFieldName, object conditionFieldValue)
        {
            return base.Sum(filedName, conditionFieldName, conditionFieldValue);
        }

        #endregion

        #region GetValue<T>

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        public virtual T GetValue<T>(string fieldName, string condition)
        {
            return base.Value<T>(fieldName, condition);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public virtual T GetValue<T>(string fieldName, string conditionFieldName, object conditionFieldValue)
        {
            return base.Value<T>(fieldName, conditionFieldName, conditionFieldValue);
        }

        #endregion

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        public virtual Info GetNextInfo<Info>(string conditionFieldName, int conditionFieldValue, string condition)
        {
            return base.GetNextRecord<Info>(conditionFieldName, conditionFieldValue, condition);
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        public virtual Info GetPreviousInfo<Info>(string conditionFieldName, int conditionFieldValue, string condition)
        {
            return base.GetPreviousRecord<Info>(conditionFieldName, conditionFieldValue, condition);
        }

        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        public virtual List<Info> GetListByIndex<Info>(int pageIndex, int pageSize, string containsFieldName, object containsFieldValue, string condition, string sort, out int recordCount)
        {
            return base.Index<Info>(pageIndex, pageSize, containsFieldName, containsFieldValue, condition, sort, out  recordCount);
        }
    }
}
