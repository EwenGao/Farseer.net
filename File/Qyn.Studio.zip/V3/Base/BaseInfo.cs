﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 实体类基类信息
    /// </summary>
    [Serializable]
    public class BaseInfo
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public BaseInfo() { }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="dr">DataRow</param>
        public BaseInfo(DataRow dr)
        {
            ID = dr["ID"].ConvertType(0);
            Caption = dr["Caption"].ToString();
            CreateAt = dr["CreateAt"].ConvertType(DateTime.Now);
            CreateID = dr["CreateID"].ConvertType(0);
        }

        /// <summary>
        /// 编号
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string Caption { get; set; }

        /// <summary>
        /// 内容
        /// </summary>
        public string Contents { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime CreateAt { get; set; }

        /// <summary>
        /// 创建人ID
        /// </summary>
        public int CreateID { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int Sort { get; set; }

    }
}
