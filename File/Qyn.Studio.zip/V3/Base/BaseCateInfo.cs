﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 实体类基类信息
    /// </summary>
    [Serializable]
    public class BaseCateInfo : BaseInfo
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public BaseCateInfo() { }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="dr">DataRow</param>
        public BaseCateInfo(DataRow dr)
        {
            ID = dr["ID"].ConvertType(0);
            Caption = dr["Caption"].ToString();
            ParentID = dr["ParentID"].ConvertType(0);
            ParentIDPath = dr["ParentIDPath"].ToString();
            CateLevel = dr["CateLevel"].ConvertType(0);
            Sort = dr["Sort"].ConvertType(0);
        }

        /// <summary>
        /// 所属ID
        /// </summary>
        public int ParentID { get; set; }
        /// <summary>
        /// 深度
        /// </summary>
        public int CateLevel { get; set; }
        /// <summary>
        /// 上级树路径
        /// </summary>
        public string ParentIDPath { get; set; }

    }
}
