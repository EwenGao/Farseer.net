﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.Data;
using System.Data;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// ORM接口工具
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    public interface IProvider<TInfo> where TInfo : BaseInfo
    {
        #region AddInfo
        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>返回新标识ID</returns>
        int AddInfo(TInfo info);
        
        #endregion

        #region DropInfo

        /// <summary>
        /// 删除单条记录(单条件)
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：True，失败：False</returns>
        bool DropInfo(string conditionFieldName, object conditionFieldValue);

        /// <summary>
        /// 删除单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：True，失败：False</returns>
        bool DropInfo(string condition);
        
        #endregion

        #region ModifyInfo

        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>成功：True，失败：False</returns>
        bool ModifyInfo(TInfo info);
        
        #endregion

        #region GetInfo

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：实体类，失败：Null</returns>
        TInfo GetInfo(string conditionFieldName, object conditionFieldValue);

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：实体类，失败：Null</returns>
        TInfo GetInfo(string condition);
        
        #endregion

        #region GetInfoByLike
        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <returns></returns>
        TInfo GetInfoByLike(string conditionFieldName, string conditionFieldValue, string condition);
        #endregion

        #region GetCount

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        int GetCount(string condition);

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        int GetCount(string conditionFieldName, object conditionFieldValue);
        
        #endregion

        #region GetLikeList

        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">分页大小</param>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <param name="sort">排序</param>
        /// <param name="recordCount">记录</param>
        /// <returns></returns>
        List<TInfo> GetLikeList(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string condition, string sort, out int recordCount);
        
        #endregion

        #region GetDataTable
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        DataTable GetDataTable(int pageIndex, int pageSize, string condition, string sort, out int recordCount);

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        DataTable GetDataTable(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string sort, out int recordCount);

        
        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        DataTable GetDataTable(int top, string[] fieldNames, string condition, string sort);

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        DataTable GetDataTable(int top, string[] fieldNames, string conditionFieldName, object conditionFieldValue, string sort);

        #endregion

        #region Modify
        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        bool Modify(string fieldName, object fieldValue, string condition);

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        bool Modify(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue);

        #endregion

        #region ModifyAdd

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        bool ModifyAdd(string fieldName, int fieldValue, string condition);

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue);

        #endregion

        #region GetSum

        /// <summary>
        /// 统计某个字段的累加值
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        decimal GetSum(string filedName);

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="condition">SQL条件语句</param>
        decimal GetSum(string filedName, string condition);

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        decimal GetSum(string filedName, string conditionFieldName, object conditionFieldValue);

        #endregion

        #region GetValue<T>

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        T GetValue<T>(string fieldName, string condition);

        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        T GetValue<T>(string fieldName, string conditionFieldName, object conditionFieldValue);

        #endregion

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        Info GetNextInfo<Info>(string conditionFieldName, int conditionFieldValue, string condition);

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        Info GetPreviousInfo<Info>(string conditionFieldName, int conditionFieldValue, string condition);

        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        List<Info> GetListByIndex<Info>(int pageIndex, int pageSize, string containsFieldName, object containsFieldValue, string condition, string sort, out int recordCount);
    }
}
