﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Tools;
using Qyn.Studio.Controls;
using System.Text.RegularExpressions;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    /// <typeparam name="TProvider">DAL层</typeparam>
    public class BaseCacheLogic<TInfo, TProvider>
        where TInfo : BaseInfo
        where TProvider : new()
    {
        /// <summary>
        /// IProvider
        /// </summary>
        public static IProvider<TInfo> Provider = (IProvider<TInfo>)new TProvider();
        private static string Key = typeof(TProvider).FullName;

        #region AddInfo
        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>返回新标识ID</returns>
        public static int AddInfo(TInfo info)
        {
            int ID = Provider.AddInfo(info);
            if (ID > 0)
            {
                List<TInfo> lst = GetList();
                if (info.ID == 0) { info.ID = ID; }
                lst.Add(info);
                ParseCache.Add<List<TInfo>>(Key, lst);
            }
            //GetTrueList();
            return ID;
        }
        #endregion

        #region AddList
        /// <summary>
        /// 添加数据批量
        /// </summary>
        /// <param name="lst">实体类批量</param>
        /// <returns>返回新标识ID</returns>
        public static void AddList(List<TInfo> lst)
        {
            foreach (TInfo info in lst)
            {
                AddInfo(info);
            }
        }
        #endregion

        #region DropInfo
        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ID">主键标识</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(int ID)
        {
            return DropInfo(ID, string.Empty, null);
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ID">主键标识</param>
        /// <param name="condition">SQL 条件</param>
        /// <param name="match">缓存删除条件</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(int ID, string condition, Predicate<TInfo> match)
        {
            if (!string.IsNullOrEmpty(condition)) { condition += " AND "; }
            condition += ParseSql.GetCondition(ParseSql.eumOperate.Equal, "ID", ID);

            bool result = Provider.DropInfo(condition);

            List<TInfo> lst = GetList();

            if (match != null)
            { match += o => o.ID == ID; }
            else { { match = o => o.ID == ID; } }

            lst.RemoveAll(match);

            ParseCache.Add<List<TInfo>>(Key, lst);

            return result;
        }

        /// <summary>
        /// 删除数据批量
        /// </summary>
        /// <param name="lst">IN 列表</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(List<int> lst)
        {
            return DropInfo(lst, string.Empty, null);
        }

        /// <summary>
        /// 删除数据批量
        /// </summary>
        /// <param name="lst">IN 列表</param>
        /// <param name="condition">SQL 条件</param>
        /// <param name="match">缓存删除条件</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(List<int> lst, string condition, Predicate<TInfo> match)
        {
            if (!string.IsNullOrEmpty(condition)) { condition += " AND "; }
            condition += ParseSql.GetCondition(ParseSql.eumIn.In, "ID", lst);

            bool result = Provider.DropInfo(condition);
            List<TInfo> lstInfo = GetList();
            if (match != null)
            { match += o => lst.Exists(oo => oo == o.ID); }
            else { { match = o => lst.Exists(oo => oo == o.ID); } }

            lstInfo.RemoveAll(match);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="ID">主键标识</param>
        /// <param name="match">缓存删除条件</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(string conditionFieldName, object ID, Predicate<TInfo> match)
        {
            bool result = Provider.DropInfo(conditionFieldName, ID);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 删除数据批量
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="lst">IN 列表</param>
        /// <param name="match">缓存删除条件</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(string conditionFieldName, List<int> lst, Predicate<TInfo> match)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, conditionFieldName, lst);
            bool result = Provider.DropInfo(condition);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 删除单条记录
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="match">缓存删除条件</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool DropInfo(string condition, Predicate<TInfo> match)
        {
            bool result = Provider.DropInfo(condition);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }
        #endregion

        #region ModifyInfo
        /// <summary>
        /// 修改数据
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>成功：True，失败：False</returns>
        public static bool ModifyInfo(TInfo info)
        {
            bool result = Provider.ModifyInfo(info);
            List<TInfo> lstInfo = GetList();
            TInfo oldInfo = lstInfo.Find(o => o.ID == info.ID);
            if (oldInfo != null) { lstInfo.Remove(oldInfo); lstInfo.Add(info); ParseCache.Add<List<TInfo>>(Key, lstInfo); }
            else { GetTrueList(); }

            return result;
        }
        #endregion

        #region GetInfo
        ///// <summary>
        ///// 获取单条记录(单条件)
        ///// </summary>
        ///// <param name="ID">主键标识</param>
        ///// <returns>成功：实体类，失败：Null</returns>
        //public static TInfo GetInfo(int ID)
        //{
        //    List<TInfo> lst = GetTrueList();
        //    foreach(TInfo info in lst)
        //    {
        //        if (info.ID == ID) { return info; }
        //    }
        //    return null;
        //}

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="match">o=>匿名委托</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(Predicate<TInfo> match)
        {
            return GetList().Find(match);
        }
        #endregion

        #region GetCount

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="match">o=>匿名委托</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static int GetCount(Predicate<TInfo> match)
        {
            List<TInfo> lst = GetList();
            if (match != null) { lst = lst.FindAll(match); }
            if (lst != null) { return lst.Count; }
            return 0;
        }

        #endregion

        #region Modify
        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="lst">IN 列表</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, List<int> lst, List<TInfo> lstModifyInfo)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, "ID", lst);
            bool result = Provider.Modify(fieldName, fieldValue, condition);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(o => lst.Exists(oo => oo == o.ID));
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="lst">IN 列表</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, string conditionFieldName, List<int> lst, Predicate<TInfo> match, List<TInfo> lstModifyInfo)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, conditionFieldName, lst);
            bool result = Provider.Modify(fieldName, fieldValue, condition);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, string condition, Predicate<TInfo> match, List<TInfo> lstModifyInfo)
        {
            bool result = Provider.Modify(fieldName, fieldValue, condition);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue, Predicate<TInfo> match, List<TInfo> lstModifyInfo)
        {
            bool result = Provider.Modify(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool Modify(string fieldName, object fieldValue, int ID, List<TInfo> lstModifyInfo)
        {
            bool result = Provider.Modify(fieldName, fieldValue, "ID", ID);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(o => o.ID == ID);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }
        #endregion

        #region ModifyAdd
        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string condition, Predicate<TInfo> match, List<TInfo> lstModifyInfo)
        {
            bool result = Provider.ModifyAdd(fieldName, fieldValue, condition);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue, Predicate<TInfo> match, List<TInfo> lstModifyInfo)
        {
            bool result = Provider.ModifyAdd(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(match);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, int ID, List<TInfo> lstModifyInfo)
        {
            bool result = Provider.ModifyAdd(fieldName, fieldValue, "ID", ID);
            List<TInfo> lstInfo = GetList();
            lstInfo.RemoveAll(o => o.ID == ID);
            lstInfo.AddRange(lstModifyInfo);
            ParseCache.Add<List<TInfo>>(Key, lstInfo);
            return result;
        }
        #endregion

        #region Caption
        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="match">o=>匿名委托</param>
        public static string Caption(Predicate<TInfo> match)
        {
            string caption = string.Empty;
            TInfo info = GetInfo(match);
            if (info != null) { caption = info.Caption; }
            return caption;
        }
        #endregion

        #region GetList
        /// <summary>
        /// 获取数据列表
        /// </summary>
        public static List<TInfo> GetList()
        {
            List<TInfo> lst = ParseCache.Get<List<TInfo>>(Key);
            if (lst == null) { return GetTrueList(); }
            return lst;
        }

        /// <summary>
        /// 获取数据列表(带排序)
        /// </summary>
        /// <param name="fieldName">要排序的字段</param>
        /// <param name="sort">排序方式</param>
        public static List<TInfo> GetList(string fieldName, ReverserInfo.Direction sort)
        {
            List<TInfo> lst = GetList();
            lst.Sort(new Reverser<TInfo>(typeof(TInfo), fieldName, sort));
            return lst;
        }

        /// <summary>
        /// 获取数据列表
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="match">匿名委托</param>
        public static List<TInfo> GetList(Repeater rpt, Predicate<TInfo> match)
        {
            List<TInfo> lst = GetList();
            if (match != null) { lst = lst.FindAll(match); }
            if (lst != null) { rpt.PageCount = lst.Count; return ParseList.Pagination(lst, rpt.PageIndex, rpt.PageSize); }
            else { return lst; }
        }

        /// <summary>
        /// 获取数据列表(带排序)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="match">匿名委托</param>
        /// <param name="fieldName">要排序的字段</param>
        /// <param name="sort">排序方式</param>
        public static List<TInfo> GetList(Repeater rpt, Predicate<TInfo> match, string fieldName, ReverserInfo.Direction sort)
        {
            List<TInfo> lst = GetList(fieldName, sort);
            if (match != null) { lst = lst.FindAll(match); }
            if (lst != null)
            {
                int pageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
                int pageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

                rpt.PageCount = lst.Count;

                if (rpt.PageCount < pageIndex * pageSize)
                {
                    pageIndex = rpt.PageCount / pageSize;
                }

                return ParseList.Pagination(lst, pageIndex, pageSize);
            }
            else { return lst; }
        }

        /// <summary>
        /// 获取数据列表
        /// </summary>
        /// <param name="match">匿名委托</param>
        public static List<TInfo> GetList(Predicate<TInfo> match)
        {
            List<TInfo> lst = GetList();
            if (match != null) { lst = lst.FindAll(match); }
            return lst;
        }

        /// <summary>
        /// 获取数据列表(带排序)
        /// </summary>
        /// <param name="match">匿名委托</param>
        /// <param name="fieldName">要排序的字段</param>
        /// <param name="sort">排序方式</param>
        public static List<TInfo> GetList(Predicate<TInfo> match, string name, ReverserInfo.Direction direction)
        {
            List<TInfo> lst = GetList(name, direction);
            if (match != null) { lst = lst.FindAll(match); }
            return lst;
        }

        #endregion

        #region GetListByID
        /// <summary>
        /// 获取ID列表
        /// </summary>
        /// <param name="match">匿名委托</param>
        public static List<int> GetListByID(Predicate<TInfo> match)
        {
            List<int> ids = new List<int>();
            List<TInfo> lst = GetList(match);
            if (lst != null)
            {
                ids = lst.Select(o => o.ID).ToList();
            }
            return ids;

        }
        #endregion

        #region GetTrueList
        /// <summary>
        /// 获取数据列表(读取数据库)
        /// </summary>
        public static List<TInfo> GetTrueList()
        {
            List<TInfo> lst = Provider.GetDataTable(0, null, string.Empty, string.Empty).ToList<TInfo>();
            ParseCache.Add<List<TInfo>>(Key, lst);
            return lst;
        }
        #endregion
    }
}
