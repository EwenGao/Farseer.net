﻿using System;
using System.Web;
using System.Web.SessionState;
using Qyn.Studio.Configs;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Web.Page
{
    /// <summary>
    /// 用户控件基类
    /// </summary>
    public class BaseControls : System.Web.UI.UserControl,IRequiresSessionState
    {
        /// <summary>
        /// 网站标题
        /// </summary>
        public string WebTitle { get; set; }

        /// <summary>
        /// 网站域名
        /// http://www.xxx.com:80
        /// </summary>
        public string DoMain { get; set; }

        /// <summary>
        /// 当前请求的路径(不带页面文字)
        /// http://www.xxx.com:80/
        /// </summary>
        public string RequestPath { get; set; }

        /// <summary>
        /// 当前请求的页面文件名称
        /// Default.aspx
        /// </summary>
        public string RequestName { get; set; }

        /// <summary>
        /// 当前请求的路径参数
        /// Default.aspx
        /// </summary>
        public string RequestParams { get; set; }

        #region 前台Url、Path
        /// <summary>
        /// 网站平台根目录
        /// /
        /// </summary>
        public string WebPath { get; set; }

        /// <summary>
        /// 网站域名地址（网站程序根目录,带域名） 
        /// http://www.xxx.com:80/
        /// </summary>
        public string WebUrl { get; set; }

        /// <summary>
        /// 网站登陆页面
        /// http://www.xxx.com:80/Login.aspx
        /// </summary>
        public string WebLoginUrl { get; set; }

        /// <summary>
        /// 网站退出页面
        /// </summary>
        public string WebLogoutUrl { get; set; }
        #endregion

        #region 后台Url、Path
        /// <summary>
        /// 管理平台根目录
        /// /Admin/
        /// </summary>
        public string AdminPath { get; set; }

        /// <summary>
        /// 管理平台域名地址（网站程序根目录,带域名） 
        /// http://www.xxx.com:80/Admin/
        /// </summary>
        public string AdminUrl { get; set; }

        /// <summary>
        /// 管理员登陆页面
        /// http://www.xxx.com:80/Admin/Login.aspx
        /// </summary>
        public string AdminLoginUrl { get; set; }

        /// <summary>
        /// 管理员退出页面
        /// </summary>
        public string AdminLogoutUrl { get; set; }
        #endregion

        /// <summary>
        /// HttpContext.Current.Request
        /// </summary>
        public HttpRequest BaseRequest = HttpContext.Current.Request;
        /// <summary>
        /// HttpContext.Current.Response
        /// </summary>
        public HttpResponse BaseResponse = HttpContext.Current.Response;

        

        /// <summary>
        /// 构造
        /// </summary>
        public BaseControls()
        {
            WebTitle = GeneralConfigs.ConfigInfo.WebTitle;

            DoMain = QynRequest.GetUrl(QynRequest.UrlType.Domain);
            RequestPath = QynRequest.GetUrl(QynRequest.UrlType.Path);
            RequestName = QynRequest.GetUrl(QynRequest.UrlType.PageName);
            RequestParams = QynRequest.GetUrl(QynRequest.UrlType.Params);


            WebPath = SysPathConfigs.ConfigInfo.WebPath;
            WebUrl = DoMain + WebPath;
            WebLoginUrl = SysPathConfigs.ConfigInfo.WebLoginUrl;
            WebLogoutUrl = SysPathConfigs.ConfigInfo.WebLogoutUrl;

            AdminPath = SysPathConfigs.ConfigInfo.AdminPath;
            AdminUrl = DoMain + AdminPath;
            AdminLoginUrl = SysPathConfigs.ConfigInfo.AdminLoginUrl;
            AdminLogoutUrl = SysPathConfigs.ConfigInfo.AdminLogoutUrl;

            DeBug();

        }

        /// <summary>
        /// 调试状态
        /// </summary>
        public void DeBug()
        {
            //清空缓存
            if (GeneralConfigs.ConfigInfo.DeBug)
            {
                GeneralConfigs.ResetConfig();
                CookiesConfigs.ResetConfig();
                SessionConfigs.ResetConfig();
                DbConfigs.ResetConfig();
                EmailConfigs.ResetConfig();
                SysPathConfigs.ResetConfig();
            }
        }

        #region 显示、弹出信息
        /// <summary>
        /// 显示信息
        /// </summary>
        public void ShowMsg(string message)
        {
            new Terminator().Throw(message);
        }

        /// <summary>
        /// 显示信息
        /// </summary>
        public void ShowMsg(string message, string title, string gotoUrl)
        {
            new Terminator().Throw(message, title, string.Format("Go to Page,{0}", gotoUrl));
        }

        /// <summary>
        /// 弹出信息
        /// </summary>
        public void Alert(string message)
        {
            new Terminator().Alert(message);
        }

        /// <summary>
        /// 弹出信息
        /// </summary>
        public void Alert(string message, string gotoUrl)
        {
            new Terminator().Alert(message, gotoUrl);
        }

        #endregion

        #region Request
        /// <summary>
        /// Request.QueryString
        /// </summary>
        public T QS<T>(string parmsName, T defValue)
        {
            return QynRequest.QS(parmsName, defValue);
        }

        /// <summary>
        /// Request.Form
        /// </summary>
        public T QF<T>(string parmsName, T defValue)
        {
            return QynRequest.QS(parmsName, defValue);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName)
        {
            return QynRequest.QS(parmsName);
        }

        /// <summary>
        /// Request.Form
        /// </summary>
        public string QF(string parmsName)
        {
            return QynRequest.QF(parmsName);
        }

        #endregion

        /// <summary>
        /// 转到网址
        /// </summary>
        public void GoToUrl(string url, params object[] args)
        {
            if (args != null && args.Length != 0) { url = string.Format(url, args); }
            BaseResponse.Redirect(url);
        }

        /// <summary>
        /// 刷新当前页
        /// </summary>
        public void Refresh()
        {
            GoToUrl("{0}?{1}", RequestName, RequestParams);
        }

        /// <summary>
        /// 刷新整页
        /// </summary>
        /// <param name="link"></param>
        public void RefreshParent(string link)
        {
            BaseResponse.Write(string.Format("<script type=\"text/javascript\">parent.document.location.href=\"{0}\"</script>", link));
        }
    }
}
