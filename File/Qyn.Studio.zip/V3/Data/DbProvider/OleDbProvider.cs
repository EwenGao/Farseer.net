﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Web;
using System.Windows.Forms;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using Qyn.Studio.Configs;
using Qyn.Config;

namespace Qyn.Studio.Data
{
    /// <summary>
    /// Access工厂
    /// </summary>
    public class OleDbExecutor : IDbProvider
    {
        /// <summary>
        /// 构造函数
        /// </summary>
        public OleDbExecutor() { }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="connnection">数据库连接字符串</param>
        public OleDbExecutor(string connnection)
        {
            this.ConnectionString = connnection;
        }

        string _connectinString;
        /// <summary>
        /// 连接字符串 
        /// </summary>
        public string ConnectionString
        {
            get { return _connectinString; }
            set { _connectinString = value; }
        }

        /// <summary>
        /// 添加参数
        /// </summary>
        private OleDbParameterCollection AddParms(OleDbParameterCollection parmsCollection, IDbDataParameter[] parameters)
        {
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    OleDbParameter parms = (OleDbParameter)parameters[i];
                    if (parms.DbType == DbType.DateTime)
                    {
                        parms.Value = string.Format("#{0}#", parms.Value.ToString());
                    }
                    parmsCollection.Add(parms);
                }
            }
            return parmsCollection;
        }

        #region IDbExector成员

        public Object ExecuteScalar(CommandType cmmType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmmType;
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                return comm.ExecuteScalar();
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return null;
        }

        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                return comm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return -1;
        }

        public int ExecuteTranSql(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = null;
            OleDbTransaction tran = null;
            int result = 0;
            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                comm = new OleDbCommand(cmdText, conn);
                comm.Transaction = tran;
                comm.CommandType = cmdType;

                AddParms(comm.Parameters, parameters);
                result = comm.ExecuteNonQuery();
                tran.Commit();
            }
            catch (OleDbException ex)
            {
                if (ex.ErrorCode != 1205 && tran != null) tran.Rollback();
                result = -1;

                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                if (tran != null) tran.Commit();
                comm.Dispose();
            }
            return result;
        }


        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return null;
        }

        public DataSet GetDataSet(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmdType;
            OleDbDataAdapter ada = new OleDbDataAdapter(comm);
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                DataSet ds = new DataSet();
                ada.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Parameters.Clear();
                ada.Dispose();
                comm.Dispose();
                conn.Dispose();
            }
            return new DataSet();
        }

        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            if (ds.Tables.Count == 0) { return new DataTable(); }
            return ds.Tables[0];
        }


        public void Dispose() { }
        #endregion

    }

}
