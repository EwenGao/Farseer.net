using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using System.Web;
using System.Windows.Forms;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using Qyn.Studio.Configs;
using Qyn.Config;

namespace Qyn.Studio.Data
{
    /// <summary>
    /// MySql����
    /// </summary>
    public class MySqlExector : IDbProvider
    {
        /// <summary>
        /// ���캯��
        /// </summary>
        public MySqlExector() { }

        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="connection">���ݿ������ַ���</param>
        public MySqlExector(string connection)
        {
            _connectinString = connection;
        }


        string _connectinString;
        /// <summary>
        /// �����ַ��� 
        /// </summary>
        public string ConnectionString
        {
            get { return _connectinString; }
            set { _connectinString = value; }
        }

        /// <summary>
        /// ���Ӳ���
        /// </summary>
        private MySqlParameterCollection AddParms(MySqlParameterCollection parmsCollection, IDbDataParameter[] parameters)
        {
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    MySqlParameter parms = (MySqlParameter)parameters[i];
                    parmsCollection.Add(parms);
                }
            }
            return parmsCollection;
        }

        #region IDbExecutor ��Ա

        /// <summary>
        /// ���ص���
        /// </summary>
        /// <param name="cmdType"></param>
        /// <param name="cmdText"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public object ExecuteScalar(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                return comm.ExecuteScalar();
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return null;
        }

        /// <summary>
        /// ����Ӱ������
        /// </summary>
        /// <param name="cmdType"></param>
        /// <param name="cmdText"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                return comm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return -1;
        }

        public int ExecuteTranSql(CommandType cmdType, string cmdText , params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = null;
            MySqlTransaction tran = null;

            int result = 0;
            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                comm = new MySqlCommand(cmdText, conn);
                comm.Transaction = tran;
                comm.CommandType = cmdType;

                AddParms(comm.Parameters, parameters);
                result = comm.ExecuteNonQuery();
                tran.Commit();
            }
            catch (MySqlException ex)
            {
                if (ex.Number != 1205 && tran != null) tran.Rollback();
                result = -1;
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                if (tran != null)  tran.Commit();
                comm.Dispose();
            }
            return result;
        }

        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return null;
        }

        public DataSet GetDataSet(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            MySqlDataAdapter ada = new MySqlDataAdapter(comm);
            try
            {
                conn.Open();
                AddParms(comm.Parameters, parameters);
                DataSet ds = new DataSet();
                ada.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                string message = "Can Not Operate DataBase!";
                if (GeneralConfigs.ConfigInfo.DeBug) { message = ex.Message; }

                if (HttpContext.Current != null) { new Terminator().Throw(message); }
                else { MessageBox.Show(message); }
            }
            finally
            {
                comm.Parameters.Clear();
                ada.Dispose();
                comm.Dispose();
                conn.Dispose();
            }
            return new DataSet();
        }

        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            if (ds.Tables.Count == 0) { return new DataTable(); }
            return ds.Tables[0];
        }

        public DataRow GetDataRow(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataTable dt = GetDataTable(cmdType, cmdText, parameters);
            if (dt.Rows.Count == 0) { return new DataTable().NewRow(); }
            return dt.Rows[0];
        }

        public List<DataRow> GetDataRowList(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataTable dt = GetDataTable(cmdType, cmdText, parameters);

            if (dt.Rows.Count == 0) { return new List<DataRow>(); }

            return dt.Rows.ToRows();
        }
        #endregion

        #region IDisposable ��Ա

        public void Dispose()
        {
           
        }

        #endregion
    }
}
