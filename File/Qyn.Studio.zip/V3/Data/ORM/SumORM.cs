﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Utils;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Data
{
    public partial class ORM
    {
        /// <summary>
        /// 统计某个字段的累加值
        /// </summary>
        protected decimal Sum(string filedName)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT SUM({0}) FROM [{1}]", filedName, TableName);

                return db.ExecuteScalar(CommandType.Text, sql).ConvertType(0);

            }
        }

        /// <summary>
        /// 统计数量(多条件)
        /// </summary>
        /// <param name="filedName">要统计的字段</param>
        /// <param name="condition">SQL条件语句</param>
        protected decimal Sum(string filedName, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT SUM({0}) FROM [{1}] {2}", filedName, TableName, ParseHacker.Condition(condition));

                return db.ExecuteScalar(CommandType.Text, sql).ConvertType(0);

            }
        }

        /// <summary>
        /// 统计数量(单条件)
        /// </summary>
        /// <param name="filedName">要统计的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        protected decimal Sum(string filedName, string conditionFieldName, object conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT SUM({0}) FROM [{1}] WHERE [{2}] = @Value", filedName,TableName, conditionFieldName);

                return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);

            }
        }
    }
}
