﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using Qyn.Studio.Utils;
using Qyn.Studio.Extend;
using Qyn.Config;

namespace Qyn.Studio.Data
{
    public partial class ORM : DbHelper
    {
        /// <summary>
        /// 表名
        /// </summary>
        protected string TableName { get; set; }
        /// <summary>
        /// 构造函数（默认Db.Config第一个配置）
        /// </summary>
        /// <param name="tableName">表名</param>
        protected ORM(string tableName) { TableName = tableName; }
        /// <summary>
        /// 构造函数（指定Db.Config的配置）
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="dbList">Db.Config配置</param>
        protected ORM(string tableName, DbList dbList) : base(dbList) { TableName = tableName; }
        /// <summary>
        /// 构造函数（指定完整的连接字符串）
        /// </summary>
        /// <param name="tableName">表</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="datatype">数据库类型</param>
        /// <param name="dataVer">数据库版本</param>
        protected ORM(string tableName, string connetionString, DataBaseType datatype, string dataVer) : base(connetionString, datatype, dataVer) { TableName = tableName; }

    }
}
