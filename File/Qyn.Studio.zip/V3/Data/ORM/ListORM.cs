﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Qyn.Studio.Utils;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Data
{
    public partial class ORM : DbHelper
    {
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        protected DataTable List(int pageIndex, int pageSize, string condition, string sort, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            recordCount = Count(condition);
            sort = ParseHacker.Sort(sort);
            condition = ParseHacker.Condition(condition);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT * FROM (SELECT *,ROW_NUMBER() OVER({0}) as Row FROM [{1}] {2}) a WHERE Row BETWEEN {3} AND {4}",
                        sort, TableName, condition, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize);
            }
            else
            {
                sql = string.Format("SELECT TOP {0} * FROM (SELECT TOP {1} * FROM [{2}] {3} {4}) a  {5}", pageSize, pageSize * pageIndex, TableName, condition, sort, sort2);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                dt = db.GetDataTable(CommandType.Text, sql);
            }


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        protected DataTable List(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string sort, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            recordCount = Count(conditionFieldName, conditionFieldValue);
            sort = ParseHacker.Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT * FROM (SELECT *,ROW_NUMBER() OVER({0}) as Row FROM [{1}] WHERE [{2}] = @Value) a WHERE Row BETWEEN {3} AND {4}",
                         sort, TableName, conditionFieldName, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize);
            }
            else
            {
                if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
                sql = string.Format("SELECT TOP {0} * FROM (SELECT TOP {1} * FROM [{2}] WHERE [{3}] = @Value {4}) a  {5}", pageSize, pageSize * pageIndex, TableName, conditionFieldName, sort, sort2);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                dt = db.GetDataTable(CommandType.Text, sql, parms);
            }


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        protected DataTable List(int top, string[] fieldNames, string condition, string sort)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string strTop = top > 0 ? "TOP " + top : string.Empty;
                string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

                string sql = string.Format("SELECT {0} {1} FROM [{2}] {3} {4}", strTop, strFields, TableName, ParseHacker.Condition(condition), ParseHacker.Sort(sort));

                return db.GetDataTable(CommandType.Text, sql);
            }
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        protected DataTable List(int top, string[] fieldNames, string conditionFieldName, object conditionFieldValue, string sort)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string strTop = top > 0 ? "TOP " + top : string.Empty;
                string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

                string sql = string.Format("SELECT {0} {1} FROM [{2}] WHERE [{3}] = @Value {4}", strTop, strFields, TableName, conditionFieldName, ParseHacker.Sort(sort));

                return db.GetDataTable(CommandType.Text, sql, parms);
            }
        }

        /// <summary>
        /// 获取随机符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        protected DataTable ListByRandom(int top, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT {0} * FROM [{1}] {2} order by newid()", top > 0 ? "TOP " + top : "", TableName, ParseHacker.Condition(condition));

                return db.GetDataTable(CommandType.Text, sql);
            }
        }

        /// <summary>
        /// 获取随机符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        protected DataTable ListByRandom(int top, string conditionFieldName, object conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT {0} * FROM [{1}] WHERE [{2}] = @Value order by newid()", top > 0 ? "TOP " + top : "", TableName, conditionFieldName);

                return db.GetDataTable(CommandType.Text, sql, parms);
            }
        }

        /// <summary>
        /// Like查找
        /// </summary>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">每显示显示数量</param>
        /// <param name="condition">条件</param>
        /// <param name="recordCount">返回结果记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        protected DataTable ListByLike(int pageIndex, int pageSize, string conditionFieldName, object conditionFieldValue, string condition, string sort, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            recordCount = CountByLike(conditionFieldName, conditionFieldValue, condition);

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }
            sort = ParseHacker.Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT * FROM (SELECT *,ROW_NUMBER() OVER({0}) as Row FROM [{1}] WHERE CHARINDEX(@Value,[{2}]) >0 {5}) a WHERE Row BETWEEN {3} AND {4}",
                         sort, TableName, conditionFieldName, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize, condition);
            }
            else if (base.DataType == DataBaseType.Access)
            {
                sql = string.Format("SELECT TOP {0} * FROM (SELECT TOP {1} * FROM [{2}] WHERE INSTR([{3}],@Value) >0 {6} {4}) a  {5}", pageSize, pageSize * pageIndex, TableName, conditionFieldName, sort, sort2, condition);
                isReverse = true;
            }
            else
            {
                sql = string.Format("SELECT TOP {0} * FROM (SELECT TOP {1} * FROM [{2}] WHERE CHARINDEX(@Value,[{3}]) >0 {6} {4}) a  {5}", pageSize, pageSize * pageIndex, TableName, conditionFieldName, sort, sort2, condition);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue)
                };

                dt = db.GetDataTable(CommandType.Text, sql, parms);
            }

            return isReverse ? dt.Reverse() : dt;
        }
    }
}
