﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
namespace Qyn.Studio.Data
{
    public partial class ORM : DbHelper
    {
        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        protected Info Get<Info>(string conditionFieldName, object conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT TOP 1 * FROM [{0}] WHERE [{1}] = @Value", TableName, conditionFieldName);

                DataTable dt = db.GetDataTable(CommandType.Text, sql, parms);
                if (dt == null || dt.Rows.Count == 0) { return default(Info); }
                return dt.Rows[0].ToInfo<Info>();
            }
        }

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        protected Info Get<Info>(string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT TOP 1 * FROM [{0}] {1}", TableName, ParseHacker.Condition(condition));
                DataTable dt = db.GetDataTable(CommandType.Text, sql, null);
                if (dt == null || dt.Rows.Count == 0) { return default(Info); }
                return dt.Rows[0].ToInfo<Info>();
            }
        }

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        protected Info GetNextRecord<Info>(string conditionFieldName, int conditionFieldValue, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT TOP 1 * FROM [{0}] {1} {2} [{3}] < @Value ORDER BY [{3}] DESC", TableName, ParseHacker.Condition(condition), ParseHacker.Condition(condition).Length > 0 ? "AND" : "WHERE", conditionFieldName);

                DataTable dt = db.GetDataTable(CommandType.Text, sql, parms);
                if (dt == null || dt.Rows.Count == 0) { return default(Info); }
                return dt.Rows[0].ToInfo<Info>();
            }
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        protected Info GetPreviousRecord<Info>(string conditionFieldName, int conditionFieldValue, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT TOP 1 * FROM [{0}] {1} {2} [{3}] > @Value ORDER BY [{3}] ASC", TableName, ParseHacker.Condition(condition), ParseHacker.Condition(condition).Length > 0 ? "AND" : "WHERE", conditionFieldName);

                DataTable dt = db.GetDataTable(CommandType.Text, sql, parms);
                if (dt == null || dt.Rows.Count == 0) { return default(Info); }
                return dt.Rows[0].ToInfo<Info>();
            }
        }

        /// <summary>
        /// Like查找
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        protected Info GetByLike<Info>(string conditionFieldName, object conditionFieldValue, string condition)
        {
            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }

            string sql = string.Empty;

            if (base.DataType == DataBaseType.SqlServer)
            {
                sql = string.Format("SELECT TOP 1 * FROM [{0}] WHERE CHARINDEX(@Value,[{1}]) >0 {2}", TableName, conditionFieldName, condition);
            }
            else
            {
                sql = string.Format("SELECT TOP 1 * FROM [{0}] WHERE instr([{1}],@Value) >0 {2}", TableName, conditionFieldName, condition);
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue)
                };

                DataTable dt = db.GetDataTable(CommandType.Text, sql, parms);
                if (dt == null || dt.Rows.Count == 0) { return default(Info); }
                return dt.Rows[0].ToInfo<Info>();
            }
        }
    }
}
