﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
namespace Qyn.Studio.Data
{
    /// <summary>
    /// 全文索引
    /// </summary>
    public partial class ORM : DbHelper
    {    
        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        protected List<Info> Index<Info>(int pageIndex, int pageSize, string containsFieldName, object containsFieldValue, string condition, string sort, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            recordCount = CountByIndex(containsFieldName, containsFieldValue, condition);

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }
            sort = ParseHacker.Sort(sort);

            List<Info> list;
            string sql = string.Empty;
            bool isReverse = false;
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT * FROM (SELECT *,ROW_NUMBER() OVER({0}) as Row FROM [{1}] WHERE CONTAINS({2},@Value) {5}) a WHERE Row BETWEEN {3} AND {4}",
                         sort, TableName, containsFieldName, (pageIndex - 1) * pageSize, pageIndex * pageSize, condition);
            }
            else if (base.DataType == DataBaseType.Access)
            {
                if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
                sql = string.Format("SELECT TOP {0} * FROM (SELECT TOP {1} * FROM [{2}] WHERE INSTR([{3}],@Value) >0 {6} {4}) a  {5}", pageSize, pageSize * pageIndex, TableName, containsFieldName, sort, sort2, condition);
                isReverse = true;
            }
            else
            {
                if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
                sql = string.Format("SELECT TOP {0} * FROM (SELECT TOP {1} * FROM [{2}] WHERE CONTAINS([{3}],@Value) {6} {4}) a  {5}", pageSize, pageSize * pageIndex, TableName, containsFieldName, sort, sort2, condition);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", containsFieldValue)
                };

                list = db.GetDataTable(CommandType.Text, sql, parms).ToList<Info>();
            }

            if (isReverse) { list.Reverse(); }
            return list;
        }

    }
}
