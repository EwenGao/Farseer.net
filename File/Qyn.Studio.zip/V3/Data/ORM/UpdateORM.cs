﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Data
{
    public partial class ORM : DbHelper
    {
        /// <summary>
        /// 更改多个字段的方法(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="paramters">多个字段的值 Name 为@字段名,Value为值</param>
        /// <returns>返回受影响的行</returns>
        protected bool Update(string conditionFieldName, object conditionFieldValue, params IDbDataParameter[] paramters)
        {
            if (paramters.Length == 0) return false;

            string sql = string.Format("UPDATE [{0}] SET ", TableName);

            IDbDataParameter[] parms = new IDbDataParameter[paramters.Length + 1];

            for (int i = 0; i < paramters.Length; i++)
            {
                sql += string.Format("[{0}] = {1} ,", paramters[i].ParameterName.Substring(1), paramters[i].ParameterName);
                parms[i] = paramters[i];
            }
            if (sql.EndsWith(",")) sql = sql.Substring(0, sql.Length - 1);

            sql += string.Format(" WHERE [{0}] = @ConditionValue", conditionFieldName);
            using (IDbProvider db = NewDbProvider())
            {
                parms[paramters.Length] = NewParam("@ConditionValue", conditionFieldValue);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 更改多个字段的方法(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="paramters">多个字段的值 Name 为@字段名,Value为值</param>
        /// <returns>返回受影响的行</returns>
        protected bool Update(string condition, params IDbDataParameter[] paramters)
        {
            if (paramters.Length == 0) return false;

            string sql = string.Format("UPDATE [{0}] SET ", TableName);
            foreach (IDbDataParameter de in paramters)
            {
                sql += string.Format("[{0}] = {1} ,", de.ParameterName.Substring(1), de.ParameterName);
            }
            if (sql.EndsWith(",")) sql = sql.Substring(0, sql.Length - 1);
            sql += string.Format(" {0}", ParseHacker.Condition(condition));
            using (IDbProvider db = NewDbProvider())
            {
                return db.ExecuteNonQuery(CommandType.Text, sql, paramters) > 0;
            }
        }

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        protected bool Update(string fieldName, object fieldValue, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", fieldValue) 

                };
                string sql = string.Format("UPDATE [{0}] SET [{1}] = @Value {2}", TableName, fieldName, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        protected bool Update(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@FieldValue", fieldValue),
                    NewParam("@ConditionValue", conditionFieldValue) 

                };
                string sql = string.Format("UPDATE [{0}] SET [{1}] = @FieldValue WHERE [{2}] = @ConditionValue", TableName, fieldName, conditionFieldName);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        protected bool UpdateAdd(string fieldName, int fieldValue, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("UPDATE [{0}] SET [{1}] = {1} + {2} {3}", TableName, fieldName, fieldValue, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql, null) > 0;
            }
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        protected bool UpdateAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 

                };
                string sql = string.Format("UPDATE [{0}] SET [{1}] = {1} + {2} WHERE [{3}] = @Value", TableName, fieldName, fieldValue, conditionFieldName);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

    }
}
