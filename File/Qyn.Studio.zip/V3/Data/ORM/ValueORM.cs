﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using Qyn.Studio.Utils;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Data
{
    public partial class ORM : DbHelper
    {
        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        protected T Value<T>(string fieldName, string conditionFieldName, object conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT {0} FROM [{1}] WHERE [{2}] = @Value", fieldName, TableName, conditionFieldName);

                object obj = db.ExecuteScalar(CommandType.Text, sql, parms);
                return ParseType.ConvertType<T>(obj, default(T));

            }
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        protected T Value<T>(string fieldName, string condition)
        {

            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT TOP 1 {0} FROM [{1}] {2}", fieldName, TableName, ParseHacker.Condition(condition));
                object obj = db.ExecuteScalar(CommandType.Text, sql);
                return ParseType.ConvertType<T>(obj, default(T));

            }
        }
    }
}
