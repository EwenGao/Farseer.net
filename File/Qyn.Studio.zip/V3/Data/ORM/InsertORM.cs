﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

using Qyn.Studio.Extend;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Data
{
    public partial class ORM : DbHelper
    {
        /// <summary>
        /// 插入记录的通用方法（支持标识键插入）
        /// </summary>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <returns>是否插入成功</returns>
        protected bool InsertIdentity(params IDbDataParameter[] parameters)
        {
            string sql = string.Format("SET IDENTITY_INSERT [{0}] ON ; ", TableName);
            sql += string.Format("INSERT INTO [{0}]", TableName);
            string fields, values;
            fields = values = "(";
            foreach (IDbDataParameter param in parameters)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            sql += string.Format(" SET IDENTITY_INSERT [{0}] OFF ; ", TableName);

            using (IDbProvider db = NewDbProvider())
            {
                return db.ExecuteNonQuery(CommandType.Text, sql, parameters) > 0;
            }
        }

        /// <summary>
        /// 插入记录的通用方法（支持默认值和isnull）
        /// </summary>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <returns>是否插入成功</returns>
        protected bool Insert(params IDbDataParameter[] parameters)
        {
            string sql = string.Format("INSERT INTO [{0}]", TableName);
            string fields, values;
            fields = values = "(";
            foreach (IDbDataParameter param in parameters)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            using (IDbProvider db = NewDbProvider())
            {
                return db.ExecuteNonQuery(CommandType.Text, sql, parameters) > 0;
            }
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        protected int Insert(out int identity, params IDbDataParameter[] parameters)
        {
            string sql = string.Format("INSERT INTO [{0}]", TableName);
            string fields, values;
            fields = values = "(";
            foreach (IDbDataParameter param in parameters)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            using (IDbProvider db = NewDbProvider())
            {
                if (DataType == DataBaseType.SqlServer)
                {
                    sql += ";SELECT @@IDENTITY";
                    //DataSet ds = db.GetDataSet(CommandType.Text, sql, parameters);
                    //identity = ds.Tables[0].Rows[0][0].ConvertType(0);
                    identity = db.ExecuteScalar(CommandType.Text, sql, parameters).ConvertType(0);
                }
                else
                {
                    identity = db.ExecuteNonQuery(CommandType.Text, sql, parameters);
                }
            }
            return identity;
        }
    }
}
