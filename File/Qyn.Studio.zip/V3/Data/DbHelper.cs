﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

using Qyn.Studio.Configs;
using Qyn.Config;
using System.IO;
using System.Web;
using Qyn.Studio.Utils;
using System.Collections;
using System.Linq;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Data
{
    /// <summary>
    /// 数据库助手
    /// </summary>
    public class DbHelper
    {
        /// <summary>
        /// 数据库类型
        /// </summary>
        protected DataBaseType DataType { get; set; }

        /// <summary>
        /// 数据库连接的字符串
        /// </summary>
        protected string ConnectString { get; set; }

        /// <summary>
        /// 数据库版本
        /// </summary>
        protected string DataVer { get; set; }

        /// <summary>
        /// 默认数据库配置第一项
        /// </summary>
        protected DbHelper() : this(DbConfigs.ConfigInfo.DataBaseList[0]) { }

        /// <summary>
        /// 指定数据库配置
        /// </summary>
        /// <param name="dbList">数据库配置</param>
        protected DbHelper(DbList dbList)
        {
            DataVer = dbList.Ver;

            switch (dbList.Type.ToLower())
            {
                case "access":
                    {
                        string fileName = dbList.Server;
                        if (fileName.IndexOf(':') == -1)
                        {
                            if (HttpContext.Current != null) { fileName = HttpContext.Current.Server.MapPath("~/App_Data/" + fileName); }
                            else { fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data/" + fileName); }
                        }

                        switch (DataVer.ToLower())
                        {
                            case "2007":
                                {
                                    ConnectString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;");
                                    break;
                                }
                            case "97":
                                {
                                    ConnectString = string.Format("Provider=Microsoft.Jet.OLEDB.3.51;");
                                    break;
                                }
                            default:
                                {
                                    ConnectString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;" );
                                    break;
                                }
                        }
                        ConnectString += string.Format("Data Source={0};User ID={1};Password ={2};",fileName, string.IsNullOrEmpty(dbList.UserID) ? "Admin" : dbList.UserID, dbList.PassWord);
                        DataType = DataBaseType.Access;
                    
                        break;
                    }
                case "mysql":
                    {
                        ConnectString = string.Format("Data Source='{0}';User Id='{1}';Password='{2}';Database='{3}';charset='gbk'", dbList.Server, dbList.UserID, dbList.PassWord, dbList.Catalog);
                        DataType = DataBaseType.MySql;
                        break;
                    }
                default:
                    {
                        ConnectString = string.Format("Data Source={0};User ID={1};Password={2};Initial Catalog={3};Pooling=true;Min Pool Size={4};Max Pool Size={5};", dbList.Server, dbList.UserID, dbList.PassWord, dbList.Catalog, dbList.PoolMinSize, dbList.PoolMaxSize);
                        DataType = DataBaseType.SqlServer;
                        break;
                    }
            }
        }

        /// <summary>
        /// 自定义数据库配置
        /// </summary>
        /// <param name="connectionString">连接字符串</param>
        /// <param name="dataType">数据库类型</param>
        /// <param name="dataVer">数据库版本</param>
        protected DbHelper(string connectionString, DataBaseType dataType,string dataVer)
        {
            ConnectString = connectionString;
            DataType = dataType;
            DataVer = dataVer;
        }

        /// <summary>
        /// 创建一个数据库连接
        /// </summary>
        /// <returns></returns>
        protected IDbConnection NewConnection()
        {
            IDbConnection connection;
            switch (DataType)
            {
                case DataBaseType.Access:
                    connection = new OleDbConnection(ConnectString);
                    break;
                case DataBaseType.MySql:
                    connection = new MySqlConnection(ConnectString);
                    break;
                default:
                    connection = new SqlConnection(this.ConnectString);
                    break;
            }

            return connection;
        }

        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        /// <param name="name">参数名称</param>
        /// <param name="valu">参数值</param>
        /// <param name="type">参数类型</param>
        /// <param name="len">参数长度</param>
        /// <param name="output">是否是输出值</param>
        protected IDbDataParameter NewParam(string name, object valu, DbType type, int len, bool output)
        {
            IDbDataParameter param;
            switch (DataType)
            {
                case DataBaseType.Access:
                    param = new OleDbParameter();
                    break;
                case DataBaseType.MySql:
                    param = new MySqlParameter();
                    break;
                default:
                    param = new SqlParameter();
                    break;
            }
            param.DbType = type;
            param.ParameterName = name;
            param.Value = valu;
            if (len > 0) param.Size = len;
            if (output) param.Direction = ParameterDirection.Output;
            return param;
        }

        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        protected IDbDataParameter NewParam(string name, object valu, DbType type, int len)
        {
            return this.NewParam(name, valu, type, len, false);
        }

        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        protected IDbDataParameter NewParam(string name, object valu)
        {
            if (valu == null) { valu = string.Empty; }
            if (valu is Enum) { valu = (byte)valu; }
            if (valu is IList) { valu = ((IList)valu).ToString(","); }

            switch (valu.GetType().Name)
            {
                case "String":
                    return this.NewParam(name, valu, DbType.String, 0);
                case "DateTime":
                    return this.NewParam(name, valu, DbType.DateTime, 8);
                case "Boolean":
                    return this.NewParam(name, valu, DbType.Boolean, 1);
                case "Int32":
                    return this.NewParam(name, valu, DbType.Int32, 4);
                case "Int16":
                    return this.NewParam(name, valu, DbType.Int16, 2);
                case "Decimal":
                    return this.NewParam(name, valu, DbType.Decimal, 8);
                case "Byte":
                    return this.NewParam(name, valu, DbType.Byte, 1);
                default:
                    return this.NewParam(name, valu, DbType.String, 0);
            }
        }

        /// <summary>
        /// 创建一个数据库执行对象
        /// </summary>
        /// <returns></returns>
        protected IDbProvider NewDbProvider()
        {
            return DbFactory.CreateExecutor(this.DataType, this.ConnectString);
        }


        #region IDisposable 成员

        public void Dispose()
        {
            // TODO:  添加 DataAgent.Dispose 实现
        }

        #endregion
    }

    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum DataBaseType
    {
        SqlServer = 1,
        Access = 2,
        MySql = 3
    }
}
