﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 类工具
    /// </summary>
    public class ParseClass
    {
        /// <summary>
        /// 获取该类的所有方法
        /// </summary>
        public static List<MethodInfo> GetMethods(Type ht)
        {
            MethodInfo[] info = ht.GetMethods();
            return info.ToList<MethodInfo>();
        }

        /// <summary>
        /// 获取该类所有公共成员
        /// </summary>
        public static List<MemberInfo> GetMembers(Type ht)
        {
            MemberInfo[] info = ht.GetMembers();
            return info.ToList<MemberInfo>();
        }

        /// <summary>
        /// 获取该类所有公共属性
        /// </summary>
        public static List<PropertyInfo> GetProperties(Type ht)
        {
            PropertyInfo[] info = ht.GetProperties(BindingFlags.Instance | BindingFlags.Public);
            return info.ToList<PropertyInfo>();
        }
    }
}
