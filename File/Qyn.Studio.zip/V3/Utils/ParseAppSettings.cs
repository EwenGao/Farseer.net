using System.Web;
using System.Configuration;

namespace Qyn.Studio.Utils
{
	///<summary>
	/// ��ConfigurationSettings.AppSettings�������з�װ
	/// </summary>
    public class ParseAppSettings
	{
		/// <summary>
		/// ��ȡweb.config��������
		/// </summary>
		/// <param name="key"></param>
		/// <returns></returns>
		public static string Get(string key)
		{
			
			return System.Configuration.ConfigurationManager.AppSettings[key];
			
		}
	}
}