﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Web;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 文件工具
    /// </summary>
    public class ParseFile
    {
        /// <summary>
        /// 返回文件是否存在
        /// </summary>
        /// <param name="filename">文件名</param>
        /// <returns>是否存在</returns>
        public static bool FileExists(string filename)
        {
            return System.IO.File.Exists(filename);
        }

        /// <summary>
        /// 返回文件夹是否存在
        /// </summary>
        /// <param name="path">路径</param>
        /// <returns>是否存在</returns>
        public static bool DirExists(string path)
        {
            return System.IO.Directory.Exists(path);

        }

        /// <summary>
        /// 获取文件名
        /// </summary>
        /// <param name="filePath">文件的路径全名称</param>
        /// <returns></returns>
        public static string GetFileName(string filePath)
        {
            return System.IO.Path.GetFileName(filePath);
        }

        /// <summary>
        /// 获取文件后缀名(小写)
        /// </summary>
        /// <param name="fileName">文件名</param>
        /// <returns></returns>
        public static string GetExtension(string fileName)
        {
            return System.IO.Path.GetExtension(fileName).Substring(1).ToLower();
        }

        /// <summary>
        /// 以指定的ContentType输出指定文件文件
        /// </summary>
        /// <param name="filepath">文件路径</param>
        /// <param name="filename">输出的文件名</param>
        /// <param name="filetype">将文件输出时设置的ContentType</param>
        public static void ResponseFile(string filepath, string filename, string filetype)
        {
            Stream iStream = null;

            // 缓冲区为10k
            byte[] buffer = new Byte[10000];

            // 文件长度
            int length;

            // 需要读的数据长度
            long dataToRead;

            try
            {
                // 打开文件
                iStream = new FileStream(filepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);


                // 需要读的数据长度
                dataToRead = iStream.Length;

                HttpContext.Current.Response.ContentType = filetype;
                HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + Utils.ParseUrl.UrlEncode(filename.Trim()).Replace("+", " "));

                while (dataToRead > 0)
                {
                    // 检查客户端是否还处于连接状态
                    if (HttpContext.Current.Response.IsClientConnected)
                    {
                        length = iStream.Read(buffer, 0, 10000);
                        HttpContext.Current.Response.OutputStream.Write(buffer, 0, length);
                        HttpContext.Current.Response.Flush();
                        buffer = new Byte[10000];
                        dataToRead = dataToRead - length;
                    }
                    else
                    {
                        // 如果不再连接则跳出死循环
                        dataToRead = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                HttpContext.Current.Response.Write("Error : " + ex.Message);
            }
            finally
            {
                if (iStream != null)
                {
                    // 关闭文件
                    iStream.Close();
                }
            }
            HttpContext.Current.Response.End();
        }

        /// <summary>
        /// 返回指定目录下的非 UTF8 字符集文件
        /// </summary>
        /// <param name="Path">路径</param>
        /// <returns>文件名的字符串数组</returns>
        public static string[] FindNoUTF8File(string Path)
        {
            //System.IO.StreamReader reader = null;
            StringBuilder filelist = new StringBuilder();
            DirectoryInfo Folder = new DirectoryInfo(Path);
            //System.IO.DirectoryInfo[] subFolders = Folder.GetDirectories(); 
            /*
            for (int i=0;i<subFolders.Length;i++) 
            { 
                FindNoUTF8File(subFolders[i].FullName); 
            }
            */
            FileInfo[] subFiles = Folder.GetFiles();
            for (int j = 0; j < subFiles.Length; j++)
            {
                if (subFiles[j].Extension.ToLower().Equals(".htm"))
                {
                    FileStream fs = new FileStream(subFiles[j].FullName, FileMode.Open, FileAccess.Read);
                    bool bUtf8 = IsUTF8(fs);
                    fs.Close();
                    if (!bUtf8)
                    {
                        filelist.Append(subFiles[j].FullName);
                        filelist.Append("\r\n");
                    }
                }
            }
            return ParseString.ToArray<string>(filelist.ToString(), "\r\n", null);

        }

        /// <summary>
        /// 判断文件流是否为UTF8字符集
        /// </summary>
        /// <param name="sbInputStream">文件流</param>
        /// <returns>判断结果</returns>
        private static bool IsUTF8(FileStream sbInputStream)
        {
            int i;
            byte cOctets;  // octets to go in this UTF-8 encoded character 
            byte chr;
            bool bAllAscii = true;
            long iLen = sbInputStream.Length;

            cOctets = 0;
            for (i = 0; i < iLen; i++)
            {
                chr = (byte)sbInputStream.ReadByte();

                if ((chr & 0x80) != 0) bAllAscii = false;

                if (cOctets == 0)
                {
                    if (chr >= 0x80)
                    {
                        do
                        {
                            chr <<= 1;
                            cOctets++;
                        }
                        while ((chr & 0x80) != 0);

                        cOctets--;
                        if (cOctets == 0) return false;
                    }
                }
                else
                {
                    if ((chr & 0xC0) != 0x80)
                    {
                        return false;
                    }
                    cOctets--;
                }
            }

            if (cOctets > 0)
            {
                return false;
            }

            if (bAllAscii)
            {
                return false;
            }

            return true;

        }

        /// <summary>
        /// 建立文件夹
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static void CreateDir(string path)
        {
            //return MakeSureDirectoryPathExists(name);
            System.IO.Directory.CreateDirectory(path);
        }

        /// <summary>
        /// 删除目录
        /// </summary>
        /// <param name="path">路径</param>
        /// <param name="recursive">true同时删除子目录所有文件</param>
        /// <returns></returns>
        public static void DropDir(string path, bool recursive)
        {
            System.IO.Directory.Delete(path, recursive);
        }

        /// <summary>
        /// 智能创建文件目录(任何级别目录)
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static bool CreateDirs(string dirPath)
        {
            string path = string.Empty;
            string mapPath = string.Empty;
            dirPath = ParseFile.ConvertPath(dirPath);

            if (dirPath.ToLower().StartsWith("http://")) { dirPath = Utils.ParseUrl.GetMapPath(dirPath); }

            string[] dirPaths = dirPath.Split('/');                     //用于创建目录
            for (int i = 0; i < dirPaths.Length; i++)
            {
                if (i == 0)
                {
                    if (dirPaths[i].ToLower().StartsWith("http:")) { break; }
                    if (dirPaths[i].IndexOf(":") != -1)
                    {
                        path = dirPaths[i] + "/";
                        continue;
                    }
                    else if (dirPaths[i] == "")
                    {
                        path = "/";
                        continue;
                    }
                }

                if (dirPaths[i] != "")
                {
                    path += dirPaths[i] + "/";

                    mapPath = Utils.ParseUrl.GetMapPath(path);
                    if (!DirExists(mapPath))
                    {
                        CreateDir(mapPath);
                    }
                }

            }
            return true;
        }

        /// <summary>
        /// 复制文件夹内的文件到指定路径
        /// </summary>
        /// <param name="srcPath">源文件夹</param>
        /// <param name="aimPath">目录文件夹</param>
        /// <param name="isCopySubDir">true:复制子文件夹;false:只复制根文件夹下的文件</param>
        /// <param name="overCopy">是复制覆盖</param>
        /// <param name="filterExtension">后缀名过滤，格式："svn|aspx|asp|exe"</param>
        public static bool CopyDir(string srcPath, string aimPath, bool isCopySubDir, bool overCopy, string filterExtension)
        {
            try
            {
                aimPath = ConvertPath(aimPath);
                if (!aimPath.EndsWith("/")) { aimPath += "/"; }

                if (!DirExists(aimPath)) { CreateDirs(aimPath); }

                List<string> lstFilter = ParseString.ToList(filterExtension, "|", string.Empty);

                string[] fileList = Directory.GetFileSystemEntries(srcPath);

                // 遍历所有的文件和目录
                foreach (string file in fileList)
                {
                    if (lstFilter.FindAll(o => string.Compare(o, GetExtension(file), true) >0) != null)
                    {
                        continue;
                    }

                    if (Directory.Exists(file) && isCopySubDir)
                    {
                        CopyDir(file, aimPath + Path.GetFileName(file), isCopySubDir, overCopy, filterExtension);
                    }

                    else
                    {
                        File.Copy(file, aimPath + Path.GetFileName(file), overCopy);
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                return false;
            }
        }

        /// <summary>
        /// 生成文件
        /// </summary>
        /// <param name="savePagePath">网站根目录路径</param>
        /// <param name="savePagePath">要保存的文件路径</param>
        /// <param name="writeCode">生成文件所使用的编码</param>
        /// <param name="strContent">要生成的内容</param>
        public static bool WriteFile(string savePagePath, string writeCode, string strContent)
        {
            try
            {
                string mapSavePagePathName;                                                                 //要保存的物路径
                Encoding enWriteCode = Encoding.GetEncoding(writeCode);                                     //生成文件所使用的编码方式
                mapSavePagePathName = Utils.ParseUrl.GetMapPath(savePagePath);                              //要保存的物路径
                StreamWriter streamWriter = new StreamWriter(mapSavePagePathName, false, enWriteCode);
                streamWriter.Write(strContent);
                streamWriter.Flush();
                streamWriter.Close();
                streamWriter.Dispose();
                return true;
            }
            catch (Exception oExcept)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Tools.Terminator().Throw(oExcept.Message);
                }
                else
                {
                    MessageBox.Show(oExcept.Message, "发生错误");
                }
                return false;
            }
        }

        /// <summary>
        /// 将\\转换成：/
        /// </summary>
        /// <returns></returns>
        public static string ConvertPath(string path)
        {
            return path.Replace("\\", "/");
        }
    }
}
