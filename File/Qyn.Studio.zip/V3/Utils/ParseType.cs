﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using System.Data;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 类型转换
    /// </summary>
    public class ParseType
    {
        /// <summary> 
        /// 将某个对像转换成指定对像
        /// </summary>
        public static T ConvertType<T>(object objValue, T defValue)
        {
            if (objValue == null) { return defValue; }
            Type type = typeof(T);
            try
            {
                if (type.IsEnum) { return (T)Enum.Parse(typeof(T), objValue.ToString()); }
                else { return (T)Convert.ChangeType(objValue, type); }
            }
            catch

            { return defValue; }
        }

        /// <summary>
        /// 转换为简体中文
        /// </summary>
        public static string ToSChinese(string str)
        {
            return Strings.StrConv(str, VbStrConv.SimplifiedChinese, 0);
        }

        /// <summary>
        /// 转换为繁体中文
        /// </summary>
        public static string ToTChinese(string str)
        {
            return Strings.StrConv(str, VbStrConv.TraditionalChinese, 0);
        }

        /// <summary>
        /// 将全角数字转换为数字
        /// </summary>
        /// <param name="SBCCase"></param>
        /// <returns></returns>
        public static string SBCCaseToNumberic(string SBCCase)
        {
            char[] c = SBCCase.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                byte[] b = System.Text.Encoding.Unicode.GetBytes(c, i, 1);
                if (b.Length == 2)
                {
                    if (b[1] == 255)
                    {
                        b[0] = (byte)(b[0] + 32);
                        b[1] = 0;
                        c[i] = System.Text.Encoding.Unicode.GetChars(b)[0];
                    }
                }
            }
            return new string(c);
        }

        /// <summary>
        /// 将字符串转换为Color
        /// </summary>
        /// <param name="color"></param>
        /// <returns></returns>
        public static Color ToColor(string color)
        {
            int red, green, blue = 0;
            char[] rgb;
            color = color.TrimStart('#');
            color = Regex.Replace(color.ToLower(), "[g-zG-Z]", "");
            switch (color.Length)
            {
                case 3:
                    rgb = color.ToCharArray();
                    red = Convert.ToInt32(rgb[0].ToString() + rgb[0].ToString(), 16);
                    green = Convert.ToInt32(rgb[1].ToString() + rgb[1].ToString(), 16);
                    blue = Convert.ToInt32(rgb[2].ToString() + rgb[2].ToString(), 16);
                    return Color.FromArgb(red, green, blue);
                case 6:
                    rgb = color.ToCharArray();
                    red = Convert.ToInt32(rgb[0].ToString() + rgb[1].ToString(), 16);
                    green = Convert.ToInt32(rgb[2].ToString() + rgb[3].ToString(), 16);
                    blue = Convert.ToInt32(rgb[4].ToString() + rgb[5].ToString(), 16);
                    return Color.FromArgb(red, green, blue);
                default:
                    return Color.FromName(color);

            }
        }

        /// <summary>
        /// string[]型转为string型
        /// </summary>
        public static string StrArrayToString(string[] strArray)
        {
            string str = "";
            if (strArray != null)
            {
                for (int i = 0; i < strArray.Length; i++)
                {
                    str += strArray[i];
                }
            }
            return str;
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string NumberFormat(int number, bool isHaveTag, int len)
        {
            string str = string.Empty;
            if (isHaveTag) { str = "￥"; }
            str += number.ToString(string.Format("n{0}", len));
            return str;
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string NumberFormat(decimal number, bool isHaveTag, int len)
        {
            string str = string.Empty;
            if (isHaveTag) { str = "￥"; }
            str += number.ToString(string.Format("n{0}", len));
            return str;
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string NumberFormat(double number, bool isHaveTag, int len)
        {
            string str = string.Empty;
            if (isHaveTag) { str = "￥"; }
            str += number.ToString(string.Format("n{0}", len));
            return str;
        }
    }
}
