﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 编码工具
    /// </summary>
    public class ParseEncode
    {
        #region 文本编码 	public static string TextEncode(string s)
        /// <summary>
        /// 文本编码
        ///</summary>
        public static string TextEncode(string s)
        {
            if (null == s || 0 == s.Length)
            {
                return string.Empty;
            }

            StringBuilder sb = new StringBuilder(s);
            sb.Replace("&", "&amp;");
            sb.Replace("<", "&lt;");
            sb.Replace(">", "&gt;");
            sb.Replace("\"", "&quot;");
            sb.Replace("\'", "&#39;");
            return Utils.ParseEncode.ShitEncode(sb.ToString());
        }
        #endregion

        #region HTML 编码 public static string HtmlEncode(string s)
        /// <summary>
        /// HTML 编码
        ///</summary>
        ///<param name="s">要编码的字符串</param>
        public static string HtmlEncode(string s)
        {
            return HtmlEncode(s, false);
        }

        /// <summary>
        /// HtmlEncode
        /// </summary>
        /// <param name="s">要编码的字符串</param>
        /// <param name="bln">是否过滤脏字</param>
        /// <returns></returns>
        public static string HtmlEncode(string s, bool bln)
        {
            if (string.IsNullOrEmpty(s)) { return string.Empty; }

            StringBuilder sb = new StringBuilder(s);
            sb.Replace("&", "&amp;");
            sb.Replace("<", "&lt;");
            sb.Replace(">", "&gt;");
            sb.Replace("\"", "&quot;");
            sb.Replace("\'", "&#39;");

            if (bln)
            {
                return Utils.ParseEncode.ShitEncode(sb.ToString());
            }
            else
            {
                return sb.ToString();
            }
        }
        #endregion

        #region HTML 解码 public static string HtmlDecode(string s)
        /// <summary>
        /// HTML 解码
        ///</summary>
        public static string HtmlDecode(string s)
        {
            StringBuilder sb = new StringBuilder(s);
            sb.Replace("&amp;", "&");
            sb.Replace("&lt;", "<");
            sb.Replace("&gt;", ">");
            sb.Replace("&quot;", "\"");
            sb.Replace("&#39;", "'");

            return sb.ToString();
        }
        #endregion

        #region Email 编码 public static string EmailEncode(string s)
        /// <summary>
        /// Email 编码
        /// </summary>
        public static string EmailEncode(string s)
        {
            string email = (TextEncode(s)).Replace("@", "&#64;").Replace(".", "&#46;");

            return string.Format("<a href='mailto:{0}'>{0}</a>",email);
        }
        #endregion

        #region JavaScript 编码 public static string JavaScriptEncode(string str)
        /// <summary>
        /// JavaScript 编码
        /// </summary>
        public static string JavaScriptEncode(string str)
        {
            StringBuilder sb = new StringBuilder(str);
            sb.Replace("\\", "\\\\");
            sb.Replace("\r", "\\0Dx");
            sb.Replace("\n", "\\x0A");
            sb.Replace("\"", "\\x22");
            sb.Replace("\'", "\\x27");
            return sb.ToString();
        }
        #endregion

        #region JavaScript 编码 public static string JavaScriptEncode(object obj)
        /// <summary>
        /// JavaScript 编码
        /// </summary>
        public static string JavaScriptEncode(object obj)
        {
            if (null == obj)
            {
                return string.Empty;
            }
            return JavaScriptEncode(obj.ToString());
        }
        #endregion

        #region 过滤脏词 public static string ShitEncode(string s)
        /// <summary>
        /// 过滤脏词，默认有为“妈的|你妈|他妈|妈b|妈比|fuck|shit|我日|法轮|我操”
        /// 可以在 bbs.config 里设置 BadWords 的值
        /// </summary>
        public static string ShitEncode(string s)
        {
            //string bw = Config.Settings["BadWords"];
            string bw = "";
            if (bw == null || 0 == bw.Length)
            {
                bw = "妈的|你妈|他妈|妈b|妈比|fuck|shit|我日|法轮|我操";
            }
            else
            {
                bw = Regex.Replace(bw, @"\|{2,}", "|");
                bw = Regex.Replace(bw, @"(^\|)|(\|$)", string.Empty);
            }
            return Regex.Replace(s, bw, "**", RegexOptions.IgnoreCase);
        }
        #endregion

    }
}
 