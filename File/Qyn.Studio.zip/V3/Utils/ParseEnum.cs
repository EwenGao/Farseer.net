﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 枚举
    /// </summary>
    public class ParseEnum
    {
        /// <summary>
        /// 缓存列表
        /// </summary>
        public static Dictionary<string, string> dicEnum = new Dictionary<string, string>();

        ///   <summary>   
        ///   获取枚举值的详细文本   
        ///   </summary>    
        public static string GetDescription(Type enumType,string enumName)
        {
            string key = string.Format("{0}.{1}", enumType.Name, enumName);

            if (dicEnum.ContainsKey(key)) { return dicEnum[key]; }

            //获取字段信息   
            System.Reflection.FieldInfo[] ms = enumType.GetFields();

            foreach (System.Reflection.FieldInfo f in ms)
            {
                //判断名称是否相等   
                if (f.Name != enumName) continue;

                //反射出自定义属性   
                foreach (Attribute attr in f.GetCustomAttributes(true))
                {
                    //类型转换找到一个Description，用Description作为成员名称   
                    System.ComponentModel.DescriptionAttribute dscript = attr as System.ComponentModel.DescriptionAttribute;
                    if (dscript != null) 
                    {
                        dicEnum.Add(key, dscript.Description);
                        return dscript.Description; 
                    }
                }

            }

            //如果没有检测到合适的注释，则用默认名称   
            return enumName;
        }

        /// <summary>
        /// 获取枚举列表
        /// </summary>
        public static Dictionary<int, string> GetList(Type enumType)
        {
            Dictionary<int, string> dic = new Dictionary<int, string>();
            foreach (byte value in Enum.GetValues(enumType))
            {
                dic.Add(value, GetDescription(enumType, Enum.GetName(enumType, value)));
            }
            return dic;
        }
    }
}
