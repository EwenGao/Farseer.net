﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Collections;
using Qyn.Studio.Controls;
using System.Windows.Forms;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 绑定
    /// </summary>
    public class ParseBind
    {
        /// <summary>
        /// 枚举转ListItem
        /// </summary>
        private static List<ListItem> GetEnumList(Type enumType)
        {
            List<ListItem> lst = new List<ListItem>();

            foreach (KeyValuePair<int,string> dic in ParseEnum.GetList(enumType))
            {
                ListItem listitem = new ListItem(dic.Value, dic.Key.ToString());
                lst.Add(listitem);
            }

            return lst;
        }

        #region WebForm
        /// <summary>
        /// WebControl插入第一行提示显示项
        /// </summary>
        private static void WebControlInsertItems(ListItemCollection listItem, string defShowText, object defShowValue)
        {
            if (!string.IsNullOrEmpty(defShowText) || !string.IsNullOrEmpty(defShowValue.ToString()))
            {
                listItem.Insert(0, new ListItem() { Text = defShowText, Value = defShowValue.ToString() });
            }
        }

        /// <summary>
        /// WebControl选则指定项
        /// </summary>
        public static void WebControlSelectedItem(System.Web.UI.WebControls.ListControl control, object selectedValue)
        {
            string selValue = string.Empty;

            if (selectedValue is Enum) { selValue = Convert.ToString((byte)selectedValue); }

            else { selValue = selectedValue.ToString(); }

            if (control.Items.FindByValue(selValue) != null)
            {
                control.SelectedIndex = -1;
                control.SelectedValue = null;
                control.Items.FindByValue(selValue).Selected = true;
            }
        }

        #region Repeater

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">System.Web.UI.WebControls.Repeater</param>
        /// <param name="type">枚举</param>
        public static void Repeater(System.Web.UI.WebControls.Repeater rpt, Type type)
        {
            rpt.DataSource =ParseEnum.GetList(type);
            rpt.DataBind();
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">System.Web.UI.WebControls.Repeater</param>
        /// <param name="Info">List列表</param>
        public static void Repeater(System.Web.UI.WebControls.Repeater rpt, IEnumerable Info)
        {
            rpt.DataSource = Info;
            rpt.DataBind();
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">Repeater</param>
        /// <param name="paginationControl">分页控件：Qyn.Studio.Controls.Pagination</param>
        /// <param name="recordCount">记录总数</param>
        /// <param name="Info">IEnumerable</param>
        public static void Repeater(System.Web.UI.WebControls.Repeater rpt, Pagination paginationControl, IEnumerable Info, int recordCount)
        {
            rpt.DataSource = Info;
            rpt.DataBind();

            paginationControl.PageCount = recordCount;
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        public static void Repeater(Qyn.Studio.Controls.Repeater rpt, IEnumerable Info)
        {
            rpt.DataSource = Info;
            rpt.DataBind();
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">Qyn.Studio.Controls.Repeater</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">记录总数</param>
        /// <param name="Info">IEnumerable</param>
        public static void Repeater(Qyn.Studio.Controls.Repeater rpt, IEnumerable Info, int recordCount)
        {
            rpt.DataSource = Info;
            rpt.DataBind();

            rpt.PageCount = recordCount;
        }
        #endregion

        #region WebControl
        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info)
        {
            WebControl(control, Info, "Caption", "ID");
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="dataTextField">绑定的文本字段</param>
        /// <param name="dataValueField">绑定的值字段</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, string dataTextField, string dataValueField)
        {
            control.DataSource = Info;
            control.DataTextField = dataTextField;
            control.DataValueField = dataValueField;
            control.DataBind();
            if (control.Items.Count > 0) { control.SelectedIndex = 0; }
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="dataTextField">绑定的文本字段</param>
        /// <param name="dataValueField">绑定的值字段</param>
        /// <param name="defShowText">第一行显示的文字</param>
        /// <param name="defShowValue">第一行显示的值</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, string dataTextField, string dataValueField,
                                      string defShowText, object defShowValue, object selectedValue)
        {
            WebControl(control, Info, dataTextField, dataValueField);
            WebControlInsertItems(control.Items,defShowText, defShowValue);
            WebControlSelectedItem(control, selectedValue);
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info,object selectedValue)
        {
            WebControl(control, Info, "Caption", "ID", "", "", selectedValue);
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="dataTextField">绑定的文本字段</param>
        /// <param name="dataValueField">绑定的值字段</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, string dataTextField, string dataValueField,object selectedValue)
        {
            WebControl(control, Info, dataTextField, dataValueField, "", "", selectedValue);
        }

        /// <summary>
        /// Eume绑定到WebControl
        /// </summary>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, Type type)
        {
            control.DataSource = GetEnumList(type);
            control.DataValueField = "Value";
            control.DataTextField = "Text";
            control.DataBind();
            if (control.Items.Count > 0) { control.SelectedIndex = 0; }
            
        }

        /// <summary>
        /// Eume绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="type">枚举的Type</param>
        /// <param name="defShowText">第一行要显示的文字</param>
        /// <param name="defShowValue">第一行要显示的值</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, Type type,
                                      string defShowText, object defShowValue, object selectedValue)
        {
            WebControl(control, type);
            WebControlInsertItems(control.Items, defShowText, defShowValue);
            WebControlSelectedItem(control, selectedValue);
        }

        /// <summary>
        /// Eume绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="type">枚举的Type</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, Type type, object selectedValue)
        {
            WebControl(control, type);
            WebControlSelectedItem(control, selectedValue);
        }

        #endregion

        #endregion

        #region WinForm

        public static void WinControl(System.Windows.Forms.ListControl control, IEnumerable Info, string displayMember, string valueMember)
        {
            control.DisplayMember = displayMember;
            control.ValueMember = valueMember;

            control.DataSource = Info;
        }

        #endregion
    }
}
