﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 解释字符串
    /// </summary>
    public class ParseString
    {
        private static Regex RegexBr = new Regex(@"(\r\n)", RegexOptions.IgnoreCase);

        /// <summary>
        /// 返回字符串真实长度, 1个汉字长度为2
        /// </summary>
        /// <returns></returns>
        public static int Length(string str)
        {
            return Encoding.Default.GetBytes(str).Length;
        }

        /// <summary>
        /// 判断指定字符串在指定字符串数组中的位置
        /// </summary>
        /// <param name="searchText">要查找字符串</param>
        /// <param name="strArr">字符串数组</param>
        /// <param name="ignoreCase">是否不区分大小写, true为不区分, false为区分</param>
        /// <returns>字符串在指定字符串数组中的位置, 如不存在则返回-1</returns>
        public static int GetArrayIndex(string searchText, string[] strArr, bool ignoreCase)
        {
            for (int i = 0; i < strArr.Length; i++)
            {
                if (string.Compare(searchText, strArr[i], ignoreCase) == 0) { return i; }
            }
            return -1;
        }

        /// <summary>
        /// 删除字符串尾部的回车/换行/空格
        /// </summary>
        public static string RTrim(string str)
        {
            str = str.TrimEnd(' ');
            str = DelEndOf(str, "\r");
            str = DelEndOf(str, "\n");
            str = DelEndOf(str, "\r\n");
            return str;
        }

        /// <summary>
        /// 从字符串的指定位置截取指定长度的子字符串
        /// </summary>
        /// <param name="str">原字符串</param>
        /// <param name="startIndex">子字符串的起始位置</param>
        /// <param name="length">子字符串的长度(负数，则获取全部)</param>
        public static string SubString(string str, int startIndex, int length)
        {
            if (str.Length < startIndex + 1) { return string.Empty; }

            if (length < 1) { return str.Substring(startIndex); }
            if (str.Length < startIndex + length) { return str.Substring(startIndex); }

            return str.Substring(startIndex, length);

        }

        /// <summary>
        /// 截取到tag字符串
        /// </summary>
        public static string SubString(string str, string tag)
        {
            if (str.IndexOf(tag) > -1) { return str.Substring(0, str.IndexOf(tag)); }
            return str;
        }

        /// <summary>
        /// 格式化字节数字符串
        /// </summary>
        /// <param name="bytes"></param>
        /// <returns></returns>
        public static string FormatBytesStr(int bytes)
        {
            if (bytes > 1073741824)
            {
                return ((double)(bytes / 1073741824)).ToString("0") + "G";
            }
            if (bytes > 1048576)
            {
                return ((double)(bytes / 1048576)).ToString("0") + "M";
            }
            if (bytes > 1024)
            {
                return ((double)(bytes / 1024)).ToString("0") + "K";
            }
            return bytes.ToString() + "Bytes";
        }

        /// <summary>
        /// 获取指定的代码,带开始结束标记  （注意 "@@-@" 代表一切任意字符  返回空串 表示没有找到）
        /// </summary>
        /// <param name="sourceCode">获取的代码</param>
        /// <param name="startString">开始的代码</param>
        /// <param name="endString">结束的代码</param>
        /// <returns></returns>
        public static string GetStringByTag(string sourceCode, string startTag, string endTag)
        {
            //  "@@-@" 代表一切任意字符
            //  "[\v\f\r\n]+"  代表 回车符、换行符、空格等

            try
            {
                string start = Regex.Escape(Regex.Replace(startTag, "[\v\f\r\n]+", "", RegexOptions.IgnoreCase)).Replace("@@-@", ".{0,}?");
                string end = Regex.Escape(Regex.Replace(endTag, "[\v\f\r\n]+", "", RegexOptions.IgnoreCase)).Replace("@@-@", ".{0,}?");
                Regex reg = new Regex(start + ".{0,}?" + end, RegexOptions.IgnoreCase);
                MatchCollection mc = reg.Matches(Regex.Replace(sourceCode, "[\v\f\r\n]+", "", RegexOptions.IgnoreCase));

                foreach (Match match in mc)
                {
                    foreach (Group group in match.Groups)
                    {
                        foreach (Capture capture in group.Captures)
                        {
                            return capture.Value;

                        }
                    }
                }

                return "";
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// 获取指定标签内的内容
        /// </summary>
        /// <param name="str">内容</param>
        /// <param name="beforeTag">开始标签</param>
        /// <param name="endTag">结尾标签</param>
        /// <returns>有用信息</returns>
        public static string GetString(string str, string beforeTag, string endTag)
        {
            string[] s = GetStringArray(str, beforeTag, endTag);
            if (s.Length == 0) return string.Empty;
            return s[0];
        }

        /// <summary>
        /// 获取一个字符串指定标签的内容
        /// </summary>
        /// <param name="str">要搜寻的字符串</param>
        /// <param name="beforeTag">开头的标签</param>
        /// <param name="endTag">结尾的标签</param>
        /// <returns></returns>
        public static string[] GetStringArray(string str, string beforeTag, string endTag)
        {

            List<string> list = new List<string>();
            int bLen = beforeTag.Length;
            int eLen = endTag.Length;
            string temp = string.Empty;
            int index = 0;
            int indexBefore = 0;
            int indexEnd = 0;
            bool findBefore = false;
            bool findEnd = false;
            int cursor = 0;
            foreach (char c in str)
            {
                if (!findBefore)
                {
                    // 寻找开始的标签
                    if (index < bLen)
                    {
                        temp += c.ToString();
                        index++;
                    }
                    else
                    {
                        temp += c.ToString();
                        temp = temp.Substring(1);
                    }
                }
                else
                {
                    // 已经找到了开始的标签
                    if (index < eLen)
                    {
                        temp += c.ToString();
                        index++;
                    }
                    else
                    {
                        temp += c.ToString();
                        temp = temp.Substring(1);
                    }
                }
                cursor++;

                if (temp == beforeTag) { findBefore = true; indexBefore = cursor; temp = ""; index = 0; }
                if (findBefore && temp == endTag) { findEnd = true; indexEnd = cursor; }
                if (findBefore && findEnd)
                {
                    list.Add(str.Substring(indexBefore, indexEnd - indexBefore - eLen));
                    findBefore = findEnd = false;
                    indexBefore = indexEnd = 0;
                }

            }
            string[] s = new string[list.Count];
            for (int i = 0; i < list.Count; i++)
                s[i] = list[i];
            return s;
        }

        /// <summary>
        /// 指定清除标签的内容
        /// </summary>
        /// <param name="str">内容</param>
        /// <param name="tag">标签</param>
        /// <returns></returns>
        public static string ClearString(string str, string tag)
        {
            return str.Replace(tag, "");
        }

        /// <summary>
        /// 过滤脏词，默认有为“妈的|你妈|他妈|妈b|妈比|fuck|shit|我日|法轮|我操”
        /// 可以在 bbs.config 里设置 BadWords 的值
        /// </summary>
        public static string ShitEncode(string s)
        {
            //string bw = Config.Settings["BadWords"];
            string bw = "";
            if (bw == null || 0 == bw.Length)
            {
                bw = "妈的|你妈|他妈|妈b|妈比|fuck|shit|我日|法轮|我操";
            }
            else
            {
                bw = Regex.Replace(bw, @"\|{2,}", "|");
                bw = Regex.Replace(bw, @"(^\|)|(\|$)", string.Empty);
            }
            return Regex.Replace(s, bw, "**", RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// 将字符串转换成List型
        /// </summary>
        /// <param name="str">要转换的字符串</param>
        /// <param name="splitString">分隔符为NullOrEmpty时，则直接拆份为Char</param>
        /// <param name="defValue">默认值(单项转换失败时，默认值为NullOrEmpty时，则不添加，否则替换为默认值)</param>
        public static List<T> ToList<T>(string str, string splitString, T defValue)
        {
            List<T> lst = new List<T>();

            string[] strArray;

            if (string.IsNullOrEmpty(str)) { return lst; }

            strArray = new string[str.Length];
            //判断是否带分隔符，如果没有。则直接拆份单个Char
            if (string.IsNullOrEmpty(splitString))
            {
                char[] c = str.ToCharArray();
                for (int i = 0; i < c.Length; i++)
                {
                    strArray[i] = ParseType.ConvertType(c[i], "");
                }
            }

            else { strArray = Regex.Split(str, Regex.Escape(splitString), RegexOptions.IgnoreCase); }

            foreach (string s in strArray)
            {
                if (s.IsType<T>()) { lst.Add(s.ConvertType(default(T))); }
                else if (defValue != null) { lst.Add(defValue); }
            }

            return lst;

        }

        /// <summary>
        /// 将字符串转换成List型
        /// </summary>
        /// <param name="str">要转换的字符串</param>
        /// <param name="splitString">分隔符为NullOrEmpty时，则直接拆份为Char</param>
        /// <param name="defValue">默认值(单项转换失败时，默认值为NullOrEmpty时，则不添加，否则替换为默认值)</param>
        public static T[] ToArray<T>(string str, string splitString, T defValue)
        {
            T[] lst;

            string[] strArray;

            if (string.IsNullOrEmpty(str)) { return null; }
            strArray = new string[str.Length];
            //判断是否带分隔符，如果没有。则直接拆份单个Char
            if (string.IsNullOrEmpty(splitString))
            {
                char[] c = str.ToCharArray();
                for (int i = 0; i < c.Length; i++)
                {
                    strArray[i] = ParseType.ConvertType(c[i], "");
                }
            }

            else { strArray = Regex.Split(str, Regex.Escape(splitString), RegexOptions.IgnoreCase); }

            lst = new T[strArray.Length];

            for (int i = 0; i < strArray.Length; i++)
            {
                if (strArray[i].IsType<T>()) { lst[i] = strArray[i].ConvertType(default(T)); }
                else if (defValue != null) { lst[i] = defValue; }
            }

            return lst;

        }

        /// <summary>
        /// 指定索引范围，替换字段串
        /// </summary>
        /// <returns></returns>
        public static string ReplaceString(string source, string str, int startIndex, int endIndex)
        {
            if (startIndex == -1 || endIndex == -1) { return source; }
            source = source.Substring(0, startIndex) + str + source.Substring(endIndex);
            return source;
        }

        /// <summary>
        /// 指定字符串开始，结束标记范围，替换字段串(未测试)
        /// </summary>
        /// <param name="sourceCode">原文内容</param>
        /// <param name="content">要替换的内容</param>
        /// <param name="startString">开始标记</param>
        /// <param name="endString">结束标记</param>
        /// <returns></returns>
        public static string ReplaceString(string sourceCode, string content, string startTag, string endTag)
        {
            //  "@@-@" 代表一切任意字符
            //  "[\v\f\r\n]+"  代表 回车符、换行符、空格等
            string list = "";
            try
            {

                string start = Regex.Escape(Regex.Replace(startTag, "[\v\f\r\n]+", "", RegexOptions.IgnoreCase)).Replace("@@-@", ".{0,}?");
                string end = Regex.Escape(Regex.Replace(endTag, "[\v\f\r\n]+", "", RegexOptions.IgnoreCase)).Replace("@@-@", ".{0,}?");
                Regex reg = new Regex(start + ".{0,}?" + end, RegexOptions.IgnoreCase);
                MatchCollection mc = reg.Matches(Regex.Replace(sourceCode, "[\v\f\r\n]+", content, RegexOptions.IgnoreCase));

                foreach (Match match in mc)
                {
                    foreach (Group group in match.Groups)
                    {
                        foreach (Capture capture in group.Captures)
                        {
                            list = list + capture.Value;
                        }
                    }
                }


                list = Regex.Replace(Regex.Replace(list, start, "", RegexOptions.IgnoreCase), end, "", RegexOptions.IgnoreCase);
            }
            catch
            {
                return "";
            }
            return list;


        }

        /// <summary>
        /// 自定义的替换字符串函数
        /// </summary>
        public static string ReplaceString(string SourceString, string SearchString, string ReplaceString, bool IsCaseInsensetive)
        {
            return Regex.Replace(SourceString, Regex.Escape(SearchString), ReplaceString, IsCaseInsensetive ? RegexOptions.IgnoreCase : RegexOptions.None);
        }

        /// <summary>
        /// 删除指定最后的字符串
        /// </summary>
        public static string DelLastOf(string str, string strChar)
        {
            int length = str.LastIndexOf(strChar);
            if (length > 0)
            {
                str = str.Substring(0, length);
            }
            return str.ToString();
        }

        /// <summary>
        /// 删除指定最后的字符串
        /// </summary>
        public static string DelEndOf(string str, string strChar)
        {
            if (str.ToLower().EndsWith(strChar.ToLower()))
            {
                int index = str.ToLower().LastIndexOf(strChar.ToLower());
                if (index > -1) { str = str.Substring(0, index); }
            }
            return str;
        }

        /// <summary>
        /// 删除指定开头的字符串
        /// </summary>
        public static string DelStartsOf(string str, string strChar)
        {
            if (str.ToLower().StartsWith(strChar.ToLower()))
            {
                int index = str.ToLower().IndexOf(strChar.ToLower());
                if (index > -1) { str = str.Substring(index + strChar.Length); }
            }
            return str;
        }

        /// <summary>
        /// 位数补齐,不足长度，前面补0
        /// </summary>
        public static string NumberString(int value, string enoughString, int lenght)
        {
            string str = value.ToString();
            while (true)
            {
                if (str.Length >= lenght) { break; }
                str = enoughString + str;
            }
            return str;
        }

        /// <summary>
        /// 转换标签，将","," "转换成"|"
        /// </summary>
        public static string ConvertTag(string str)
        {
            return ClearDbTag(str.Replace(" ", "|").Replace(",", "|"), "|");
        }

        /// <summary>
        /// 清理重复出现的标签
        /// </summary>
        public static string ClearDbTag(string str, string tag)
        {
            string strs = string.Empty;
            foreach (string s in str.Split(tag.ToCharArray()))
            {
                if (string.IsNullOrEmpty(s)) { continue; }
                strs += s + tag;
            }
            return DelEndOf(str, tag);
        }

        /// <summary>
        /// 截取字符串长，超过指定长度，用tag代替。
        /// 一个汉字，长度为2
        /// </summary>
        public static string CutString(string str, int length, string tag)
        {
            if (str.Length >= length) { return SubString(str, 0, length) + tag; }
            return str;
        }

        /// <summary>
        /// 字符串Split
        /// </summary>
        public static string[] Split(string str, string splitString)
        {
            return str.Split(new string[1] { splitString }, StringSplitOptions.None);
        }

        /// <summary>
        /// 填充指定数量的Tag
        /// </summary>
        public static string FillTag(int tagNum, string tag)
        {
            StringBuilder str = new StringBuilder();
            for (int i = 0; i < tagNum; i++)
            {
                str.Append(tag);
            }
            return str.ToString();
        }

        /// <summary>
        /// 条件相等，输出字符串
        /// </summary>
        public static string BoolToString(bool b, bool result, string str)
        {
            return b == result ? str : string.Empty;
        }

        /// <summary>
        /// 检测Email
        /// </summary>
        /// <param name="strEmail"></param>
        /// <returns></returns>
        public static string GetEmailHostName(string strEmail)
        {
            if (strEmail.IndexOf("@") < 0)
            {
                return "";
            }
            return strEmail.Substring(strEmail.LastIndexOf("@")).ToLower();
        }

        /// <summary>
        /// 转全角的函数(SBC case) 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string ToSBC(string input)
        {
            //半角转全角： 
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 32)
                {
                    c[i] = (char)12288;
                    continue;
                }
                if (c[i] < 127)
                    c[i] = (char)(c[i] + 65248);
            }
            return new string(c);
        }


        /// <summary>
        /// 转半角的函数(DBC case) 
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static string ToDBC(string input)
        {
            char[] c = input.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                if (c[i] == 12288)
                {
                    c[i] = (char)32;
                    continue;
                }
                if (c[i] > 65280 && c[i] < 65375)
                    c[i] = (char)(c[i] - 65248);
            }
            return new string(c);
        }

        /// <summary>
        /// 比较两者是否相等，不考虑大小写
        /// </summary>
        /// <param name="str">对比一</param>
        /// <param name="str2">对比二</param>
        /// <returns></returns>
        public static bool IsEquals(string str, string str2)
        {
            return string.Compare(str, str2, true) == 0;
        }
    }
}
