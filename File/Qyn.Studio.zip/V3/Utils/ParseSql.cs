﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.ComponentModel;
using Qyn.Studio.Extend;
using Qyn.Studio.Data;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 检测Sql语句
    /// </summary>
    public class ParseSql
    {
        /// <summary>
        /// 改正sql语句中的转义字符
        /// </summary>
        public static string mashSQL(string str)
        {
            string str2;

            if (str == null)
            {
                str2 = "";
            }
            else
            {
                str = str.Replace("\'", "'");
                str2 = str;
            }
            return str2;
        }

        /// <summary>
        /// 替换sql语句中的有问题符号
        /// </summary>
        public static string ChkSQL(string str)
        {
            string str2;

            if (str == null)
            {
                str2 = "";
            }
            else
            {
                str = str.Replace("'", "''");
                str2 = str;
            }
            return str2;
        }

        /// <summary>
        /// 检测是否有Sql危险字符
        /// </summary>
        /// <param name="str">要判断字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsSafeSqlString(string str)
        {

            return !Regex.IsMatch(str, @"[-|;|,|\/|\(|\)|\[|\]|\}|\{|%|@|\*|!|\']");
        }

        #region In、Not In
        /// <summary>
        /// 运算符(In、Not In)
        /// </summary>
        public enum eumIn : byte
        {
            /// <summary>
            /// In
            /// </summary>
            [Description("In")]
            In,
            /// <summary>
            /// Not In
            /// </summary>
            [Description("Not In")]
            NotIn
        }

        /// <summary>
        /// 获取Sql 条件语句(In、Not In)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="lst">条件值列表</param>
        /// <returns></returns>
        public static string GetCondition(eumIn operate, string filedName, List<int> lst)
        {
            string sql = string.Empty;

            switch (operate)
            {
                case eumIn.In:
                    {
                        sql = string.Format("[{0}] IN ({1})", filedName, lst.ToString(","));
                        break;
                    }
                case eumIn.NotIn:
                    {
                        sql = string.Format("[{0}] NOT IN ({1})", filedName, lst.ToString(","));
                        break;
                    }
            }

            return sql;
        }

        /// <summary>
        /// 获取Sql 条件语句(In、Not In)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="lst">条件值列表</param>
        /// <returns></returns>
        public static string GetCondition(eumIn operate, string filedName, List<string> lst)
        {
            string sql = string.Empty;

            switch (operate)
            {
                case eumIn.In:
                    {
                        sql = string.Format("[{0}] IN ('{1}')", filedName, lst.ToString("','"));
                        break;
                    }
                case eumIn.NotIn:
                    {
                        sql = string.Format("[{0}] NOT IN ('{1}')", filedName, lst.ToString("','"));
                        break;
                    }
            }

            return sql;
        }

        /// <summary>
        /// 获取Sql 条件语句(In、Not In)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="ids">条件值字符串，如果引用的值是非数字，则发音在两端加'符号</param>
        /// <returns></returns>
        public static string GetCondition(eumIn operate, string filedName, string ids)
        {
            string sql = string.Empty;

            switch (operate)
            {
                case eumIn.In:
                    {
                        sql = string.Format("[{0}] IN ({1})", filedName, ids);
                        break;
                    }
                case eumIn.NotIn:
                    {
                        sql = string.Format("[{0}] NOT IN ({1})", filedName, ids);
                        break;
                    }
            }

            return sql;
        }

        #endregion

        #region Between And

        /// <summary>
        /// 运算符
        /// </summary>
        public enum eumBetween : byte
        {
            /// <summary>
            /// Between And
            /// </summary>
            [Description("Between And")]
            Between
        }

        /// <summary>
        /// 获取Sql 条件语句(Between And)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="leftFiledValue">数字区间下限</param>
        /// <param name="rightFieldValue">数字区间上限</param>
        /// <returns></returns>
        public static string GetCondition(eumBetween operate, string filedName, int leftFiledValue, int rightFieldValue)
        {
            return string.Format("[{0}] BETWEEN {1} AND {2}", filedName, leftFiledValue, rightFieldValue);
        }

        /// <summary>
        /// 获取Sql 条件语句(Between And)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="leftFiledValue">字符串区间下限</param>
        /// <param name="rightFieldValue">字符串间上限</param>
        /// <returns></returns>
        public static string GetCondition(eumBetween operate, string filedName, string leftFiledValue, string rightFieldValue)
        {
            return string.Format("[{0}] BETWEEN '{1}' AND '{2}'", filedName, leftFiledValue, rightFieldValue);
        }

        /// <summary>
        /// 获取Sql 条件语句(Between And)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="leftFiledValue">时间区间下限</param>
        /// <param name="rightFieldValue">时间区间上限</param>
        /// <returns></returns>
        public static string GetCondition(eumBetween operate, string filedName, DateTime leftFiledValue, DateTime rightFieldValue)
        {
            return string.Format("[{0}] BETWEEN '{1}' AND '{2}'", filedName, leftFiledValue, rightFieldValue);
        }
        #endregion

        #region Like、NotLike

        /// <summary>
        /// 运算符
        /// </summary>
        public enum eumLike : byte
        {
            /// <summary>
            /// Like
            /// </summary>
            [Description("Like")]
            Like,
            /// <summary>
            /// Not Like
            /// </summary>
            [Description("Not Like")]
            NotLike
        }

        /// <summary>
        /// 获取Sql 条件语句(In、Not In)
        /// </summary>
        /// <param name="operate">操作符</param>
        /// <param name="dbType">数据库类型</param>
        /// <param name="filedName">字段名</param>
        /// <param name="filedValue">要搜索的值</param>
        /// <returns></returns>
        public static string GetCondition(eumLike operate,DataBaseType dbType, string filedName, string filedValue)
        {
            string sql = string.Empty;

            switch (operate)
            {
                case eumLike.Like:
                    {
                        if (dbType == DataBaseType.Access)
                        {
                            sql = string.Format("INSTR([{0}],'{1}') > 0", filedName, filedValue);
                        }
                        else
                        {
                            sql = string.Format("CHARINDEX('{1}',[{0}]) > 0", filedName, filedValue);
                        }
                        break;
                    }
                case eumLike.NotLike:
                    {
                        if (dbType == DataBaseType.Access)
                        {
                            sql = string.Format("INSTR([{0}],'{1}') = 0", filedName, filedValue);
                        }
                        else
                        {
                            sql = string.Format("CHARINDEX('{1}',[{0}]) = 0", filedName, filedValue);
                        }
                        break;
                    }
            }

            return sql;
        }

        #endregion

        #region >、>=、=、!=、<、<=

        /// <summary>
        /// 基本运算符
        /// </summary>
        public enum eumOperate : byte
        {
            /// <summary>
            /// 等于
            /// </summary>
            [Description("=")]
            Equal,
            /// <summary>
            /// 不等于
            /// </summary>
            [Description("<>")]
            NotEqual,
            /// <summary>
            /// 大于
            /// </summary>
            [Description(">")]
            GreaterThan,
            /// <summary>
            /// 大于等于
            /// </summary>
            [Description(">=")]
            GreaterThanEqual,
            /// <summary>
            /// 小于
            /// </summary>
            [Description("<")]
            LessThan,
            /// <summary>
            /// 小于等于
            /// </summary>
            [Description("<=")]
            LessThanEqual
        }

        /// <summary>
        /// 获取Sql 条件语句(In、Not In)
        /// </summary>
        /// <param name="operate">基本运算符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="filedValue">要搜索的值</param>
        /// <returns></returns>
        public static string GetCondition(eumOperate operate, string filedName, string filedValue)
        {
            return string.Format("[{0}] {1} '{2}'", filedName,operate.GetName(), filedValue);
        }

        /// <summary>
        /// 获取Sql 条件语句(In、Not In)
        /// </summary>
        /// <param name="operate">基本运算符</param>
        /// <param name="filedName">字段名</param>
        /// <param name="filedValue">要搜索的值</param>
        /// <returns></returns>
        public static string GetCondition(eumOperate operate, string filedName, int filedValue)
        {
            return string.Format("[{0}] {1} {2}", filedName, operate.GetName(), filedValue);
        }

        #endregion
        
    }
}
