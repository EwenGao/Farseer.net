﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// Web控制集合操作
    /// </summary>
    public class ParseWebControls
    {
        /// <summary>
        /// 返回Repeater选中的CheckBox的ID
        /// </summary>
        /// <param name="rpt">Repeater</param>
        public static List<int> GetRepeaterCheckBoxValue(Repeater rpt)
        {
            List<int> lst = new List<int>();
            int ID;
            foreach (RepeaterItem item in rpt.Items)
            {
                CheckBox chkItem = item.FindControl("chkItem") as CheckBox;
                if (chkItem.Checked)
                {
                    ID = chkItem.ToolTip.ConvertType(0);
                    lst.Add(ID);
                }
            }
            return lst;
        }

        /// <summary>
        /// 获取CheckBoxList的选中值
        /// </summary>
        /// <param name="chk">CheckBoxList</param>
        public static List<int> GetCheckBoxListValue(CheckBoxList chk)
        {
            List<int> lst = new List<int>();
            foreach (ListItem item in chk.Items)
            {
                if (item.Selected) { lst.Add(item.Value.ConvertType(0)); }
            }
            return lst;

        }
        /// <summary>
        /// 设置CheckBoxList的选中值
        /// </summary>
        /// <param name="chk">CheckBoxList</param>
        /// <param name="lst">要选中的值</param>
        public static void SetCheckBoxListSelected(CheckBoxList chk,List<int> lst)
        {
            foreach (ListItem item in chk.Items)
            {
                if (!item.Value.IsType<Int32>()) { continue; }
                item.Selected = lst.Exists(o => o == item.Value.ConvertType(0));
            }
        }
    }
}
