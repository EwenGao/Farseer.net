﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;
using Qyn.Studio.Tools;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// Cookies工具
    /// </summary>
    public class ParseCookies
    {
        private static string appPrefix = "Qyn_";

        /// <summary>
        /// 写cookie值(默认14天过期)
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        public static void Set(string strName, string strValue)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[appPrefix + strName];
            if (cookie == null) { cookie = new HttpCookie(appPrefix + strName); }

            cookie.Value = strValue;
            cookie.Expires = DateTime.Now.AddDays(14);

            string domain = QynRequest.GetUrl(QynRequest.UrlType.Domain).ClearString("http://");
            int index = domain.IndexOf(".");
            if (index > -1 && !ParseIsType.IsNumberString(domain.Split(':')[0], ".")) { cookie.Domain = domain.Substring(index + 1); }

            HttpContext.Current.Response.AppendCookie(cookie);
        }

        /// <summary>
        /// 写cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        /// <param name="expires">过期时间(分钟)</param>
        public static void Set(string strName, string strValue, int expires)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[appPrefix + strName];
            if (cookie == null) if (cookie == null) { cookie = new HttpCookie(appPrefix + strName); }

            cookie.Value = strValue;
            cookie.Expires = DateTime.Now.AddMinutes(expires);

            string domain = QynRequest.GetUrl(QynRequest.UrlType.Domain).ClearString("http://");
            int index = domain.IndexOf(".");
            if (index > -1 && !ParseIsType.IsNumberString(domain.Split(':')[0], ".")) { cookie.Domain = domain.Substring(index + 1); }

            HttpContext.Current.Response.AppendCookie(cookie);
        }

        /// <summary>
        /// 读cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="defValue">默认值</param>
        /// <returns>cookie值</returns>
        public static T Get<T>(string strName, T defValue)
        {
            if (HttpContext.Current.Request.Cookies != null && HttpContext.Current.Request.Cookies[appPrefix + strName] != null)
            {
                object value = HttpContext.Current.Request.Cookies[appPrefix + strName].Value;

                return ParseType.ConvertType<T>(value, defValue);

            }
            return defValue;
        }

        /// <summary>
        /// 移除cookie值
        /// </summary>
        /// <param name="strName">名称c</param>
        /// <returns></returns>
        public static void RemoveCookie(string strName)
        {
            Set(strName, "", -60 * 24);
        }

        /// <summary>
        /// 是否为有效域
        /// </summary>
        /// <param name="host">域名</param>
        /// <returns></returns>
        public static bool IsValidDomain(string host)
        {
            Regex r = new Regex(@"^\d+$");
            if (host.IndexOf(".") == -1)
            {
                return false;
            }
            return r.IsMatch(host.Replace(".", string.Empty)) ? false : true;
        }

    }
}
