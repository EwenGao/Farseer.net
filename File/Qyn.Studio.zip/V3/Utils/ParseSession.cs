﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.SessionState;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// Session工具
    /// </summary>
    public class ParseSession : IRequiresSessionState
    {
        private static string appPrefix = "Qyn_";

        /// <summary>
        /// 从 Session 读取 键为 name 的值
        /// </summary>
        /// <param name="name">SessionID</param>
        /// <param name="defValue">为空时返回的值</param>
        public static string Get(string name, string defValue)
        {
            return Get<string>(name, defValue);
        }

        /// <summary>
        /// 从 Session 读取 键为 name 的值
        /// </summary>
        /// <param name="name">SessionID</param>
        /// <param name="defValue">为空时返回的值</param>
        public static T Get<T>(string name,T defValue)
        {
            T t = defValue;
            object obj = HttpContext.Current.Session[appPrefix + name];
            if (obj != null) { t = ParseType.ConvertType<T>(obj, defValue); }
            
            return t;
        }

        /// <summary>
        /// 向 Session 保存 键为 name 的， 值为 value
        /// </summary>
        /// <param name="name">SessionID</param>
        /// <param name="value">插入的值</param>
        public static void Set(string name, object value)
        {
            HttpContext.Current.Session.Add(appPrefix + name, value);
        }

        /// <summary>
        /// 从 Session 删除 键为 name session 项
        /// </summary>
        /// <param name="name">SessionID</param>
        public static void Remove(string name)
        {
            if (HttpContext.Current.Session[appPrefix + name] != null)
            {
                HttpContext.Current.Session.Remove(appPrefix + name);
            }
        }

        /// <summary>
        /// 删除所有 session 项
        /// </summary>
        public static void RemoveAll()
        {
            HttpContext.Current.Session.RemoveAll();
        }

    }
}
