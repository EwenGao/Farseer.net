﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Web;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 图片工具
    /// </summary>
    public partial class ParseImage
    {
        /// <summary>
        /// 保存图片
        /// </summary>
        public static void SaveImageByRequest(string imageUrl, string savePath, ImageFormat imgFormat)
        {
            WebRequest wreq = WebRequest.Create(imageUrl);
            HttpWebResponse wresp = (HttpWebResponse)wreq.GetResponse();
            Stream s = wresp.GetResponseStream();
            Image img = Image.FromStream(s);
            img.Save(savePath, imgFormat);   //保存 
        }

        /// <summary>
        /// 保存图片
        /// </summary>
        public static void SaveImageByClient(string imageUrl, string savePath, ImageFormat imgFormat)
        {
            WebClient my = new WebClient();
            byte[] mybyte = my.DownloadData(imageUrl);
            MemoryStream ms = new MemoryStream(mybyte);
            System.Drawing.Image img;
            img = System.Drawing.Image.FromStream(ms);
            img.Save(savePath, imgFormat);   //保存

            //如果是真实的图片地址直接用 
            //my.DownloadFile("http://www.xueit.com/eimg/uploadfile/downpig/20098/098215331763.gif","D:\\a.gif");   //保存 
            //直接可以保存

        }

        /// <summary>
        /// 用HttpContext.Current.Response.BinaryWrite输出
        /// </summary>
        public static void WriteImage(byte[] buffer)
        {
            //下面直接输出 
            HttpContext.Current.Response.ClearContent();
            HttpContext.Current.Response.ContentType = "image/gif";
            HttpContext.Current.Response.BinaryWrite(buffer);

            //return new WebClient().DownloadData(imageUrl);
        }
    }


    /// <summary>
    /// 图片工具
    /// </summary>
    public partial class ParseImage
    {
        static string[] FontItems = new string[] { "Arial", "Helvetica", "Geneva", "sans-serif", "Verdana" };
        static Brush[] BrushItems = new Brush[] { Brushes.OliveDrab, Brushes.ForestGreen, Brushes.DarkCyan, Brushes.LightSlateGray, Brushes.RoyalBlue, Brushes.SlateBlue, Brushes.DarkViolet, Brushes.MediumVioletRed, Brushes.IndianRed, Brushes.Firebrick, Brushes.Chocolate, Brushes.Peru, Brushes.Goldenrod };

        private static Random random;
        private static int brushNameIndex;



        /// <summary>
        /// 绘画事件
        /// </summary>
        public static string WriteVerifyImage()
        {
            return WriteVerifyImage(4, 12, 60, 20, 30, Color.White, Pens.DarkGray);
        }

        /// <summary>
        /// 绘画事件
        /// </summary>
        /// <param name="codeLenght">随机字符长度</param>
        /// <param name="fontSize">字体长度</param>
        /// <param name="imgWidth">图片长度</param>
        /// <param name="imgHeiht">图片高度</param>
        /// <param name="stainLenght">噪音点长度</param>
        /// <param name="backColor">背景色</param>
        /// <param name="borderColor">边框色</param>
        /// <returns></returns>
        public static string WriteVerifyImage(int codeLenght, int fontSize, int imgWidth, int imgHeiht, int stainLenght, Color backColor, Pen borderColor)
        {
            random = new Random();
            string code = GetRandomCode(codeLenght);

            SetPageNoCache();

            Bitmap oBitmap = new Bitmap(imgWidth, imgHeiht);
            Graphics g = Graphics.FromImage(oBitmap);

            Paint_Background(g, backColor);
            Paint_Text(g, fontSize, code);
            Paint_Stain(oBitmap, imgWidth, imgHeiht, stainLenght);
            Paint_Border(g, imgWidth, imgHeiht, borderColor);

            oBitmap.Save(HttpContext.Current.Response.OutputStream, ImageFormat.Gif);

            HttpContext.Current.Response.ContentType = "image/gif";

            if (oBitmap != null) { oBitmap.Dispose(); }
            if (g != null) { g.Dispose(); }

            return code;
        }

        /// <summary>
        /// 设置页面不被缓存
        /// </summary>
        private static void SetPageNoCache()
        {
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ExpiresAbsolute = System.DateTime.Now.AddSeconds(-1);
            HttpContext.Current.Response.Expires = 0;
            HttpContext.Current.Response.CacheControl = "no-cache";
            HttpContext.Current.Response.AppendHeader("Pragma", "No-Cache");
        }

        /// <summary>
        /// 取得一个 4 位的随机码 
        /// </summary>
        /// <returns></returns>
        private static string GetRandomCode(int codeLenght)
        {
            return Guid.NewGuid().ToString().Substring(0, codeLenght);
        }

        /// <summary>
        /// 取一个字体的样式   
        /// </summary>
        /// <returns></returns>
        private static FontStyle GetFontStyle()
        {
            switch (DateTime.Now.Second % 2)
            {
                case 0:
                    {
                        return FontStyle.Regular | FontStyle.Bold;
                    }
                case 1:
                    {
                        return FontStyle.Italic | FontStyle.Bold;
                    }
                default:
                    {
                        return FontStyle.Regular | FontStyle.Bold;
                    }
            }
        }

        /// <summary>
        /// 随机取一个笔刷
        /// </summary>
        /// <returns></returns>
        private static Brush GetBrush()
        {
            brushNameIndex = random.Next(0, BrushItems.Length);
            return BrushItems[brushNameIndex];
        }

        /// <summary>
        /// 随机取一个字体
        /// </summary>
        /// <returns></returns>
        private static Font GetFont(int fontSize)
        {
            int fontIndex = random.Next(0, FontItems.Length);
            return new Font(FontItems[fontIndex], fontSize, GetFontStyle());
        }

        /// <summary>
        /// 绘画背景色
        /// </summary>
        /// <param name="g"></param>
        private static void Paint_Background(Graphics g, Color backColor)
        {
            g.Clear(backColor);
        }

        /// <summary>
        /// 绘画边框
        /// </summary>
        /// <param name="g"></param>
        private static void Paint_Border(Graphics g, int imgWidth, int imgHeiht, Pen borderColor)
        {
            g.DrawRectangle(borderColor, 0, 0, imgWidth - 1, imgHeiht - 1);
        }

        /// <summary>
        /// 绘画文字
        /// </summary>
        /// <param name="g"></param>
        private static void Paint_Text(Graphics g, int fontSize,string code)
        {
            g.DrawString(code, GetFont(fontSize), GetBrush(), 1, 1);
        }

        /// <summary>
        /// 绘画噪音点
        /// </summary>
        /// <param name="b"></param>
        private static void Paint_Stain(Bitmap b, int imgWidth, int imgHeiht, int stainLenght)
        {
            for (int n = 0; n < stainLenght; n++)
            {
                int x = random.Next(imgWidth);
                int y = random.Next(imgHeiht);
                b.SetPixel(x, y, Color.FromName(BrushItems[brushNameIndex].ToString()));
            }
        }

        /// <summary>
        /// 对用户输入的验证码进行检测，返回检测结果。   
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool Check(string input)
        {
            if (HttpContext.Current.Session["_VerifyCode"] == null || input == null)
            {
                return false;
            }

            string _code = HttpContext.Current.Session["_VerifyCode"].ToString();
            HttpContext.Current.Session.Remove("_VerifyCode");

            if (_code.ToUpper() != input.ToUpper())
            {
                return false;
            }

            return true;
        }
    }
}
