﻿using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Qyn.Studio.Configs;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Base
{
    public class BaseController : Controller 
    {
        /// <summary>
        /// 网站标题
        /// </summary>
        public string WebTitle { get; set; }

        #region 前台Url、Path
        /// <summary>
        /// 前台网站应用程序目录(相对于IIS)
        /// </summary>
        public string WebDirectory { get; set; }

        /// <summary>
        /// 网站登陆页面
        /// http://www.xxx.com:80/Login.aspx
        /// </summary>
        public string WebLoginUrl { get; set; }

        /// <summary>
        /// 网站退出页面
        /// </summary>
        public string WebLogoutUrl { get; set; }
        #endregion

        #region 后台Url、Path
        /// <summary>
        /// 管理平台根目录
        /// /Admin/
        /// </summary>
        public string AdminDirectory { get; set; }

        /// <summary>
        /// 管理员登陆页面
        /// /Login.aspx
        /// </summary>
        public string AdminLoginUrl { get; set; }

        /// <summary>
        /// 管理员退出页面
        /// </summary>
        public string AdminLogoutUrl { get; set; }
        #endregion

        /// <summary>
        /// HttpContext.Current.Request
        /// </summary>
        public new HttpRequest Request = System.Web.HttpContext.Current.Request;
        /// <summary>
        /// HttpContext.Current.Response
        /// </summary>
        public new HttpResponse Response = System.Web.HttpContext.Current.Response;

        /// <summary>
        /// 构造
        /// </summary>
        public BaseController()
        {
            WebTitle = GeneralConfigs.ConfigInfo.WebTitle;
            WebDirectory = GeneralConfigs.ConfigInfo.WebDirectory;
            WebLoginUrl = GeneralConfigs.ConfigInfo.WebLoginUrl;
            WebLogoutUrl = GeneralConfigs.ConfigInfo.WebLogoutUrl;

            AdminDirectory = GeneralConfigs.ConfigInfo.AdminDirectory;
            AdminLoginUrl = GeneralConfigs.ConfigInfo.AdminLoginUrl;
            AdminLogoutUrl = GeneralConfigs.ConfigInfo.AdminLogoutUrl;

        }

        #region 显示、弹出信息
        /// <summary>
        /// 显示信息
        /// </summary>
        public void ShowMsg(string message)
        {
            new Terminator().Throw(message);
        }

        /// <summary>
        /// 显示信息
        /// </summary>
        public void ShowMsg(string message, string title, string gotoUrl)
        {
            if (gotoUrl.StartsWith("?")) { gotoUrl = MvcRequest.GetPageName() + gotoUrl; }
            new Terminator().Throw(message, title, string.Format("Go to Page,{0}", gotoUrl));
        }

        /// <summary>
        /// 弹出信息
        /// </summary>
        public void Alert(string message)
        {
            new Terminator().Alert(message);
        }

        /// <summary>
        /// 弹出信息
        /// </summary>
        public void Alert(string message, string gotoUrl)
        {
            if (gotoUrl.StartsWith("?")) { gotoUrl = MvcRequest.GetPageName() + gotoUrl; }
            new Terminator().Alert(message, gotoUrl);
        }
        #endregion

        #region Request

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName, Encoding encoding)
        {
            return MvcRequest.QS(parmsName, string.Empty, encoding);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName)
        {
            return MvcRequest.QS(parmsName);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public T QS<T>(string parmsName, T defValue)
        {
            return MvcRequest.QS(parmsName, defValue);
        }
        #endregion

        /// <summary>
        /// 转到网址
        /// </summary>
        public void GoToUrl(string url, params object[] args)
        {
            if (args != null && args.Length != 0) { url = string.Format(url, args); }
            GoToUrl(url);
        }

        /// <summary>
        /// 转到网址
        /// </summary>
        public void GoToUrl(string url)
        {
            if (url.StartsWith("?")) { url = MvcRequest.GetPageName() + url; }
            Response.Redirect(url);
        }

        /// <summary>
        /// 刷新当前页
        /// </summary>
        public void Refresh()
        {
            GoToUrl("{0}?{1}", MvcRequest.GetPageName(), MvcRequest.GetParams());
        }

        /// <summary>
        /// 刷新整页
        /// </summary>
        /// <param name="link"></param>
        public void RefreshParent(string link)
        {
            Response.Write(string.Format("<script type=\"text/javascript\">parent.document.location.href=\"{0}\"</script>", link));
        }

        /// <summary>
        /// 返回连接参数
        /// </summary>
        /// <param name="kic">页面需要用到的参数名称、值</param>
        /// <param name="parmsName">要重新赋值的参数</param>
        /// <param name="value">新的参数值</param>
        protected string Parms(Dictionary<string, object> kic, string parmsName, object value)
        {
            string parms = string.Empty;
            foreach (KeyValuePair<string, object> kvp in kic)
            {
                parms += string.Format("{0}={1}&", kvp.Key, kvp.Key.IsEquals(parmsName) ? value : kvp.Value);
            }
            return parms.DelEndOf("&");
        }

        /// <summary>
        /// 返回连接参数
        /// </summary>
        /// <param name="kic">页面需要用到的参数名称、值</param>
        /// <param name="parmsName">省略key等于当前参数名称的值</param>
        protected string Parms(Dictionary<string, object> kic, string parmsName)
        {
            string parms = string.Empty;
            foreach (KeyValuePair<string, object> kvp in kic)
            {
                if (kvp.Key.IsEquals(parmsName)) { continue; }
                parms += string.Format("{0}={1}&", kvp.Key, kvp.Value);
            }
            return parms.DelEndOf("&");
        }
    }
}