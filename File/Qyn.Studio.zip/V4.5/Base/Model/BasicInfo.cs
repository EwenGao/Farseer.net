﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 实体类基类信息
    /// </summary>
    [Serializable]
    public class BasicInfo : BaseInfo
    {
        /// <summary>
        /// 标题
        /// </summary>
        [Display(Name = "标题")]
        public virtual string Caption { get; set; }

        /// <summary>
        /// 创建时间
        /// </summary>
        [Display(Name = "创建时间")]
        public virtual DateTime? CreateAt { get; set; }

        /// <summary>
        /// 创建人ID
        /// </summary>
        [Display(Name = "创建人ID")]
        public virtual int? CreateID { get; set; }

        /// <summary>
        /// 创建人名称
        /// </summary>
        [Display(Name = "创建人名称")]
        public virtual string CreateName { get; set; }

        /// <summary>
        /// 修改时间
        /// </summary>
        [Display(Name = "修改时间")]
        public virtual DateTime? UpdateAt { get; set; }

        /// <summary>
        /// 修改人ID
        /// </summary>
        [Display(Name = "修改人ID")]
        public virtual int? UpdateID { get; set; }

        /// <summary>
        /// 修改人名称
        /// </summary>
        [Display(Name = "修改人名称")]
        public virtual string UpdateName { get; set; }
    }
}