﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Linq.Mapping;
using System.Linq;
using System.Reflection;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 实体类基类信息
    /// </summary>
    [Serializable]
    public class BaseInfo : ICloneable
    {
        /// <summary>
        /// 系统编号
        /// </summary>
        [Display(Name = "系统编号")]
        [Column(IsPrimaryKey = true)]
        public virtual int? ID { get; set; }

        /// <summary>
        /// 克隆出一个新的对像
        /// </summary>
        /// <typeparam name="T">对像，必需继续于BaseInfo</typeparam>
        public T Clone<T>() where T : BaseInfo
        {
            return this.MemberwiseClone() as T;
        }

        /// <summary>
        /// 克隆出一个新的对像
        /// </summary>
        public object Clone()
        {
            return this.MemberwiseClone();
        }

        /// <summary>
        /// 检测实体类值状况
        /// </summary>
        public virtual bool Check(Action<string, string> tip = null, string url = "")
        {
            //返回错误
            string ErrorMessage = string.Empty; ;
            if (tip == null) { tip = new Terminator().Alert; }
            Mapping map = ModelCache.GetInfo(this.GetType());
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.ModelList.Where(o => o.Value.IsAttribute))
            {
                object value = kic.Key.GetValue(this, null);

                // 是否必填
                if (kic.Value.Required != null && !kic.Value.Required.IsValid(value)) { ErrorMessage = kic.Value.Required.ErrorMessage; continue; }

                if (value == null) { continue; }

                // 字符串长度判断
                if (kic.Value.StringLength != null && !kic.Value.StringLength.IsValid(value)) { ErrorMessage = kic.Value.StringLength.ErrorMessage; continue; }

                // 值的长度
                if (kic.Value.Range != null && !kic.Value.Range.IsValid(value)) { ErrorMessage = kic.Value.Range.ErrorMessage; continue; }

                // 正则
                if (kic.Value.RegularExpression != null && !kic.Value.RegularExpression.IsValid(value)) { ErrorMessage = kic.Value.RegularExpression.ErrorMessage; continue; }
            }
            if (!ErrorMessage.IsNullOrEmpty()) { tip(ErrorMessage, url); return false; }
            return true;
        }

        /// <summary>
        /// 检测实体类值状况
        /// </summary>
        public virtual bool CheckNoTip()
        {
            Mapping map = this.GetType();
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.ModelList.Where(o => o.Value.IsAttribute))
            {
                object value = kic.Key.GetValue(this, null);

                // 是否必填
                if (kic.Value.Required != null && !kic.Value.Required.IsValid(value)) { return false; }

                if (value == null) { continue; }

                // 字符串长度判断
                if (kic.Value.StringLength != null && !kic.Value.StringLength.IsValid(value)) { return false; }

                // 值的长度
                if (kic.Value.Range != null && !kic.Value.Range.IsValid(value)) { return false; }

                // 正则
                if (kic.Value.RegularExpression != null && !kic.Value.RegularExpression.IsValid(value)) { return false; }
            }
            return true;
        }
    }
}
