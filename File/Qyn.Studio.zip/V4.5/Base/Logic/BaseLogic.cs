﻿using System;
using System.Web;
using Qyn.Studio.Bean;
using Qyn.Studio.Data;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 逻辑层基类工具
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    public partial class BaseLogic<TInfo> where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 数据库持久化
        /// </summary>
        public static IBean<TInfo> Data
        {
            get { return DbFactory.CreateBean<TInfo>(); }
        }

        /// <summary>
        /// 把Request.Form提交过来的内容转化成为实体类
        /// </summary>
        /// <param name="prefix">控件前缀</param>
        public static TInfo Form(Action<string> tip = null, string prefix = "hl")
        {
            return QynRequest.Fill<TInfo>(HttpContext.Current.Request.Form, tip, prefix);
        }

        /// <summary>
        /// 把Request.QueryString提交过来的内容转化成为实体类
        /// </summary>
        /// <param name="prefix">控件前缀</param>
        public static TInfo QueryString(Action<string> tip = null, string prefix = "hl")
        {
            return QynRequest.Fill<TInfo>(HttpContext.Current.Request.QueryString, tip, prefix);
        }

        /// <summary>
        /// 快捷工具类
        /// </summary>
        public class Tools
        {
            /// <summary>
            /// 添加（带实体检测）
            /// </summary>
            /// <param name="info">当前实体类型</param>
            /// <param name="IsTip">在检测数据时，是否要Alert</param>
            /// <param name="db">事务</param>
            public static bool Insert(TInfo info, bool IsTip = false, DbExecutor db = null)
            {
                if (IsTip) { if (!info.Check()) { return false; } }
                else { if (!info.CheckNoTip()) { return false; } }
                return Data.Insert(info, db);
            }

            /// <summary>
            /// 添加（带实体检测）
            /// </summary>
            /// <param name="info">当前实体类型</param>
            /// <param name="IsTip">在检测数据时，是否要Alert</param>
            /// <param name="db">事务</param>
            /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
            public static bool Insert(TInfo info, out int identity, bool IsTip = false, DbExecutor db = null)
            {
                if (IsTip) { if (!info.Check()) { identity = 0; return false; } }
                else { if (!info.CheckNoTip()) { identity = 0; return false; } }
                return Data.Insert(info, out identity, db);
            }

            /// <summary>
            /// 更改实体类（带实体检测）
            /// </summary>
            /// <param name="info">当前实体类型</param>
            /// <param name="IsTip">在检测数据时，是否要Alert</param>
            /// <param name="db">事务</param>
            public static bool Update(TInfo info, bool IsTip = false, DbExecutor db = null)
            {
                if (IsTip) { if (!info.Check()) { return false; } }
                else { if (!info.CheckNoTip()) { return false; } }
                return Data.Update(o => o.ID == info.ID, info, db);
            }
        }
    }
}
