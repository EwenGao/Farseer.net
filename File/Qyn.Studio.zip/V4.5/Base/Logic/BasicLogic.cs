﻿
using System;
using Qyn.Studio.Bean;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 逻辑层基类工具
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    public partial class BasicLogic<TInfo> : BaseLogic<TInfo> where TInfo : BasicInfo, new()
    {
        /// <summary>
        /// 逻辑层工具集
        /// </summary>
        public new class Tools
        {
            /// <summary>
            /// 获取标题
            /// </summary>
            /// <param name="ID">通过ID</param>
            public static string Caption(int? ID)
            {
                return Data.GetValue(o => o.ID == ID, o => o.Caption, "");
            }

            /// <summary>
            /// 更新时间的范围
            /// </summary>
            /// <param name="startAt">开始时间</param>
            /// <param name="stopAt">结束时间</param>
            /// <param name="isOnlyDate">true:则清空时间，只匹配日期</param>
            public static IBean<TInfo> UpdateAtBetween(DateTime? startAt, DateTime? stopAt, bool isOnlyDate = true)
            {
                if (isOnlyDate)
                {
                    startAt = startAt.ToShortDate();
                    stopAt = stopAt.ToShortDate();
                }

                return Data.Where(o => o.UpdateAt >= startAt && o.UpdateAt < stopAt.GetValueOrDefault().AddDays(1));
            }

            /// <summary>
            /// 创建时间的范围
            /// </summary>
            /// <param name="startAt">开始时间</param>
            /// <param name="stopAt">结束时间</param>
            /// <param name="isOnlyDate">true:则清空时间，只匹配日期</param>
            public static IBean<TInfo> CreateAtBetween(DateTime? startAt, DateTime? stopAt, bool isOnlyDate = true)
            {
                if (isOnlyDate)
                {
                    startAt = startAt.ToShortDate();
                    stopAt = stopAt.ToShortDate();
                }

                return Data.Where(o => o.CreateAt >= startAt && o.CreateAt < stopAt.GetValueOrDefault().AddDays(1));
            }
        }
    }
}
