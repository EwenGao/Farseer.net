﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Web;
using Qyn.Studio.Bean;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using Qyn.Studio.Tools;
using Qyn.Studio.UI.WebControls;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 逻辑层缓存基类
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    public partial class BaseCacheLogic<TInfo> where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 数据缓存操作
        /// </summary>
        public static BaseCache<TInfo> Cache
        {
            get { return new BaseCache<TInfo>(); }
        }

        /// <summary>
        /// 把Request.Form提交过来的内容转化成为实体类
        /// </summary>
        /// <param name="prefix">控件前缀</param>
        public static TInfo Form(Action<string> tip = null, string prefix = "hl")
        {
            return QynRequest.Fill<TInfo>(HttpContext.Current.Request.Form, tip, prefix);
        }

        /// <summary>
        /// 把Request.QueryString提交过来的内容转化成为实体类
        /// </summary>
        /// <param name="prefix">控件前缀</param>
        public static TInfo QueryString(Action<string> tip = null, string prefix = "hl")
        {
            return QynRequest.Fill<TInfo>(HttpContext.Current.Request.QueryString, tip, prefix);
        }

        /// <summary>
        /// 快捷工具类
        /// </summary>
        public class Tools
        {
            /// <summary>
            /// 添加（带实体检测）
            /// </summary>
            /// <param name="info">当前实体类型</param>
            /// <param name="IsTip">在检测数据时，是否要Alert</param>
            /// <param name="db">事务</param>
            public static bool Insert(TInfo info, bool IsTip = false, DbExecutor db = null)
            {
                if (IsTip) { if (!info.Check()) { return false; } }
                else { if (!info.CheckNoTip()) { return false; } }
                return Cache.Insert(info, db);
            }

            /// <summary>
            /// 添加（带实体检测）
            /// </summary>
            /// <param name="info">当前实体类型</param>
            /// <param name="IsTip">在检测数据时，是否要Alert</param>
            /// <param name="db">事务</param>
            /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
            public static bool Insert(TInfo info, out int identity, bool IsTip = false, DbExecutor db = null)
            {
                if (IsTip) { if (!info.Check()) { identity = 0; return false; } }
                else { if (!info.CheckNoTip()) { identity = 0; return false; } }
                return Cache.Insert(info, out identity, db);
            }

            /// <summary>
            /// 更改实体类（带实体检测）
            /// </summary>
            /// <param name="info">当前实体类型</param>
            /// <param name="IsTip">在检测数据时，是否要Alert</param>
            /// <param name="db">事务</param>
            public static bool Update(TInfo info, bool IsTip = false, DbExecutor db = null)
            {
                if (IsTip) { if (!info.Check()) { return false; } }
                else { if (!info.CheckNoTip()) { return false; } }
                return Cache.Update(o => o.ID == info.ID, info, db);
            }
        }
    }

    /// <summary>
    /// 逻辑层缓存基类
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    public class BaseCache<TInfo> : IBean<TInfo> where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 等同于获取List<TInfo>
        /// </summary>
        /// <param name="cache"></param>
        /// <returns></returns>
        public static implicit operator List<TInfo>(BaseCache<TInfo> cache)
        {
            return cache.ToList(0, 1, null);
        }

        /// <summary>
        /// 数据库类型
        /// </summary>
        DataBaseType DataType;
        /// <summary>
        /// 连接字符中
        /// </summary>
        string ConnetionString;
        /// <summary>
        /// 执行T-SQL超时间
        /// </summary>
        int CommandTimeout;

        /// <summary>
        /// 兼容Qyn.Factory项目
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="commandTimeout">命令执时超时时间</param>
        public BaseCache(DataBaseType dbType, string connetionString, int commandTimeout)
        {
            Key = Encrypt.MD5(connetionString + Map.Type.FullName);
            DataType = dbType;
            ConnetionString = connetionString;
            CommandTimeout = commandTimeout;
        }

        /// <summary>
        /// 默认使用
        /// </summary>
        public BaseCache()
        {
            Key = Encrypt.MD5(Map.ClassInfo.ConnStr + Map.Type.FullName);
            DataType = Map.ClassInfo.DataType;
            ConnetionString = Map.ClassInfo.ConnStr;
            CommandTimeout = Map.ClassInfo.CommandTimeout;
        }

        /// <summary>
        /// Cache Key
        /// </summary>
        private string Key { get; set; }

        /// <summary>
        /// 实体映射
        /// </summary>
        private Mapping Map = typeof(TInfo);

        /// <summary>
        /// 数据库持久化
        /// </summary>
        private IBean<TInfo> data;

        /// <summary>
        /// 数据库持久化
        /// </summary>
        private IBean<TInfo> Data
        {
            get
            {
                if (data == null) { data = DbFactory.CreateBean<TInfo>(DataType, ConnetionString, CommandTimeout); }
                return data;
            }
        }

        /// <summary>
        /// Where表达式
        /// </summary>
        private Expression<Func<TInfo, bool>> ExpWhere;

        /// <summary>
        /// Selector表达式
        /// </summary>
        private Expression<Func<TInfo, object>> ExpSelector;

        /// <summary>
        /// 排序的字段名称
        /// </summary>
        private string OrderByFieldName;

        /// <summary>
        /// 排序方式
        /// </summary>
        private ReverserInfo.eumOrderBy OrderBy;

        /// <summary>
        /// 获取数据列表(读取数据库)
        /// </summary>
        public List<TInfo> GetTrueList(DbExecutor db = null)
        {
            List<TInfo> lst = Data.ToList(0, 1, db);
            ParseCache.Add(Key, lst);
            return lst;
        }

        /// <summary>
        /// 获取缓存中的列表
        /// </summary>
        /// <returns></returns>
        public List<TInfo> ToList()
        {
            return ToList(null);
        }

        /// <summary>
        /// 获取缓存中的列表
        /// </summary>
        /// <returns></returns>
        public List<TInfo> ToList(DbExecutor db)
        {
            List<TInfo> lst = ParseCache.Get<List<TInfo>>(Key) ?? new List<TInfo>();
            if (lst.Count == 0) { lst = GetTrueList(db) ?? new List<TInfo>(); }
            return lst;
        }

        #region IBean<TInfo> Members
        /// <summary>
        /// 条件语句
        /// </summary>
        /// <param name="where">Lambda条件</param>
        public IBean<TInfo> Where(Expression<Func<TInfo, bool>> where)
        {
            if (where == null) { return this; }

            ExpWhere = ExpWhere.AndAlso(where);

            return this;
        }

        /// <summary>
        /// 字段筛选
        /// </summary>
        /// <param name="selector">选择单个字段</param>
        public IBean<TInfo> Selector(Expression<Func<TInfo, object>> selector)
        {
            ExpSelector = selector;
            return this;
        }

        /// <summary>
        /// 升序
        /// </summary>
        /// <param name="sort">选择单个字段</param>
        public IBean<TInfo> Asc(Expression<Func<TInfo, object>> sort)
        {
            OrderBy = ReverserInfo.eumOrderBy.Asc;
            OrderByFieldName = sort.GetUsedName();

            return this;
        }

        /// <summary>
        /// 降序
        /// </summary>
        /// <param name="sort">选择单个字段</param>
        public IBean<TInfo> Desc(Expression<Func<TInfo, object>> sort)
        {
            OrderBy = ReverserInfo.eumOrderBy.Desc;
            OrderByFieldName = sort.GetUsedName();

            return this;
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        public bool Insert(TInfo info, DbExecutor db = null)
        {
            int identity;
            return Insert(info, out identity, db);
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        public bool Insert(TInfo info, out int identity, DbExecutor db = null)
        {
            ExpWhere = null;
            bool result;
            bool indexHaveValue = Map.GetModelInfo().Key != null ? Map.GetModelInfo().Key.GetValue(info, null) != null : false;
            List<TInfo> lst = ToList(db);

            // 如果标识没有值，则必需取值。
            if (indexHaveValue)
            {
                result = Data.Insert(info, db);
                identity = Map.GetModelInfo().Key.GetValue(info, null).ConvertType(0);
            }
            else
            {
                result = Data.Insert(info, out identity, db);

                #region 赋值给主键
                if (!Map.IndexName.IsNullOrEmpty())
                {
                    KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetModelInfo(Map.IndexName);
                    if (kic.Key.CanWrite)
                    {
                        kic.Key.SetValue(info, identity, null);
                    }
                }
                #endregion
            }

            if (result)
            {
                lst.Add(info);
                //ParseCache.Add(Key, lst);
            }
            return result;
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        public int GetCount(DbExecutor db = null)
        {
            if (ExpWhere != null) { throw new Exception("此方法的性能较差，请直接使用Linq的Count()方法"); }

            List<TInfo> lst = ParseCache.Get<List<TInfo>>(Key);
            if (lst == null || lst.Count == 0) { lst = GetTrueList(); }
            if (lst == null || lst.Count == 0) { return 0; }

            return lst.Count;
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public int GetCount(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return GetCount(db);
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        public bool Delete(DbExecutor db = null)
        {
            bool result = Data.Where(ExpWhere).Delete(db);

            if (result)
            {
                if (ExpWhere == null) { GetTrueList(); }
                else { var lst = ToList().RemoveAll(ExpWhere.Compile().ToPredicate()); }
            }
            return result;
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public bool Delete(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return Delete(db);
        }

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        public TInfo ToInfo(DbExecutor db = null)
        {
            throw new Exception("此方法的性能较差，请直接使用Linq的FirstOrDefault()方法");
        }

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public TInfo ToInfo(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return ToInfo(db);
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        public DataTable ToTable(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            throw new NotImplementedException("抱歉，缓存基类方法不支持该方法");
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public DataTable ToTable(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToTable(out  recordCount, pageSize, pageIndex, db);
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public DataTable ToTable(int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            throw new NotImplementedException("抱歉，缓存基类方法不支持该方法");
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        public DataTable ToTable(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToTable(pageSize, pageIndex, db);
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        public List<TInfo> ToList(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            if (ExpWhere != null) { throw new Exception("ToList不支持带条件的调用，请直接使用Linq的ToList()方法"); }
            var lst = ToList();
            recordCount = lst.Count;
            return lst.ToList(pageSize, pageIndex);
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public List<TInfo> ToList(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            if (ExpWhere != null || where != null) { throw new Exception("ToList不支持带条件的调用，请直接使用Linq的ToList()方法"); }
            var lst = ToList();
            recordCount = lst.Count;
            return lst.ToList(pageSize, pageIndex);
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="db">可传入事务的db</param>
        public List<TInfo> ToList(Repeater rpt, DbExecutor db = null)
        {
            if (ExpWhere != null) { throw new Exception("ToList不支持带条件的调用，请直接使用Linq的ToList()方法"); }
            return ToList().ToList(rpt);
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public List<TInfo> ToList(Expression<Func<TInfo, bool>> where, Repeater rpt, DbExecutor db = null)
        {
            if (ExpWhere != null || where != null) { throw new Exception("ToList不支持带条件的调用，请直接使用Linq的ToList()方法"); }
            return ToList().ToList(rpt);
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        public List<TInfo> ToList(int pageSize, int pageIndex, DbExecutor db = null)
        {
            if (ExpWhere != null) { throw new Exception("ToList不支持带条件的调用，请直接使用Linq的ToList()方法"); }
            return ToList(db).ToList(pageSize, pageIndex);
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public List<TInfo> ToList(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            if (ExpWhere != null || where != null) { throw new Exception("ToList不支持带条件的调用，请直接使用Linq的ToList()方法"); }
            return ToList().ToList(pageSize, pageIndex);
        }

        /// <summary>
        /// 更改实体类
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        public bool Update(TInfo info, DbExecutor db = null)
        {
            var where = ExpWhere;
            ExpWhere = null;

            bool result = Data.Where(where).Update(info, db);

            if (result)
            {
                List<TInfo> lst = ToList();

                if (where != null) { lst = lst.Where(where.Compile()).ToList(); }

                foreach (TInfo item in lst)
                {
                    foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in Map.ModelList.Where(o => o.Value.IsAttribute))
                    {
                        object objValue = kic.Key.GetValue(info, null);
                        if (objValue == null) { continue; }
                        if (!kic.Key.CanWrite) { continue; }
                        kic.Key.SetValue(item, objValue, null);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 更改实体类
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public bool Update(Expression<Func<TInfo, bool>> where, TInfo info, DbExecutor db = null)
        {
            Where(where);
            return Update(info, db);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldValue">字段值(请先指定selector字段)</param>
        /// <param name="selector">选择字段</param>
        /// <param name="db">可传入事务的db</param>
        public bool UpdateValue<T>(Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null)
        {
            var where = ExpWhere;
            ExpWhere = null;

            bool result = Data.Where(where).UpdateValue(selector, fieldValue, db);

            if (result)
            {
                //获取索引的属性
                KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetModelInfo(selector.GetUsedName());

                List<TInfo> lst = ToList();
                if (where != null) { lst = lst.Where(where.Compile()).ToList(); }

                Type type = typeof(T);
                // 判断是否为泛型
                if (type.IsGenericType)
                {
                    // 非 Nullable<> 类型
                    if (type.GetGenericTypeDefinition() != typeof(Nullable<>)) { type = type.GetGenericArguments()[0]; }
                    else { type = Nullable.GetUnderlyingType(type); }
                }

                foreach (TInfo info in lst)
                {
                    T value = kic.Key.GetValue(info, null).ConvertType(default(T));
                    if (!kic.Key.CanWrite) { continue; }

                    object oVal;
                    switch (type.Name)
                    {
                        case "Int32":
                        case "Int16":
                        case "Byte": oVal = value.ConvertType(0) + fieldValue.ConvertType(0); break;
                        case "Decimal":
                        case "Long":
                        case "Float":
                        case "Double": oVal = value.ConvertType(0m) + fieldValue.ConvertType(0m); break;
                        default: throw new Exception("类型：" + type.Name + "， 未有转换程序对其解析。");
                    }

                    kic.Key.SetValue(info, oVal, null);
                }
            }
            return result;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldValue">字段值(请先指定selector字段)</param>
        /// <param name="selector">选择字段</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public bool UpdateValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null)
        {
            Where(where);
            return UpdateValue(selector, fieldValue, db);
        }

        /// <summary>
        /// 统计数量
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        public T GetSum<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            throw new Exception("此方法的性能较差，请直接使用Linq的Sum()方法");
        }

        /// <summary>
        /// 统计数量
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public T GetSum<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            Where(where);
            return GetSum(selector, db);
        }

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        public T GetMax<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            throw new Exception("此方法的性能较差，请直接使用Linq的Max()方法");
        }

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public T GetMax<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            Where(where);
            return GetMax(selector, db);
        }

        /// <summary>
        /// 获取单个字段的数据
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="defValue">为null时默认值</param>
        /// <param name="db">可传入事务的db</param>
        public T GetValue<T>(Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null)
        {
            var where = ExpWhere;
            ExpWhere = null;

            var lst = ToList();
            if (where != null) { lst = ToList().Where(where.Compile()).ToList(); }
            lst.Sort(new Qyn.Studio.Tools.Reverser<TInfo>(typeof(TInfo), OrderByFieldName, OrderBy));

            var value = lst.Select(selector.Compile()).FirstOrDefault();

            return value != null ? (T)value : defValue;
        }

        /// <summary>
        /// 获取单个字段的数据
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="defValue">为null时默认值</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public T GetValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null)
        {
            Where(where);
            return GetValue(selector, defValue, db);
        }

        /// <summary>
        /// 重置标识
        /// </summary>
        public void ResetIdentity(DbExecutor db = null)
        {
            Data.ResetIdentity(db);
        }

        #endregion

    }
}