﻿using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.SessionState;
using Qyn.Studio.Configs;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Web.Page
{
    /// <summary>
    /// 页面基类
    /// </summary>
    public class BasePage : System.Web.UI.Page, IRequiresSessionState
    {
        /// <summary>
        /// 网站标题
        /// </summary>
        public string WebTitle { get; set; }

        #region 前台Url、Path
        /// <summary>
        /// 前台网站应用程序目录(相对于IIS)
        /// </summary>
        public string WebDirectory { get; set; }

        /// <summary>
        /// 网站登陆页面
        /// http://www.xxx.com:80/Login.aspx
        /// </summary>
        public string WebLoginUrl { get; set; }

        /// <summary>
        /// 网站退出页面
        /// </summary>
        public string WebLogoutUrl { get; set; }
        #endregion

        #region 后台Url、Path
        /// <summary>
        /// 管理平台根目录
        /// /Admin/
        /// </summary>
        public string AdminDirectory { get; set; }

        /// <summary>
        /// 管理员登陆页面
        /// /Login.aspx
        /// </summary>
        public string AdminLoginUrl { get; set; }

        /// <summary>
        /// 管理员退出页面
        /// </summary>
        public string AdminLogoutUrl { get; set; }
        #endregion

        /// <summary>
        /// HttpContext.Current.Request
        /// </summary>
        public new HttpRequest Request = HttpContext.Current.Request;
        /// <summary>
        /// HttpContext.Current.Response
        /// </summary>
        public new HttpResponse Response = HttpContext.Current.Response;

        /// <summary>
        /// 构造
        /// </summary>
        public BasePage()
        {
            WebTitle = GeneralConfigs.ConfigInfo.WebTitle;
            WebDirectory = GeneralConfigs.ConfigInfo.WebDirectory;
            WebLoginUrl = GeneralConfigs.ConfigInfo.WebLoginUrl;
            WebLogoutUrl = GeneralConfigs.ConfigInfo.WebLogoutUrl;

            AdminDirectory = GeneralConfigs.ConfigInfo.AdminDirectory;
            AdminLoginUrl = GeneralConfigs.ConfigInfo.AdminLoginUrl;
            AdminLogoutUrl = GeneralConfigs.ConfigInfo.AdminLogoutUrl;

        }

        #region 显示、弹出信息
        /// <summary>
        /// 输出指定的提示信息
        /// </summary>
        /// <param name="message">提示内容</param>
        /// <param name="title">标题</param>
        /// <param name="links">链拉 例：是,yes.htm|否,no.htm</param>
        /// <param name="url">跳转页面URL</param>
        /// <param name="showback">是否显示返回链接</param>
        public void Message(string message, string title = "", string links = "", string url = "", bool showback = true)
        {
            new Terminator().Throw(message, title, links, url, showback);
        }

        /// <summary>
        /// JS弹出框
        /// </summary>
        /// <param name="message">提示内容</param>
        /// <param name="gotoUrl">跳转页面URL</param>
        public void Alert(string message, string gotoUrl = "")
        {
            new Terminator().Alert(message, gotoUrl);
        }

        /// <summary>
        /// 使用Dialog.alert弹出框架来提示内容。（可以防止数据保持问题）
        /// </summary>
        /// <param name="message">提示内容</param>
        /// <param name="url">跳转地址</param>
        public void Tip(string message)
        {
            Tip(message, null);
        }

        /// <summary>
        /// 使用Dialog.alert弹出框架来提示内容。（可以防止数据保持问题）
        /// </summary>
        /// <param name="message">提示内容</param>
        /// <param name="url">跳转地址</param>
        public void Tip(string message, string url = null)
        {
            url = url.IsNullOrEmpty() ? string.Format("Dialog.alert('{0}');", message) : "Dialog.alert('" + message + "',function(){ location.href='" + url + "'; });";
            Page.ClientScript.RegisterStartupScript(Page.GetType(), "System.Tip", url, true);
        }

        /// <summary>
        /// 使用Dialog.alert弹出框架来提示内容。（带脚本运行功能）
        /// </summary>
        /// <param name="message">提示内容</param>
        /// <param name="func">确定后，执行的脚本</param>
        public void TipFunc(string message, string func)
        {
            var script = "Dialog.alert('" + message + "',function(){ " + func + "; });";
            Page.ClientScript.RegisterStartupScript(Page.GetType(), "System.Tip", script, true);
        }
        #endregion

        #region Request

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName, Encoding encoding)
        {
            return QynRequest.QS(parmsName, encoding);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName)
        {
            return QynRequest.QS(parmsName);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public T QS<T>(string parmsName, T defValue)
        {
            return QynRequest.QS(parmsName, defValue);
        }

        /// <summary>
        /// Request.Form
        /// </summary>
        public T QF<T>(string parmsName, T defValue)
        {
            return QynRequest.QS(parmsName, defValue);
        }

        /// <summary>
        /// Request.Form
        /// </summary>
        public string QF(string parmsName)
        {
            return QynRequest.QF(parmsName);
        }

        /// <summary>
        /// 先QF后QS
        /// </summary>
        /// <param name="parmsName"></param>
        /// <returns></returns>
        public string QA(string parmsName)
        {
            return QynRequest.QA(parmsName);
        }

        #endregion

        /// <summary>
        /// 转到网址
        /// </summary>
        public void GoToUrl(string url, params object[] args)
        {
            if (url.StartsWith("?")) { url = QynRequest.GetPageName() + url; }
            if (args != null && args.Length != 0) { url = string.Format(url, args); }
            Response.Redirect(url);
        }

        /// <summary>
        /// 刷新当前页
        /// </summary>
        public void Refresh()
        {
            GoToUrl("{0}?{1}", QynRequest.GetPageName(), QynRequest.GetParams());
        }

        /// <summary>
        /// 刷新整页
        /// </summary>
        /// <param name="link"></param>
        public void RefreshParent(string link)
        {
            Response.Write(string.Format("<script type=\"text/javascript\">parent.document.location.href=\"{0}\"</script>", link));
        }

        /// <summary>
        /// 返回连接参数
        /// </summary>
        /// <param name="kic">页面需要用到的参数名称、值</param>
        /// <param name="parmsName">要重新赋值的参数</param>
        /// <param name="value">新的参数值</param>
        protected string Parms<T>(Dictionary<string, T> kic, string parmsName, T value)
        {
            string parms = string.Empty;
            foreach (KeyValuePair<string, T> kvp in kic)
            {
                parms += string.Format("{0}={1}&", kvp.Key, kvp.Key.IsEquals(parmsName) ? value : kvp.Value);
            }
            return parms.DelEndOf("&");
        }

        /// <summary>
        /// 返回连接参数
        /// </summary>
        /// <param name="kic">页面需要用到的参数名称、值</param>
        /// <param name="parmsName">省略key等于当前参数名称的值</param>
        protected string Parms<T>(Dictionary<string, T> kic, string parmsName)
        {
            string parms = string.Empty;
            foreach (KeyValuePair<string, T> kvp in kic)
            {
                if (kvp.Key.IsEquals(parmsName)) { continue; }
                parms += string.Format("{0}={1}&", kvp.Key, kvp.Value);
            }
            return parms.DelEndOf("&");
        }

    }
}
