﻿using System;
namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 配置文件
    /// </summary>
    [Serializable]
    public class SystemConfig
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        public string Cookies_User_ID = "Cookies_User_ID";

        /// <summary>
        /// 用户名
        /// </summary>
        public string Cookies_User_Name = "Cookies_User_Name";

        /// <summary>
        /// 用户登陆验证码的
        /// </summary>
        public string Cookies_User_VerifyCode = "Cookies_User_VerifyCode";

        /// <summary>
        /// 管理员ID的Cookies
        /// </summary>
        public string Cookies_Admin_ID = "Cookies_Admin_ID";

        /// <summary>
        /// 管理员名称的Cookies
        /// </summary>
        public string Cookies_Admin_Name = "Cookies_Admin_Name";

        /// <summary>
        /// 管理员登陆验证码的
        /// </summary>
        public string Cookies_Admin_VerifyCode = "Cookies_Admin_VerifyCode";
    }
}
