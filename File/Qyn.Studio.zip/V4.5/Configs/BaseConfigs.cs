﻿using System;
using System.IO;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 配置管理工具
    /// </summary>
    public class BaseConfigs<T> where T : new()
    {
        /// <summary>
        /// 锁对象
        /// </summary>
        private static object m_LockHelper = new object();

        /// <summary>
        /// 配置文件路径
        /// </summary>
        private static string filePath;

        /// <summary>
        /// 配置变量
        /// </summary>
        protected static T m_ConfigInfo;

        /// <summary>
        /// Config修改时间
        /// </summary>
        protected static DateTime LoadAt;

        /// <summary>
        /// 获取配置文件所在路径
        /// </summary>
        protected static string FilePath
        {
            get
            {
                if (filePath.IsNullOrEmpty())
                {
                    string fileName = string.Format("App_Data/{0}.config",
                            typeof(T).Name.EndsWith("Config", true, null)
                            ? typeof(T).Name.Substring(0, typeof(T).Name.Length - 6) :
                            typeof(T).Name);

                    filePath = ParseFile.GetRootPath() + fileName;
                }
                return filePath;
            }
        }

        /// <summary>
        /// 配置变量
        /// </summary>
        public static T ConfigInfo
        {
            get
            {
                if (m_ConfigInfo == null || LoadAt != File.GetLastWriteTime(FilePath)) { LoadConfig(); }
                //if (m_ConfigInfo == null) { LoadConfig(); }
                return m_ConfigInfo;
            }
        }

        /// <summary>
        /// 加载(反序列化)指定对象类型的配置对象
        /// </summary>
        protected static void LoadConfig()
        {
            //不存在则自动接创建
            if (!File.Exists(FilePath))
            {
                SaveConfig(new T());
            }

            LoadAt = File.GetLastWriteTime(FilePath);

            lock (m_LockHelper) { m_ConfigInfo = Serialization<T>.Load(FilePath); }

        }

        /// <summary>
        /// 保存(序列化)指定路径下的配置文件
        /// </summary>
        /// <param name="t">Config配置</param>
        public static bool SaveConfig(T t)
        {
            bool result = Serialization<T>.Save(t, FilePath);
            return result;
        }
    }
}
