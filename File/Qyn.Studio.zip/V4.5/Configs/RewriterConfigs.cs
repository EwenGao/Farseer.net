﻿using System;
using System.Collections.Generic;


namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 全局
    /// </summary>
    public class RewriterConfigs : BaseConfigs<RewriterConfig> { }

    /// <summary>
    /// 重写地址规则
    /// </summary>
    [Serializable]
    public class RewriterConfig
    {
        /// <summary>
        /// 重写地址规则列表
        /// </summary>
        public List<RewriterRule> Rules = new List<RewriterRule>();
    }

    /// <summary>
    /// 重写地址规则
    /// </summary>
    public class RewriterRule
    {
        /// <summary>
        /// 通过索引返回实体
        /// </summary>
        public static implicit operator RewriterRule(int index)
        {
            if (RewriterConfigs.ConfigInfo.Rules.Count <= index) { return null; }
            return RewriterConfigs.ConfigInfo.Rules[index];
        }

        /// <summary>
        /// 请求地址
        /// </summary>
        public string LookFor { get; set; }

        /// <summary>
        /// 重写地址
        /// </summary>
        public string SendTo { get; set; }
    }
}
