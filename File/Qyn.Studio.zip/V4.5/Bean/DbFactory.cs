﻿using System;
using System.Data;
using System.IO;
using System.Web;
using Qyn.Studio.Base;
using Qyn.Studio.Bean.Xml;
using Qyn.Studio.Configs;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using Qyn.Studio.Tools;
using Qyn.Studio.Utils;
//using CrystalDecisions.Shared;

namespace Qyn.Studio.Bean
{
    /// <summary>
    /// 数据库工厂模式
    /// </summary>
    public class DbFactory
    {
        /// <summary>
        /// 创建数据库持久化
        /// </summary>
        /// <typeparam name="TInfo">实体类</typeparam>
        public static IBean<TInfo> CreateBean<TInfo>() where TInfo : BaseInfo, new()
        {
            Mapping map = typeof(TInfo);
            switch (map.ClassInfo.DataType)
            {
                case DataBaseType.Access: return new OleDbBean<TInfo>();
                case DataBaseType.Excel: return new OleDbBean<TInfo>();
                case DataBaseType.MySql: return new MySqlBean<TInfo>();
                case DataBaseType.Xml: return new XmlBean<TInfo>();
                case DataBaseType.SQLite: return new SQLiteBean<TInfo>();
                case DataBaseType.Oracle: return new OracleBean<TInfo>();
                default: return new SqlServerBean<TInfo>();
            }
        }

        /// <summary>
        /// 创建数据库持久化
        /// </summary>
        /// <typeparam name="TInfo">实体类</typeparam>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="commandTimeout">命令执时超时时间</param>
        public static IBean<TInfo> CreateBean<TInfo>(DataBaseType dbType, string connetionString, int commandTimeout = 60) where TInfo : BaseInfo, new()
        {
            switch (dbType)
            {
                case DataBaseType.Access: return new OleDbBean<TInfo>(dbType, connetionString, commandTimeout);
                case DataBaseType.Excel: return new OleDbBean<TInfo>(dbType, connetionString, commandTimeout);
                case DataBaseType.MySql: return new MySqlBean<TInfo>(dbType, connetionString, commandTimeout);
                case DataBaseType.Xml: return new XmlBean<TInfo>(connetionString);
                case DataBaseType.SQLite: return new SQLiteBean<TInfo>(dbType, connetionString, commandTimeout);
                case DataBaseType.Oracle: return new OracleBean<TInfo>(dbType, connetionString, commandTimeout);
                default: return new SqlServerBean<TInfo>(dbType, connetionString, commandTimeout);
            }
        }

        /// <summary>
        /// 创建数据库持久化
        /// </summary>
        /// <param name="dbInfo">数据库配置</param>
        public static IBean<TInfo> CreateBean<TInfo>(DbInfo dbInfo) where TInfo : BaseInfo, new()
        {
            switch (dbInfo.DataType)
            {
                case DataBaseType.Access: return new OleDbBean<TInfo>(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout);
                case DataBaseType.Excel: return new OleDbBean<TInfo>(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout);
                case DataBaseType.MySql: return new MySqlBean<TInfo>(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout);
                case DataBaseType.Xml: return new XmlBean<TInfo>(CreateConnString(dbInfo));
                case DataBaseType.SQLite: return new SQLiteBean<TInfo>(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout);
                case DataBaseType.Oracle: return new OracleBean<TInfo>(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout);
                default: return new SqlServerBean<TInfo>(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout);
            }
        }

        /// <summary>
        /// 创建数据库操作
        /// </summary>
        /// <typeparam name="TInfo">实体类</typeparam>
        /// <param name="tranLevel">开启事务等级</param>
        public static DbExecutor CreateDbExecutor<TInfo>(IsolationLevel tranLevel = IsolationLevel.ReadUncommitted) where TInfo : BaseInfo, new()
        {
            Mapping map = typeof(TInfo);
            var dataType = map.ClassInfo.DataType;
            var connetionString = map.ClassInfo.ConnStr;
            var commandTimeout = map.ClassInfo.CommandTimeout;

            return new DbExecutor(dataType, connetionString, commandTimeout, tranLevel);
        }

        /// <summary>
        /// 创建数据库操作
        /// </summary>
        /// <param name="dbInfo">数据库链接配置</param>
        /// <param name="tranLevel">开启事务等级</param>
        public static DbExecutor CreateDbExecutor(IsolationLevel tranLevel = IsolationLevel.ReadUncommitted, DbInfo dbInfo = null)
        {
            if (dbInfo == null) { dbInfo = 0; }
            return new DbExecutor(dbInfo.DataType, CreateConnString(dbInfo), dbInfo.CommandTimeout, tranLevel);
        }

        /// <summary>
        /// 创建数据库连接字符串
        /// </summary>
        /// <param name="dbInfo">数据库配置</param>
        public static string CreateConnString(DbInfo dbInfo = null)
        {
            if (dbInfo == null) { dbInfo = 0; }
            switch (dbInfo.DataType)
            {
                case DataBaseType.MySql: { return string.Format("Data Source='{0}';User Id='{1}';Password='{2}';Database='{3}';charset='gbk'", dbInfo.Server, dbInfo.UserID, dbInfo.PassWord, dbInfo.Catalog); }
                case DataBaseType.SqlServer:
                    {
                        string connString = string.Empty;
                        if (dbInfo.UserID.IsNullOrEmpty() && dbInfo.PassWord.IsNullOrEmpty()) { connString = string.Format("Pooling=true;Integrated Security=True;"); }
                        else { connString = string.Format("User ID={0};Password={1};Pooling=true;", dbInfo.UserID, dbInfo.PassWord); }

                        connString += string.Format("Data Source={0};Initial Catalog={1};", dbInfo.Server, dbInfo.Catalog);

                        if (dbInfo.PoolMinSize > 0) { connString += string.Format("Min Pool Size={0};", dbInfo.PoolMinSize); }
                        if (dbInfo.PoolMaxSize > 0) { connString += string.Format("Max Pool Size={0};", dbInfo.PoolMaxSize); }
                        if (dbInfo.ConnectTimeout > 0) { connString += string.Format("Connect Timeout={0};", dbInfo.ConnectTimeout); }
                        return connString;
                    }
                case DataBaseType.Excel:
                    {
                        string connString = string.Empty;
                        switch (dbInfo.DataVer)
                        {
                            case "3.0": { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 3.0;"); break; }
                            case "4.0": { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 4.0;"); break; }
                            case "5.0": { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 5.0;"); break; }
                            case "95": { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 5.0;"); break; }
                            case "2007": { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 9.0;"); break; }
                            default: { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Extended Properties=Excel 8.0;"); break; }
                        }
                        return connString += string.Format("Data Source={0};", GetFilePath(dbInfo.Server));
                    }
                case DataBaseType.Access:
                    {
                        string connString = string.Empty;
                        switch (dbInfo.DataVer)
                        {
                            case "2007": { connString = string.Format("Provider=Microsoft.ACE.OLEDB.12.0;"); break; }
                            case "97": { connString = string.Format("Provider=Microsoft.Jet.OLEDB.3.51;"); break; }
                            default: { connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;"); break; }
                        }
                        return connString += string.Format("Data Source={0};User ID={1};Password ={2};", GetFilePath(dbInfo.Server), string.IsNullOrEmpty(dbInfo.UserID) ? "Admin" : dbInfo.UserID, dbInfo.PassWord);
                    }
                case DataBaseType.Xml: { if (dbInfo.Server.IsNullOrEmpty()) { return string.Empty; } return GetFilePath(dbInfo.Server); }
                case DataBaseType.SQLite:
                    {
                        StringPlus plus = new StringPlus();
                        plus.AppendFormat("Data Source={0};Min Pool Size={1};Max Pool Size={2};", GetFilePath(dbInfo.Server), dbInfo.PoolMinSize, dbInfo.PoolMaxSize);
                        if (!dbInfo.PassWord.IsNullOrEmpty()) { plus.AppendFormat("Password={0};", dbInfo.PassWord); }
                        if (!dbInfo.DataVer.IsNullOrEmpty()) { plus.AppendFormat("Version={0};", dbInfo.DataVer); }
                        return plus.Value;
                    }
                case DataBaseType.Oracle:
                    {
                        if (dbInfo.Port.IsNullOrEmpty()) { dbInfo.Port = "1521"; }
                        return string.Format("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST={0})(PORT={3})))(CONNECT_DATA=(SERVER=DEDICATED)(SID={4})));User Id={1};Password={2};", dbInfo.Server, dbInfo.UserID, dbInfo.PassWord, dbInfo.Port, dbInfo.SID);
                    }
                default: return string.Empty;
            }
        }

        /// <summary>
        /// 返回数据库的参数前缀符号
        /// </summary>
        /// <param name="dataType">数据库类型</param>
        public static string CreateParamsName(DataBaseType dataType = DataBaseType.SqlServer)
        {
            switch (dataType)
            {
                case DataBaseType.Oracle: return ":";
                default: return "@";
            }
        }

        /// <summary>
        /// 返回数据库保护系统名称的符号
        /// </summary>
        /// <param name="dataType">数据库类型</param>
        /// <param name="fileName">字段名称</param>
        public static string CreateTableAegis(string fileName, DataBaseType dataType = DataBaseType.SqlServer)
        {
            switch (dataType)
            {
                case DataBaseType.Oracle: return string.Format("{0}", fileName);
                case DataBaseType.MySql: return string.Format("`{0}`", fileName);
                default: return string.Format("[{0}]", fileName);
            }
        }

        /// <summary>
        /// 压缩数据库
        /// </summary>
        /// <param name="dataType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        public static void Compression(string connetionString, DataBaseType dataType = DataBaseType.SqlServer)
        {
            DbExecutor db = new DbExecutor(dataType, connetionString, 30);
            switch (dataType)
            {
                case DataBaseType.SQLite:
                    {
                        db.ExecuteNonQuery(System.Data.CommandType.Text, "VACUUM", null);
                        break;
                    }
                default: throw new NotImplementedException("该数据库不支持该方法！");
            }
        }

        /// <summary>
        /// 压缩数据库
        /// </summary>
        /// <param name="dbInfo">数据库配置</param>
        public static void Compression(DbInfo dbInfo = null)
        {
            Compression(CreateConnString(dbInfo), dbInfo.DataType);
        }

        /// <summary>
        /// 创建修改数据库类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        public static DbModify CreateDbModify(string connetionString, string tableName, DataBaseType dbType = DataBaseType.SqlServer)
        {
            switch (dbType)
            {
                case DataBaseType.Access: return new AccessModify(dbType, connetionString, tableName);
                case DataBaseType.MySql: return new MySqlModify(dbType, connetionString, tableName);
                case DataBaseType.SQLite: return new SqliteModify(dbType, connetionString, tableName);
                case DataBaseType.Oracle: return new OracleModify(dbType, connetionString, tableName);
                case DataBaseType.SqlServer: return new SqlServerModify(dbType, connetionString, tableName);
                default:
                    {
                        throw new Exception("该数据库不支持此操作！");
                    }
            }
        }

        /// <summary>
        /// 创建修改数据库类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        /// <param name="commandTimeout">数据库执行超时时间</param>
        public static DbBean CreateBean(string connetionString, string tableName, DataBaseType dbType = DataBaseType.SqlServer, int commandTimeout = 30)
        {
            switch (dbType)
            {
                case DataBaseType.SqlServer: return new SqlServerBean(connetionString, tableName, dbType, commandTimeout);
                case DataBaseType.MySql: return new MySqlBean(connetionString, tableName, dbType, commandTimeout);
                case DataBaseType.SQLite: return new SQLiteBean(connetionString, tableName, dbType, commandTimeout);
                case DataBaseType.Oracle: return new OracleBean(connetionString, tableName, dbType, commandTimeout);
                default:
                    {
                        return new OleDbBean(connetionString, tableName, dbType, commandTimeout);
                    }
            }
        }

        ///// <summary>
        ///// 创建报表数据库信息
        ///// </summary>
        ///// <param name="serverName">服务器</param>
        ///// <param name="tableName">数据</param>
        ///// <param name="catalog">数据库名称</param>
        ///// <param name="userName">用户名</param>
        ///// <param name="password">密码</param>
        ///// <returns></returns>
        //public static TableLogOnInfo CreateTableLogInfo(string serverName, string catalog, string userName, string password)
        //{
        //    TableLogOnInfo logOnInfo = new TableLogOnInfo();

        //    logOnInfo.ConnectionInfo.DatabaseName = catalog;
        //    logOnInfo.ConnectionInfo.UserID = userName;
        //    logOnInfo.ConnectionInfo.Password = password;
        //    logOnInfo.ConnectionInfo.ServerName = serverName;
        //    return logOnInfo;
        //}

        ///// <summary>
        ///// 创建报表数据库信息
        ///// </summary>
        ///// <param name="dbInfo">数据库配置</param>
        ///// <returns></returns>
        //public static TableLogOnInfo CreateTableLogInfo(DbInfo dbInfo = null)
        //{
        //    if (dbInfo == null) { dbInfo = DbConfigs.ConfigInfo.DbList[0]; }
        //    return CreateTableLogInfo(dbInfo.Server, dbInfo.Catalog, dbInfo.UserID, dbInfo.PassWord);

        //}

        /// <summary>
        /// 获取数据库文件的路径
        /// </summary>
        /// <param name="filePath">数据库路径</param>
        private static string GetFilePath(string filePath)
        {
            string fileName = ParseFile.ConvertPath(filePath);
            if (fileName.StartsWith("/")) { fileName = fileName.Substring(1); }

            if (fileName.IndexOf(':') == -1)
            {
                if (HttpContext.Current != null) { fileName = HttpContext.Current.Request.PhysicalApplicationPath + "App_Data/" + fileName; }
                else { fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data/" + fileName); }
            }
            return fileName;
        }
    }

}