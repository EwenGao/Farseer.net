﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Xml.Linq;
using Qyn.Studio.Base;
using Qyn.Studio.Data;
using Qyn.Studio.Data.Xml;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using Qyn.Studio.Tools;
using Qyn.Studio.UI.WebControls;

namespace Qyn.Studio.Bean.Xml
{
    /// <summary>
    /// 操作XML基类
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    internal class XmlBean<TInfo> : XmlExecutor, IBean<TInfo> where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 实体类映射
        /// </summary>
        private Mapping Map = typeof(TInfo);

        /// <summary>
        /// 使用实体类的UsedName作为文件名
        /// </summary>
        internal XmlBean()
        {
            if (!Map.ClassInfo.ConnStr.IsNullOrEmpty()) { base.FilePath = Map.ClassInfo.ConnStr; }
            else { base.FilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data/" + Map.ClassInfo.Name + ".Xml"); }

            base.XmlName = Map.ClassInfo.Name + "s";
        }
        /// <summary>
        /// 使用实体类的UsedName作为文件名
        /// </summary>
        internal XmlBean(string filePath)
        {
            base.FilePath = filePath;
            base.XmlName = Map.ClassInfo.Name + "s";
        }

        /// <summary>
        /// Where表达式
        /// </summary>
        private Expression<Func<TInfo, bool>> ExpWhere;

        /// <summary>
        /// Selector表达式
        /// </summary>
        private Expression<Func<TInfo, object>> ExpSelector;

        /// <summary>
        /// 排序的字段名称
        /// </summary>
        private string OrderByFieldName;

        /// <summary>
        /// 排序方式
        /// </summary>
        private ReverserInfo.eumOrderBy OrderBy;

        /// <summary>
        /// 条件语句
        /// </summary>
        /// <param name="where">Lambda条件</param>
        public IBean<TInfo> Where(Expression<Func<TInfo, bool>> where)
        {
            if (where == null) { return this; }

            ExpWhere = ExpWhere.AndAlso(where);

            return this;
        }

        /// <summary>
        /// 字段筛选
        /// </summary>
        /// <param name="selector">选择单个字段</param>
        public IBean<TInfo> Selector(Expression<Func<TInfo, object>> selector)
        {
            ExpSelector = selector;
            return this;
        }

        /// <summary>
        /// 升序
        /// </summary>
        /// <param name="sort">选择单个字段</param>
        public IBean<TInfo> Asc(Expression<Func<TInfo, object>> sort)
        {
            OrderBy = ReverserInfo.eumOrderBy.Asc;
            OrderByFieldName = sort.GetUsedName();

            return this;
        }

        /// <summary>
        /// 降序
        /// </summary>
        /// <param name="sort">选择单个字段</param>
        public IBean<TInfo> Desc(Expression<Func<TInfo, object>> sort)
        {
            OrderBy = ReverserInfo.eumOrderBy.Desc;
            OrderByFieldName = sort.GetUsedName();

            return this;
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        public bool Insert(TInfo info, DbExecutor db = null)
        {
            int identity;
            return Insert(info, out identity);
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        /// <param name="db">可传入事务的db</param>
        public bool Insert(TInfo info, out int identity, DbExecutor db = null)
        {
            identity = 0;
            XElement element = Load();
            List<object> lst = new List<object>();

            #region 添加所有属性变量为节点元素
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in Map.ModelList.Where(o => o.Value.IsAttribute))
            {
                object value = kic.Key.GetValue(info, null);

                //如果是索引
                if (kic.Value.Column.IsPrimaryKey)
                {
                    //当索引的值为0时，自动计算当前List的数量 + 1;
                    if (value == null || (value.IsType<int>() && value.ConvertType(0) == 0))
                    {
                        int count = GetCount();
                        TInfo lastInfo = Selector(o => o.ID).Desc(o => o.ID).ToInfo();

                        int indexValue = count > 0
                        ? kic.Key.GetValue(lastInfo, null).ConvertType(0) + 1
                        : 1;

                        while (Where(o => o.ID == indexValue).ToInfo() != null)
                        {
                            indexValue++;
                        }
                        if (kic.Key.CanWrite)
                        {
                            kic.Key.SetValue(info, value, null);
                        }
                        value = identity = indexValue;
                    }
                }

                if (value == null) { continue; }

                #region List处理
                Type type = value.GetType();
                if (type.IsGenericType && type.GetGenericTypeDefinition() != typeof(Nullable<>))
                {
                    value = ((IList)value).ToString(",");
                }
                #endregion

                if (kic.Value.PropertyExtend == eumPropertyExtend.Attribute) { lst.Add(new XAttribute(kic.Value.Column.Name, value)); }
                else { lst.Add(new XElement(kic.Value.Column.Name, value)); }
            }
            #endregion

            element.Add(new XElement(Map.ClassInfo.Name, lst.ToArray()));
            element.Save(FilePath);

            return true;
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        public int GetCount(DbExecutor db = null)
        {
            return ToList().Count;
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public int GetCount(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return GetCount(db);
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        public bool Delete(DbExecutor db = null)
        {
            XElement element = Load();

            List<int> lst = ToList().Select(o => o.ID.Value).ToList();

            foreach (int item in lst)
            {
                //索引属性
                KeyValuePair<PropertyInfo, ModelAttribute> kicIndexProperty = Map.GetModelInfo();

                //判断索引是属性，还是元素
                bool isAttribute = kicIndexProperty.Value.PropertyExtend == eumPropertyExtend.Attribute;

                foreach (XElement el in element.Elements())
                {
                    string xmlIndexValue = isAttribute ? el.Attribute(Map.IndexName).Value : el.Element(Map.IndexName).Value;

                    if (xmlIndexValue == item.ToString()) { el.Remove(); }
                }
            }
            element.Save(FilePath);

            return true;
        }

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public bool Delete(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return Delete(db);
        }

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        public TInfo ToInfo(DbExecutor db = null)
        {
            List<TInfo> lst = ToList();
            if (lst == null || lst.Count == 0) { return null; }
            return ToList().FirstOrDefault();
        }

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public TInfo ToInfo(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return ToInfo(db);
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        public List<TInfo> ToList(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            List<TInfo> lst = ToList();
            recordCount = GetCount();

            return lst.ToList(pageSize, pageIndex);
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public List<TInfo> ToList(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToList(out  recordCount, pageSize, pageIndex, db);
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        public List<TInfo> ToList(int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            int recordCount;
            if (pageIndex > 1) { return ToList(out recordCount, pageSize, pageIndex); }

            List<TInfo> lst;
            if (ExpWhere == null) { lst = Load().ToList<TInfo>(); }
            else { lst = Load().ToList<TInfo>().Where(ExpWhere.Compile()).ToList(); }

            if (!OrderByFieldName.IsNullOrEmpty())
            {
                List<TInfo> lstClone = lst.Clone();
                lstClone.Sort(new Reverser<TInfo>(typeof(TInfo), OrderByFieldName, OrderBy));

                List<TInfo> lstSort = new List<TInfo>();
                foreach (var item in lstClone)
                {
                    TInfo sortInfo = lst.Find(o => o.ID == item.ID);
                    if (sortInfo == null) { continue; }
                    lstSort.Add(sortInfo);

                    if (pageSize > 0 && lstSort.Count >= pageSize) { return lstSort; }

                }
                return lstSort.ToList(pageSize, pageIndex);
            }
            return lst.ToList(pageSize, pageIndex);
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public List<TInfo> ToList(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToList(pageSize, pageIndex, db);
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="db">可传入事务的db</param>
        public List<TInfo> ToList(Repeater rpt, DbExecutor db = null)
        {
            rpt.PageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            rpt.PageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            int recordCount = GetCount();

            #region 计算总页数
            int allCurrentPage = 0;
            if (rpt.PageSize != 0)
            {
                allCurrentPage = (recordCount / rpt.PageSize);
                allCurrentPage = ((recordCount % rpt.PageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (rpt.PageIndex > allCurrentPage) { rpt.PageIndex = allCurrentPage; }
            #endregion

            List<TInfo> lst = ToList(out recordCount, rpt.PageIndex, rpt.PageSize);
            rpt.PageCount = recordCount;

            return lst;
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public List<TInfo> ToList(Expression<Func<TInfo, bool>> where, Repeater rpt, DbExecutor db = null)
        {
            Where(where);
            return ToList(rpt, db);
        }

        /// <summary>
        /// 更改实体类
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        public bool Update(TInfo info, DbExecutor db = null)
        {
            XElement element = Load();

            List<int> lst = ToList().Select(o => o.ID.Value).ToList();

            bool result = false;

            foreach (int item in lst)
            {
                //索引属性
                KeyValuePair<PropertyInfo, ModelAttribute> kicIndexProperty = Map.GetModelInfo();

                XElement el;

                #region 查找记录
                if (kicIndexProperty.Value.PropertyExtend == eumPropertyExtend.Attribute)
                {
                    el = element.Elements().First(o => o.Attribute(Map.IndexName).Value == item.ToString());
                }
                else
                {
                    el = element.Elements().First(o => o.Element(Map.IndexName).Value == item.ToString());
                }

                if (el == null) { continue; }
                #endregion

                #region 修改数据
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in Map.ModelList.Where(o => o.Value.IsAttribute))
                {
                    //获取实体类属性的赋值
                    object value = kic.Key.GetValue(info, null);

                    if (value == null) { continue; }

                    #region List处理
                    Type type = value.GetType();
                    if (type.IsGenericType && type.GetGenericTypeDefinition() != typeof(Nullable<>))
                    {
                        value = ((IList)value).ToString(",");
                    }
                    #endregion

                    //判断实体类属性是XML的属性还是元素
                    if (kic.Value.PropertyExtend == eumPropertyExtend.Attribute)
                    {
                        el.SetAttributeValue(kic.Value.Column.Name, value);
                    }
                    else
                    {
                        el.SetElementValue(kic.Value.Column.Name, value);
                    }
                }
                #endregion

                result = true;
            }

            if (result) { element.Save(FilePath); }
            return result;
        }

        /// <summary>
        /// 更改实体类
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public bool Update(Expression<Func<TInfo, bool>> where, TInfo info, DbExecutor db = null)
        {
            Where(where);
            return Update(info, db);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldValue">字段值(请先指定selector字段)</param>
        /// <param name="selector">选择字段</param>
        /// <param name="db">可传入事务的db</param>
        public bool UpdateValue<T>(Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null)
        {
            XElement element = Load();

            List<int> lst = ToList().Select(o => o.ID.Value).ToList();

            bool result = false;

            foreach (int item in lst)
            {
                //索引属性
                KeyValuePair<PropertyInfo, ModelAttribute> kicIndexProperty = Map.GetModelInfo();

                XElement el;

                #region 查找记录
                if (kicIndexProperty.Value.PropertyExtend == eumPropertyExtend.Attribute)
                {
                    el = element.Elements().First(o => o.Attribute(Map.IndexName).Value == item.ToString());
                }
                else
                {
                    el = element.Elements().First(o => o.Element(Map.IndexName).Value == item.ToString());
                }

                if (el == null) { continue; }
                #endregion

                string fieldName = selector.GetUsedName();
                KeyValuePair<PropertyInfo, ModelAttribute> fieldProperty = Map.GetModelInfo(ExpSelector.GetUsedName());

                if (fieldProperty.Value.PropertyExtend == eumPropertyExtend.Attribute)
                {
                    decimal value = 0;
                    XAttribute xAttribute = el.Attribute(fieldName);
                    if (xAttribute != null) { value = xAttribute.Value.ConvertType(0m); }
                    value += fieldValue.ConvertType(0m);
                    el.SetAttributeValue(fieldName, value);
                }
                else
                {
                    decimal value = 0;
                    XElement xElement = el.Element(fieldName);
                    if (xElement != null) { value = xElement.Value.ConvertType(0m); }
                    value += fieldValue.ConvertType(0m);
                    el.SetElementValue(fieldName, value);
                }

                result = true;
            }
            if (result) { element.Save(FilePath); }

            return result;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldValue">字段值(请先指定selector字段)</param>
        /// <param name="selector">选择字段</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public bool UpdateValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null)
        {
            Where(where);
            return UpdateValue(selector, fieldValue, db);
        }

        /// <summary>
        /// 统计数量
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        public T GetSum<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            throw new NotImplementedException("抱歉，缓存基类方法不支持该方法，请直接使用Linq 的 Max()方法");
        }

        /// <summary>
        /// 统计数量
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public T GetSum<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            Where(where);
            return GetSum(selector, db);
        }

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        public T GetMax<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            List<TInfo> lst = ToList();
            return lst.Max(selector.Compile());
        }

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public T GetMax<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            Where(where);
            return GetMax(selector, db);
        }

        /// <summary>
        /// 获取单个字段的数据
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="defValue">为null时默认值</param>
        /// <param name="db">可传入事务的db</param>
        public T GetValue<T>(Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null)
        {
            XElement element = Load();

            TInfo info = ToInfo();

            if (info == null) { return default(T); }

            string fieldName = ExpSelector.GetUsedName();
            KeyValuePair<PropertyInfo, ModelAttribute> fieldProperty = Map.GetModelInfo(ExpSelector.GetUsedName());

            return fieldProperty.Key.GetValue(info, null).ConvertType(defValue);
        }

        /// <summary>
        /// 获取单个字段的数据
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="defValue">为null时默认值</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public T GetValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null)
        {
            Where(where);
            return GetValue(selector, defValue, db);
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        public DataTable ToTable(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            throw new NotImplementedException("抱歉，XML不支持该方法");
        }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public DataTable ToTable(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToTable(out recordCount, pageSize, pageIndex, db);
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        public DataTable ToTable(int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            throw new NotImplementedException("抱歉，XML不支持该方法");
        }

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        public DataTable ToTable(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToTable(pageSize, pageIndex, db);
        }

        public void ResetIdentity(DbExecutor db = null)
        {
            throw new NotImplementedException("Xml不支持该方法！");
        }
    }
}
