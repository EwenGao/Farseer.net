﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Qyn.Studio.Base;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using Qyn.Studio.Tools;
using Qyn.Studio.UI.WebControls;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Bean
{
    /// <summary>
    /// 数据库持久化层
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    internal abstract partial class DbBean<TInfo> where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 实体类映射
        /// </summary>
        internal Mapping Map;

        /// <summary>
        /// 当前数据库类型
        /// </summary>
        internal DataBaseType DataType;

        /// <summary>
        /// 连接字符串 
        /// </summary>
        internal string ConnectionString { get; set; }

        /// <summary>
        /// 数据库执行时间，单位秒
        /// </summary>
        internal int CommandTimeout { get; set; }

        private DbExecutor dbExtor;
        internal DbExecutor DbExtor
        {
            get
            {
                if (dbExtor == null) { dbExtor = new DbExecutor(DataType, ConnectionString, CommandTimeout); }
                return dbExtor;
            }
        }

        /// <summary>
        /// 构造函数（指定完整的连接字符串）
        /// </summary>
        internal DbBean()
        {
            Map = typeof(TInfo);
            DataType = Map.ClassInfo.DataType;
            ConnectionString = Map.ClassInfo.ConnStr;
            CommandTimeout = Map.ClassInfo.CommandTimeout;
        }

        /// <summary>
        /// 构造函数（指定完整的连接字符串）
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="commandTimeout">命令执时超时时间</param>
        internal DbBean(DataBaseType dbType, string connetionString, int commandTimeout)
        {
            Map = typeof(TInfo);
            DataType = dbType;
            ConnectionString = connetionString;
            CommandTimeout = commandTimeout;
        }

        /// <summary>
        /// 返回参数列表
        /// </summary>
        /// <param name="info">实体类</param>
        internal List<DbParameter> GetParameter(TInfo info, DbExecutor db = null)
        {
            List<DbParameter> lst = new List<DbParameter>();

            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in Map.ModelList.Where(o => o.Value.IsAttribute))
            {
                object obj = kic.Key.GetValue(info, null);
                if (obj == null) { continue; }

                #region List处理
                Type type = obj.GetType();
                if (type.IsGenericType)
                {
                    if (type.GetGenericTypeDefinition() != typeof(Nullable<>)) { obj = ((IList)obj).ToString(","); }
                    else
                    {
                        if (type.GetGenericArguments()[0] == typeof(int)) { obj = ((List<int?>)obj).ToString(","); }
                    }
                }
                #endregion

                lst.Add(NewParam(kic.Value.Column.Name, obj, db));
            }

            return lst;
        }

        internal List<DbParameter> WhereParams = new List<DbParameter>();
        internal StringBuilder WhereString = new StringBuilder();
        internal StringBuilder SelectorString = new StringBuilder();
        internal StringBuilder SortString = new StringBuilder();

        public virtual void ResetIdentity(DbExecutor db = null)
        {
            throw new NotImplementedException("该数据库不支持该方法！");
        }

        #region 参数设置
        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        /// <param name="name">参数名称</param>
        /// <param name="valu">参数值</param>
        /// <param name="type">参数类型</param>
        /// <param name="len">参数长度</param>
        /// <param name="output">是否是输出值</param>
        public DbParameter NewParam(string name, object valu, DbType type, int len, bool output = false, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            #region Oracle
            if (DataType == DataBaseType.Oracle)
            {
                if (valu.GetType() == typeof(byte[]))
                {
                    OracleParameter oracleParam = new OracleParameter(DbFactory.CreateParamsName(DataType) + name, OracleType.Blob, 0);
                    oracleParam.Value = valu;
                    return oracleParam;
                }
                else if (type == DbType.String && (ParseString.Length(valu.ToString()) * 2) > (1024 * 4))
                {
                    OracleParameter oracleParam = new OracleParameter(DbFactory.CreateParamsName(DataType) + name, OracleType.Clob, valu.ToString().Length);
                    oracleParam.Value = valu;
                    return oracleParam;
                }

            }
            #endregion

            if (type == DbType.DateTime && valu.ConvertType(DateTime.MinValue) == DateTime.MinValue) { valu = "1900-01-01".ConvertType<DateTime>(); }

            if (valu is Enum) { valu = (int)valu; len = 8; }
            if (valu.GetType().IsGenericType)
            {

                if (valu.GetType().GetGenericTypeDefinition() != typeof(Nullable<>)) { valu = ((IList)valu).ToString(","); }
                else
                {
                    if (valu.GetType().GetGenericArguments()[0] == typeof(int)) { valu = ((List<int?>)valu).ToString(","); }
                }
                len = valu.ToString().Length;
            }

            DbParameter param = db.factory.CreateParameter();
            param.DbType = type;
            param.ParameterName = DbFactory.CreateParamsName(DataType) + name;
            param.Value = valu;
            if (len > 0) param.Size = len;
            if (output) param.Direction = ParameterDirection.Output;
            return param;
        }

        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        public DbParameter NewParam(string name, object valu, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            if (valu == null) { valu = string.Empty; }

            Type type = valu.GetType();
            if (type.Name.IsEquals("Nullable`1")) { type = Nullable.GetUnderlyingType(type); }

            switch (type.Name)
            {
                case "DateTime":
                    return this.NewParam(name, valu, DbType.DateTime, 8, false, db);
                case "Boolean":
                    return this.NewParam(name, valu, DbType.Boolean, 1, false, db);
                case "Int32":
                    return this.NewParam(name, valu, DbType.Int32, 4, false, db);
                case "Int16":
                    return this.NewParam(name, valu, DbType.Int16, 2, false, db);
                case "Decimal":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                case "Byte":
                    return this.NewParam(name, valu, DbType.Byte, 1, false, db);
                case "Long":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                case "Float":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                case "Double":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                default:
                    return this.NewParam(name, valu, DbType.String, valu.ToString().Length, false, db);
            }
        }
        #endregion
    }

    /// <summary>
    /// 实现IBean接口
    /// </summary>    
    internal abstract partial class DbBean<TInfo> : IBean<TInfo>
    {
        public virtual IBean<TInfo> Where(Expression<Func<TInfo, bool>> where)
        {
            if (where != null)
            {
                if (WhereString.Length == 0) { WhereString.Append("Where "); }
                else { WhereString.Append(" AND "); }

                List<DbParameter> lstParams;
                WhereString.Append(Translator(where, out lstParams));
                WhereParams.AddRange(lstParams);
            }
            return this;
        }

        public virtual IBean<TInfo> Selector(Expression<Func<TInfo, object>> selector)
        {
            if (selector != null)
            {
                if (SelectorString.Length > 0) { SelectorString.Append(","); }
                SelectorString.Append(Translator(selector).ToString(",").DelEndOf(","));
            }
            return this;
        }

        public virtual IBean<TInfo> Asc(Expression<Func<TInfo, object>> sort)
        {
            if (sort != null)
            {
                if (SortString.Length == 0) { SortString.Append("Order By "); }
                else { SortString.Append(","); }

                SortString.Append((Translator(sort).ToString(" ASC,") + " ASC").DelEndOf(","));
            }
            return this;
        }

        public virtual IBean<TInfo> Desc(Expression<Func<TInfo, object>> sort)
        {
            if (sort != null)
            {
                if (SortString.Length == 0) { SortString.Append("Order By "); }
                else { SortString.Append(","); }

                SortString.Append((Translator(sort).ToString(" DESC,") + " DESC").DelEndOf(","));
            }
            return this;
        }

        public virtual bool Insert(TInfo info, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            List<DbParameter> parms = GetParameter(info, db);

            if (parms.Count == 0) { return false; }

            bool indexHaveValue = Map.GetModelInfo().Key != null ? Map.GetModelInfo().Key.GetValue(info, null) != null : false;

            //要插入的表
            StringPlus sql = new StringPlus();

            sql.AppendFormat("INSERT INTO {0}", DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType));

            #region 要插入的值
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parms)
            {
                fields += string.Format("{0},", DbFactory.CreateTableAegis(param.ParameterName.Substring(1), DataType));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";

            sql.AppendFormat(fields + " VALUES " + values);
            #endregion

            return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
        }

        public virtual bool Insert(TInfo info, out int identity, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            // 开启事务，获得标识ID
            db.OpenTran(IsolationLevel.ReadCommitted);
            Insert(info, db);
            identity = db.ExecuteScalar(CommandType.Text, string.Format("select max({0}) from {1}", Map.IndexName, DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType))).ConvertType(0);
            db.Commit();
            db.Close(true);
            return true;
        }

        public virtual int GetCount(DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            string sql = string.Format("SELECT Count(0) FROM {0} {1}", DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString);
            return db.ExecuteScalar(CommandType.Text, sql, WhereParams.ToArray()).ConvertType(0);
        }

        public virtual int GetCount(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return GetCount(db);
        }

        public virtual bool Delete(DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            string sql = string.Format("DELETE FROM {0} {1}", DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString);

            return db.ExecuteNonQuery(CommandType.Text, sql, WhereParams.ToArray()) > 0;
        }

        public virtual bool Delete(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return Delete(db);
        }

        public virtual TInfo ToInfo(DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string strFields = SelectorString.Length == 0 ? "*" : SelectorString.ToString();
            string sql = string.Format("select top 1 {0} from {1} {2} {3}", strFields, DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString, SortString);
            IDataReader reader = db.GetReader(CommandType.Text, sql, WhereParams.ToArray());
            return reader.ToInfo<TInfo>();
        }

        public virtual TInfo ToInfo(Expression<Func<TInfo, bool>> where, DbExecutor db = null)
        {
            Where(where);
            return ToInfo(db);
        }

        public virtual DataTable ToTable(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            recordCount = GetCount(db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            if (pageIndex == 1) { return ToTable(pageSize, pageIndex, db); }

            DataTable dt;
            string sql = string.Empty;
            if (SortString.Length == 0) { SortString.AppendFormat("ORDER BY {0} ASC", Map.IndexName); }
            string strFields = SelectorString.Length == 0 ? "*" : SelectorString.ToString();

            string sort2 = SortString.ToString().Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT TOP {1} {0} FROM (SELECT TOP {2} {0} FROM {3} {4} {5}) a  {6}",
                    strFields, pageSize, pageSize * pageIndex, DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString, SortString, sort2);

            dt = db.GetDataTable(CommandType.Text, sql, WhereParams.ToArray());

            return dt.Reverse();
        }

        public virtual DataTable ToTable(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToTable(out recordCount, pageSize, pageIndex, db);
        }

        public virtual DataTable ToTable(int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            if (pageIndex > 1)
            {
                int recordCount;
                return ToTable(out recordCount, pageSize, pageIndex, db);
            }

            if (db == null) { db = DbExtor; }

            string strFields = SelectorString.Length == 0 ? "*" : SelectorString.ToString();
            string topString = pageSize > 0 ? string.Format("TOP {0}", pageSize) : string.Empty;

            string sql = string.Format("SELECT {0} {1} FROM {2} {3} {4}", topString, strFields, DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString, SortString);

            return db.GetDataTable(CommandType.Text, sql, WhereParams.ToArray());
        }

        public virtual DataTable ToTable(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToTable(pageSize, pageIndex, db);
        }

        public virtual List<TInfo> ToList(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DataTable dt = ToTable(out recordCount, pageSize, pageIndex, db);
            if (dt != null) { return dt.ToList<TInfo>(); }
            return new List<TInfo>();
        }

        public virtual List<TInfo> ToList(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToList(out  recordCount, pageSize, pageIndex, db);
        }

        public virtual List<TInfo> ToList(int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            return ToTable(pageSize, pageIndex, db).ToList<TInfo>();
        }

        public virtual List<TInfo> ToList(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null)
        {
            Where(where);
            return ToList(pageSize, pageIndex, db);
        }

        public virtual List<TInfo> ToList(Repeater rpt, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            rpt.PageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            rpt.PageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            int recordCount = GetCount(db);

            #region 计算总页数
            int allCurrentPage = 0;
            if (rpt.PageSize != 0)
            {
                allCurrentPage = (recordCount / rpt.PageSize);
                allCurrentPage = ((recordCount % rpt.PageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (rpt.PageIndex > allCurrentPage) { rpt.PageIndex = allCurrentPage; }
            #endregion

            List<TInfo> lst = ToList(out recordCount, rpt.PageSize, rpt.PageIndex, db);
            rpt.PageCount = recordCount;

            return lst;
        }

        public virtual List<TInfo> ToList(Expression<Func<TInfo, bool>> where, Repeater rpt, DbExecutor db = null)
        {
            Where(where);
            return ToList(rpt, db);
        }

        public virtual bool Update(TInfo info, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            List<DbParameter> parms = GetParameter(info, db);
            if (parms.Count == 0) return false;

            //要更新的表
            StringPlus sql = new StringPlus();
            sql.AppendFormat("UPDATE {0} SET ", DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType));

            //要更新的字段
            foreach (DbParameter parm in parms)
            {
                sql.AppendFormat("{0} = {1} ,", DbFactory.CreateTableAegis(parm.ParameterName.Substring(1), DataType), parm.ParameterName);
            }
            sql.DelLastChar(",");

            sql.AppendFormat(" {0}", WhereString);

            parms.AddRange(WhereParams);

            return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
        }

        public virtual bool Update(Expression<Func<TInfo, bool>> where, TInfo info, DbExecutor db = null)
        {
            Where(where);
            return Update(info, db);
        }

        public virtual bool UpdateValue<T>(Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("UPDATE {0} SET {1} = {1} + {2} {3}", DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), selector.GetUsedName(), fieldValue, WhereString);
            return db.ExecuteNonQuery(CommandType.Text, sql, WhereParams.ToArray()) > 0;
        }

        public virtual bool UpdateValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null)
        {
            Where(where);
            return UpdateValue(selector, fieldValue, db);
        }

        public virtual T GetSum<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SELECT SUM({0}) FROM {1} {2}", Translator(selector).ToString(","), DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString);

            return db.ExecuteScalar(CommandType.Text, sql, WhereParams.ToArray()).ConvertType(default(T));
        }

        public virtual T GetSum<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            Where(where);
            return GetSum(selector, db);
        }

        public virtual T GetMax<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SELECT MAX({0}) FROM {1} {2}", Translator(selector).ToString(","), DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString);

            return db.ExecuteScalar(CommandType.Text, sql, WhereParams.ToArray()).ConvertType(default(T));
        }

        public virtual T GetMax<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct
        {
            Where(where);
            return GetMax(selector, db);
        }

        public virtual T GetValue<T>(Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SELECT TOP 1 {0} FROM {1} {2}", Translator(selector).ToString(","), DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType), WhereString);
            return db.ExecuteScalar(CommandType.Text, sql, WhereParams.ToArray()).ConvertType(defValue);
        }

        public virtual T GetValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null)
        {
            Where(where);
            return GetValue(selector, defValue, db);
        }

    }

    /// <summary>
    /// Expressions访问器
    /// </summary>
    internal abstract partial class DbBean<TInfo>
    {
        /// <summary>
        /// 条件堆栈
        /// </summary>
        protected Stack<string> m_conditionParts;
        /// <summary>
        /// 参数列表
        /// </summary>
        protected List<DbParameter> m_lstParams;
        /// <summary>
        /// 参数个数（标识）
        /// </summary>
        protected int m_ParamsCount;

        /// <summary>
        /// 解释T-SQL(Where)
        /// </summary>
        /// <param name="expression">Lambda表达式</param>
        /// <param name="lstParams">输出参数列表</param>
        internal virtual string Translator(Expression expression, out List<DbParameter> lstParams)
        {
            this.m_conditionParts = new Stack<string>();
            this.m_lstParams = new List<DbParameter>();

            if (expression != null) { this.Visit(expression); }

            lstParams = m_lstParams;
            string sql = string.Empty;
            while (m_conditionParts.Count > 0) { sql = this.m_conditionParts.Pop() + " " + sql; }
            return sql.IsNullOrEmpty() ? "where 1=1" : sql;
        }

        /// <summary>
        /// 解释T-SQL(Selector、Order)
        /// </summary>
        /// <param name="expression">Lambda表达式</param>
        internal virtual List<string> Translator(Expression expression)
        {
            this.m_conditionParts = new Stack<string>();

            if (expression != null) { this.Visit(expression); }

            List<string> lst = new List<string>();
            while (this.m_conditionParts.Count > 0) { lst.Add(this.m_conditionParts.Pop()); }
            lst.Reverse();
            return lst;
        }

        /// <summary>
        /// 将二元符号转换成T-SQL可识别的操作符
        /// </summary>
        internal virtual Expression VisitBinary(BinaryExpression b)
        {
            if (b == null) return b;

            string opr;
            switch (b.NodeType)
            {
                case ExpressionType.Equal:
                    opr = "=";
                    break;
                case ExpressionType.NotEqual:
                    opr = "<>";
                    break;
                case ExpressionType.GreaterThan:
                    opr = ">";
                    break;
                case ExpressionType.GreaterThanOrEqual:
                    opr = ">=";
                    break;
                case ExpressionType.LessThan:
                    opr = "<";
                    break;
                case ExpressionType.LessThanOrEqual:
                    opr = "<=";
                    break;
                case ExpressionType.AndAlso:
                    opr = "AND";
                    break;
                case ExpressionType.OrElse:
                    opr = "OR";
                    break;
                case ExpressionType.Add:
                    opr = "+";
                    break;
                case ExpressionType.Subtract:
                    opr = "-";
                    break;
                case ExpressionType.Multiply:
                    opr = "*";
                    break;
                case ExpressionType.Divide:
                    opr = "/";
                    break;
                default:
                    throw new NotSupportedException(b.NodeType + "is not supported.");
            }

            this.Visit(b.Left);
            this.Visit(b.Right);
            string right = this.m_conditionParts.Pop();
            // 当存在Not 时，特殊处理
            while (this.m_conditionParts.Count > 0 && this.m_conditionParts.First().IsEquals("Not"))
            {
                right = this.m_conditionParts.Pop() + " " + right;
            }

            string left = this.m_conditionParts.Pop();
            // 当存在Not 时，特殊处理
            while (this.m_conditionParts.Count > 0 && this.m_conditionParts.First().IsEquals("Not"))
            {
                left = this.m_conditionParts.Pop() + " " + left;
            }

            if (opr == "AND" || opr == "OR")
            {
                if (m_lstParams.Where(o => o.ParameterName == right).Count() > 0)
                {
                    bool result = m_lstParams.Where(o => o.ParameterName == right).FirstOrDefault().Value.ToString().IsEquals("true");
                    m_lstParams.RemoveAll(o => o.ParameterName == right);
                    if (result) { right = "1=1"; }
                    else { right = "1<>1"; }
                }

                if (m_lstParams.Where(o => o.ParameterName == left).Count() > 0)
                {
                    bool result = m_lstParams.Where(o => o.ParameterName == left).FirstOrDefault().Value.ToString().IsEquals("true");
                    m_lstParams.RemoveAll(o => o.ParameterName == left);
                    if (result) { left = "1=1"; }
                    else { left = "1<>1"; }
                }
            }
            string condition = String.Format("({2} {1} {0})", right, opr, left);

            this.m_conditionParts.Push(condition);

            return b;
        }

        /// <summary>
        /// 将属性变量的右边值，转换成T-SQL的字段值
        /// </summary>
        internal virtual Expression VisitConstant(ConstantExpression c)
        {
            if (c == null) return c;
            m_ParamsCount++;
            string paramsPrefix = DbFactory.CreateParamsName(DataType);
            string paramName = String.Format("{0}Parms_{1}", paramsPrefix, m_ParamsCount.ToString());
            this.m_conditionParts.Push(paramName);
            m_lstParams.Add(NewParam(paramName.Substring(paramsPrefix.Length), c.Value));

            return c;
        }

        /// <summary>
        /// 将属性变量转换成T-SQL字段名
        /// </summary>
        internal virtual Expression VisitMemberAccess(MemberExpression m)
        {
            if (m == null) return m;

            switch (m.NodeType)//switch (m.Expression.NodeType)
            {
                //局部变量
                case ExpressionType.Constant:
                    return Visit(VisitConvert(m));
                default:
                    {
                        KeyValuePair<PropertyInfo, ModelAttribute> keyValue;

                        while (m != null)
                        {
                            keyValue = Map.GetModelInfo(((PropertyInfo)m.Member).Name);
                            if (keyValue.Key == null) { m = m.Expression as MemberExpression; continue; }

                            string usedName = keyValue.Value.Column.Name;
                            this.m_conditionParts.Push(String.Format("{0}", DbFactory.CreateTableAegis(usedName, DataType)));
                            break;
                        }
                        return m;
                    }
            }
        }

        /// <summary>
        /// 数组值
        /// </summary>
        internal virtual Expression VisitNewArray(NewArrayExpression na)
        {
            foreach (Expression ex in na.Expressions)
            {
                this.Visit(ex);
            }
            return null;
        }

        /// <summary>
        /// 值类型的转换
        /// </summary>
        internal virtual Expression VisitUnary(UnaryExpression u)
        {
            if (u.NodeType == ExpressionType.Not) { this.m_conditionParts.Push("Not"); }
            return this.Visit(((UnaryExpression)u).Operand);
        }

        /// <summary>
        /// 将变量转换成值
        /// </summary>
        internal virtual Expression VisitConvert(Expression e)
        {
            //if (e is BinaryExpression || e.NodeType == ExpressionType.Constant || e.NodeType == ExpressionType.Call) { return e; }// || e.NodeType == ExpressionType.Convert
            //if (e.NodeType == ExpressionType.MemberAccess)
            //{
            //    MemberExpression memberExpression = e as MemberExpression;
            //    if (memberExpression == null || (memberExpression.Expression != null && memberExpression.Expression.NodeType == ExpressionType.Parameter)) { return e; }
            //}
            try
            {
                LambdaExpression lambda = Expression.Lambda(e);
                return Expression.Constant(lambda.Compile().DynamicInvoke(null), e.Type);
            }
            catch { return e; }
        }

        internal virtual Expression Visit(Expression exp)
        {
            if (exp == null) { return exp; }

            if (exp.NodeType != ExpressionType.Lambda && exp.NodeType != ExpressionType.Convert) { exp = VisitConvert(exp); }
            switch (exp.NodeType)
            {
                case ExpressionType.Add:
                case ExpressionType.AddChecked:
                case ExpressionType.And:
                case ExpressionType.AndAlso:
                case ExpressionType.ArrayIndex:
                case ExpressionType.Coalesce:
                case ExpressionType.Divide:
                case ExpressionType.Equal:
                case ExpressionType.ExclusiveOr:
                case ExpressionType.GreaterThan:
                case ExpressionType.GreaterThanOrEqual:
                case ExpressionType.LeftShift:
                case ExpressionType.LessThan:
                case ExpressionType.LessThanOrEqual:
                case ExpressionType.Modulo:
                case ExpressionType.Multiply:
                case ExpressionType.MultiplyChecked:
                case ExpressionType.NotEqual:
                case ExpressionType.Or:
                case ExpressionType.OrElse:
                case ExpressionType.Power:
                case ExpressionType.RightShift:
                case ExpressionType.Subtract:
                case ExpressionType.SubtractChecked:
                    return this.VisitBinary((BinaryExpression)exp);
                case ExpressionType.ArrayLength:
                case ExpressionType.Convert:
                    {
                        Expression ex = ((UnaryExpression)exp).Operand;
                        return Visit(ex);
                        //switch (ex.NodeType)
                        //{
                        //    case ExpressionType.MemberAccess: 
                        //    case ExpressionType.Call: return Visit(ex);
                        //}
                        //return VisitConstant((ConstantExpression)ex);
                    }
                case ExpressionType.ConvertChecked:
                case ExpressionType.Negate:
                case ExpressionType.UnaryPlus:
                case ExpressionType.NegateChecked:
                case ExpressionType.Not:
                case ExpressionType.Quote:
                case ExpressionType.TypeAs:
                    return this.VisitUnary((UnaryExpression)exp);

                case ExpressionType.Call:
                    return this.VisitMethodCall((MethodCallExpression)exp);

                case ExpressionType.Conditional:
                    return this.VisitConditional((ConditionalExpression)exp);

                case ExpressionType.Constant:
                    return this.VisitConstant((ConstantExpression)exp);

                case ExpressionType.Invoke:
                    return this.VisitInvocation((InvocationExpression)exp);

                case ExpressionType.Lambda:
                    return this.VisitLambda((LambdaExpression)exp);

                case ExpressionType.ListInit:
                    return this.VisitListInit((ListInitExpression)exp);

                case ExpressionType.MemberAccess:
                    return this.VisitMemberAccess((MemberExpression)exp);

                case ExpressionType.MemberInit:
                    return this.VisitMemberInit((MemberInitExpression)exp);

                case ExpressionType.New:
                    return this.VisitNew((NewExpression)exp);

                case ExpressionType.NewArrayInit:
                case ExpressionType.NewArrayBounds:
                    return this.VisitNewArray((NewArrayExpression)exp);

                case ExpressionType.Parameter:
                    return this.VisitParameter((ParameterExpression)exp);

                case ExpressionType.TypeIs:
                    return this.VisitTypeIs((TypeBinaryExpression)exp);
            }
            throw new Exception(string.Format("类型：(ExpressionType){0}，不存在。", exp.NodeType));
        }

        /// <summary>
        /// 解析方法
        /// </summary>
        internal virtual Expression VisitMethodCall(MethodCallExpression m)
        {
            if (m.Object == null)
            {
                for (int i = m.Arguments.Count - 1; i > 0; i--)
                {
                    Expression exp = m.Arguments[i];
                    while (exp.NodeType == ExpressionType.Call) { exp = ((MethodCallExpression)exp).Object; }
                    this.Visit(exp);
                }
                this.Visit(m.Arguments[0]);
            }
            else
            {
                this.Visit(m.Object);
                for (int i = 0; i < m.Arguments.Count; i++)
                {
                    Expression exp = m.Arguments[i];
                    while (exp.NodeType == ExpressionType.Call) { exp = ((MethodCallExpression)exp).Object; }
                    this.Visit(exp);
                }
            }
            return m;
        }

        internal virtual MemberBinding VisitBinding(MemberBinding binding)
        {
            switch (binding.BindingType)
            {
                case MemberBindingType.Assignment:
                    return this.VisitMemberAssignment((MemberAssignment)binding);

                case MemberBindingType.MemberBinding:
                    return this.VisitMemberMemberBinding((MemberMemberBinding)binding);

                case MemberBindingType.ListBinding:
                    return this.VisitMemberListBinding((MemberListBinding)binding);
            }
            throw new Exception(string.Format("类型：(MemberBindingType){0}，不存在。", binding.BindingType));
        }
        internal virtual IEnumerable<MemberBinding> VisitBindingList(ReadOnlyCollection<MemberBinding> original)
        {
            List<MemberBinding> list = null;
            int num = 0;
            int count = original.Count;
            while (num < count)
            {
                MemberBinding item = this.VisitBinding(original[num]);
                if (list != null)
                {
                    list.Add(item);
                }
                else if (item != original[num])
                {
                    list = new List<MemberBinding>(count);
                    for (int i = 0; i < num; i++)
                    {
                        list.Add(original[i]);
                    }
                    list.Add(item);
                }
                num++;
            }
            if (list != null)
            {
                return list;
            }
            return original;
        }
        internal virtual Expression VisitConditional(ConditionalExpression c)
        {
            Expression test = this.Visit(c.Test);
            Expression ifTrue = this.Visit(c.IfTrue);
            Expression ifFalse = this.Visit(c.IfFalse);
            if (((test == c.Test) && (ifTrue == c.IfTrue)) && (ifFalse == c.IfFalse))
            {
                return c;
            }
            return Expression.Condition(test, ifTrue, ifFalse);
        }
        internal virtual ElementInit VisitElementInitializer(ElementInit initializer)
        {
            ReadOnlyCollection<Expression> arguments = this.VisitExpressionList(initializer.Arguments);
            if (arguments != initializer.Arguments)
            {
                return Expression.ElementInit(initializer.AddMethod, arguments);
            }
            return initializer;
        }
        internal virtual IEnumerable<ElementInit> VisitElementInitializerList(ReadOnlyCollection<ElementInit> original)
        {
            List<ElementInit> list = null;
            int num = 0;
            int count = original.Count;
            while (num < count)
            {
                ElementInit item = this.VisitElementInitializer(original[num]);
                if (list != null)
                {
                    list.Add(item);
                }
                else if (item != original[num])
                {
                    list = new List<ElementInit>(count);
                    for (int i = 0; i < num; i++)
                    {
                        list.Add(original[i]);
                    }
                    list.Add(item);
                }
                num++;
            }
            if (list != null)
            {
                return list;
            }
            return original;
        }
        internal virtual ReadOnlyCollection<Expression> VisitExpressionList(ReadOnlyCollection<Expression> original)
        {
            List<Expression> sequence = null;
            int num = 0;
            int count = original.Count;
            while (num < count)
            {
                Expression item = this.Visit(original[num]);
                if (sequence != null)
                {
                    sequence.Add(item);
                }
                else if (item != original[num])
                {
                    sequence = new List<Expression>(count);
                    for (int i = 0; i < num; i++)
                    {
                        sequence.Add(original[i]);
                    }
                    sequence.Add(item);
                }
                num++;
            }
            if (sequence != null)
            {
                ReadOnlyCollection<Expression> onlys = (ReadOnlyCollection<Expression>)(IEnumerable)sequence;
                if (onlys != null) { return onlys; }

                new Buffer<Expression>(sequence).ToArray();

                return new ReadOnlyCollection<Expression>(new Buffer<Expression>(sequence).ToArray());

            }
            return original;
        }
        internal virtual Expression VisitInvocation(InvocationExpression iv)
        {
            IEnumerable<Expression> arguments = this.VisitExpressionList(iv.Arguments);
            Expression expression = this.Visit(iv.Expression);
            if ((arguments == iv.Arguments) && (expression == iv.Expression))
            {
                return iv;
            }
            return Expression.Invoke(expression, arguments);
        }
        internal virtual Expression VisitLambda(LambdaExpression lambda)
        {
            Expression body = this.Visit(lambda.Body);
            if (body != lambda.Body)
            {
                try
                {
                    return Expression.Lambda(lambda.Type, Expression.Convert(body, typeof(object)), lambda.Parameters);
                }
                catch
                {
                    return lambda.Body;
                }
            }
            return lambda;
        }
        internal virtual Expression VisitListInit(ListInitExpression init)
        {
            NewExpression newExpression = this.VisitNew(init.NewExpression);
            IEnumerable<ElementInit> initializers = this.VisitElementInitializerList(init.Initializers);
            if ((newExpression == init.NewExpression) && (initializers == init.Initializers))
            {
                return init;
            }
            return Expression.ListInit(newExpression, initializers);
        }
        internal virtual MemberAssignment VisitMemberAssignment(MemberAssignment assignment)
        {
            Expression expression = this.Visit(assignment.Expression);
            if (expression != assignment.Expression)
            {
                return Expression.Bind(assignment.Member, expression);
            }
            return assignment;
        }
        internal virtual Expression VisitMemberInit(MemberInitExpression init)
        {
            NewExpression newExpression = this.VisitNew(init.NewExpression);
            IEnumerable<MemberBinding> bindings = this.VisitBindingList(init.Bindings);
            if ((newExpression == init.NewExpression) && (bindings == init.Bindings))
            {
                return init;
            }
            return Expression.MemberInit(newExpression, bindings);
        }
        internal virtual MemberListBinding VisitMemberListBinding(MemberListBinding binding)
        {
            IEnumerable<ElementInit> initializers = this.VisitElementInitializerList(binding.Initializers);
            if (initializers != binding.Initializers)
            {
                return Expression.ListBind(binding.Member, initializers);
            }
            return binding;
        }
        internal virtual MemberMemberBinding VisitMemberMemberBinding(MemberMemberBinding binding)
        {
            IEnumerable<MemberBinding> bindings = this.VisitBindingList(binding.Bindings);
            if (bindings != binding.Bindings)
            {
                return Expression.MemberBind(binding.Member, bindings);
            }
            return binding;
        }
        internal virtual NewExpression VisitNew(NewExpression nex)
        {
            IEnumerable<Expression> arguments = this.VisitExpressionList(nex.Arguments);
            if (arguments == nex.Arguments)
            {
                return nex;
            }
            if (nex.Members != null)
            {
                return Expression.New(nex.Constructor, arguments, nex.Members);
            }
            return Expression.New(nex.Constructor, arguments);
        }
        internal virtual Expression VisitParameter(ParameterExpression p)
        {
            return p;
        }
        internal virtual Expression VisitTypeIs(TypeBinaryExpression b)
        {
            Expression expression = this.Visit(b.Expression);
            if (expression != b.Expression)
            {
                return Expression.TypeIs(expression, b.TypeOperand);
            }
            return b;
        }
        [StructLayout(LayoutKind.Sequential)]
        internal struct Buffer<TElement>
        {
            internal TElement[] items;
            internal int count;
            internal Buffer(IEnumerable<TElement> source)
            {
                TElement[] array = null;
                int length = 0;
                ICollection<TElement> is2 = source as ICollection<TElement>;
                if (is2 != null)
                {
                    length = is2.Count;
                    if (length > 0)
                    {
                        array = new TElement[length];
                        is2.CopyTo(array, 0);
                    }
                }
                else
                {
                    foreach (TElement local in source)
                    {
                        if (array == null)
                        {
                            array = new TElement[4];
                        }
                        else if (array.Length == length)
                        {
                            TElement[] destinationArray = new TElement[length * 2];
                            Array.Copy(array, 0, destinationArray, 0, length);
                            array = destinationArray;
                        }
                        array[length] = local;
                        length++;
                    }
                }
                this.items = array;
                this.count = length;
            }

            internal TElement[] ToArray()
            {
                if (this.count == 0)
                {
                    return new TElement[0];
                }
                if (this.items.Length == this.count)
                {
                    return this.items;
                }
                TElement[] destinationArray = new TElement[this.count];
                Array.Copy(this.items, 0, destinationArray, 0, this.count);
                return destinationArray;
            }
        }

        /// <summary>
        /// 清除值为空的条件，并给与1<>1的SQL
        /// </summary>
        internal virtual bool ClearCallSql()
        {
            if (m_lstParams.GetLast().Value.ToString().IsNullOrEmpty())
            {
                m_lstParams.RemoveAt(m_lstParams.Count - 1);
                m_conditionParts.Pop();
                m_conditionParts.Pop();
                this.m_conditionParts.Push("1<>1");
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// 实现IBean接口
    /// </summary>    
    public abstract partial class DbBean
    {
        private DbExecutor dbExtor;
        /// <summary>
        /// DbExecutor实体
        /// </summary>
        public DbExecutor DbExtor
        {
            get
            {
                if (dbExtor == null) { dbExtor = new DbExecutor(DataType, ConnectionString, CommandTimeout); }
                return dbExtor;
            }
        }

        /// <summary>
        /// 连接字符串 
        /// </summary>
        public string ConnectionString { get; set; }

        /// <summary>
        /// 数据库执行时间，单位秒
        /// </summary>
        public int CommandTimeout { get; set; }

        /// <summary>
        /// 表名
        /// </summary>
        public string TableName { get; set; }

        /// <summary>
        /// 当前数据库类型
        /// </summary>
        public DataBaseType DataType;

        /// <summary>
        /// 传入数据库连接配置
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">表名称</param>
        /// <param name="commandTimeout">执行SQL超时时间</param>
        public DbBean(string connetionString, string tableName, DataBaseType dbType = DataBaseType.SqlServer, int commandTimeout = 30)
        {
            TableName = tableName;
            DataType = dbType;
            ConnectionString = connetionString;
            CommandTimeout = commandTimeout;
        }

        #region 参数设置
        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        /// <param name="name">参数名称</param>
        /// <param name="valu">参数值</param>
        /// <param name="type">参数类型</param>
        /// <param name="len">参数长度</param>
        /// <param name="output">是否是输出值</param>
        public DbParameter NewParam(string name, object valu, DbType type, int len, bool output = false, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            #region Oracle
            if (DataType == DataBaseType.Oracle)
            {
                if (valu.GetType() == typeof(byte[]))
                {
                    OracleParameter oracleParam = new OracleParameter(DbFactory.CreateParamsName(DataType) + name, OracleType.Blob, 0);
                    oracleParam.Value = valu;
                    return oracleParam;
                }
                else if (type == DbType.String && (ParseString.Length(valu.ToString()) * 2) > (1024 * 4))
                {
                    OracleParameter oracleParam = new OracleParameter(DbFactory.CreateParamsName(DataType) + name, OracleType.Clob, valu.ToString().Length);
                    oracleParam.Value = valu;
                    return oracleParam;
                }
            }
            #endregion

            if (type == DbType.DateTime && valu.ConvertType(DateTime.MinValue) == DateTime.MinValue) { valu = "1900-01-01".ConvertType<DateTime>(); }

            if (valu is Enum) { valu = (int)valu; len = 8; }
            if (valu.GetType().IsGenericType)
            {

                if (valu.GetType().GetGenericTypeDefinition() != typeof(Nullable<>)) { valu = ((IList)valu).ToString(","); }
                else
                {
                    if (valu.GetType().GetGenericArguments()[0] == typeof(int)) { valu = ((List<int?>)valu).ToString(","); }
                }
                len = valu.ToString().Length;
            }

            DbParameter param = db.factory.CreateParameter();
            param.DbType = type;
            param.ParameterName = DbFactory.CreateParamsName(DataType) + name;
            param.Value = valu;
            if (len > 0) param.Size = len;
            if (output) param.Direction = ParameterDirection.Output;
            return param;
        }

        /// <summary>
        /// 创建一个数据库参数对象
        /// </summary>
        public DbParameter NewParam(string name, object valu, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            if (valu == null) { valu = string.Empty; }

            Type type = valu.GetType();
            if (type.Name.IsEquals("Nullable`1")) { type = Nullable.GetUnderlyingType(type); }

            switch (type.Name)
            {
                case "DateTime":
                    return this.NewParam(name, valu, DbType.DateTime, 8, false, db);
                case "Boolean":
                    return this.NewParam(name, valu, DbType.Boolean, 1, false, db);
                case "Int32":
                    return this.NewParam(name, valu, DbType.Int32, 4, false, db);
                case "Int16":
                    return this.NewParam(name, valu, DbType.Int16, 2, false, db);
                case "Decimal":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                case "Byte":
                    return this.NewParam(name, valu, DbType.Byte, 1, false, db);
                case "Long":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                case "Float":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                case "Double":
                    return this.NewParam(name, valu, DbType.Decimal, 8, false, db);
                default:
                    return this.NewParam(name, valu, DbType.String, valu.ToString().Length, false, db);
            }
        }
        #endregion

        /// <summary>
        /// 检查排序语句是否符合规则
        /// </summary>
        protected string Sort(string sort = "")
        {
            if (string.IsNullOrEmpty(sort)) { return string.Empty; }
            if (sort.IsStartsWith("ORDER BY")) { sort = sort.Substring(9).Trim(); }
            if (string.IsNullOrEmpty(sort)) { return string.Empty; }
            return string.Format("ORDER BY {0}", sort.ToUpper());
        }

        /// <summary>
        /// 检查查询语句是否符合规则(ID = 1 AND UserName = 'steden') 非数字，要加''
        /// </summary>
        protected static string Condition(string condition = "")
        {
            if (condition.IsNullOrEmpty()) { condition = "1=1"; }
            if (condition.ToUpper().StartsWith("WHERE")) { condition = condition.Substring(6).Trim(); }
            //如果前面出现："IsSafe = "字符串，则表明无需验证
            if (condition.StartsWith("IsSafe = ")) { return string.Format("WHERE {0}", condition.Substring(9)); }
            if (!condition.StartsWith("1=1")) condition = "1=1 AND " + condition;
            return string.Format("WHERE {0} ", condition);
        }

        /// <summary>
        /// 插入记录的通用方法（支持标识键插入）
        /// </summary>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool InsertIdentity(DbExecutor db = null, params DbParameter[] parameters)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("INSERT INTO {0}", DbFactory.CreateTableAegis(TableName, DataType));
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parameters)
            {
                fields += string.Format("{0},", DbFactory.CreateTableAegis(param.ParameterName.Substring(1), DataType));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            return db.ExecuteNonQuery(CommandType.Text, sql, parameters) > 0;
        }

        /// <summary>
        /// 插入记录的通用方法（支持默认值和isnull）
        /// </summary>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Insert(DbExecutor db = null, params DbParameter[] parameters)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("INSERT INTO {0}", DbFactory.CreateTableAegis(TableName, DataType));
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parameters)
            {
                fields += string.Format("{0},", DbFactory.CreateTableAegis(param.ParameterName.Substring(1), DataType));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            return db.ExecuteNonQuery(CommandType.Text, sql, parameters) > 0;
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Insert(out int identity, DbExecutor db = null, params DbParameter[] parameters)
        {
            if (db == null) { db = DbExtor; }
            // 开启事务
            db.OpenTran(IsolationLevel.ReadCommitted);
            var result = Insert(db, parameters);
            identity = GetCount("", db);
            db.Commit();
            db.Close(true);
            return result;
        }

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual int GetCount(string condition = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SELECT Count(0) FROM {0} {1}", DbFactory.CreateTableAegis(TableName, DataType), Condition(condition));
            return db.ExecuteScalar(CommandType.Text, sql).ConvertType(0);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual int GetCount(string conditionFieldName, object conditionFieldValue, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            string sql = string.Format("SELECT Count(0) FROM {0} WHERE {1} = {2}", DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName);
            return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);
        }

        /// <summary>
        /// 获取数量(用Like方式)
        /// </summary>
        /// <param name="containsFieldName"></param>
        /// <param name="containsFieldValue"></param>
        /// <param name="condition"></param>
        /// <returns></returns>
        public virtual int GetCountByLike(string containsFieldName, object containsFieldValue, string condition = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Empty;

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }

            DbParameter[] parms = { NewParam("Value", containsFieldValue, db) };

            sql = string.Format("SELECT Count(0) FROM {0} WHERE CHARINDEX({1},{2}) >0 {3}", DbFactory.CreateTableAegis(TableName, DataType), parms[0].ParameterName, DbFactory.CreateTableAegis(containsFieldName, DataType), condition);

            return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);
        }

        /// <summary>
        /// 获取数量(用Like方式)
        /// </summary>
        /// <param name="containsFieldName"></param>
        /// <param name="containsFieldValue"></param>
        /// <param name="condition"></param>
        /// <returns></returns>
        public virtual int GetCountByIndex(string containsFieldName, object containsFieldValue, string condition = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Empty;

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }

            DbParameter[] parms = { NewParam("Value", containsFieldValue, db) };

            sql = string.Format("SELECT Count(0) FROM {0} WHERE CHARINDEX({1},{2}) >0 {3}", DbFactory.CreateTableAegis(TableName, DataType), parms[0].ParameterName, DbFactory.CreateTableAegis(containsFieldName, DataType), condition);

            return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);
        }

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public virtual IDataReader ToInfo(string fieldNames, object conditionFieldValue, string conditionFieldName = "ID", string sort = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            string strFields = fieldNames.IsNullOrEmpty() ? "*" : fieldNames;
            string sql = string.Format("select top 1 {0} from {1} WHERE {2} = {3} {4}", strFields, DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName, Sort(sort));
            IDataReader reader = db.GetReader(CommandType.Text, sql, parms);
            return reader;
        }

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public virtual IDataReader ToInfo(string fieldNames, string condition, string sort = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string strFields = fieldNames.IsNullOrEmpty() ? "*" : fieldNames;
            string sql = string.Format("select top 1 {0} from {1} {2} {3}", strFields, DbFactory.CreateTableAegis(TableName, DataType), Condition(condition), Sort(sort));
            IDataReader reader = db.GetReader(CommandType.Text, sql);
            return reader;
        }

        /// <summary>
        /// Like查找
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        /// <param name="sort">排序</param>
        public virtual IDataReader ToInfoByLike(string fieldNames, string conditionFieldName, object conditionFieldValue, string condition = "", string sort = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            string strFields = fieldNames.IsNullOrEmpty() ? "*" : fieldNames;
            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }

            string sql = string.Format("select top 1 {0} from {1} WHERE CHARINDEX({3},{2}) >0 {4} {5}", strFields, DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName, condition, Sort(sort));
            IDataReader reader = db.GetReader(CommandType.Text, sql, parms);
            return reader;
        }

        /// <summary>
        /// 删除单条记录(单条件)
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Delete(object conditionFieldValue, string conditionFieldName = "ID", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };

            string sql = string.Format("DELETE FROM {0} WHERE {1} = {2}", DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName);

            return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
        }

        /// <summary>
        /// 删除单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Delete(string condition, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("DELETE FROM {0}  {1}", DbFactory.CreateTableAegis(TableName, DataType), Condition(condition));
            return db.ExecuteNonQuery(CommandType.Text, sql) > 0;
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        public virtual DataTable GetList(out int recordCount, string fieldNames = "*", string sort = "ID DESC", string condition = "", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            recordCount = GetCount(condition, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            if (pageIndex == 1) { return GetList(pageSize, fieldNames, sort, condition, db); }

            sort = Sort(sort);
            condition = Condition(condition);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT TOP {0} {1} FROM (SELECT TOP {2} * FROM {3} {4} {5}) a  {6}", pageSize, fieldNames, pageSize * pageIndex, DbFactory.CreateTableAegis(TableName, DataType), condition, sort, sort2);
            isReverse = true;

            dt = db.GetDataTable(CommandType.Text, sql);


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        public virtual DataTable GetList(out int recordCount, object conditionFieldValue, string conditionFieldName = "ID", string fieldNames = "*", string sort = "ID DESC", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            recordCount = GetCount(conditionFieldName, conditionFieldValue, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            if (pageIndex == 1) { return GetList(pageSize, conditionFieldValue, conditionFieldName, fieldNames, sort, db); }

            sort = Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
            sql = string.Format("SELECT TOP {0} {1} FROM (SELECT TOP {2} * FROM {3} WHERE {4} = {7} {5}) a  {6}", pageSize, fieldNames, pageSize * pageIndex, DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), sort, sort2, parms[0].ParameterName);
            isReverse = true;



            dt = db.GetDataTable(CommandType.Text, sql, parms);


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        public virtual DataTable GetList(int top = 0, string fieldNames = "*", string sort = "ID DESC", string condition = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            sort = Sort(sort);
            condition = Condition(condition);
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }

            string topString = top > 0 ? string.Format("TOP {0}", top) : string.Empty;

            string sql = string.Format("SELECT {0} {1} FROM {2} {3} {4}", topString, fieldNames, DbFactory.CreateTableAegis(TableName, DataType), condition, sort);
            return db.GetDataTable(CommandType.Text, sql);
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        public virtual DataTable GetList(int top = 0, object conditionFieldValue = null, string conditionFieldName = "ID", string fieldNames = "*", string sort = "ID DESC", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            sort = Sort(sort);
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }

            string topString = top > 0 ? string.Format("TOP {0}", top) : string.Empty;

            string sql = string.Format("SELECT {0} {1} FROM {2} WHERE {3} = {4} {5}", topString, fieldNames, DbFactory.CreateTableAegis(TableName, DataType), conditionFieldName, parms[0].ParameterName, sort);
            return db.GetDataTable(CommandType.Text, sql, parms);
        }

        /// <summary>
        /// Like查找
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">每显示显示数量</param>
        /// <param name="condition">条件</param>
        /// <param name="recordCount">返回结果记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public virtual DataTable GetListByLike(out int recordCount, object conditionFieldValue, string conditionFieldName = "ID", string fieldNames = "*", string sort = "ID DESC", string condition = "", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            recordCount = GetCountByLike(conditionFieldName, conditionFieldValue, condition, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }
            sort = Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT TOP {0} {1} FROM (SELECT TOP {2} {1} FROM {3} WHERE CHARINDEX({8},{4}) >0 {7} {8}) a  {6}", pageSize, fieldNames, pageSize * pageIndex, DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), sort, sort2, condition, parms[0].ParameterName);
            isReverse = true;

            dt = db.GetDataTable(CommandType.Text, sql, parms);

            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 更改多个字段的方法(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="paramters">多个字段的值 Name 为@字段名,Value为值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Update(string condition, DbExecutor db = null, params DbParameter[] paramters)
        {
            if (db == null) { db = DbExtor; }
            if (paramters.Length == 0) return false;

            string sql = string.Format("UPDATE {0} SET ", DbFactory.CreateTableAegis(TableName, DataType));
            foreach (DbParameter de in paramters)
            {
                sql += string.Format("{0} = {1} ,", DbFactory.CreateTableAegis(de.ParameterName.Substring(1), DataType), de.ParameterName);
            }
            if (sql.EndsWith(",")) sql = sql.Substring(0, sql.Length - 1);
            sql += string.Format(" {0}", Condition(condition));

            return db.ExecuteNonQuery(CommandType.Text, sql, paramters) > 0;
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Update(string fieldName, object fieldValue, object conditionFieldValue, string conditionFieldName = "ID", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = 
                {
                    NewParam("FieldValue", fieldValue,db),
                    NewParam("ConditionValue", conditionFieldValue,db) 

                };
            string sql = string.Format("UPDATE {0} SET {1} = {3} WHERE {2} = {4}", DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(fieldName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName, parms[1].ParameterName);
            return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
        }

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Update(string fieldName, object fieldValue, string condition, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", fieldValue, db) };
            string sql = string.Format("UPDATE {0} SET {1} = {2} {3}", DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(fieldName, DataType), parms[0].ParameterName, Condition(condition));
            return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;

        }

        /// <summary>
        /// 更改多个字段的方法(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="paramters">多个字段的值 Name 为@字段名,Value为值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool Update(object conditionFieldValue, string conditionFieldName = "ID", DbExecutor db = null, params DbParameter[] paramters)
        {
            if (db == null) { db = DbExtor; }
            if (paramters.Length == 0) return false;

            string sql = string.Format("UPDATE {0} SET ", DbFactory.CreateTableAegis(TableName, DataType));

            DbParameter[] parms = new DbParameter[paramters.Length + 1];

            for (int i = 0; i < paramters.Length; i++)
            {
                sql += string.Format("{0} = {1} ,", DbFactory.CreateTableAegis(paramters[i].ParameterName.Substring(1), DataType), paramters[i].ParameterName);
                parms[i] = paramters[i];
            }
            if (sql.EndsWith(",")) sql = sql.Substring(0, sql.Length - 1);

            parms[paramters.Length] = NewParam("ConditionValue", conditionFieldValue, db);

            sql += string.Format(" WHERE {0} = {1}", DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[paramters.Length].ParameterName);


            return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool UpdateAdd(string fieldName, int fieldValue, string condition, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("UPDATE {0} SET {1} = {1} + {2} {3}", DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(fieldName, DataType), fieldValue, Condition(condition));
            return db.ExecuteNonQuery(CommandType.Text, sql, null) > 0;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="db">DbExecutor实体</param>
        public virtual bool UpdateAdd(string fieldName, int fieldValue, object conditionFieldValue, string conditionFieldName = "ID", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };
            string sql = string.Format("UPDATE {0} SET {1} = {1} + {2} WHERE {3} = {4}", DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(fieldName, DataType), fieldValue, DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName);
            return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="defValue">默认值</param>
        public virtual T Value<T>(string fieldName, T defValue, object conditionFieldValue, string conditionFieldName = "ID", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };

            string sql = string.Format("SELECT {0} FROM {1} WHERE {2} = {3}", DbFactory.CreateTableAegis(fieldName, DataType), DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName);

            return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(defValue); ;
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="defValue">默认值</param>
        public virtual T Value<T>(string fieldName, string condition, T defValue, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SELECT TOP 1 {0} FROM {1} {2}", DbFactory.CreateTableAegis(fieldName, DataType), DbFactory.CreateTableAegis(TableName, DataType), Condition(condition));
            return db.ExecuteScalar(CommandType.Text, sql).ConvertType(defValue); ;
        }

        /// <summary>
        /// 统计数量(多条件)
        /// </summary>
        /// <param name="filedName">要统计的字段</param>
        /// <param name="condition">SQL条件语句</param>
        public virtual decimal Sum(string filedName, string condition = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SELECT SUM({0}) FROM {1} {2}", DbFactory.CreateTableAegis(filedName, DataType), DbFactory.CreateTableAegis(TableName, DataType), Condition(condition));

            return db.ExecuteScalar(CommandType.Text, sql).ConvertType(0);
        }

        /// <summary>
        /// 统计数量(单条件)
        /// </summary>
        /// <param name="filedName">要统计的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public virtual decimal Sum(string filedName, object conditionFieldValue, string conditionFieldName = "ID", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            DbParameter[] parms = { NewParam("Value", conditionFieldValue, db) };

            string sql = string.Format("SELECT SUM({0}) FROM {1} WHERE {2} = {3}", DbFactory.CreateTableAegis(filedName, DataType), DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, DataType), parms[0].ParameterName);

            return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);
        }
    }
}