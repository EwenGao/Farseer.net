﻿using System;
using System.Data;
using System.Linq.Expressions;
using Qyn.Studio.Base;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Bean
{
    /// <summary>
    /// MySql数据库持久化
    /// </summary>
    /// <typeparam name="TInfo"></typeparam>
    internal partial class MySqlBean<TInfo> : DbBean<TInfo> where TInfo : BaseInfo, new()
    {
        internal MySqlBean() { }

        /// <summary>
        /// 构造函数（指定完整的连接字符串）
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="commandTimeout">命令执时超时时间</param>
        internal MySqlBean(DataBaseType dbType, string connetionString, int commandTimeout) : base(dbType, connetionString, commandTimeout) { }

        /// <summary>
        /// 将方法转换成T-SQL特殊函数名
        /// </summary>
        /// <param name="m">自定义特殊的函数</param>
        internal override Expression VisitMethodCall(MethodCallExpression m)
        {
            base.VisitMethodCall(m);
            switch (m.Method.Name.ToUpper())
            {
                case "CONTAINS":
                    {
                        if (ClearCallSql()) { return m; }
                        Type type;
                        if (m.Object == null) { type = m.Arguments[0].Type; }
                        else { type = m.Object.Type; }
                        if (!type.IsGenericType || type.GetGenericTypeDefinition() == typeof(Nullable<>))
                        {
                            this.m_conditionParts.Push(String.Format("CHARINDEX({0},{1}) > 0", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                        }
                        else
                        {
                            if (m.Object == null) { m_conditionParts.Pop(); }
                            string fileName = m_conditionParts.Pop();
                            if (m.Object != null) { m_conditionParts.Pop(); }
                            if (base.m_lstParams.GetLast().DbType == DbType.String)
                            {
                                base.m_lstParams.GetLast().Value = "'" + base.m_lstParams.GetLast().Value.ToString().Replace(",", "','") + "'";
                            }
                            this.m_conditionParts.Push(String.Format("{0} IN ({1})", fileName, base.m_lstParams.GetLast().Value));
                            base.m_lstParams.Remove(base.m_lstParams.GetLast());
                        }

                        break;
                    }
                case "STARTSWITH": this.m_conditionParts.Push(String.Format("CHARINDEX({0},{1}) = 1", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                case "ENDSWITH": this.m_conditionParts.Push(String.Format("{0} LIKE {1}", m_conditionParts.Pop(), m_conditionParts.Pop())); m_lstParams.GetLast().Value = string.Format("%{0}", m_lstParams.GetLast().Value); break;
                case "ISEQUALS": this.m_conditionParts.Push(String.Format("{0} = {1}", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                case "LEN": this.m_conditionParts.Push(String.Format("LEN({0})", m_conditionParts.Pop())); break;
                //case "NOTLIKE":this.m_conditionParts.Push(String.Format("CHARINDEX({1},{0}) = 0", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "NOTIN":this.m_conditionParts.Push(String.Format("{0} NOT IN ({1})", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "BETWEEN":this.m_conditionParts.Push(String.Format("{0} BETWEEN {1} AND {2}", m_conditionParts.Pop(), m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "CONVERTTYPE": return VisitConvert(m);
                default:
                    {
                        if (m.Arguments.Count == 0 && m.Object != null) { return m; }
                        else { return VisitConvert(m); throw new Exception(string.Format("暂不支持该方法的SQL转换：" + m.Method.Name.ToUpper())); }
                    }
            }
            return m;
        }

        public override void ResetIdentity(DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("ALTER TABLE `{0}` AUTO_INCREMENT=1", Map.ClassInfo.Name);
            db.ExecuteScalar(CommandType.Text, sql);
        }
    }

    /// <summary>
    /// MySql数据库持久化
    /// </summary>
    public class MySqlBean : DbBean
    {
        /// <summary>
        /// 传入数据库连接配置
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connnection">连接字符串</param>
        /// <param name="tableName">表名称</param>
        /// <param name="commandTimeout">执行SQL超时时间</param>
        public MySqlBean(string connetionString, string tableName, DataBaseType dbType = DataBaseType.SqlServer, int commandTimeout = 30) : base(connetionString, tableName, dbType, commandTimeout) { }
    }
}
