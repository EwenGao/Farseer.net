﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq.Expressions;
using Qyn.Studio.Base;
using Qyn.Studio.Data;
using Qyn.Studio.UI.WebControls;

namespace Qyn.Studio.Bean
{
    /// <summary>
    /// 操作数据库的抽像方法接口
    /// </summary>
    public interface IBean<TInfo> where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 条件语句
        /// </summary>
        /// <param name="where">Lambda条件</param>
        IBean<TInfo> Where(Expression<Func<TInfo, bool>> where);

        /// <summary>
        /// 字段筛选
        /// </summary>
        /// <param name="selector">选择单个字段</param>
        IBean<TInfo> Selector(Expression<Func<TInfo, object>> selector);

        /// <summary>
        /// 升序
        /// </summary>
        /// <param name="sort">选择单个字段</param>
        IBean<TInfo> Asc(Expression<Func<TInfo, object>> sort);

        /// <summary>
        /// 降序
        /// </summary>
        /// <param name="sort">选择单个字段</param>
        IBean<TInfo> Desc(Expression<Func<TInfo, object>> sort);

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        bool Insert(TInfo info, DbExecutor db = null);

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        /// <param name="db">可传入事务的db</param>
        bool Insert(TInfo info, out int identity, DbExecutor db = null);

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        int GetCount(DbExecutor db = null);

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        int GetCount(Expression<Func<TInfo, bool>> where, DbExecutor db = null);

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        bool Delete(DbExecutor db = null);

        /// <summary>
        /// 删除记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        bool Delete(Expression<Func<TInfo, bool>> where, DbExecutor db = null);

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        TInfo ToInfo(DbExecutor db = null);

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        TInfo ToInfo(Expression<Func<TInfo, bool>> where, DbExecutor db = null);

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        DataTable ToTable(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        DataTable ToTable(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        DataTable ToTable(int pageSize = 0, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        DataTable ToTable(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        List<TInfo> ToList(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="recordCount">返回记录总数</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        List<TInfo> ToList(Expression<Func<TInfo, bool>> where, out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        List<TInfo> ToList(int pageSize = 0, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 获取分页、Top、全部的数据方法(根据pageSize、pageIndex自动识别使用场景)
        /// </summary>
        /// <param name="pageIndex">分页索引，为1时，使用Top方法</param>
        /// <param name="pageSize">为0时，获取所有数据</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        List<TInfo> ToList(Expression<Func<TInfo, bool>> where, int pageSize = 0, int pageIndex = 1, DbExecutor db = null);

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="db">可传入事务的db</param>
        List<TInfo> ToList(Repeater rpt, DbExecutor db = null);

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        List<TInfo> ToList(Expression<Func<TInfo, bool>> where, Repeater rpt, DbExecutor db = null);

        /// <summary>
        /// 更改实体类
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        bool Update(TInfo info, DbExecutor db = null);

        /// <summary>
        /// 更改实体类
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        bool Update(Expression<Func<TInfo, bool>> where, TInfo info, DbExecutor db = null);

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldValue">字段值(请先指定selector字段)</param>
        /// <param name="selector">选择字段</param>
        /// <param name="db">可传入事务的db</param>
        bool UpdateValue<T>(Expression<Func<TInfo, T>> selector, T fieldValue , DbExecutor db = null);

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldValue">字段值(请先指定selector字段)</param>
        /// <param name="selector">选择字段</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        bool UpdateValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T fieldValue, DbExecutor db = null);

        /// <summary>
        /// 统计数量
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        T GetSum<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct;

        /// <summary>
        /// 统计数量
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        T GetSum<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct;

        /// <summary>
        /// 获取单个字段的数据
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="defValue">为null时默认值</param>
        /// <param name="db">可传入事务的db</param>
        T GetValue<T>(Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null);

        /// <summary>
        /// 获取单个字段的数据
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="defValue">为null时默认值</param>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        T GetValue<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, T defValue, DbExecutor db = null);

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        T GetMax<T>(Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct;

        /// <summary>
        /// 获取最大值
        /// </summary>
        /// <param name="selector">选择字段</param>
        /// <typeparam name="T">值类型变量</typeparam>
        /// <param name="db">可传入事务的db</param>
        /// <param name="where">条件</param>
        T GetMax<T>(Expression<Func<TInfo, bool>> where, Expression<Func<TInfo, T>> selector, DbExecutor db = null) where T : struct;

        /// <summary>
        /// 重置标识
        /// </summary>
        /// <param name="db">可传入事务的db</param>
        void ResetIdentity(DbExecutor db = null);
    }
}
