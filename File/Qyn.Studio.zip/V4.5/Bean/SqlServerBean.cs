﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq.Expressions;
using Qyn.Studio.Base;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Bean
{
    /// <summary>
    /// SqlServer数据库持久化
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    internal class SqlServerBean<TInfo> : DbBean<TInfo> where TInfo : BaseInfo, new()
    {
        internal SqlServerBean() { }

        /// <summary>
        /// 构造函数（指定完整的连接字符串）
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="commandTimeout">命令执时超时时间</param>
        internal SqlServerBean(DataBaseType dbType, string connetionString, int commandTimeout) : base(dbType, connetionString, commandTimeout) { }

        internal override Expression VisitMethodCall(MethodCallExpression m)
        {
            base.VisitMethodCall(m);
            switch (m.Method.Name.ToUpper())
            {
                case "CONTAINS":
                    {
                        if (ClearCallSql()) { return m; }
                        Type type;
                        if (m.Object == null) { type = m.Arguments[0].Type; }
                        else { type = m.Object.Type; }
                        if (!type.IsGenericType || type.GetGenericTypeDefinition() == typeof(Nullable<>))
                        {
                            this.m_conditionParts.Push(String.Format("CHARINDEX({0},{1}) > 0", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                        }
                        else
                        {
                            if (m.Object == null) { m_conditionParts.Pop(); }
                            string fileName = m_conditionParts.Pop();
                            if (m.Object != null) { m_conditionParts.Pop(); }

                            if (base.m_lstParams.GetLast().DbType == DbType.String)
                            {
                                base.m_lstParams.GetLast().Value = "'" + base.m_lstParams.GetLast().Value.ToString().Replace(",", "','") + "'";
                            }
                            this.m_conditionParts.Push(String.Format("{0} IN ({1})", fileName, base.m_lstParams.GetLast().Value));
                            base.m_lstParams.Remove(base.m_lstParams.GetLast());
                        }

                        break;
                    }
                case "STARTSWITH": this.m_conditionParts.Push(String.Format("CHARINDEX({0},{1}) = 1", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                case "ENDSWITH": this.m_conditionParts.Push(String.Format("{0} LIKE {1}", m_conditionParts.Pop(), m_conditionParts.Pop())); m_lstParams.GetLast().Value = string.Format("%{0}", m_lstParams.GetLast().Value); break;
                case "ISEQUALS": this.m_conditionParts.Push(String.Format("{0} = {1}", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                case "LEN": this.m_conditionParts.Push(String.Format("LEN({0})", m_conditionParts.Pop())); break;

                //case "NOTLIKE": this.m_conditionParts.Push(String.Format("CHARINDEX({1},{0}) = 0", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "NOTIN": this.m_conditionParts.Push(String.Format("{0} NOT IN ({1})", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "CONTAINS": this.m_conditionParts.Push(String.Format("CONTAINS({0},{1})", m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "BETWEEN": this.m_conditionParts.Push(String.Format("{0} BETWEEN {1} AND {2}", m_conditionParts.Pop(), m_conditionParts.Pop(), m_conditionParts.Pop())); break;
                //case "CONVERTTYPE": return VisitConvert(m);
                default:
                    {
                        if (m.Arguments.Count == 0 && m.Object != null) { return m; }
                        else { return VisitConvert(m); throw new Exception(string.Format("暂不支持该方法的SQL转换：" + m.Method.Name.ToUpper())); }
                    }
            }
            return m;
        }

        public override bool Insert(TInfo info, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            List<DbParameter> parms = GetParameter(info, db);

            bool indexHaveValue = Map.GetModelInfo().Key != null ? Map.GetModelInfo().Key.GetValue(info, null) != null : false;

            //要插入的表
            StringPlus sql = new StringPlus();
            if (!Map.IndexName.IsNullOrEmpty() && indexHaveValue) { sql.AppendFormat("SET IDENTITY_INSERT [{0}] ON ; ", Map.ClassInfo.Name); }

            sql.AppendFormat("INSERT INTO [{0}]", Map.ClassInfo.Name);

            #region 要插入的值
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parms)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";

            sql.AppendFormat(fields + " VALUES " + values);
            #endregion

            if (!Map.IndexName.IsNullOrEmpty() && indexHaveValue) { sql.AppendFormat("; SET IDENTITY_INSERT [{0}] OFF ; ", Map.ClassInfo.Name); }

            return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
        }

        public override bool Insert(TInfo info, out int identity, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            List<DbParameter> parms = GetParameter(info, db);

            if (parms.Count == 0) { identity = -1; return false; }

            bool indexHaveValue = Map.GetModelInfo().Key != null ? Map.GetModelInfo().Key.GetValue(info, null) != null : false;

            //要插入的表
            StringPlus sql = new StringPlus();
            if (!Map.IndexName.IsNullOrEmpty() && indexHaveValue) { sql.AppendFormat("SET IDENTITY_INSERT [{0}] ON ; ", Map.ClassInfo.Name); }

            sql.AppendFormat("INSERT INTO [{0}]", Map.ClassInfo.Name);

            #region 要插入的值
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parms)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";

            sql.AppendFormat(fields + " VALUES " + values);
            #endregion

            if (!Map.IndexName.IsNullOrEmpty() && indexHaveValue) { sql.AppendFormat("; SET IDENTITY_INSERT [{0}] OFF ; ", Map.ClassInfo.Name); }

            sql.Append(";SELECT @@IDENTITY");
            identity = db.ExecuteScalar(CommandType.Text, sql.Value, parms.ToArray()).ConvertType(0);

            return true;
        }

        public override bool Update(TInfo info, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }

            List<DbParameter> parms = GetParameter(info, db);

            #region 如果主键有值，则取消修改主键的SQL
            bool indexHaveValue = Map.GetModelInfo().Key != null ? Map.GetModelInfo().Key.GetValue(info, null) != null : false;
            if (indexHaveValue)
            {
                parms.RemoveAll(o => o.ParameterName.IsEquals(DbFactory.CreateParamsName(DataType) + Map.IndexName));
            }
            #endregion

            if (parms.Count == 0) return false;

            //要更新的表
            StringPlus sql = new StringPlus();
            sql.AppendFormat("UPDATE {0} SET ", DbFactory.CreateTableAegis(Map.ClassInfo.Name, DataType));

            //要更新的字段
            foreach (DbParameter parm in parms)
            {
                sql.AppendFormat("{0} = {1} ,", DbFactory.CreateTableAegis(parm.ParameterName.Substring(1), DataType), parm.ParameterName);
            }
            sql.DelLastChar(",");

            sql.AppendFormat(" {0}", WhereString);

            parms.AddRange(WhereParams);

            return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
        }

        public override DataTable ToTable(out int recordCount, int pageSize, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            if (Map.ClassInfo.DataVer == "2000") { return base.ToTable(out recordCount, pageIndex, pageSize, db); }

            recordCount = GetCount(db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            if (pageIndex == 1) { return ToTable(pageSize, pageIndex, db); }

            if (SortString.Length == 0) { SortString.AppendFormat("ORDER BY {0} ASC", Map.IndexName); }

            string strFields = SelectorString.Length == 0 ? "*" : SelectorString.ToString();

            string sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM [{2}] {3}) a WHERE Row BETWEEN {4} AND {5}",
                        strFields, SortString, Map.ClassInfo.Name, WhereString, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize);

            return db.GetDataTable(CommandType.Text, sql, WhereParams.ToArray());
        }

        public override void ResetIdentity(DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("dbcc checkident({0},reseed,0)", Map.ClassInfo.Name);
            db.ExecuteScalar(CommandType.Text, sql);
        }
    }

    /// <summary>
    /// SqlServer数据库持久化
    /// </summary>
    public class SqlServerBean : DbBean
    {
        /// <summary>
        /// 传入数据库连接配置
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connnection">连接字符串</param>
        /// <param name="tableName">表名称</param>
        /// <param name="commandTimeout">执行SQL超时时间</param>
        public SqlServerBean(string connetionString, string tableName, DataBaseType dbType = DataBaseType.SqlServer, int commandTimeout = 30) : base(connetionString, tableName, dbType, commandTimeout) { }

        /// <summary>
        /// 插入记录的通用方法（支持标识键插入）
        /// </summary>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <param name="db">DbExecutor实体</param>
        public override bool InsertIdentity(DbExecutor db = null, params DbParameter[] parameters)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("SET IDENTITY_INSERT {0} ON ; ", DbFactory.CreateTableAegis(TableName, DataType));
            sql += string.Format("INSERT INTO {0}", DbFactory.CreateTableAegis(TableName, DataType));
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parameters)
            {
                fields += string.Format("{0},", DbFactory.CreateTableAegis(param.ParameterName.Substring(1), DataType));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            sql += string.Format(" SET IDENTITY_INSERT {0} OFF ; ", DbFactory.CreateTableAegis(TableName, DataType));

            return db.ExecuteNonQuery(CommandType.Text, sql, parameters) > 0;
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        /// <param name="parameters">要插入的值 Name 为@字段名 Value 为要插入的值</param>
        /// <param name="db">DbExecutor实体</param>
        public override bool Insert(out int identity, DbExecutor db = null, params DbParameter[] parameters)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Format("INSERT INTO {0}", DbFactory.CreateTableAegis(TableName, DataType));
            string fields, values;
            fields = values = "(";
            foreach (DbParameter param in parameters)
            {
                fields += string.Format("{0},", DbFactory.CreateTableAegis(param.ParameterName.Substring(1), DataType));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";
            sql = sql + fields + " VALUES" + values;

            sql += ";SELECT @@IDENTITY";
            identity = db.ExecuteScalar(CommandType.Text, sql, parameters).ConvertType(0);
            return identity > 0;
        }

        /// <summary>
        /// 获取数量(用Like方式)
        /// </summary>
        /// <param name="containsFieldName"></param>
        /// <param name="containsFieldValue"></param>
        /// <param name="condition"></param>
        /// <returns></returns>
        public override int GetCountByIndex(string containsFieldName, object containsFieldValue, string condition = "", DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            string sql = string.Empty;

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }

            DbParameter[] parms = { NewParam("Value", containsFieldValue, db) };

            sql = string.Format("SELECT Count(0) FROM [{0}] WHERE CONTAINS({1},{2}) {3}",
                DbFactory.CreateTableAegis(TableName, DataType),
                DbFactory.CreateTableAegis(containsFieldName, base.DataType),
                parms[0].ParameterName,
                condition);

            return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);
        }

        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        public DataTable Index(out int recordCount, object containsFieldValue, string containsFieldName = "ID", string sort = "ID DESC", string condition = "", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            recordCount = GetCountByIndex(containsFieldName, containsFieldValue, condition, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            DbParameter[] parms = 
                {
                    NewParam("Value", containsFieldValue,db)
                };
            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }
            sort = Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT * FROM (SELECT *,ROW_NUMBER() OVER({0}) as Row FROM {1} WHERE CONTAINS({2},{6}) {5}) a WHERE Row BETWEEN {3} AND {4}",
                         sort,
                         DbFactory.CreateTableAegis(TableName, base.DataType),
                         DbFactory.CreateTableAegis(containsFieldName, base.DataType),
                         (pageIndex - 1) * pageSize, pageIndex * pageSize, condition,
                         parms[0].ParameterName);



            dt = db.GetDataTable(CommandType.Text, sql, parms);

            if (isReverse) { dt.Reverse(); }
            return dt;
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        public override DataTable GetList(out int recordCount, string fieldNames = "*", string sort = "ID DESC", string condition = "", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            recordCount = GetCount(condition, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            sort = Sort(sort);
            condition = Condition(condition);
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM {2} {3}) a WHERE Row BETWEEN {4} AND {5}", fieldNames, sort, DbFactory.CreateTableAegis(TableName, base.DataType), condition, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize);

            dt = db.GetDataTable(CommandType.Text, sql);


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(一定要填写，除非记录字段有ID名称的)</param>
        /// <param name="recordCount">返回记录总数</param>
        public override DataTable GetList(out int recordCount, object conditionFieldValue, string conditionFieldName = "ID", string fieldNames = "*", string sort = "ID DESC", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            recordCount = GetCount(conditionFieldName, conditionFieldValue, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            sort = Sort(sort);
            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }

            DbParameter[] parms = 
                {
                    NewParam("Value", conditionFieldValue,db) 
                };
            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM {2} WHERE {3} = {6}) a WHERE Row BETWEEN {4} AND {5}",
                         fieldNames, sort, DbFactory.CreateTableAegis(TableName, base.DataType), DbFactory.CreateTableAegis(conditionFieldName, base.DataType), (pageIndex - 1) * pageSize + 1, pageIndex * pageSize, parms[0].ParameterName);



            dt = db.GetDataTable(CommandType.Text, sql, parms);


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// Like查找
        /// </summary>
        /// <param name="fieldNames">显示字段</param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">每显示显示数量</param>
        /// <param name="condition">条件</param>
        /// <param name="recordCount">返回结果记录数</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public override DataTable GetListByLike(out int recordCount, object conditionFieldValue, string conditionFieldName = "ID", string fieldNames = "*", string sort = "ID DESC", string condition = "", int pageSize = 20, int pageIndex = 1, DbExecutor db = null)
        {
            if (db == null) { db = DbExtor; }
            recordCount = GetCountByLike(conditionFieldName, conditionFieldValue, condition, db);

            #region 计算总页数
            int allCurrentPage = 0;

            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            if (fieldNames.IsNullOrEmpty()) { fieldNames = "*"; }

            DbParameter[] parms = 
                {
                    NewParam("Value", conditionFieldValue,db)
                };
            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", Condition(condition).Substring(6)); }
            sort = Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM {2} WHERE CHARINDEX({7},{3}) >0 {6}) a WHERE Row BETWEEN {4} AND {5}",
                         fieldNames, sort, DbFactory.CreateTableAegis(TableName, DataType), DbFactory.CreateTableAegis(conditionFieldName, base.DataType), (pageIndex - 1) * pageSize + 1, pageIndex * pageSize, condition, parms[0].ParameterName);



            dt = db.GetDataTable(CommandType.Text, sql, parms);

            return isReverse ? dt.Reverse() : dt;
        }
    }
}