﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Qyn.Studio.Data;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Bean
{
    /// <summary>
    /// 数据库修改
    /// </summary>
    public class DbModify
    {
        /// <summary>
        /// 数据库类型
        /// </summary>
        protected DataBaseType DbType { get; set; }
        /// <summary>
        /// 连接字符串
        /// </summary>
        protected string ConnetionString { get; set; }
        /// <summary>
        /// 要操作的表名
        /// </summary>
        protected string TableName { get; set; }
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        protected DbModify(DataBaseType dbType, string connetionString, string tableName)
        {
            DbType = dbType;
            ConnetionString = connetionString;
            TableName = tableName;
        }
        private DbModify() { }

        /// <summary>
        /// 获取字段创建字符串
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        /// <param name="isPrimaryKey">是否为主键</param>
        /// <param name="isIdentity">是否自增长</param>
        /// <param name="isNotNull">是否不为空</param>
        /// <param name="fieldType">字段类型</param>
        /// <param name="fieldLength">字段长度</param>
        /// <param name="fieldDefaultValue">字段默认值</param>
        public virtual string CreateFieldString(string fieldName, bool isPrimaryKey, bool isIdentity, bool isNotNull, FieldType fieldType, int? fieldLength, object fieldDefaultValue)
        {
            if (fieldDefaultValue is Enum) { fieldDefaultValue = (int)fieldDefaultValue; }
            if (fieldDefaultValue != null)
            {
                if (
                    !fieldDefaultValue.ToString().StartsWith("'") &&
                    (fieldType == FieldType.Char ||
                    fieldType == FieldType.NChar ||
                    fieldType == FieldType.Ntext ||
                    fieldType == FieldType.Nvarchar ||
                    fieldType == FieldType.Text ||
                    fieldType == FieldType.Varchar))
                {
                    fieldDefaultValue = "'" + fieldDefaultValue + "'";
                }
            }
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat("{0} ", DbFactory.CreateTableAegis(fieldName, DbType));
            sql.AppendFormat("{0} ", fieldType.ToString());
            if (fieldLength != null) { sql.AppendFormat("({0}) ", fieldLength); }
            if (isIdentity) { sql.Append("IDENTITY(1,1) "); }
            sql.Append(isNotNull ? "NOT NULL " : "NULL ");
            if (isPrimaryKey) { sql.Append("PRIMARY KEY "); }
            if (fieldDefaultValue != null && fieldDefaultValue.ToString().Length > 0) { sql.AppendFormat("DEFAULT {0} ", fieldDefaultValue); };

            return sql.ToString();
        }

        /// <summary>
        /// 创建表
        /// </summary>
        /// <param name="lstCreateField">创建的字段列表</param>
        public virtual bool CreateTable(List<string> lstCreateField)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat("CREATE TABLE {0} (", DbFactory.CreateTableAegis(TableName, DbType));
            sql.Append(lstCreateField.ToString(","));
            sql.Append(");");


            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return IsExistTable();
        }

        /// <summary>
        /// 修改表名称
        /// </summary>
        /// <param name="tableName">新表名称</param>
        public virtual bool ReNameTable(string tableName)
        {
            if (!IsExistTable()) { return false; }
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("ALTER TABLE {0} RENAME TO {1}", TableName, tableName);

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 删除表
        /// </summary>
        public virtual bool DropTable()
        {
            if (!IsExistTable()) { return true; }

            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("DROP TABLE {0}", TableName);

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 判断表是否存在
        /// </summary>
        public virtual bool IsExistTable() { return false; }

        /// <summary>
        /// 添加字段
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        /// <param name="isPrimaryKey">是否为主键</param>
        /// <param name="isIdentity">是否自增长</param>
        /// <param name="isNotNull">是否不为空</param>
        /// <param name="fieldType">字段类型</param>
        /// <param name="fieldLength">字段长度</param>
        /// <param name="fieldDefaultValue">字段默认值</param>
        public virtual bool AddField(string fieldName, bool isPrimaryKey, bool isIdentity, bool isNotNull, FieldType fieldType, int? fieldLength, object fieldDefaultValue)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("alter table {0} ADD ", TableName);
            sql.Append(CreateFieldString(fieldName, isPrimaryKey, isIdentity, isNotNull, fieldType, fieldLength, fieldDefaultValue));

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 修改字段
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        /// <param name="isPrimaryKey">是否为主键</param>
        /// <param name="isIdentity">是否自增长</param>
        /// <param name="isNotNull">是否不为空</param>
        /// <param name="fieldType">字段类型</param>
        /// <param name="fieldLength">字段长度</param>
        /// <param name="fieldDefaultValue">字段默认值</param>
        public virtual bool UpdateField(string fieldName, bool isPrimaryKey, bool isIdentity, bool isNotNull, FieldType fieldType, int? fieldLength, object fieldDefaultValue)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("alter table {0} alter column ", TableName);
            sql.Append(CreateFieldString(fieldName, isPrimaryKey, isIdentity, isNotNull, fieldType, fieldLength, fieldDefaultValue));

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 修改字段名称
        /// </summary>
        /// <param name="oldFieldName">旧字段名称</param>
        /// <param name="newFieldName">新字段名称</param>
        public virtual bool ReNameField(string oldFieldName, string newFieldName)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("alter table {0} rename column {1} to {2}", TableName, oldFieldName, newFieldName);

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 删除字段
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        public virtual bool DropField(string fieldName)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("alter table {0} drop column {1}", TableName, fieldName);

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 判断字段是否存在
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        public virtual bool IsExistField(string fieldName)
        {
            DataTable dt = new DbExecutor(DbType, ConnetionString, 60).GetDataTable(CommandType.Text, string.Format("select * from {0} where 1<>1", TableName), null);
            return dt.Columns.Contains(fieldName);
        }

    }

    /// <summary>
    /// 数据库修改表结构
    /// </summary>
    public class SqlServerModify : DbModify
    {
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        public SqlServerModify(DataBaseType dbType, string connetionString, string tableName) : base(dbType, connetionString, tableName) { }

        /// <summary>
        /// 判断表是否存在
        /// </summary>
        public override bool IsExistTable()
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("select count(*) from sysobjects where name='{0}' and xtype= 'u'", TableName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }

        /// <summary>
        /// 修改表名称
        /// </summary>
        /// <param name="tableName">新表名称</param>
        public override bool ReNameTable(string tableName)
        {
            if (!IsExistTable()) { return false; }
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("EXEC sp_rename '{0}', '{1}'", TableName, tableName);

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 修改字段名称
        /// </summary>
        /// <param name="oldFieldName">旧字段名称</param>
        /// <param name="newFieldName">新字段名称</param>
        /// <returns></returns>
        public override bool ReNameField(string oldFieldName, string newFieldName)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("EXEC sp_rename '{0}.[{1}]', '{2}', 'COLUMN'", TableName, oldFieldName, newFieldName);

            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, sql.ToString(), null);
            return true;
        }

        /// <summary>
        /// 判断字段是否存在
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        public override bool IsExistField(string fieldName)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("select count(0) from sysobjects a inner join syscolumns b on a.id=b.id where a.id= object_id('{0}') and b.name='{1}'", TableName, fieldName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }
    }

    /// <summary>
    /// 数据库修改表结构
    /// </summary>
    public class SqliteModify : DbModify
    {
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        public SqliteModify(DataBaseType dbType, string connetionString, string tableName) : base(dbType, connetionString, tableName) { }

        /// <summary>
        /// 判断表是否存在
        /// </summary>
        public override bool IsExistTable()
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("select count(*) from sqlite_master where tbl_name='{0}'", TableName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }

        /// <summary>
        /// 获取字段创建字符串
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        /// <param name="isPrimaryKey">是否为主键</param>
        /// <param name="isIdentity">是否自增长</param>
        /// <param name="isNotNull">是否不为空</param>
        /// <param name="fieldType">字段类型</param>
        /// <param name="fieldLength">字段长度</param>
        /// <param name="fieldDefaultValue">字段默认值</param>
        public override string CreateFieldString(string fieldName, bool isPrimaryKey, bool isIdentity, bool isNotNull, FieldType fieldType, int? fieldLength, object fieldDefaultValue)
        {
            if (fieldDefaultValue is Enum) { fieldDefaultValue = (int)fieldDefaultValue; }
            if (fieldDefaultValue != null)
            {
                if (
                    !fieldDefaultValue.ToString().StartsWith("'") &&
                    (fieldType == FieldType.Char ||
                    fieldType == FieldType.NChar ||
                    fieldType == FieldType.Ntext ||
                    fieldType == FieldType.Nvarchar ||
                    fieldType == FieldType.Text ||
                    fieldType == FieldType.Varchar))
                {
                    fieldDefaultValue = "'" + fieldDefaultValue + "'";
                }
            }
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat("{0} ", DbFactory.CreateTableAegis(fieldName, DbType));
            sql.AppendFormat("{0} ", isIdentity ? "INTEGER" : fieldType.ToString());
            if (fieldLength != null) { sql.AppendFormat("({0}) ", fieldLength); }

            sql.Append(isNotNull ? "NOT NULL " : "NULL ");
            if (isPrimaryKey) { sql.Append("PRIMARY KEY "); }
            if (fieldDefaultValue != null && fieldDefaultValue.ToString().Length > 0) { sql.AppendFormat("DEFAULT ({0}) ", fieldDefaultValue); };

            return sql.ToString();
        }


    }

    /// <summary>
    /// 数据库修改表结构
    /// </summary>
    public class OracleModify : DbModify
    {
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        public OracleModify(DataBaseType dbType, string connetionString, string tableName) : base(dbType, connetionString, tableName) { }

        /// <summary>
        /// 判断表是否存在
        /// </summary>
        public override bool IsExistTable()
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("select count(*) into a from user_tables where table_name= '{0} '", TableName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }


    }

    /// <summary>
    /// 数据库修改表结构
    /// </summary>
    public class MySqlModify : DbModify
    {
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        public MySqlModify(DataBaseType dbType, string connetionString, string tableName) : base(dbType, connetionString, tableName) { }

        /// <summary>
        /// 判断表是否存在
        /// </summary>
        public override bool IsExistTable()
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("SELECT count(*) from information_schema.TABLES WHERE table_name ='{0}'", TableName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }

        /// <summary>
        /// 获取字段创建字符串
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        /// <param name="isPrimaryKey">是否为主键</param>
        /// <param name="isIdentity">是否自增长</param>
        /// <param name="isNotNull">是否不为空</param>
        /// <param name="fieldType">字段类型</param>
        /// <param name="fieldLength">字段长度</param>
        /// <param name="fieldDefaultValue">字段默认值</param>
        public override string CreateFieldString(string fieldName, bool isPrimaryKey, bool isIdentity, bool isNotNull, FieldType fieldType, int? fieldLength, object fieldDefaultValue)
        {
            if (fieldDefaultValue is Enum) { fieldDefaultValue = (int)fieldDefaultValue; }
            if (fieldDefaultValue != null)
            {
                if (
                    !fieldDefaultValue.ToString().StartsWith("'") &&
                    (fieldType == FieldType.Char ||
                    fieldType == FieldType.NChar ||
                    fieldType == FieldType.Ntext ||
                    fieldType == FieldType.Nvarchar ||
                    fieldType == FieldType.Text ||
                    fieldType == FieldType.Varchar))
                {
                    fieldDefaultValue = "'" + fieldDefaultValue + "'";
                }
            }
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat("{0} ", DbFactory.CreateTableAegis(fieldName, DbType));
            sql.AppendFormat("{0} ", fieldType.ToString());
            if (fieldLength != null) { sql.AppendFormat("({0}) ", fieldLength); }
            if (isIdentity) { sql.Append("AUTO_INCREMENT "); }
            sql.Append(isNotNull ? "NOT NULL " : "NULL ");
            if (isPrimaryKey) { sql.Append("PRIMARY KEY "); }
            if (fieldDefaultValue != null && fieldDefaultValue.ToString().Length > 0) { sql.AppendFormat("DEFAULT {0} ", fieldDefaultValue); };

            return sql.ToString();
        }

        /// <summary>
        /// 判断字段是否存在
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        public override bool IsExistField(string fieldName)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("select count(0) from information_schema.columns where  table_name ='{0}' and column_name='{1}'", TableName, fieldName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }
    }

    /// <summary>
    /// 数据库修改表结构
    /// </summary>
    public class AccessModify : DbModify
    {
        /// <summary>
        /// 初始化类
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="tableName">要操作的表名</param>
        public AccessModify(DataBaseType dbType, string connetionString, string tableName) : base(dbType, connetionString, tableName) { }

        /// <summary>
        /// 判断表是否存在
        /// </summary>
        public override bool IsExistTable()
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("Select * from MSysObjects where name='{0}' and type=1", TableName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }

        /// <summary>
        /// 修改表名称
        /// </summary>
        /// <param name="tableName">新表名称</param>
        public override bool ReNameTable(string tableName)
        {
            if (!IsExistTable()) { return false; }
            new DbExecutor(DbType, ConnetionString, 60).ExecuteNonQuery(CommandType.Text, string.Format("select * into {0} from {1}", TableName, TableName), null);
            DropTable();
            return true;
        }

        /// <summary>
        /// 判断字段是否存在
        /// </summary>
        /// <param name="fieldName">字段名称</param>
        public override bool IsExistField(string fieldName)
        {
            StringBuilder sql = new StringBuilder();
            sql.AppendFormat("select count(0) from information_schema.columns where  table_name ='{0}' and column_name='{1}'", TableName, fieldName);

            return new DbExecutor(DbType, ConnetionString, 60).ExecuteScalar(CommandType.Text, sql.ToString(), null).ConvertType(0) > 0;
        }

    }

}
