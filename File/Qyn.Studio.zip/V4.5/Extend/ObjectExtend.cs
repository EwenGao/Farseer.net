﻿using System;
using Qyn.Studio.Base;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Object扩展工具
    /// </summary>
    public static class ObjectExtend
    {
        /// <summary>
        /// 将对像转换为T类型
        /// </summary>
        /// <param name="objValue">要转换的源对像</param>
        /// <param name="defValue">转换失败时，代替的默认值</param>
        /// <typeparam name="T">基本类型</typeparam>
        public static T ConvertType<T>(this object objValue, T defValue)
        {
            if (objValue == null) { return defValue; }
            string strValue = objValue.ToString();

            Type type = typeof(T);
            // 相同类型，则直接返回原型
            if (type == objValue.GetType()) { return (T)objValue; }

            // 判断是否为泛型
            if (type.IsGenericType)
            {
                // 非 Nullable<> 类型
                if (type.GetGenericTypeDefinition() != typeof(Nullable<>))
                {
                    // List型处理
                    type = type.GetGenericArguments()[0];
                    switch (type.Name)
                    {
                        case "String": return (T)(object)strValue.ToList(string.Empty, ",");
                        case "DateTime": return (T)(object)strValue.ToList(DateTime.MinValue);
                        case "Boolean": return (T)(object)strValue.ToList(false);
                        case "Int32": return (T)(object)strValue.ToList(0);
                        case "Int16": return (T)(object)strValue.ToList(0);
                        case "Decimal": return (T)(object)strValue.ToList(0m);
                        case "Byte": return (T)(object)strValue.ToList((byte)0);
                        case "Long": return (T)(object)strValue.ToList(0L);
                        case "Float": return (T)(object)strValue.ToList(0f);
                        case "Double": return (T)(object)strValue.ToList(0d);
                        default: throw new Exception("类型：" + type.Name + "， 未有转换程序对其解析。");
                    }
                }
                // 对Nullable<>类型处理
                type = Nullable.GetUnderlyingType(type);
            }

            // 枚举
            //if (type.IsEnum) { return (T)Enum.Parse(typeof(T), objValue.ToString()); }
            if (type.IsEnum) { return (T)(strValue.IsType<int>() ? Enum.ToObject(type, int.Parse(strValue)) : !strValue.IsNullOrEmpty() ? Enum.Parse(type, strValue) : defValue); }

            // 引用变量的转换
            if (type.IsClass && type != typeof(string))
            {
                try
                {
                    if (objValue.GetType() == typeof(T)) { return (T)objValue; }
                    T t = (T)objValue;
                    if (t != null) { return t; }
                    return defValue;
                }
                catch
                {
                    return defValue;
                }
            }

            try
            {
                if (type.Name == "Boolean")
                {
                    if (strValue.Length == 0) { return defValue; }
                    return (T)(object)(strValue.IsEquals("on") || strValue == "1" || strValue.IsEquals("true"));
                }
                return (T)Convert.ChangeType(objValue, type);
            }
            catch { return defValue; }
        }

        /// <summary>
        /// 将对像转换为T类型
        /// </summary>
        /// <param name="obj">要转换的源对像</param>
        /// <typeparam name="T">基本类型</typeparam>
        public static T ConvertType<T>(this object obj)
        {
            return ConvertType(obj, default(T));
        }

        /// <summary>
        /// 将值转换成类型对像的值
        /// </summary>
        /// <param name="objValue">要转换的值</param>
        /// <param name="type">要转换的对像的类型</param>
        /// <returns></returns>
        public static object ConvertType(this object objValue, Type type)
        {
            if (objValue.GetType() == type) { return objValue; }
            string strValue = objValue != null ? objValue.ToString() : string.Empty;

            // 泛型类型处理
            if (type.IsGenericType)
            {
                // Nullable变量类型
                if (type.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    type = Nullable.GetUnderlyingType(type);
                    switch (type.Name)
                    {
                        case "DateTime": return strValue.ConvertType<DateTime?>(null);
                        case "Boolean": return strValue.ConvertType<bool?>(null);
                        case "Int32": return strValue.ConvertType<int?>(null);
                        case "Int16": return strValue.ConvertType<Int16?>(null);
                        case "Decimal": return strValue.ConvertType<Decimal?>(null);
                        case "Byte": return strValue.ConvertType<byte?>(null);
                        case "Long": return strValue.ConvertType<long?>(null);
                        case "Float": return strValue.ConvertType<float?>(null);
                        case "Double": return strValue.ConvertType<Double?>(null);
                        //default: throw new Exception("类型：" + type.Name + "， 未有转换程序对其解析。");
                    }
                }
                else // List 变量类型
                {
                    type = type.GetGenericArguments()[0];
                    switch (type.Name)
                    {
                        case "String": return strValue.ToList(string.Empty);
                        case "DateTime": return strValue.ToList(DateTime.MinValue);
                        case "Boolean": return strValue.ToList(false);
                        case "Int32": return strValue.ToList(0);
                        case "Int16": return strValue.ToList(0);
                        case "Decimal": return strValue.ToList(0m);
                        case "Byte": return strValue.ToList((byte)0);
                        case "Long": return strValue.ToList(0L);
                        case "Float": return strValue.ToList(0f);
                        case "Double": return strValue.ToList(0d);
                    }
                    return strValue.ToList(Activator.CreateInstance(type));
                }
            }

            if (type.IsEnum) { return strValue.IsType<int>() ? Enum.ToObject(type, int.Parse(strValue)) : !strValue.IsNullOrEmpty() ? Enum.Parse(type, strValue) : null; }

            switch (type.Name)
            {
                case "String": return strValue;
                case "DateTime": return strValue.ConvertType(DateTime.MinValue);
                case "Boolean": return strValue.ConvertType(false);
                case "Int32": return strValue.ConvertType(0);
                case "Int16": return strValue.ConvertType<Int16>();
                case "Decimal": return strValue.ConvertType(0m);
                case "Byte": return strValue.ConvertType((byte)0);
                case "Long": return strValue.ConvertType(0L);
                case "Float": return strValue.ConvertType(0f);
                case "Double": return strValue.ConvertType(0d);
            }

            if (objValue == null || strValue.IsNullOrEmpty())
            {
                if (type.Name.EndsWith("[]")) { return null; }
            }

            return Convert.ChangeType(objValue, type);
        }

        /// <summary>
        /// 判断是否T类型
        /// </summary>
        /// <param name="obj">要判断的对像</param>
        /// <typeparam name="T">基本类型</typeparam>
        public static bool IsType<T>(this object obj)
        {
            if (obj == null) { return false; }
            Type objType = obj.GetType();
            Type tType = typeof(T);

            if (tType.IsEnum) { return obj is Enum; }

            try
            {
                switch (tType.Name)
                {
                    case "DateTime": return obj.ConvertType<DateTime?>(null) != null;
                    case "Boolean": return obj.ConvertType<Boolean?>(null) != null;
                    case "Int32": return obj.ConvertType<Int32?>(null) != null;
                    case "Int16": return obj.ConvertType<Int16?>(null) != null;
                    case "Decimal": return obj.ConvertType<Decimal?>(null) != null;
                    case "Byte": return obj.ConvertType<Byte?>(null) != null;
                    case "Long": return obj.ConvertType<long?>(null) != null;
                    case "Float": return obj.ConvertType<float?>(null) != null;
                    case "Double": return obj.ConvertType<Double?>(null) != null;
                }

            }
            catch { return false; }
            return objType == tType;

        }

        /// <summary>
        /// Func 转换成 Predicate 对像
        /// </summary>
        /// <typeparam name="T">实体类</typeparam>
        /// <param name="source">源Func对像</param>
        public static Predicate<T> ToPredicate<T>(this Func<T, bool> source) where T : BaseInfo, new()
        {
            return new Predicate<T>(source);
        }

        /// <summary>
        /// 当NullOrEmpty，用新的字符串代替，否则用原来的。
        /// </summary>
        /// <param name="obj">要检测的值</param>
        /// <param name="newString">要替换的新字符串</param>
        public static string WhileNullOrEmpty(this string obj, string newString)
        {
            return obj.IsNullOrEmpty() ? newString : obj.ToString();
        }

        /// <summary>
        /// 当NullOrEmpty，用新的字符串代替，否则用原来的。
        /// </summary>
        /// <param name="obj">要检测的值</param>
        /// <param name="newString">要替换的新字符串</param>
        public static string WhileNullOrEmpty<T>(this T? obj, string newString) where T : struct
        {
            return (obj == null || obj.ToString().IsNullOrEmpty()) ? newString : obj.ToString();
        }

        /// <summary>
        /// 当不为NullOrEmpty，用新的字符串代替，否则用原来的。
        /// </summary>
        /// <param name="obj">要检测的值</param>
        /// <param name="newString">要替换的新字符串</param>
        public static string WhileNotNullOrEmpty(this string obj, string newString)
        {
            return obj.IsNullOrEmpty() ? obj : newString;
        }

        /// <summary>
        /// 当不为NullOrEmpty，用新的字符串代替，否则用原来的。
        /// </summary>
        /// <param name="obj">要检测的值</param>
        /// <param name="newString">要替换的新字符串</param>
        public static string WhileNotNullOrEmpty<T>(this T? obj, string newString) where T : struct
        {
            return (obj == null || obj.ToString().IsNullOrEmpty()) ? string.Empty : obj.ToString();
        }

        /// <summary>
        /// 设置创建人信息
        /// </summary>
        /// <param name="createInfo">被赋值的实体</param>
        /// <param name="createID">创建人ID</param>
        /// <param name="createName">创建人名称</param>
        public static void SetCreateInfo(this ICreateInfo createInfo, int? createID = 0, string createName = "")
        {
            createInfo.CreateIP = ParseIP.GetIP();
            createInfo.CreateAt = DateTime.Now;
            createInfo.CreateID = createID;
            createInfo.CreateName = createName;
        }

        /// <summary>
        /// 设置修改人信息
        /// </summary>
        /// <param name="updateInfo">被赋值的实体</param>
        /// <param name="updateID">创建人ID</param>
        /// <param name="updateName">创建人名称</param>
        public static void SetUpdateInfo(this IUpdateInfo updateInfo, int? updateID = 0, string updateName = "")
        {
            updateInfo.UpdateIP = ParseIP.GetIP();
            updateInfo.UpdateAt = DateTime.Now;
            updateInfo.UpdateID = updateID;
            updateInfo.UpdateName = updateName;
        }

        /// <summary>
        /// 设置审核人信息
        /// </summary>
        /// <param name="auditInfo">被赋值的实体</param>
        /// <param name="auditID">创建人ID</param>
        /// <param name="auditName">创建人名称</param>
        public static void SetAuditInfo(this IAuditInfo auditInfo, int? auditID = 0, string auditName = "")
        {
            auditInfo.AuditIP = ParseIP.GetIP();
            auditInfo.AuditAt = DateTime.Now;
            auditInfo.AuditID = auditID;
            auditInfo.AuditName = auditName;
        }
    }
}