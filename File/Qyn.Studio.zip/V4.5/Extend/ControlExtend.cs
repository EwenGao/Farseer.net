﻿using Qyn.Studio.Base;
using Qyn.Studio.Bean;
using System.Web.UI.WebControls;
using System.Collections.Generic;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// 控件扩展工具
    /// </summary>
    public static class ControlExtend 
    {
        /// <summary>
        /// 获取ListBox的值
        /// </summary>
        /// <param name="control">ListBox</param>
        public static List<T> GetValue<T>(this ListControl control)
        {
            List<T> lst = new List<T>();
            if (control is CheckBoxList)
            {
                foreach (ListItem item in control.Items) { if (item.Selected) { lst.Add(item.Value.ConvertType<T>()); } }
            }
            else
            {
                foreach (ListItem item in control.Items) { lst.Add(item.Value.ConvertType<T>()); }
            }
            return lst;

        }

        /// <summary>
        /// 设置ListBox的值
        /// </summary>
        /// <param name="control">ListBox</param>
        /// <param name="lst">要设置的值</param>
        public static void SetValue<T>(this ListControl control, List<T> lst)
        {
            if (control is CheckBoxList)
            {
                foreach (ListItem item in control.Items)
                {
                    if (!item.Value.IsType<T>()) { continue; }
                    item.Selected = lst.Exists(o => o.ToString() == item.Value);
                }
            }
            else { foreach (T item in lst) { control.Items.Add(item.ToString()); } }
        }

        /// <summary>
        /// 获取CheckBoxList中，选中后的枚举值
        /// </summary>
        /// <param name="control">CheckBoxList</param>
        /// <returns></returns>
        public static int GetValue(this CheckBoxList control)
        {
            int enumValue = 0;

            foreach (ListItem item in control.Items)
            {
                if (item.Selected) { enumValue |= item.Value.ConvertType<int>(); }
            }
            return enumValue;
        }

        /// <summary>
        /// 获取CheckBoxList中，选中后的枚举值
        /// </summary>
        /// <param name="control">CheckBoxList</param>
        /// <returns></returns>
        public static void SetValue(this CheckBoxList control, int value)
        {
            foreach (ListItem item in control.Items)
            {
                var val = item.Value.ConvertType(0);
                item.Selected = (val & value) == val;
            }
        }
    }
}