﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Qyn.Studio.Base;
using Qyn.Studio.Data;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Data扩展工具
    /// </summary>
    public static class ListExtend
    {
        /// <summary>
        /// 对List进行分页
        /// </summary>
        public static List<T> ToList<T>(this IEnumerable<T> lst, int pageSize, int pageIndex = 1) where T : BaseInfo, new()
        {
            if (pageSize == 0) { return lst.ToList(); }

            #region 计算总页数
            int allCurrentPage = 0;
            int recordCount = lst.Count();
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            if (pageIndex > allCurrentPage) { pageIndex = allCurrentPage; }
            #endregion

            return lst.Skip(pageSize * (pageIndex - 1)).Take(pageSize).ToList();

            //if (pageIndex < 1)
            //{
            //    pageIndex = 1;
            //}
            //if (pageSize < 1)
            //{
            //    pageSize = 1;
            //}

            //List<T> newList = new List<T>();
            //int firstIndex;
            //int endIndex;

            //#region 计算 开始索引
            //if (pageIndex == 1)
            //{
            //    firstIndex = 0;
            //}
            //else
            //{
            //    firstIndex = pageSize * (pageIndex - 1);
            //    //索引超出记录总数时，返回空的表格
            //    if (firstIndex > lst.Count)
            //    {
            //        return newList;
            //    }
            //}
            //#endregion

            //#region 计算 结束索引
            //endIndex = pageSize + firstIndex;
            //if (endIndex > lst.Count)
            //{
            //    endIndex = lst.Count;
            //}
            //#endregion

            //for (int i = firstIndex; i < endIndex; i++)
            //{
            //    newList.Add(lst[i]);
            //}
            //return newList;
        }

        /// <summary>
        /// 对List进行分页
        /// </summary>
        public static List<T> ToList<T>(this IEnumerable<T> lst, Qyn.Studio.UI.WebControls.Repeater rpt) where T : BaseInfo, new() { rpt.PageCount = lst.Count(); return ToList(lst, rpt.PageSize, rpt.PageIndex); }

        /// <summary>
        /// 自动填充到指定数量
        /// </summary>
        public static IList Fill(this IList lst, int maxCount, object defValue)
        {
            while (true)
            {
                if (lst.Count >= maxCount) { break; }
                lst.Add(defValue);
            }

            return lst;
        }

        /// <summary>
        /// 将集合类转换成DataTable
        /// </summary>
        /// <param name="list">集合</param>
        /// <returns></returns>
        public static DataTable ToDataTable(this IList list)
        {
            DataTable result = new DataTable();
            if (list.Count > 0)
            {
                PropertyInfo[] propertys = list[0].GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    result.Columns.Add(pi.Name, pi.PropertyType);
                }

                for (int i = 0; i < list.Count; i++)
                {
                    ArrayList tempList = new ArrayList();
                    foreach (PropertyInfo pi in propertys)
                    {
                        object obj = pi.GetValue(list[i], null);
                        tempList.Add(obj);
                    }
                    object[] array = tempList.ToArray();
                    result.LoadDataRow(array, true);
                }
            }
            return result;
        }

        /// <summary>
        /// 将泛型集合类转换成DataTable
        /// </summary>
        /// <param name="list">集合</param>
        /// <param name="propertyName">需要返回的列的列名</param>
        /// <returns>数据集(表)</returns>
        public static DataTable ToDataTable(this IList list, params string[] propertyName)
        {
            List<string> propertyNameList = new List<string>();
            if (propertyName != null)
                propertyNameList.AddRange(propertyName);

            DataTable result = new DataTable();
            if (list.Count > 0)
            {
                PropertyInfo[] propertys = list[0].GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    if (propertyNameList.Count == 0)
                    {
                        result.Columns.Add(pi.Name, pi.PropertyType);
                    }
                    else
                    {
                        if (propertyNameList.Contains(pi.Name))
                            result.Columns.Add(pi.Name, pi.PropertyType);
                    }
                }

                for (int i = 0; i < list.Count; i++)
                {
                    ArrayList tempList = new ArrayList();
                    foreach (PropertyInfo pi in propertys)
                    {
                        if (propertyNameList.Count == 0)
                        {
                            object obj = pi.GetValue(list[i], null);
                            tempList.Add(obj);
                        }
                        else
                        {
                            if (propertyNameList.Contains(pi.Name))
                            {
                                object obj = pi.GetValue(list[i], null);
                                tempList.Add(obj);
                            }
                        }
                    }
                    object[] array = tempList.ToArray();
                    result.LoadDataRow(array, true);
                }
            }
            return result;
        }

        /// <summary>
        /// 关联两个实体
        /// </summary>
        /// <typeparam name="T1">主实体</typeparam>
        /// <typeparam name="T2">要附加关联的实体</typeparam>
        /// <param name="lst">主列表</param>
        /// <param name="JoinModule">要关联的子实体</param>
        /// <param name="JoinModuleSelect">要附加关联的子实体的字段筛选</param>
        /// <param name="RelationPropery">主表关系字段</param>
        /// <param name="defInfo">为空时如何处理？</param>
        public static List<T1> Join<T1, T2>(this List<T1> lst, Expression<Func<T1, T2>> JoinModule, Expression<Func<T2, object>> JoinModuleSelect = null, T2 defInfo = null, Func<T1, int?> RelationPropery = null, bool isCacheLogic = false, DbExecutor db = null)
            where T1 : BaseInfo, new()
            where T2 : BaseInfo, new()
        {
            if (RelationPropery == null) { RelationPropery = o => o.ID; }

            #region 获取实际类型
            MemberExpression memberExpression = JoinModule.Body as MemberExpression;
            string propertyName = ((PropertyInfo)memberExpression.Member).Name; // 属性名称

            List<PropertyInfo> lstPropery = new List<PropertyInfo>();
            Type type = typeof(T1);
            while (memberExpression.Expression.NodeType == ExpressionType.MemberAccess)
            {
                memberExpression = memberExpression.Expression as MemberExpression;
                lstPropery.Add(ModelCache.GetInfo(type).GetModelInfo(((PropertyInfo)memberExpression.Member).Name).Key);
                type = memberExpression.Type;
            }
            lstPropery.Reverse();
            // 获取属性类型
            var propertyType = ModelCache.GetInfo(type).GetModelInfo(propertyName).Key;
            #endregion

            // 内容ID
            var lstIDs = lst.Select(RelationPropery).ToList();
            // 详细资料
            List<T2> lstSub;
            if (isCacheLogic) { lstSub = BaseCacheLogic<T2>.Cache.ToList().Where(o => lstIDs.Contains(o.ID)).ToList(); }
            else { lstSub = BaseLogic<T2>.Data.Where(o => lstIDs.Contains(o.ID)).Selector(JoinModuleSelect).Selector(o => o.ID).ToList(0, 1, db); }

            foreach (var item in lst)
            {
                var subInfo = lstSub.Where(o => o.ID == RelationPropery.Invoke(item)).FirstOrDefault() ?? defInfo;
                object value = item;
                foreach (var propery in lstPropery) { value = propery.GetValue(value, null); }

                propertyType.SetValue(value, subInfo, null);
            }

            return lst;
        }

        /// <summary>
        /// 关联两个实体
        /// </summary>
        /// <typeparam name="T1">主实体</typeparam>
        /// <typeparam name="T2">要附加关联的实体</typeparam>
        /// <param name="lst">主列表</param>
        /// <param name="JoinModule">要关联的子实体</param>
        /// <param name="JoinModuleSelect">要附加关联的子实体的字段筛选</param>
        /// <param name="RelationPropery">主表关系字段</param>
        /// <param name="defInfo">为空时如何处理？</param>
        public static T1 Join<T1, T2>(this T1 info, Expression<Func<T1, T2>> JoinModule, Expression<Func<T2, object>> JoinModuleSelect = null, T2 defInfo = null, Func<T1, int?> RelationPropery = null, bool isCacheLogic = false, DbExecutor db = null)
            where T1 : BaseInfo, new()
            where T2 : BaseInfo, new()
        {
            if (info == null) { return null; }
            if (RelationPropery == null) { RelationPropery = o => o.ID; }

            #region 获取实际类型
            MemberExpression memberExpression = JoinModule.Body as MemberExpression;
            string propertyName = ((PropertyInfo)memberExpression.Member).Name; // 属性名称

            List<PropertyInfo> lstPropery = new List<PropertyInfo>();
            Type type = typeof(T1);
            while (memberExpression.Expression.NodeType == ExpressionType.MemberAccess)
            {
                memberExpression = memberExpression.Expression as MemberExpression;
                lstPropery.Add(ModelCache.GetInfo(type).GetModelInfo(((PropertyInfo)memberExpression.Member).Name).Key);
                type = memberExpression.Type;
            }
            lstPropery.Reverse();
            // 获取属性类型
            var propertyType = ModelCache.GetInfo(type).GetModelInfo(propertyName).Key;
            #endregion

            // 详细资料
            T2 subInfo;
            if (isCacheLogic) { subInfo = BaseCacheLogic<T2>.Cache.ToList().Where(o => o.ID == RelationPropery.Invoke(info)).FirstOrDefault() ?? defInfo; }
            else { subInfo = BaseLogic<T2>.Data.Where(o => o.ID == RelationPropery.Invoke(info)).Selector(JoinModuleSelect).ToInfo(db) ?? defInfo; }
            object value = info;
            foreach (var propery in lstPropery) { value = propery.GetValue(value, null); }

            propertyType.SetValue(value, subInfo, null);

            return info;
        }
    }
}