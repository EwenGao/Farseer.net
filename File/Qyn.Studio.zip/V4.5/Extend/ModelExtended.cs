﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Web.UI;
using Qyn.Studio.Base;
using Qyn.Studio.ORM;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// 实体类扩展方法
    /// </summary>
    public static class ModelExtended
    {
        /// <summary>
        /// 获取字段名称
        /// </summary>
        /// <param name="selector">字段名称</param>
        /// <returns></returns> 
        public static string GetUsedName<T1, T2>(this Expression<Func<T1, T2>> selector) where T1 : BaseInfo
        {
            MemberExpression memberExpression;

            UnaryExpression unary = selector.Body as UnaryExpression;
            if (unary != null) { memberExpression = unary.Operand as MemberExpression; }
            else if (selector.Body.NodeType == ExpressionType.Call) { memberExpression = (MemberExpression)((MethodCallExpression)selector.Body).Object; }
            else { memberExpression = selector.Body as MemberExpression; }

            Mapping map = ModelCache.GetInfo(typeof(T1));
            KeyValuePair<PropertyInfo, ModelAttribute> modelInfo = map.GetModelInfo(((PropertyInfo)memberExpression.Member).Name);

            return modelInfo.Value.Column.Name;
        }

        /// <summary>
        /// 将实体类填充到控件中
        /// </summary>
        /// <param name="page">当前页</param>
        /// <param name="info">要填入数据的实体类</param>
        /// <param name="contentPlaceHolderID">母版页面版ID</param>
        /// <param name="prefix">控件前缀</param>
        public static void Fill<TInfo>(this TInfo info, Page page, string contentPlaceHolderID, string prefix = "hl") where TInfo : BaseInfo, new()
        {
            ParseWebControls.Fill<TInfo>(page, contentPlaceHolderID, info, prefix);
        }

        /// <summary>
        /// 将实体类填充到控件中
        /// </summary>
        /// <param name="page">当前页</param>
        /// <param name="prefix">控件前缀</param>
        /// <param name="info">要填充的值</param>
        public static void Fill<TInfo>(this TInfo info, Page page, string prefix = "hl") where TInfo : BaseInfo, new()
        {
            ParseWebControls.Fill<TInfo>(page, info, prefix);
        }
    }
}
