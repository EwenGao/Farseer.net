﻿
namespace Qyn.Studio.Extend
{
    public static class HtmlExtend
    {
        ///// <summary>
        ///// 单选框绑定
        ///// </summary>
        ///// <typeparam name="TModel">实体</typeparam>
        ///// <typeparam name="TProperty">类型</typeparam>
        ///// <param name="htmlHelper">Html帮助</param>
        ///// <param name="expression">表达树</param>
        ///// <param name="eumType">枚举</param>
        ///// <param name="value">控件Attributes</param>
        //public static MvcHtmlString RadioButtonBind<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, Type eumType, int defValue = 0, IDictionary<string, object> htmlAttributes = null)
        //{
        //    if (htmlAttributes == null) { htmlAttributes = new Dictionary<string, object>(); }
        //    StringPlus str = new StringPlus();
        //    var lstEum = ParseEnum.GetList(eumType);
        //    foreach (var item in lstEum)
        //    {
        //        if (item.Key == defValue) { htmlAttributes.Add("checked", "checked"); }
        //        str.AppendLine(htmlHelper.RadioButtonFor(expression, item.Key, htmlAttributes).ToHtmlString() + "<label>" + item.Value + "</label>");
        //        htmlAttributes.Remove("checked");
        //    }
        //    return MvcHtmlString.Create(str.Value);
        //}

        ///// <summary>
        ///// 列表框绑定
        ///// </summary>
        ///// <typeparam name="TModel">实体</typeparam>
        ///// <typeparam name="TProperty">类型</typeparam>
        ///// <param name="htmlHelper">Html帮助</param>
        ///// <param name="expression">表达树</param>
        ///// <param name="eumType">枚举</param>
        ///// <param name="defValue">默认值</param>
        ///// <param name="htmlAttributes"></param>
        ///// <returns></returns>
        //public static MvcHtmlString DropDownListFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, Type eumType, int defValue = 0, IDictionary<string, object> htmlAttributes = null)
        //{
        //    var list = new List<SelectListItem>();
        //    foreach (var item in ParseEnum.GetList(eumType))
        //    {
        //        list.Add(new SelectListItem { Value = item.Key.ToString(), Text = item.Value, Selected = item.Key == defValue });
        //    }
        //    return htmlHelper.DropDownListFor(expression, list, htmlAttributes);
        //}
    }
}
