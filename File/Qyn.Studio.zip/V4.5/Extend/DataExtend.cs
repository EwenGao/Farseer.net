﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using Qyn.Studio.Base;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Data扩展工具
    /// </summary>
    public static class DataExtend
    {
        /// <summary>
        /// 对DataTable排序
        /// </summary>
        /// <param name="dt">要排序的表</param>
        /// <param name="sort">要排序的字段</param>
        public static DataTable Sort(this DataTable dt, string sort = "ID DESC")
        {
            DataRow[] rows = dt.Select("", sort);
            DataTable tmpDt = dt.Clone();

            foreach (DataRow row in rows)
            {
                tmpDt.ImportRow(row);
            }
            return tmpDt;
        }

        /// <summary>
        /// 对DataTable分页
        /// </summary>
        /// <param name="dt">源表</param>
        /// <param name="pageSize">每页显示的记录数</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static DataTable Pagination(this DataTable dt, int pageIndex = 1, int pageSize = 20)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 1; }
            DataTable dtNew = dt.Clone();

            if (dt != null)
            {
                int firstIndex;
                int endIndex;

                #region 计算 开始索引
                if (pageIndex == 1) { firstIndex = 0; }
                else
                {
                    firstIndex = pageSize * (pageIndex - 1);
                    //索引超出记录总数时，返回空的表格
                    if (firstIndex > dt.Rows.Count) { return dtNew; }
                }
                #endregion

                #region 计算 结束索引
                endIndex = pageSize + firstIndex;
                if (endIndex > dt.Rows.Count) { endIndex = dt.Rows.Count; }
                #endregion

                for (int i = firstIndex; i < endIndex; i++) { dtNew.ImportRow(dt.Rows[i]); }
            }
            return dtNew;
        }

        /// <summary>
        /// DataTable倒序
        /// </summary>
        /// <param name="dt">源DataTable</param>
        public static DataTable Reverse(this DataTable dt)
        {
            DataRow[] rows = dt.Select("");
            DataTable tmpDt = dt.Clone();

            for (int i = dt.Rows.Count - 1; i >= 0; i--)
            {
                tmpDt.ImportRow(dt.Rows[i]);
            }
            return tmpDt;
        }

        /// <summary>
        /// DataTable转换为实体类
        /// </summary>
        /// <param name="dt">源DataTable</param>
        /// <typeparam name="T">实体类</typeparam>
        public static List<T> ToList<T>(this DataTable dt) where T : BaseInfo
        {
            List<T> list = new List<T>();
            Mapping map = ModelCache.GetInfo(typeof(T));
            T t;
            foreach (DataRow dr in dt.Rows)
            {
                t = (T)Activator.CreateInstance(typeof(T));

                //赋值字段
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.ModelList.Where(o => o.Value.IsAttribute))
                {
                    if (dr.Table.Columns.Contains(kic.Value.Column.Name))
                    {
                        if (!kic.Key.CanWrite) { continue; }
                        kic.Key.SetValue(t, dr[kic.Value.Column.Name].ConvertType(kic.Key.PropertyType), null);
                    }
                }
                list.Add(t);
            }
            return list;
        }

        /// <summary>
        /// DataTable转换为实体类
        /// </summary>
        /// <param name="dt">源DataTable</param>
        /// <typeparam name="T">实体类</typeparam>
        public static List<T> ToList2<T>(this DataTable dt)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            foreach (DataRow dr in dt.Rows)
            {
                T t = (T)Activator.CreateInstance(ht, dr);
                list.Add(t);
            }
            dt.Dispose();
            return list;
        }

        /// <summary>
        /// IDataReader转换为实体类
        /// </summary>
        /// <param name="reader">源IDataReader</param>
        /// <typeparam name="T">实体类</typeparam>
        public static List<T> ToList<T>(this IDataReader reader) where T : BaseInfo
        {
            List<T> list = new List<T>();
            Mapping Map = ModelCache.GetInfo(typeof(T));
            T t;

            while (reader.Read())
            {
                t = (T)Activator.CreateInstance(typeof(T));

                //赋值字段
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in Map.ModelList.Where(o => o.Value.IsAttribute))
                {
                    if (reader.GetOrdinal(kic.Value.Column.Name) > -1)
                    {
                        if (!kic.Key.CanWrite) { continue; }
                        kic.Key.SetValue(t, reader[kic.Value.Column.Name].ConvertType(kic.Key.PropertyType), null);
                    }
                }

                list.Add(t);
            }
            reader.Close();
            reader.Dispose();
            return list;
        }

        /// <summary>
        /// IDataReader转换为实体类
        /// </summary>
        /// <param name="ds">源DataSet</param>
        /// <typeparam name="T">实体类</typeparam>
        public static List<T> ToList<T>(this DataSet ds) where T : BaseInfo
        {
            if (ds.Tables.Count == 0) return null;
            return ds.Tables[0].ToList<T>();
        }

        /// <summary>
        /// 将ListItem 转换为List
        /// </summary>
        /// <typeparam name="T">指定要转换的基本类型</typeparam>
        /// <param name="lstItem">ListItemCollection</param>
        public static List<T> ToList<T>(this ListItemCollection lstItem) where T : struct
        {
            List<T> lst = new List<T>();
            foreach (ListItem item in lstItem)
            {
                lst.Add(item.Value.ConvertType<T>());
            }
            return lst;
        }

        /// <summary>
        /// 将XML转成实体
        /// </summary>
        public static List<T> ToList<T>(this XElement element)
        {
            Mapping orm = ModelCache.GetInfo(typeof(T));
            List<T> list = new List<T>();
            Type type;

            T t;

            foreach (XElement el in element.Elements())
            {
                t = (T)Activator.CreateInstance(typeof(T));

                //赋值字段
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in orm.ModelList.Where(o => o.Value.IsAttribute))
                {
                    type = kic.Key.PropertyType;
                    if (!kic.Key.CanWrite) { continue; }
                    if (kic.Value.PropertyExtend == eumPropertyExtend.Attribute)
                    {
                        if (el.Attribute(kic.Value.Column.Name) == null) { continue; }
                        kic.Key.SetValue(t, el.Attribute(kic.Value.Column.Name).Value.ConvertType(type), null);
                    }
                    else if (kic.Value.PropertyExtend == eumPropertyExtend.Element)
                    {
                        if (el.Element(kic.Value.Column.Name) == null) { continue; }
                        kic.Key.SetValue(t, el.Element(kic.Value.Column.Name).Value.ConvertType(type), null);
                    }
                }
                list.Add(t);
            }
            return list;
        }

        /// <summary>
        /// 将DataRowCollection转成List[DataRow]
        /// </summary>
        /// <param name="drc">DataRowCollection</param>
        public static List<DataRow> ToRows(this DataRowCollection drc)
        {
            List<DataRow> lstRow = new List<DataRow>();

            if (drc == null) { return lstRow; }

            foreach (DataRow dr in drc)
            {
                lstRow.Add(dr);
            }

            return lstRow;
        }

        /// <summary>
        /// 将DataRow转成实体类
        /// </summary>
        /// <typeparam name="T">实体类</typeparam>
        /// <param name="dr">源DataRow</param>
        public static T ToInfo<T>(this DataRow dr) where T : BaseInfo
        {
            Mapping map = ModelCache.GetInfo(typeof(T));
            T t = (T)Activator.CreateInstance(typeof(T));
            bool isHaveValue = false;

            //赋值字段
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.ModelList.Where(o => o.Value.IsAttribute))
            {
                if (dr.Table.Columns.Contains(kic.Value.Column.Name))
                {
                    if (!kic.Key.CanWrite) { continue; }
                    kic.Key.SetValue(t, dr[kic.Value.Column.Name].ConvertType(kic.Key.PropertyType), null);
                    isHaveValue = true;
                }
            }
            return isHaveValue ? t : null;
        }

        /// <summary>
        /// 数据填充
        /// </summary>
        /// <param name="reader">源IDataReader</param>
        /// <typeparam name="T">实体类</typeparam>
        public static T ToInfo<T>(this IDataReader reader) where T : BaseInfo
        {
            Mapping map = ModelCache.GetInfo(typeof(T));

            T t = (T)Activator.CreateInstance(typeof(T));
            bool isHaveValue = false;

            if (reader.Read())
            {
                //赋值字段
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.ModelList.Where(o => o.Value.IsAttribute))
                {
                    if (reader.HaveName(kic.Value.Column.Name))
                    {
                        if (!kic.Key.CanWrite) { continue; }
                        kic.Key.SetValue(t, reader[kic.Value.Column.Name].ConvertType(kic.Key.PropertyType), null);
                        isHaveValue = true;
                    }
                }
            }
            reader.Close();
            reader.Dispose();
            return isHaveValue ? t : null;
        }

        /// <summary>
        /// 判断IDataReader是否存在某列
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public static bool HaveName(this IDataReader reader, string name)
        {
            for (int i = 0; i < reader.FieldCount; i++)
            {
                if (reader.GetName(i).IsEquals(name)) { return true; }
            }
            return false;
        }
    }
}