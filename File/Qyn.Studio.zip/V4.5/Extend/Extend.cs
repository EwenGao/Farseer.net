﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// 其它扩展，夫归类的扩展
    /// </summary>
    public static class Extend
    {
        /// <summary>
        /// 将任何数组转换成用符号连接的字符串
        /// </summary>
        /// <param name="obj">任何对像</param>
        /// <param name="func">传入要在转换过程中要执行的方法</param>
        /// <param name="sign">分隔符</param>
        /// <typeparam name="T">基本对像</typeparam>
        public static string ToString<T>(this T[] obj, string sign = ",", Func<T, string> func = null)
        {
            if (obj == null || obj.Length == 0) { return string.Empty; }

            StringBuilder str = new StringBuilder();
            for (int i = 0; i < obj.Length; i++)
            {
                if (func == null) { str.Append(sign + obj[i]); }
                else { str.Append(sign + func(obj[i])); }
            }

            return str.ToString().Substring(sign.Length);
        }

        /// <summary>
        /// 获取短日期
        /// </summary>
        /// <param name="time">时间对像</param>
        public static string ToShortString(this DateTime time, string format = "yyyy-MM-dd")
        {
            string date = time.ToString(format);
            return date.Contains("0001") || date.Contains("1900") ? string.Empty : date;
        }

        /// <summary>
        /// 获取短日期
        /// </summary>
        /// <param name="time">时间对像</param>
        public static string ToShortString(this DateTime? time, string format = "yyyy-MM-dd")
        {
            return time.GetValueOrDefault().ToShortString(format);
        }

        /// <summary>
        /// 获取短日期
        /// </summary>
        /// <param name="time">时间对像</param>
        public static DateTime ToShortDate(this DateTime time)
        {
            return time.ToShortString().ConvertType(time);
        }

        /// <summary>
        /// 获取短日期
        /// </summary>
        /// <param name="time">时间对像</param>
        public static DateTime ToShortDate(this DateTime? time)
        {
            return time.GetValueOrDefault().ToShortDate();
        }

        /// <summary>
        /// 获取长日期
        /// </summary>
        /// <param name="time">时间对像</param>
        public static string ToLongString(this DateTime time, string format = "yyyy-MM-dd HH:mm")
        {
            string date = time.ToString(format);
            return date.Contains("0001") || date.Contains("1900") ? string.Empty : date;
        }

        /// <summary>
        /// 获取长日期
        /// </summary>
        /// <param name="time">时间对像</param>
        public static string ToLongString(this DateTime? time, string format = "yyyy-MM-dd HH:mm")
        {
            return time.GetValueOrDefault().ToLongString(format);
        }

        /// <summary>
        /// 扩展 Dictionary 根据Value反向查找Key的方法
        /// </summary>
        /// <param name="list">Dictionary对像</param>
        /// <param name="t2">键值</param>
        /// <typeparam name="T1">Key</typeparam>
        /// <typeparam name="T2">Value</typeparam>
        public static T1 GetKey<T1, T2>(this Dictionary<T1, T2> list, T2 t2)
        {
            foreach (KeyValuePair<T1, T2> obj in list) { if (obj.Value.Equals(t2)) return obj.Key; }
            return default(T1);
        }

        /// <summary>
        /// 将List转换成字符串
        /// </summary>
        /// <param name="lst">要拼接的LIST</param>
        /// <param name="sign">分隔符</param>
        public static string ToString(this IEnumerable lst, string sign = ",")
        {
            if (lst == null) { return string.Empty; }
            StringBuilder str = new StringBuilder();
            foreach (var item in lst)
            {
                str.Append(item.ToString() + sign);
            }
            return str.ToString().DelEndOf(sign);
        }

        /// <summary>
        /// 获取枚举中文
        /// </summary>
        /// <param name="eum">枚举对像</param>
        public static string GetName(this Enum eum)
        {
            if (eum == null) { return string.Empty; }
            return ParseEnum.GetName(eum);
        }

        /// <summary>
        /// 条件相等，输出字符串
        /// </summary>
        /// <param name="b">判断源结果</param>
        /// <param name="result">输出时的结果</param>
        /// <param name="str">输出的字符串</param>
        public static string ToString(this bool b, bool result, string str)
        {
            return b == result ? str : string.Empty;
        }

        /// <summary>
        /// 条件相等，输出字符串
        /// </summary>
        /// <param name="b">判断源结果</param>
        /// <param name="result">输出时的结果</param>
        /// <param name="str">输出的字符串</param>
        public static string ToString(this bool? b, bool result, string str)
        {
            return b.GetValueOrDefault() == result ? str : string.Empty;
        }

        /// <summary>
        /// 复制一个新的List
        /// </summary>
        public static List<T> Copy<T>(this List<T> lst)
        {
            List<T> lstNew = new List<T>();

            if (lst != null) { lst.ForEach(o => lstNew.Add(o)); }

            return lstNew;
        }

        /// <summary>
        /// 克隆List
        /// </summary>
        /// <typeparam name="T">要转换的类型</typeparam>
        /// <param name="list"></param>
        /// <returns></returns>
        public static List<T> Clone<T>(this List<T> list) where T : ICloneable
        {
            if (list == null) { return null; }
            return list.Select(o => (T)o.Clone()).ToList<T>();
        }

        /// <summary>
        /// 获取List最后一项
        /// </summary>
        /// <typeparam name="T">任何对像</typeparam>
        /// <param name="lst">List列表</param>
        public static T GetLast<T>(this List<T> lst)
        {
            if (lst.Count > 0) { return lst[lst.Count - 1]; }
            return default(T);
        }

        /// <summary>
        /// 数据分页
        /// </summary>
        /// <typeparam name="TSource">实体</typeparam>
        /// <param name="source">源对像</param>
        /// <param name="pageIndex">页码</param>
        /// <param name="pageSize">每页大小</param>
        public static IQueryable<TSource> PageSplit<TSource>(this IQueryable<TSource> source, int pageSize = 20, int pageIndex = 1)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 20; }
            return source.Skip(pageSize * (pageIndex - 1)).Take(pageSize);
        }

        ///// <summary>
        ///// 将列转换成Join字符串
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="list"></param>
        ///// <param name="split"></param>
        ///// <returns></returns>
        //public static string ToJoin<T>(this IEnumerable<T> list, string split = ",")
        //{
        //    if (list == null) return string.Empty;
        //    StringBuilder sb = new StringBuilder();
        //    int index = 0;
        //    int count = list.Count();
        //    foreach (T t in list)
        //    {
        //        index++;
        //        sb.AppendFormat("{0}{1}", t, index == count ? "" : split.ToString());
        //    }
        //    return sb.ToString();
        //}

        /// <summary>
        /// 把服務器返回的Cookies信息寫入到客戶端中
        /// </summary>
        public static void Cookies(this WebClient wc)
        {
            if (wc.ResponseHeaders == null) return;
            string setcookie = wc.ResponseHeaders[HttpResponseHeader.SetCookie];
            if (!string.IsNullOrEmpty(setcookie))
            {
                string cookie = wc.Headers[HttpRequestHeader.Cookie];
                Dictionary<string, string> cookieList = new Dictionary<string, string>();

                if (!string.IsNullOrEmpty(cookie))
                {
                    foreach (string ck in cookie.Split(';'))
                    {
                        string key = ck.Substring(0, ck.IndexOf('='));
                        string value = ck.Substring(ck.IndexOf('=') + 1);
                        if (!cookieList.ContainsKey(key)) cookieList.Add(key, value);
                    }
                }

                foreach (string ck in setcookie.Split(';'))
                {
                    string str = ck;
                    while (str.Contains(',') && str.IndexOf(',') < str.LastIndexOf('='))
                    {
                        str = str.Substring(str.IndexOf(',') + 1);
                    }
                    string key = str.IndexOf('=') != -1 ? str.Substring(0, str.IndexOf('=')) : "";
                    string value = str.Substring(str.IndexOf('=') + 1);
                    if (!cookieList.ContainsKey(key))
                        cookieList.Add(key, value);
                    else
                        cookieList[key] = value;
                }

                string[] list = new string[cookieList.Count()];
                int index = 0;
                foreach (var pair in cookieList)
                {
                    list[index] = string.Format("{0}={1}", pair.Key, pair.Value);
                    index++;
                }

                wc.Headers[HttpRequestHeader.Cookie] = list.ToString(";");
            }
        }

        /// <summary>
        /// 判断value是否存在于列表中
        /// </summary>
        /// <param name="lst">数据源</param>
        /// <param name="value">要判断的值</param>
        /// <returns></returns>
        public static bool Contains(this IEnumerator<int> lst, int? value)
        {
            return lst.Contains(value.GetValueOrDefault());
        }

        /// <summary>
        /// 判断value是否存在于列表中
        /// </summary>
        /// <param name="lst">数据源</param>
        /// <param name="value">要判断的值</param>
        /// <returns></returns>
        public static bool Contains(this List<int> lst, int? value)
        {
            return lst.Contains(value.GetValueOrDefault());
        }
    }
}