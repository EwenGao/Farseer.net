﻿using Qyn.Studio.Base;
using Qyn.Studio.Bean;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Bean扩展工具
    /// </summary>
    public static class BeanExtend 
    {
        /// <summary>
        /// 获取下一条记录
        /// </summary>
        /// <param name="bean">原条件</param>
        /// <param name="ID">当前ID</param>
        public static TInfo ToNextInfo<TInfo>(this IBean<TInfo> bean, int ID) where TInfo : BaseInfo, new()
        {
            return bean.Where(o => o.ID > ID).Asc(o => o.ID).ToInfo();
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="bean">原条件</param>
        /// <param name="ID">当前ID</param>
        public static TInfo ToPreviousInfo<TInfo>(this IBean<TInfo> bean, int ID) where TInfo : BaseInfo, new()
        {
            return bean.Where(o => o.ID < ID).Desc(o => o.ID).ToInfo();
        }
    }
}