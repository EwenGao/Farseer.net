﻿namespace Qyn.Studio.Extend
{
    /// <summary>
    /// 数字类型扩展工具
    /// </summary>
    public static class NumberExtend
    {
        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string Format(this int number, bool isHaveTag = true, int len = 2)
        {
            string str = string.Empty;
            if (isHaveTag) { str = "￥"; }
            return str +  number.ToString(string.Format("n{0}", len));
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string Format(this int? number, bool isHaveTag = true, int len = 2)
        {
            return Format(number.GetValueOrDefault(), isHaveTag, len);
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string Format(this decimal number, bool isHaveTag = true, int len = 2)
        {
            string str = string.Empty;
            if (isHaveTag) { str = "￥"; }
            return str + number.ToString(string.Format("n{0}", len));
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string Format(this decimal? number, bool isHaveTag = true, int len = 2)
        {
            return Format(number.GetValueOrDefault(), isHaveTag, len);
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string Format(this double number, bool isHaveTag = true, int len = 2)
        {
            string str = string.Empty;
            if (isHaveTag) { str = "￥"; }
            return str + number.ToString(string.Format("n{0}", len));
        }

        /// <summary>
        /// 数字格式化,将转换成1000,10
        /// </summary>
        public static string Format(this double? number, bool isHaveTag = true, int len = 2)
        {
            return Format(number.GetValueOrDefault(), isHaveTag, len);
        }
    }
}
