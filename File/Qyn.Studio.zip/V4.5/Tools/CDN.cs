using System;
using System.IO;
using System.Web;
using System.Web.SessionState;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// ��дģ��ĳ������
    /// </summary>
    /// <remarks></remarks>
    public class CDN : IHttpModule, IRequiresSessionState
    {
        /// <summary>
        /// �����¼��ܵ�
        /// </summary>
        public void Init(HttpApplication app)
        {
            app.AuthorizeRequest += new EventHandler(this.CDN_AuthorizeRequest);
        }

        /// <summary>
        /// ִ����д����
        /// </summary>
        protected void CDN_AuthorizeRequest(object sender, EventArgs e)
        {
            HttpApplication app = (HttpApplication)sender;

            // д��׷����־��Ϣ
            app.Context.Trace.Write("CDN����", "��ʼִ�С�");

            HttpApplication context = (HttpApplication)sender;

            string path = context.Request.RawUrl;
            if (path.Contains("?")) path = path.Substring(0, path.IndexOf('?'));
            if (!File.Exists(context.Server.MapPath(path)))
            {
                ParseFile.CreateDirs(context.Server.MapPath(path));
                Down.DownloadFile(string.Format("http:/{0}", path), context.Server.MapPath(path), null);
            }
            app.Context.Trace.Write("CDN����", "����ִ��");
            return;
        }

        /// <summary>
        /// ע��
        /// </summary>
        public void Dispose() { }
    }
}
