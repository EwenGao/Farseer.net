﻿using System.Xml.Linq;
using Qyn.Studio.Utils;
namespace Qyn.Studio.Data.Xml
{
    internal class XmlExecutor
    {
        internal protected string FilePath { get; set; }
        internal protected string XmlName { get; set; }

        /// <summary>
        /// 读取XML文档(直接读取xml文档)
        /// 路径不存，或者返回Null时，会自动创建xml
        /// </summary>
        internal protected XElement Load()
        {
            XElement element;
            if (!ParseFile.FileExists(FilePath)) { element = Create(); }
            else
            {
                element = XElement.Load(FilePath);
                if (element == null) { element = Create(); }
            }
            return element;
        }

        /// <summary>
        /// 创建XML文件
        /// </summary>
        internal protected XElement Create()
        {
            XDocument doc = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XElement(XmlName));

            ParseFile.CreateDirs(FilePath);
            doc.Save(FilePath);
            return doc.Element(XmlName);
        }
    }
}
