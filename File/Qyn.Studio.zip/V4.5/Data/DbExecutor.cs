﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Common;
using System.Text.RegularExpressions;
using System.Web;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Data
{
    /// <summary>
    /// 数据库操作
    /// </summary>
    public class DbExecutor : IDisposable
    {
        public static implicit operator DbExecutor(Type type)
        {
            Mapping map = type;
            return new DbExecutor(map.ClassInfo.DataType, map.ClassInfo.ConnStr, map.ClassInfo.CommandTimeout, IsolationLevel.ReadCommitted);
        }

        /// <summary>
        /// 连接字符串 
        /// </summary>
        private string ConnectionString { get; set; }

        /// <summary>
        /// 数据库执行时间，单位秒
        /// </summary>
        private int CommandTimeout { get; set; }

        /// <summary>
        /// 数据类型
        /// </summary>
        public DataBaseType DataType { get; set; }

        internal DbProviderFactory factory;
        private DbConnection conn;
        private DbCommand comm;

        /// <summary>
        /// 是否开启事务
        /// </summary>
        public bool IsTransaction { get; set; }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connnection">数据库连接字符串</param>
        /// <param name="commandTimeout">数据库执行时间，单位秒</param>
        public DbExecutor(DataBaseType dbType, string connnection, int commandTimeout) : this(dbType, connnection, commandTimeout, IsolationLevel.Unspecified) { }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="dbType">数据库类型</param>
        /// <param name="connnection">数据库连接字符串</param>
        /// <param name="commandTimeout">数据库执行时间，单位秒</param>
        /// <param name="tranLevel">开启事务等级</param>
        public DbExecutor(DataBaseType dbType, string connnection, int commandTimeout, IsolationLevel tranLevel)
        {
            this.ConnectionString = connnection.Replace("|RootDirectory|", HttpContext.Current != null ? HttpContext.Current.Request.PhysicalApplicationPath : AppDomain.CurrentDomain.BaseDirectory, RegexOptions.IgnoreCase);
            this.CommandTimeout = commandTimeout;
            this.DataType = dbType;

            factory = DbProviderFactories.GetFactory(dbType.GetName());
            comm = factory.CreateCommand();
            comm.CommandTimeout = commandTimeout;

            conn = factory.CreateConnection();
            conn.ConnectionString = ConnectionString;
            comm.Connection = conn;

            OpenTran(tranLevel);
        }

        /// <summary>
        /// 开启事务。
        /// </summary>
        /// <param name="tranLevel">事务方式</param>
        public void OpenTran(IsolationLevel tranLevel)
        {
            if (tranLevel != IsolationLevel.Unspecified)
            {
                Open();
                comm.Transaction = conn.BeginTransaction(tranLevel);
                IsTransaction = true;
            }
        }

        /// <summary>
        /// 打开数据库连接
        /// </summary>
        public void Open()
        {
            if (conn == null)
            {
                conn = factory.CreateConnection();
                conn.ConnectionString = ConnectionString;
                comm.Connection = conn;
            }
            if (conn.State == ConnectionState.Closed) { conn.Open(); }
        }

        /// <summary>
        /// 关闭数据库连接
        /// </summary>
        public void Close(bool dispose)
        {
            if ((dispose || comm.Transaction == null) && conn != null && conn.State != ConnectionState.Closed)
            {
                comm.Parameters.Clear();
                conn.Close();
                conn.Dispose();
                conn = null;
            }
        }

        /// <summary>
        /// 提交事务
        /// 如果未开启事务则会引发异常
        /// </summary>
        public void Commit()
        {
            if (comm.Transaction == null) { throw new Exception("未开启事务"); }
            comm.Transaction.Commit();
        }

        /// <summary>
        /// 注销
        /// </summary>
        public void Dispose()
        {
            this.Close(true);
        }

        /// <summary>
        /// 添加参数
        /// </summary>
        /// <param name="parameters">SqlParameterCollection的参数对像</param>
        /// <param name="parmsCollection">参数值</param>
        private DbParameterCollection AddParms(DbParameterCollection parmsCollection, DbParameter[] parameters)
        {
            parmsCollection.Clear();
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    DbParameter parms = (DbParameter)parameters[i];
                    parmsCollection.Add(parms);
                }
            }
            return parmsCollection;
        }

        /// <summary>
        /// 返回第一行第一列数据
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public object ExecuteScalar(CommandType cmdType, string cmdText, params DbParameter[] parameters)
        {
            try
            {
                Open();
                comm.CommandType = cmdType;
                comm.CommandText = cmdText;
                AddParms(comm.Parameters, parameters);

                return comm.ExecuteScalar();
            }
            finally { Close(false); }
        }

        /// <summary>
        /// 返回受影响的行数
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params DbParameter[] parameters)
        {
            try
            {
                Open();
                comm.CommandType = cmdType;
                comm.CommandText = cmdText;
                AddParms(comm.Parameters, parameters);

                return comm.ExecuteNonQuery();
            }
            finally { Close(false); }
        }

        /// <summary>
        /// 返回数据(IDataReader)
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public IDataReader GetReader(CommandType cmdType, string cmdText, params DbParameter[] parameters)
        {
            try
            {
                Open();
                comm.CommandType = cmdType;
                comm.CommandText = cmdText;
                AddParms(comm.Parameters, parameters);

                if (IsTransaction) { return comm.ExecuteReader(); }
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            finally { }// Close();
        }

        /// <summary>
        /// 返回数据(DataSet)
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public DataSet GetDataSet(CommandType cmdType, string cmdText, params DbParameter[] parameters)
        {
            try
            {
                Open();
                comm.CommandType = cmdType;
                comm.CommandText = cmdText;
                AddParms(comm.Parameters, parameters);
                DbDataAdapter ada = factory.CreateDataAdapter();
                ada.SelectCommand = comm;
                DataSet ds = new DataSet();
                ada.Fill(ds);
                return ds;

            }
            finally { Close(false); }
        }

        /// <summary>
        /// 返回数据(DataTable)
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public DataTable GetDataTable(CommandType cmdType, string cmdText, params DbParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            if (ds.Tables.Count == 0) { return new DataTable(); }
            return ds.Tables[0];
        }
    }

    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum DataBaseType
    {
        /// <summary>
        /// SqlServer数据库
        /// </summary>
        [Display(Name = "System.Data.SqlClient")]
        SqlServer,
        /// <summary>
        /// Access数据库
        /// </summary>
        [Display(Name = "System.Data.OleDb")]
        Access,
        /// <summary>
        /// MySql数据库
        /// </summary>
        [Display(Name = "MySql.Data.MySqlClient")]
        MySql,
        /// <summary>
        /// Excel表
        /// </summary>
        [Display(Name = "System.Data.OleDb")]
        Excel,
        /// <summary>
        /// Xml
        /// </summary>
        [Display(Name = "System.Linq.Xml")]
        Xml,
        /// <summary>
        /// SQLite
        /// </summary>
        [Display(Name = "System.Data.SQLite")]
        SQLite,
        /// <summary>
        /// Oracle
        /// </summary>
        [Display(Name = "System.Data.OracleClient")]
        Oracle,
    }

    /// <summary>
    /// 字段类型
    /// </summary>
    public enum FieldType
    {
        /// <summary>
        /// 整型
        /// </summary>
        [Display(Name = "Int")]
        Int,
        /// <summary>
        /// 布尔型
        /// </summary>
        [Display(Name = "Bit")]
        Bit,
        /// <summary>
        /// 可变字符串
        /// </summary>
        [Display(Name = "Varchar")]
        Varchar,
        /// <summary>
        /// 可变字符串（双字节）
        /// </summary>
        [Display(Name = "Nvarchar")]
        Nvarchar,
        /// <summary>
        /// 不可变字符串
        /// </summary>
        [Display(Name = "Char")]
        Char,
        /// <summary>
        /// 不可变字符串（双字节）
        /// </summary>
        [Display(Name = "NChar")]
        NChar,
        /// <summary>
        /// 不可变文本
        /// </summary>
        [Display(Name = "Text")]
        Text,
        /// <summary>
        /// 不可变文本
        /// </summary>
        [Display(Name = "Ntext")]
        Ntext,
        /// <summary>
        /// 日期
        /// </summary>
        [Display(Name = "DateTime")]
        DateTime,
        /// <summary>
        /// 短整型
        /// </summary>
        [Display(Name = "Smallint")]
        Smallint,
        /// <summary>
        /// 浮点
        /// </summary>
        [Display(Name = "Float")]
        Float,
    }
}
