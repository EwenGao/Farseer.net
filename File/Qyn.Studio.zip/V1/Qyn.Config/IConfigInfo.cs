﻿using System;
using System.Text;

namespace Qyn.IConfig
{
    /// <summary>
    /// 配置信息类接口
    /// </summary>
    public interface IConfigInfo
    {
    }
}
