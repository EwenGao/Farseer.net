﻿using System;

namespace Qyn.Config
{
	/// <summary>
	/// 网站基本设置描述类, 加[Serializable]标记为可序列化
	/// </summary>
	[Serializable]
    public class GeneralConfigInfo : Qyn.IConfig.IConfigInfo
    {
        #region 私有字段

		private string m_WebTitle = "网站后台管理(可通过config/General.config文件设置此标题)";                         //网站名称
		private string m_Icp = "";                              //网站备案信息
        private bool m_Closed = false;                          //网站关闭
        private string m_CloseDreason = "";                     //网站关闭提示信息


		private bool m_Regstatus = true;                        //是否允许新用户注册
        private string m_CensorUser = "admin";                  //用户名保留关键字,用|分开.
        private bool m_DoubleEmail = false;                     //允许同一 Email 注册不同用户
		private bool m_Regverify = false;                       //新用户注册验证,需要验证
        private string m_CensorEmail = "";                      //Email禁止地址,用|分开.
		private int m_Regctrl = 0;                              //IP 注册间隔限制(小时)
        private string m_IpRegctrl = "";                        //特殊 IP 注册限制,用|分开.
        private string m_IpDenyAccess = "";                     //IP禁止访问列表,用|分开.
        private string m_CookieDomain = "";                     //身份验证Cookie域
        private bool m_IsShowUserOnlineCount = true;            //是否显示在线用户人数
       
        private string m_Session_User_VerifyCode = "UserCode";   //用户登陆验证码的Session
        private string m_Session_Admin_VerifyCode = "AdminCode";      //管理员登陆验证码的Session

        private string m_Url_Web_Login = "";                    //用户登陆入口页面
        private string m_Url_Admin_Login = "login.aspx";        //管理员登陆入口页面

        private string m_AdminName = "Admin";            //超级管理员,只能一个(保证信息安全)

        #endregion

        #region 属性

		/// <summary>
		/// 网站名称
		/// </summary>
		public string WebTitle
		{
			get { return m_WebTitle;}
			set { m_WebTitle = value;}
		}

		/// <summary>
		/// 网站备案信息
		/// </summary>
		public string Icp
		{
			get { return m_Icp;}
			set { m_Icp = value;}
		}

		/// <summary>
        /// 网站关闭
		/// </summary>
		public bool Closed
		{
			get { return m_Closed;}
			set { m_Closed = value;}
		}

		/// <summary>
		/// 网站关闭提示信息
		/// </summary>
		public string CloseDreason
		{
			get { return m_CloseDreason;}
			set { m_CloseDreason = value;}
		}

		/// <summary>
		/// 是否允许新用户注册
		/// </summary>
		public bool Regstatus
		{
			get { return m_Regstatus;}
			set { m_Regstatus = value;}
		}

		/// <summary>
        /// 用户名保留关键字,用|分开.
		/// </summary>
		public string CensorUser
		{
			get { return m_CensorUser;}
			set { m_CensorUser = value;}
		}

		/// <summary>
        /// 允许同一 Email 注册不同用户,禁止
		/// </summary>
        public bool DoubleEmail
		{
			get { return m_DoubleEmail;}
            set { m_DoubleEmail = value; }
		}

		/// <summary>
        /// 新用户注册验证,需要验证
		/// </summary>
        public bool Regverify
		{
			get { return m_Regverify;}
			set { m_Regverify = value;}
		}

		/// <summary>
        /// Email禁止地址,用|分开.
		/// </summary>
		public string Censoremail
		{
			get { return m_CensorEmail;}
            set { m_CensorEmail = value; }
		}

		/// <summary>
		/// IP 注册间隔限制(小时)
		/// </summary>
		public int Regctrl
		{
			get { return m_Regctrl;}
			set { m_Regctrl = value;}
		}

		/// <summary>
        /// 特殊 IP 注册限制,用|分开.
		/// </summary>
		public string IpRegctrl
		{
			get { return m_IpRegctrl;}
			set { m_IpRegctrl = value;}
		}

		/// <summary>
        /// IP禁止访问列表,用|分开.
		/// </summary>
		public string IpDenyAccess
		{
            get { return m_IpDenyAccess; }
            set { m_IpDenyAccess = value; }
		}

		/// <summary>
		/// 身份验证Cookie域
		/// </summary>
		public string CookieDomain
		{
            get { return m_CookieDomain; }
            set { m_CookieDomain = value; }
		}

        /// <summary>
        /// 是否显示在线用户人数
        /// </summary>
        public bool IsShowUserOnlineCount
        {
            get { return m_IsShowUserOnlineCount; }
            set { m_IsShowUserOnlineCount = value; }
        }

        /// <summary>
        /// 用户登陆验证码的Session
        /// </summary>
        public string Session_User_VerifyCode
        {
            get { return m_Session_User_VerifyCode; }
            set { m_Session_User_VerifyCode = value; }
        }

        /// <summary>
        /// 管理员登陆验证码的Session
        /// </summary>
        public string Session_Admin_VerifyCode
        {
            get { return m_Session_Admin_VerifyCode; }
            set { m_Session_Admin_VerifyCode = value; }
        }

        /// <summary>
        /// 用户登陆入口页面
        /// </summary>
        public string Url_Web_Login
        {
            get { return m_Url_Web_Login; }
            set { m_Url_Web_Login = value; }
        }

        /// <summary>
        /// 管理员登陆入口页面
        /// </summary>
        public string Url_Admin_Login
        {
            get { return m_Url_Admin_Login; }
            set { m_Url_Admin_Login = value; }
        }

        /// <summary>
        /// 超级管理员，只有该管理员才可修改其它管理员资料 ,用|分开
        /// </summary>
        public string AdminName
        {
            get { return m_AdminName; }
            set { m_AdminName = value; }
        }
        #endregion
    }
}
