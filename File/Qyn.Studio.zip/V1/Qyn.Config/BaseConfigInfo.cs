﻿using System;

namespace Qyn.Config
{
    /// <summary>
    /// 基本设置描述类, 加[Serializable]标记为可序列化
    /// </summary>
    [Serializable]
    public class BaseConfigInfo :Qyn.IConfig.IConfigInfo
    {
        #region 私有字段

        /// <summary>
        /// 数据库连接串
        /// </summary>
        private string m_DbConnectString = "Data Source=.;User ID=sa;Password=123456;Initial Catalog=qyn;Pooling=true";
        /// <summary>
        /// 数据库类型
        /// </summary>
        private string m_DbType = "SqlServer";
        /// <summary>
        /// 网站路径
        /// </summary>
        private string m_WebPath = "/wwwroot/";
        /// <summary>
        /// 是否调试
        /// </summary>
        private bool m_DeBug = false;

        /// <summary>
        /// 数据库版本
        /// </summary>
        private string m_DbVer = "2005";

        /// <summary>
        /// 数据库表前缀
        /// </summary>
        private string m_Tableprefix = "";

        /// <summary>
        /// 前台模板名称
        /// </summary>
        private string m_WebTemplates = "Default";

        /// <summary>
        /// 前台页面伪aspx后缀名
        /// </summary>
        private string m_WebPageExtension = ".qyn";

        /// <summary>
        /// 后台模板名称
        /// </summary>
        private string m_AdminTemplates = "Default";

        /// <summary>
        /// 后台页面伪aspx后缀名
        /// </summary>
        private string m_AdminPageExtension = ".qynx";


        #endregion

        #region 属性

        /// <summary>
        /// 数据库连接串
        /// </summary>
        public string DbConnectString
        {
            get { return m_DbConnectString; }
            set { m_DbConnectString = value; }
        }

        /// <summary>
        /// 数据库类型
        /// </summary>
        public string DbType
        {
            get { return m_DbType; }
            set { m_DbType = value; }
        }

        /// <summary>
        /// 网站路径
        /// </summary>
        public string WebPath
        {
            get { return m_WebPath; }
            set { m_WebPath = value; }
        }

        /// <summary>
        /// 是否调试
        /// </summary>
        public bool DeBug
        {
            get { return m_DeBug; }
            set { m_DeBug = value; }
        }

        /// <summary>
        /// 数据库版本
        /// </summary>
        public string DbVer
        {
            get { return m_DbVer; }
            set { m_DbVer = value; }
        }

        /// <summary>
        /// 数据库表前缀
        /// </summary>
        public string Tableprefix
        {
            get { return m_Tableprefix; }
            set { m_Tableprefix = value; }
        }

        /// <summary>
        /// 前台模板名称
        /// </summary>
        public string WebTemplates
        {
            get { return m_WebTemplates; }
            set { m_WebTemplates = value; }
        }

        /// <summary>
        /// 前台页面伪aspx后缀名
        /// </summary>
        public string WebPageExtension
        {
            get { return m_WebPageExtension; }
            set { m_WebPageExtension = value; }
        }

        /// <summary>
        /// 后台模板名称
        /// </summary>
        public string AdminTemplates
        {
            get { return m_AdminTemplates; }
            set { m_AdminTemplates = value; }
        }

        /// <summary>
        /// 后台页面伪aspx后缀名
        /// </summary>
        public string AdminPageExtension
        {
            get { return m_AdminPageExtension; }
            set { m_AdminPageExtension = value; }
        }
        #endregion
    }
}
