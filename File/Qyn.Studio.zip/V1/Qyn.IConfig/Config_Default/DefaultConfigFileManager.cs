﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Text;

namespace Qyn.IConfig
{

    /// <summary>
    /// 文件配置管理基类
    /// </summary>
    public class DefaultConfigFileManager
    {
        #region fields   字段
        /// <summary>文件所在路径变量
        /// </summary>
        private static string m_configfilepath;

        /// <summary>临时配置对象变量
        /// </summary>
        private static IConfigInfo m_configinfo = null;

        /// <summary>锁对象
        /// </summary>
        private static object m_lockHelper = new object();

        #endregion

        #region 属性

        #region public static string ConfigFilePath   Config文件所在路径
        /// <summary>
        /// 文件所在路径
        /// </summary>
        public static string ConfigFilePath
        {
            get { return m_configfilepath; }
            set { m_configfilepath = value; }
        }

        #endregion

        #region public static IConfigInfo ConfigInfo   临时配置对象
        /// <summary>临时配置对象
        /// </summary>
        public static IConfigInfo ConfigInfo
        {
            get { return m_configinfo; }
            set { m_configinfo = value; }
        }
        #endregion

        #endregion

        #region 方法

            #region protected static IConfigInfo LoadConfig(ref DateTime fileoldchange, string configFilePath, IConfigInfo configinfo)   加载(反序列化)指定对象类型的配置对象
            /// <summary>
            /// 加载(反序列化)指定对象类型的配置对象
            /// </summary>
            /// <param name="fileoldchange">文件加载时间</param>
            /// <param name="configFilePath">配置文件所在路径</param>
            /// <param name="configinfo">相应的变量 注:该参数主要用于设置m_configinfo变量 和 获取类型.GetType()</param>
            /// <returns></returns>
            protected static IConfigInfo LoadConfig(ref DateTime fileoldchange, string configFilePath, IConfigInfo configinfo)
            {
                return LoadConfig(ref fileoldchange, configFilePath, configinfo, true);
            }
            #endregion

            #region protected static IConfigInfo LoadConfig(ref DateTime fileoldchange, string configFilePath, IConfigInfo configinfo, bool checkTime)   加载(反序列化)指定对象类型的配置对象

            /// <summary>
            /// 加载(反序列化)指定对象类型的配置对象
            /// </summary>
            /// <param name="fileoldchange">文件加载时间</param>
            /// <param name="configFilePath">配置文件所在路径(包括文件名)</param>
            /// <param name="configinfo">相应的变量 注:该参数主要用于设置m_configinfo变量 和 获取类型.GetType()</param>
            /// <param name="checkTime">是否检查并更新传递进来的"文件加载时间"变量</param>
            /// <returns></returns>
            protected static IConfigInfo LoadConfig(ref DateTime fileoldchange, string configFilePath, IConfigInfo configinfo, bool checkTime)
            {
                m_configfilepath = configFilePath;                  //保存Config文件路径
                m_configinfo = configinfo;                          //保存临时配置对像变量

                if (checkTime)                                      //是否检查并更新传递进来的"文件加载时间"变量
                {
                    DateTime m_filenewchange = System.IO.File.GetLastWriteTime(configFilePath);             //保存文件最后修改的时间

                    //当程序运行中config文件发生变化时则对config重新赋值
                    if (fileoldchange != m_filenewchange)                                                   //如果保存的修改时间与上一次修改时间不致,表明此文件已更改过
                    {
                        fileoldchange = m_filenewchange;                                                    //重新获取时间值.
                        lock (m_lockHelper)
                        {
                            m_configinfo = DeserializeInfo(configFilePath, configinfo.GetType());           //反序列化(加载)Config文件
                        }
                    }
                }
                else                                                                                        //不保存时间,时间重读加载
                {
                    lock (m_lockHelper)
                    {
                        m_configinfo = DeserializeInfo(configFilePath, configinfo.GetType());               //反序列化(加载)Config文件
                    }
                    
                }
            

                return m_configinfo;
            }

            #endregion

            #region public static IConfigInfo DeserializeInfo(string configfilepath, Type configtype)   反序列化指定的类
            /// <summary>
            /// 反序列化指定的类
            /// </summary>
            /// <param name="configfilepath">config 文件的路径</param>
            /// <param name="configtype">相应的类型</param>
            /// <returns></returns>
            public static IConfigInfo DeserializeInfo(string configfilepath, Type configtype)
            {

                IConfigInfo iconfiginfo;
                FileStream fs = null;
                try
                {
                    fs = new FileStream(configfilepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    XmlSerializer serializer = new XmlSerializer(configtype);
                    iconfiginfo = (IConfigInfo)serializer.Deserialize(fs);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }

                return iconfiginfo;
            }
            #endregion

            #region public virtual bool SaveConfig()   保存配置实例(虚方法需继承)
            /// <summary>
            /// 保存配置实例(虚方法需继承)
            /// </summary>
            /// <returns></returns>
            public virtual bool SaveConfig()
            {
                return true;
            }
            #endregion

            #region public bool SaveConfig(string configFilePath, IConfigInfo configinfo)   保存(序列化)指定路径下的配置文件
            /// <summary>
            /// 保存(序列化)指定路径下的配置文件
            /// </summary>
            /// <param name="configFilePath">指定的配置文件所在的路径(包括文件名)</param>
            /// <param name="configinfo">被保存(序列化)的对象</param>
            /// <returns></returns>
            public bool SaveConfig(string configFilePath, IConfigInfo configinfo)
            {
                configFilePath = configFilePath.Replace("\\","/");
                Qyn.Common.Utils.ParseFile.CreateDirs(configFilePath.Substring(0, configFilePath.LastIndexOf("/")));
                bool succeed = false;
                FileStream fs = null;
                try
                {
                    fs = new FileStream(configFilePath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
                    XmlSerializer serializer = new XmlSerializer(configinfo.GetType());
                    serializer.Serialize(fs, configinfo);
                    //成功则将会返回true
                    succeed = true;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (fs != null)
                    {
                        fs.Close();
                    }
                }

                return succeed;
            }
            #endregion

        #endregion
    }
}
