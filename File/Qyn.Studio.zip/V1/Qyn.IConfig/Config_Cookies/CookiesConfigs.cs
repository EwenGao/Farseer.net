﻿using System;
using System.Data;
using System.Data.Common;
using System.Text.RegularExpressions;

using Qyn.Common;
using Qyn.Config;

namespace Qyn.IConfig
{
    /// <summary>
    /// 网站基本设置类
    /// </summary>
    public class CookiesConfigs
    {
        private static object lockHelper = new object();

        private static System.Timers.Timer CookiesConfigTimer;

        private static CookiesConfigInfo m_configinfo;

        /// <summary>
        /// 静态构造函数初始化相应实例和定时器 24小时
        /// </summary>
        static CookiesConfigs()
        {
            CookiesConfigTimer = new System.Timers.Timer(86400000);
            m_configinfo = CookiesConfigFileManager.LoadConfig();
            CookiesConfigTimer.AutoReset = true;
            CookiesConfigTimer.Enabled = true;
            CookiesConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);
            CookiesConfigTimer.Start();
        }

        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }


        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            CookiesConfigFileManager.filename = null;
            m_configinfo = CookiesConfigFileManager.LoadConfig();
        }

        public static CookiesConfigInfo GetConfig()
        {
            return m_configinfo;
        }

        #region public static double BaseConfigTimer   获取或设置刷新的频率
        /// <summary>
        /// 获取或设置刷新的频率
        /// </summary>
        public static double BaseConfigTimer
        {
            get { return CookiesConfigTimer.Interval; }
            set { CookiesConfigTimer.Interval = value; }
        }
        #endregion

        #region public static bool SaveConfig(BaseConfigInfo baseconfiginfo)   保存配置实例

        /// <summary>
        /// 保存配置实例
        /// </summary>
        /// <param name="baseconfiginfo"></param>
        /// <returns></returns>
        public static bool SaveConfig(CookiesConfigInfo CookiesConfigInfo)
        {
            CookiesConfigFileManager acfm = new CookiesConfigFileManager();
            CookiesConfigFileManager.ConfigInfo = CookiesConfigInfo;
            return acfm.SaveConfig();
        }
        #endregion


        #region Helper

        /// <summary>
        /// 序列化配置信息为XML
        /// </summary>
        /// <param name="configinfo">配置信息</param>
        /// <param name="configFilePath">配置文件完整路径</param>
        public static CookiesConfigInfo Serialiaze(CookiesConfigInfo configinfo, string configFilePath)
        {
            lock (lockHelper)
            {
                SerializationHelper.Save(configinfo, configFilePath);
            }
            return configinfo;
        }


        public static CookiesConfigInfo Deserialize(string configFilePath)
        {
            return (CookiesConfigInfo)SerializationHelper.Load(typeof(CookiesConfigInfo), configFilePath);
        }

        #endregion

    }
}
