﻿using System;
using System.Text;
using System.Web;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

using Qyn.Common;
using Qyn.Config;

namespace Qyn.IConfig
{
    /// <summary>
    /// 网站基本设置管理类
    /// </summary>
    class CookiesConfigFileManager : Qyn.IConfig.DefaultConfigFileManager
    {
        private static CookiesConfigInfo m_configinfo;


        /// <summary>
        /// 文件修改时间
        /// </summary>
        private static DateTime m_fileoldchange;


        /// <summary>
        /// 初始化文件修改时间和对象实例
        /// </summary>
        static CookiesConfigFileManager()
        {
            m_fileoldchange = System.IO.File.GetLastWriteTime(ConfigFilePath);

            try
            {
                m_configinfo = (CookiesConfigInfo)DefaultConfigFileManager.DeserializeInfo(ConfigFilePath, typeof(CookiesConfigInfo));
            }
            catch
            {
                if (File.Exists(ConfigFilePath))
                {
                    m_configinfo = (CookiesConfigInfo)DefaultConfigFileManager.DeserializeInfo(ConfigFilePath, typeof(CookiesConfigInfo));
                }
            }
        }


        /// <summary>
        /// 当前配置类的实例
        /// </summary>
        public new static IConfigInfo ConfigInfo
        {
            get { return m_configinfo; }
            set { m_configinfo = (CookiesConfigInfo)value; }
        }

        /// <summary>
        /// 配置文件所在路径
        /// </summary>
        public static string filename = null;


        /// <summary>
        /// 获取配置文件所在路径
        /// </summary>
        public new static string ConfigFilePath
        {
            get
            {
                if (filename == null)
                {
                    HttpContext context = HttpContext.Current;
                    if (context != null)
                    {
                        filename = context.Server.MapPath("~/config/Cookies.config");
                    }
                    else
                    {
                        filename = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config/Cookies.config");
                    }
                    filename = filename.Replace("/", "\\");
                }

                if (!File.Exists(filename))
                {
                    DefaultConfigFileManager __DefaultConfigFileManager = new DefaultConfigFileManager();
                    CookiesConfigInfo __CookiesConfigInfo = new CookiesConfigInfo();
                    __DefaultConfigFileManager.SaveConfig(filename, __CookiesConfigInfo);
                    //string errorMessage = "根目录下的config文件夹里没有正确的Cookies.config文件,现在已重新创建了此文件，\r\n创建路径为：" + filename;
                    //HttpContext context = HttpContext.Current;
                    //if (context != null)
                    //{
                    //    new Qyn.Common.Terminator().Throw(errorMessage);
                    //}
                    //else
                    //{
                    //    System.Windows.Forms.MessageBox.Show(errorMessage, "发生错误");
                    //}
                }
                return filename;
            }
        }

        /// <summary>
        /// 返回配置类实例
        /// </summary>
        /// <returns></returns>
        public static CookiesConfigInfo LoadConfig()
        {

            try
            {
                ConfigInfo = DefaultConfigFileManager.LoadConfig(ref m_fileoldchange, ConfigFilePath, ConfigInfo, true);
            }
            catch
            {
                ConfigInfo = DefaultConfigFileManager.LoadConfig(ref m_fileoldchange, ConfigFilePath, ConfigInfo, true);
            }
            return ConfigInfo as CookiesConfigInfo;
        }

        /// <summary>
        /// 保存配置类实例
        /// </summary>
        /// <returns></returns>
        public override bool SaveConfig()
        {
            return base.SaveConfig(ConfigFilePath, ConfigInfo);
        }

    }
}

