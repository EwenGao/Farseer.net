﻿using System;
using System.Data;
using System.Data.Common;
using System.Text.RegularExpressions;

using Qyn.Common;
using Qyn.Config;

namespace Qyn.IConfig
{
    /// <summary>
    /// 网站基本设置类
    /// </summary>
    public class EmailConfigs
    {
        private static object lockHelper = new object();

        private static System.Timers.Timer EmailConfigTimer;

        private static EmailConfigInfo m_configinfo;

        /// <summary>
        /// 静态构造函数初始化相应实例和定时器 24小时
        /// </summary>
        static EmailConfigs()
        {
            EmailConfigTimer = new System.Timers.Timer(86400000);
            m_configinfo = EmailConfigFileManager.LoadConfig();
            EmailConfigTimer.AutoReset = true;
            EmailConfigTimer.Enabled = true;
            EmailConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);
            EmailConfigTimer.Start();
        }

        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }


        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            EmailConfigFileManager.filename = null;
            m_configinfo = EmailConfigFileManager.LoadConfig();
        }

        public static EmailConfigInfo GetConfig()
        {
            return m_configinfo;
        }

        #region public static double BaseConfigTimer   获取或设置刷新的频率
        /// <summary>
        /// 获取或设置刷新的频率
        /// </summary>
        public static double BaseConfigTimer
        {
            get { return EmailConfigTimer.Interval; }
            set { EmailConfigTimer.Interval = value; }
        }
        #endregion

        #region public static bool SaveConfig(BaseConfigInfo baseconfiginfo)   保存配置实例

        /// <summary>
        /// 保存配置实例
        /// </summary>
        /// <param name="baseconfiginfo"></param>
        /// <returns></returns>
        public static bool SaveConfig(EmailConfigInfo EmailConfigInfo)
        {
            EmailConfigFileManager ecfm = new EmailConfigFileManager();
            EmailConfigFileManager.ConfigInfo = EmailConfigInfo;
            return ecfm.SaveConfig();
        }
        #endregion


        #region Helper

        /// <summary>
        /// 序列化配置信息为XML
        /// </summary>
        /// <param name="configinfo">配置信息</param>
        /// <param name="configFilePath">配置文件完整路径</param>
        public static EmailConfigInfo Serialiaze(EmailConfigInfo configinfo, string configFilePath)
        {
            lock (lockHelper)
            {
                SerializationHelper.Save(configinfo, configFilePath);
            }
            return configinfo;
        }


        public static EmailConfigInfo Deserialize(string configFilePath)
        {
            return (EmailConfigInfo)SerializationHelper.Load(typeof(EmailConfigInfo), configFilePath);
        }

        #endregion

    }
}
