﻿using System;
using Qyn.Config;

namespace Qyn.IConfig
{
    /// <summary>
    /// 基本设置类
    /// </summary>
    public class BaseConfigs
    {
        #region Fields   字段

        /// <summary>锁定
        /// </summary>
        private static object lockHelper = new object();

        /// <summary> 每60秒判断一次
        /// </summary>
        private static System.Timers.Timer baseConfigTimer = new System.Timers.Timer(60000);

        /// <summary>配置变量
        /// </summary>
        private static BaseConfigInfo m_configinfo;

        #endregion

        #region static BaseConfigs()   静态构造函数初始化相应实例和定时器
        /// <summary>
        /// 静态构造函数初始化相应实例和定时器
        /// </summary>
        static BaseConfigs()
        {
            m_configinfo = BaseConfigFileManager.LoadConfig();
            baseConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);            //委托Timer_Elapsed事件								                                            //读取Config文件.
            AutoResetOpen(true, 60);
        }
        #endregion

        #region 属性

        #region public static string GetDBConnectString   返回数据库连接串

        /// <summary>
        /// 返回数据库连接串
        /// </summary>
        public static string DBConnectString
        {
            get
            {
                return GetBaseConfig().DbConnectString;
            }
        }

        /// <summary>
        /// 数据库类型
        /// </summary>
        public static string DbType
        {
            get
            {
                return GetBaseConfig().DbType;
            }
        }

        /// <summary>
        /// 网站路径
        /// </summary>
        public static string WebPath
        {
            get
            {
                return GetBaseConfig().WebPath;
            }
        }

        /// <summary>
        /// 是否调试
        /// </summary>
        public static bool DeBug
        {
            get
            {
                return GetBaseConfig().DeBug;
            }
        }

        /// <summary>
        /// 数据库版本
        /// </summary>
        public static string DbVer
        {
            get
            {
                return GetBaseConfig().DbVer;
            }
        }

        /// <summary>
        /// 数据库表前缀
        /// </summary>
        public static string Tableprefix
        {
            get
            {
                return GetBaseConfig().Tableprefix;
            }
        }

        #endregion

        /// <summary>
        /// 前台模板名称
        /// </summary>
        public static string WebTemplates
        {
            get 
            {
                return GetBaseConfig().WebTemplates;
            }
        }

        /// <summary>
        /// 前台页面伪aspx后缀名
        /// </summary>
        public static string WebPageExtension
        {
            get 
            { 
                return GetBaseConfig().WebPageExtension; 
            }
        }
        /// <summary>
        /// 后台模板名称
        /// </summary>
        public static string AdminTemplates
        {
            get
            {
                return GetBaseConfig().AdminTemplates;
            }
        }

        /// <summary>
        /// 后台页面伪aspx后缀名
        /// </summary>
        public static string AdminPageExtension
        {
            get
            {
                return GetBaseConfig().AdminPageExtension;
            }
        }
        #endregion

        #region 方法

        #region private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)   Timer_Elapsed事件
        /// <summary>
        /// Timer_Elapsed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }

        #endregion

        #region public static void ResetConfig()   重设配置类实例
        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            BaseConfigFileManager.filename = null;
            m_configinfo = BaseConfigFileManager.LoadRealConfig();
        }
        #endregion

        #region public static BaseConfigInfo GetBaseConfig()   获取BaseConfigInfo类配置
        /// <summary>
        /// 获取BaseConfigInfo类配置
        /// </summary>
        /// <returns></returns>
        public static BaseConfigInfo GetBaseConfig()
        {
            return m_configinfo;
        }
        #endregion

        #region public static bool SaveConfig(BaseConfigInfo baseconfiginfo)   保存配置实例

        /// <summary>
        /// 保存配置实例
        /// </summary>
        /// <param name="baseconfiginfo"></param>
        /// <returns></returns>
        public static bool SaveConfig(BaseConfigInfo baseconfiginfo)
        {
            BaseConfigFileManager acfm = new BaseConfigFileManager();
            BaseConfigFileManager.ConfigInfo = baseconfiginfo;
            return acfm.SaveConfig();
        }
        #endregion


        /// <summary>
        /// 开启自动检测Config
        /// </summary>
        /// <param name="isOpen">true：开启,false:关闭</param>
        /// <param name="time"></param>
        public static void AutoResetOpen(bool isOpen, double time)
        {
            time = time * 1000;
            if (isOpen)
            {
                baseConfigTimer = new System.Timers.Timer(time);
                baseConfigTimer.AutoReset = true;                                                           //连续运行Time
                baseConfigTimer.Enabled = true;                                                             //激活事件
                baseConfigTimer.Start();
            }
            else
            {
                baseConfigTimer.AutoReset = false;
                baseConfigTimer.Enabled = false;
                baseConfigTimer.Close();
            }
        }

        #endregion

    }
}
