﻿using System;
using System.Text;
using System.Web;
using System.IO;

using Qyn.Common;
using Qyn.Config;

namespace Qyn.IConfig
{

    /// <summary>
    /// 基本设置信息管理类
    /// </summary>
    class BaseConfigFileManager : DefaultConfigFileManager
    {
        #region Fields   字段
        /// <summary>临时配置类型
        /// </summary>
        private static BaseConfigInfo m_configinfo;

        /// <summary> 锁对象
        /// </summary>
        private static object m_lockHelper = new object();

        /// <summary>文件修改时间
        /// </summary>
        private static DateTime m_fileoldchange;

        /// <summary>配置文件所在路径
        /// </summary>
        public static string filename = null;

        #endregion

        #region static BaseConfigFileManager()   初始化文件修改时间和对象实例(构造函数)


        /// <summary>
        /// 初始化文件修改时间和对象实例
        /// </summary>
        static BaseConfigFileManager()
        {
            m_fileoldchange = System.IO.File.GetLastWriteTime(ConfigFilePath);
            m_configinfo = (BaseConfigInfo)DefaultConfigFileManager.DeserializeInfo(ConfigFilePath, typeof(BaseConfigInfo));
        }
        #endregion

        #region 属性

        #region public new static IConfigInfo ConfigInfo   当前配置类的实例
        /// <summary>
        /// 当前配置类的实例(因为要加载BaseConfigInfo这个类,所以重写此属性.在原基础Set上,加个转换类型.)
        /// </summary>
        public new static IConfigInfo ConfigInfo
        {
            get { return m_configinfo; }
            set { m_configinfo = (BaseConfigInfo)value; }
        }

        #endregion

        #region public new static string ConfigFilePath   获取配置文件所在路径
        /// <summary>
        /// 获取配置文件所在路径
        /// </summary>
        public new static string ConfigFilePath
        {
            get
            {
                if (filename == null)
                {
                    HttpContext context = HttpContext.Current;
                    if (context != null)
                    {
                        filename = context.Server.MapPath("~/config/qyn.config");
                    }
                    else
                    {
                        filename = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config/qyn.config");
                    }
                    filename = filename.Replace("/", "\\");
                }
                if (!File.Exists(filename))
                {
                    DefaultConfigFileManager __DefaultConfigFileManager = new DefaultConfigFileManager();
                    BaseConfigInfo __BaseConfigInfo = new BaseConfigInfo();
                    __DefaultConfigFileManager.SaveConfig(filename, __BaseConfigInfo);
                    //string errorMessage = "根目录下的config文件夹里没有正确的qyn.config文件,现在已重新创建了此文件，\r\n创建路径为：" + filename;
                    //HttpContext context = HttpContext.Current;
                    //if (context != null)
                    //{
                    //    new Qyn.Common.Terminator().Throw(errorMessage);
                    //}
                    //else
                    //{
                    //    System.Windows.Forms.MessageBox.Show(errorMessage, "发生错误");
                    //}
                }
                return filename;
            }
        }
        #endregion
        #endregion

        #region 方法

        

        #region public static BaseConfigInfo LoadConfig()   加载配置类
        /// <summary>
        /// 加载配置类
        /// </summary>
        /// <returns></returns>
        public static BaseConfigInfo LoadConfig()
        {
            ConfigInfo = DefaultConfigFileManager.LoadConfig(ref m_fileoldchange, ConfigFilePath, ConfigInfo);
            return ConfigInfo as BaseConfigInfo;
        }
        #endregion

        #region public static BaseConfigInfo LoadRealConfig()   加载真正有效的配置类(直接加载,不更新时间)
        /// <summary>
        /// 加载真正有效的配置类(直接加载,不更新时间)
        /// </summary>
        /// <returns></returns>
        public static BaseConfigInfo LoadRealConfig()
        {
            ConfigInfo = DefaultConfigFileManager.LoadConfig(ref m_fileoldchange, ConfigFilePath, ConfigInfo, false);
            return ConfigInfo as BaseConfigInfo;
        }
        #endregion

        #region public override bool SaveConfig()   保存配置
        /// <summary>
        /// 保存配置
        /// </summary>
        /// <returns></returns>
        public override bool SaveConfig()
        {
            return base.SaveConfig(ConfigFilePath, ConfigInfo);
        }
        #endregion

        #endregion
    }
}
