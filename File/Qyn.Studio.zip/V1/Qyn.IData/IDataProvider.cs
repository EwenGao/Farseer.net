﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using System.Data.Common;

namespace Qyn.IData
{
    /// <summary>
    /// 所有Sql语言操作接口
	/// <para>IDataReader:返回一行信息</para>
	/// <para>DataTable:返回一个表</para>
	/// <para>string:返回一个字符串信息</para>
    /// </summary>
    public partial interface IDataProvider
    {

    }
}
