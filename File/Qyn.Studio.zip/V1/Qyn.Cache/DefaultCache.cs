﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Qyn.Cache
{
    public class DefaultCache
    {
        System.Web.Caching.Cache webCache=System.Web.HttpRuntime.Cache;

        public int m_TimeOut=1440;//默认缓存存活期为1440分钟(24小时)

        /// <summary>
        /// 设置到期相对时间[单位：／分钟] 
        /// </summary>
        public int TimeOut
        {
            set { m_TimeOut = value > 0 ? value : 6000; }
            get { return m_TimeOut > 0 ? m_TimeOut : 6000; }
        }

        /// <summary>
        /// 添加对像到缓存
        /// </summary>
        /// <param name="key">缓存对像ID</param>
        /// <param name="o">缓存对像</param>
        public void AddObject(string key, object o)
        {
            if (key != null && key.Length > 0 && o != null)
            {
                webCache.Insert(key, o, null,DateTime.Now.AddMinutes( TimeOut), System.Web.Caching.Cache.NoSlidingExpiration);
            }
        }

        /// <summary>
        /// 删除缓存对象
        /// </summary>
        /// <param name="objId">对象的关键字</param>
        public void RemoveObject(string key)
        {
            if (key == null || key.Length == 0)
            {
                return;
            }
            webCache.Remove(key);
        }


        /// <summary>
        /// 返回一个指定的对象
        /// </summary>
        /// <param name="objId">对象的关键字</param>
        /// <returns>对象</returns>
        public object RetrieveObject(string key)
        {

            if (key == null || key.Length == 0)
            {
                return null;
            }

            return webCache.Get(key);
        }
    }
}
