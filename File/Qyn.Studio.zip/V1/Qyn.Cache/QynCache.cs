﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

using System.Data;

namespace Qyn.Cache
{
    public class QynCache
    {
        private static DefaultCache cache;

        static QynCache()
        {
            cache = new DefaultCache();
        }

        /// <summary>
        /// 添加对像(字符串)
        /// </summary>
        /// <param name="key"></param>
        /// <param name="str"></param>
        public static void AddString(string key, string str)
        {
            cache.AddObject(key, (object)str);
        }

        /// <summary>
        /// 返回对像(字符串)
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static string GetString(string key)
        {
            if (key != null && key.Length > 0)
            {
                return (string)cache.RetrieveObject(key);
            }
            return null;
        }

        /// <summary>
        /// 添加对像(DataTable)
        /// </summary>
        /// <param name="key"></param>
        /// <param name="str"></param>
        public static void AddDataTable(string key, DataTable dt)
        {
            cache.AddObject(key, (object)dt);
        }

        /// <summary>
        /// 返回对像(DataTable)
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(string key)
        {
            if (key != null && key.Length > 0)
            {
                return (DataTable)cache.RetrieveObject(key);
            }
            return null;
        }

        /// <summary>
        /// 删除对像
        /// </summary>
        /// <param name="key"></param>
        public static void Clear(string key)
        {
            cache.RemoveObject(key);
        }
    }
}
