﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;

using Qyn.Data;
using Qyn.IData;

namespace Qyn.Data.Access
{
	public partial class DataProvider : IDataProvider
	{
		//在Qyn.Data.Access类库里的所有类文件都是在同一个public  class DataProvider类里．
		//用partial　关键字将它们分开来，只是为了方便我们进行管理．

		//******************************************************************************

		//这个类里面的所有方法都是继承于IDataProvider接口．
		//这里只是处理Sql语句．最终调用Qyn.Data.DbHelper类的方法，执行Sql语句．

	}
}
