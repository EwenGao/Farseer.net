﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;

using Qyn.Data;

namespace Qyn.Data
{
    public class AccessProvider : Qyn.Data.IDbProvider
    {
        public DbProviderFactory Instance()
        {
            return OleDbFactory.Instance;
        }

        public DbParameter MakeParam(string ParamName, DbType DbType, Int32 Size)
        {
            OleDbParameter param;
            if (Size > 0)
            {
                param = new OleDbParameter(ParamName, (OleDbType)DbType, Size);
            }
            else
            {
                param = new OleDbParameter(ParamName, (OleDbType)DbType);
            }
            return param;
        }
    }
}
