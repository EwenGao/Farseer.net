using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data;

using Qyn.Data;
using Qyn.IData;

namespace Qyn.Data.SqlServer
{
    public partial class DataProvider : IDataProvider
    {

    }
}
