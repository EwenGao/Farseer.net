﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Error
{
    public class ErrorMessage
    {
        public static string GetMessage(int errorId)
        {
            switch (errorId)
            {
                case 0:
                    return "无法连接数据库";
                case 20:
                    return "添加成功";
                case 21:
                    return "保存成功";
                case 22:
                    return "添加失败";
                case 23:
                    return "保存失败";
                case 24:
                    return "是否不保存，退出？";
                default:
                    return "未知错误";
            }
        }
    }
}
