﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

using Qyn.Common.Utils;
using Qyn.Common;
using Qyn.Config;
using Qyn.IConfig;
using System.IO;

namespace Qyn.Web.UI
{
    public class AdminBasePage : System.Web.UI.Page
    {   
        /// <summary>
        /// 当前管理员ID
        /// </summary>
        protected internal int adminId = -1;

        /// <summary>
        /// 当前管理员名
        /// </summary>
        protected internal string adminName = "";

        /// <summary>
        /// 权限, -1:未登陆,0:超级管理员,1:普通管理员,2:推广员
        /// </summary>
        protected internal int adminPurview = -1;

        /// <summary>
        /// 页面标题
        /// </summary>
        protected internal string webTitle = GeneralConfigs.GetConfig().WebTitle;

        /// <summary>
        /// 登陆入口页面
        /// </summary>
        protected internal string loginUrl = Path.Combine(BaseConfigs.GetBaseConfig().WebPath, GeneralConfigs.GetConfig().Url_Admin_Login);

        /// <summary>
        /// 判断登陆状态
        /// </summary>
        public bool IsLogin()
        {
            if (BaseConfigs.GetBaseConfig().DeBug)
            {
                adminId = 3;
                adminName = GeneralConfigs.GetConfig().AdminName;
                adminName = "admin";
                adminPurview = 1;
                return true;
            }
            else if (adminId != -1 && adminName.Length != 0 && adminPurview > -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 获取Session管理员信息
        /// </summary>
        private void GetAdminStatus()
        {
            //adminId = ParseCookies.GetCookie(GeneralConfigs.GetConfig().Cookies_Admin_Id,-1);
            //adminName = ParseCookies.GetCookie(GeneralConfigs.GetConfig().Cookies_Admin_Name);
            //adminPurview = ParseCookies.GetCookie(GeneralConfigs.GetConfig().Cookies_Admin_Purview, -1);
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        public AdminBasePage()
        {
            //if (BaseConfigs.GetBaseConfig().DeBug)
            //{
            //    Qyn.Config.GeneralConfigs.SaveConfig(new GeneralConfigInfo());
            //    GeneralConfigs.ResetConfig();
            //    Qyn.Config.BaseConfigs.SaveConfig(new BaseConfigInfo());
            //    BaseConfigs.ResetConfig();
            //}

            //获取管理权限
            GetAdminStatus();

            //登陆页面时,不检测登陆状态!
            if (QynRequest.GetPageName().ToLower() != GeneralConfigs.GetConfig().Url_Admin_Login.ToLower())
            {
                if (!IsLogin())
                {
                    new Terminator().Throw("방문", "잘못된", "돌아가기 방문," + loginUrl);
                    return;
                }
            }
            else
            {
                if (IsLogin())
                {
                    System.Web.HttpContext.Current.Response.Redirect("index.aspx");
                    return;
                }
            }
        }
    }
}
