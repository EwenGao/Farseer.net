using System;
using System.Text;

//namespace Qyn.Common.Xml
//{
//    public class InvalidXmlException : DNTException
//    {
//        public InvalidXmlException(string message)
//            : base(message)
//        {
//        }
//    }
//}
