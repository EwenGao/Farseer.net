﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Text.RegularExpressions;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 判断类型
    /// </summary>
    public class ParseIsType
    {
        /// <summary>
        /// 判断是否为时间
        /// </summary>
        /// <returns></returns>
        public static bool IsTime(string timeval)
        {
            return Regex.IsMatch(timeval, @"^((([0-1]?[0-9])|(2[0-3])):([0-5]?[0-9])(:[0-5]?[0-9])?)$");
        }

        /// <summary>
        /// 判断字符串是否是yy-mm-dd字符串
        /// </summary>
        /// <param name="str">待判断字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsDate(string str)
        {
            return Regex.IsMatch(str, @"(\d{4})-(\d{1,2})-(\d{1,2})");
        }

        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip">Ip</param>
        /// <returns></returns>
        public static bool IsIP(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");

        }

        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip">Ip</param>
        /// <returns></returns>
        public static bool IsIPSect(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){2}((2[0-4]\d|25[0-5]|[01]?\d\d?|\*)\.)(2[0-4]\d|25[0-5]|[01]?\d\d?|\*)$");

        }

        /// <summary>
        /// 验证是否为正整数
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool IsInt(string str)
        {

            return Regex.IsMatch(str, @"^[0-9]*$");
        }

        /// <summary>
        /// 判断对象是否为Int32类型的数字
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool IsInt32(object Expression)
        {
            if (Expression != null)
            {
                string str = Expression.ToString();
                if (str.Length > 0 && str.Length <= 11 && Regex.IsMatch(str, @"^[-]?[0-9]*[.]?[0-9]*$"))
                {
                    if ((str.Length < 10) || (str.Length == 10 && str[0] == '1') || (str.Length == 11 && str[0] == '-' && str[1] == '1'))
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// 判断对象是否为Double类型的数字
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool IsDouble(object Expression)
        {
            if (Expression != null)
            {
                return Regex.IsMatch(Expression.ToString(), @"^([0-9])[0-9]*(\.\w*)?$");
            }
            return false;
        }

        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strNumber">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsDoubleArray(string[] strDouble)
        {
            if (strDouble == null)
            {
                return false;
            }
            if (strDouble.Length < 1)
            {
                return false;
            }
            foreach (string id in strDouble)
            {
                if (!IsDouble(id))
                {
                    return false;
                }
            }
            return true;

        }
        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strNumber">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsIntArray(string[] strInt)
        {
            if (strInt == null)
            {
                return false;
            }
            if (strInt.Length < 1)
            {
                return false;
            }
            foreach (string id in strInt)
            {
                if (!IsInt(id))
                {
                    return false;
                }
            }
            return true;

        }

        /// <summary>
        /// 判断是否为bool型
        /// </summary>
        /// <param name="strValue">要判断的字符串</param>
        public static bool IsBool(object Expression)
        {
            bool defValue = false;

            if (Expression != null)
            {
                if (string.Compare(Expression.ToString(), "true", true) == 0)
                {
                    return true;
                }
                else if (string.Compare(Expression.ToString(), "false", true) == 0)
                {
                    return true;
                }
            }
            return defValue;
        }

        /// <summary>
        /// 判断是否为bool型(此方法同时计算1为true,0为false)
        /// </summary>
        /// <param name="strValue">要判断的字符串</param>
        public static bool IsBoolByInt(object Expression)
        {
            bool defValue = false;

            if (Expression != null)
            {
                if (string.Compare(Expression.ToString(), "true", true) == 0)
                {
                    return true;
                }
                else if (string.Compare(Expression.ToString(), "false", true) == 0)
                {
                    return true;
                }
                else if (Expression.ToString() == "1")
                {
                    return true;
                }
                else if (Expression.ToString() == "0")
                {
                    return true;
                }
            }
            return defValue;
        }

        /// <summary>
        /// 判断是否为decimal型
        /// </summary>
        /// <param name="Expression"></param>
        /// <returns></returns>
        public static bool IsDecimal(object Expression)
        {
            decimal result;
            if (Expression != null)
            {
                return decimal.TryParse(Expression.ToString(), out result);
            }
            return false;
        }
    }
}
