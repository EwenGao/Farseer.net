﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 解释Url
    /// </summary>
    public class ParseUrl
    {
        /// <summary>
        /// 返回 URL 字符串的编码结果
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>编码结果</returns>
        public static string UrlEncode(string str)
        {
            return HttpUtility.UrlEncode(str);
        }

        /// <summary>
        /// 返回 URL 字符串的编码结果
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>解码结果</returns>
        public static string UrlDecode(string str)
        {
            return HttpUtility.UrlDecode(str);
        }

        /// <summary>
        /// 获得当前绝对路径
        /// </summary>
        /// <param name="strPath">指定的路径</param>
        /// <returns>绝对路径</returns>
        public static string GetMapPath(string strPath)
        {
            if (strPath.IndexOf(':') == -1 && HttpContext.Current != null)
            {
                return HttpContext.Current.Server.MapPath(strPath);
            }
            else //非web程序引用
            {
                return System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, strPath);
            }
        }

        /// <summary>
        /// 检测是否是正确的Url
        /// </summary>
        /// <param name="strUrl">要验证的Url</param>
        /// <returns>判断结果</returns>
        public static bool IsURL(string strUrl)
        {
            return Regex.IsMatch(strUrl, @"^(http|https)\://([a-zA-Z0-9\.\-]+(\:[a-zA-Z0-9\.&%\$\-]+)*@)*((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|localhost|([a-zA-Z0-9\-]+\.)*[a-zA-Z0-9\-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{1,10}))(\:[0-9]+)*(/($|[a-zA-Z0-9\.\,\?\'\\\+&%\$#\=~_\-]+))*$");
        }

        /// <summary>
        /// 返回URL中结尾的文件名
        /// </summary>		
        public static string GetFilename(string url)
        {
            if (url == null)
            {
                return "";
            }
            string[] strs1 = url.Split(new char[] { '/' });
            return strs1[strs1.Length - 1].Split(new char[] { '?' })[0];
        }

        /// <summary>
        /// 返回完全域名，带端口
        /// </summary>
        /// <param name="url">来源URL</param>
        /// <returns></returns>
        public static string GetDomainUrl(string url)
        {
            string newUrl;
            //去掉 http://字符串
            newUrl = url.ToLower().Replace("\\", "/").Replace("http://", "");
            //只截取到第一个'/'符号的字符串
            newUrl = newUrl.Substring(0, newUrl.IndexOf('/'));
            newUrl = "http://" + newUrl;
            return newUrl;
        }

        /// <summary>
        /// 得到网站的真实路径
        /// </summary>
        /// <returns></returns>
        public static string GetTrueWebPath()
        {
            string forumPath = HttpContext.Current.Request.Path;
            if (forumPath.LastIndexOf("/") != forumPath.IndexOf("/"))
            {
                forumPath = forumPath.Substring(forumPath.IndexOf("/"), forumPath.LastIndexOf("/") + 1);
            }
            else
            {
                forumPath = "/";
            }
            return forumPath;

        }

        #region 获得网站域名 	public static string ServerDomain
        /// <summary>
        /// 获得网站域名
        /// </summary>
        public static string ServerDomain
        {
            get
            {
                string host = HttpContext.Current.Request.Url.Host.ToLower();
                string[] arr = host.Split('.');
                if (arr.Length < 3 || Qyn.Common.Utils.ParseRegExp.IsIp(host))
                {
                    return host;
                }
                string domain = host.Remove(0, host.IndexOf(".") + 1);
                if (domain.StartsWith("com.") || domain.StartsWith("net.") || domain.StartsWith("org.") || domain.StartsWith("gov."))
                {
                    return host;
                }
                return domain;
            }
        }
        #endregion

        #region 获得当前路径
        /// <summary>
        /// 获得当前路径
        /// </summary>
        public static string CurrentPath
        {
            get
            {
                string path = HttpContext.Current.Request.Path;
                path = path.Substring(0, path.LastIndexOf("/"));
                if (path == "/")
                {
                    return string.Empty;
                }
                return path;
            }
        }
        #endregion

        #region 获得网站虚拟根目录 	public static string PathUpSeek
        /// <summary>
        /// 获得网站虚拟根目录
        /// </summary>
        public static string PathUpSeek
        {
            get
            {
                string currentPath = CurrentPath;
                string lower_current_path = currentPath.ToLower();


#if DEBUG
                string[] arr = (Utils.ParseString.JoinString(Qyn.Common.Utils.ParseAppSettings.Get("PathUpSeek"), "|/install|/upgrade|/test")).ToLower().Split('|');
#else
				string[] arr = (Utils.ParseString..JoinString(ApplicationSettings.Get("PathUpSeek"), "|/install|/upgrade")).ToLower().Split('|');
#endif


                foreach (string s in arr)
                {
                    if (null == s || 0 == s.Length)
                    {
                        continue;
                    }
                    if (s[0] != '/')
                    {
                        continue;
                    }
                    if (lower_current_path.EndsWith(s))
                    {
                        return currentPath.Remove(currentPath.Length - s.Length, s.Length);
                    }
                }

                int indexof = currentPath.IndexOf("/templates/");
                if (-1 != indexof)
                {
                    return currentPath.Substring(0, indexof);
                }
                return currentPath;
            }
        }
        #endregion

        #region 获得当前URL public static string CurrentUrl
        /// <summary> 
        /// 获得当前URL
        /// </summary>
        public static string CurrentUrl
        {
            get
            {
                return HttpContext.Current.Request.Url.ToString();
            }
        }
        #endregion

        #region 获取当前请求的原始URL
        /// <summary>
        /// 获取当前请求的原始 URL
        /// </summary>
        public static string webCurrentUrl
        {
            get
            {
                return HttpContext.Current.Request.RawUrl.ToString();
            }
        }
        #endregion

        #region 获得来源URL public static string Referrer
        /// <summary>
        /// 获得来源URL
        /// </summary>
        public static string Referrer
        {
            get
            {
                Uri uri = HttpContext.Current.Request.UrlReferrer;
                if (uri == null)
                {
                    return string.Empty;
                }
                return Convert.ToString(uri);
            }
        }
        #endregion

        #region 是否从其他连接向本域名连接 	public static bool IsPostFromAnotherDomain
        /// <summary>
        /// 是否从其他连接向本域名连接
        /// </summary>
        public static bool IsPostFromAnotherDomain
        {
            get
            {
                if (HttpContext.Current.Request.HttpMethod == "GET")
                {
                    return false;
                }
                return Referrer.IndexOf(ServerDomain) == -1;
            }
        }
        #endregion

        #region 是否从其他连接向本域名以POST方式提交表单 	public static bool IsGetFromAnotherDomain
        /// <summary>
        /// 是否从其他连接向本域名以POST方式提交表单
        /// </summary>
        public static bool IsGetFromAnotherDomain
        {
            get
            {
                if (HttpContext.Current.Request.HttpMethod == "POST")
                {
                    return false;
                }
                return Referrer.IndexOf(ServerDomain) == -1;
            }
        }
        #endregion
    }
}
