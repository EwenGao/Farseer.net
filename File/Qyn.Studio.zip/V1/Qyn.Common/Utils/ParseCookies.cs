﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;

namespace Qyn.Common.Utils
{
    public class ParseCookies
    {
        private static string appPrefix = "Qyn_";

        /// <summary>
        /// 写cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        public static void WriteCookie(string strName, string strValue)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[appPrefix + strName];
            if (cookie == null)
            {
                cookie = new HttpCookie(appPrefix + strName);
            }
            cookie.Value = strValue;
            HttpContext.Current.Response.AppendCookie(cookie);
        }

        /// <summary>
        /// 写cookie值
        /// </summary>
        /// <param name="strName">名称</param>
        /// <param name="strValue">值</param>
        /// <param name="strValue">过期时间(分钟)</param>
        public static void WriteCookie(string strName, string strValue, int expires)
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[appPrefix + strName];
            if (cookie == null)
            {
                cookie = new HttpCookie(appPrefix + strName);
            }
            cookie.Value = strValue;
            cookie.Expires = DateTime.Now.AddMinutes(expires);
            HttpContext.Current.Response.AppendCookie(cookie);

        }

        /// <summary>
        /// 读cookie值string
        /// </summary>
        /// <param name="strName">名称</param>
        /// <returns>cookie值</returns>
        public static string GetCookie(string strName)
        {
            if (HttpContext.Current.Request.Cookies != null && HttpContext.Current.Request.Cookies[appPrefix + strName] != null)
            {
                return HttpContext.Current.Request.Cookies[appPrefix + strName].Value.ToString();
            }

            return "";
        }

        /// <summary>
        /// 读cookie值INT
        /// </summary>
        /// <param name="strName">名称</param>
        /// <returns>cookie值</returns>
        public static string GetCookie(string strName, string deValue)
        {
            return GetCookie(strName).Trim().Length == 0 ? deValue : GetCookie(strName).Trim();
        }

        /// <summary>
        /// 读cookie值INT
        /// </summary>
        /// <param name="strName">名称</param>
        /// <returns>cookie值</returns>
        public static int GetCookie(string strName, int deValue)
        {
            return ParseType.StrToInt(GetCookie(strName),deValue);
        }

        /// <summary>
        /// 移除cookie值
        /// </summary>
        /// <param name="strName">名称c</param>
        /// <returns></returns>
        public static void  RemoveCookie(string strName)
        {
            WriteCookie(appPrefix + strName, "By Qyn", -10);
        }

        /// <summary>
        /// 是否为有效域
        /// </summary>
        /// <param name="host">域名</param>
        /// <returns></returns>
        public static bool IsValidDomain(string host)
        {
            Regex r = new Regex(@"^\d+$");
            if (host.IndexOf(".") == -1)
            {
                return false;
            }
            return r.IsMatch(host.Replace(".", string.Empty)) ? false : true;
        }

    }
}
