﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Web;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;

namespace Qyn.Common.Utils
{
    public class ParseFile
    {
        

        /// <summary>
        /// 返回文件是否存在
        /// </summary>
        /// <param name="filename">文件名</param>
        /// <returns>是否存在</returns>
        public static bool FileExists(string filename)
        {
            return System.IO.File.Exists(filename);
        }

        /// <summary>
        /// 返回文件夹是否存在
        /// </summary>
        /// <param name="path">路径</param>
        /// <returns>是否存在</returns>
        public static bool DirExists(string path)
        {
            return System.IO.Directory.Exists(path);
            
        }

        /// <summary>
        /// 获取文件名
        /// </summary>
        /// <param name="filePath">文件的路径全名称</param>
        /// <returns></returns>
        public static string GetFileName(string filePath)
        {
            return System.IO.Path.GetFileName(filePath);
        }

        /// <summary>
        /// 获取文件后缀名(小写)
        /// </summary>
        /// <param name="fileName">文件名</param>
        /// <returns></returns>
        public static string GetExtension(string fileName)
        {
            return System.IO.Path.GetExtension(fileName).Substring(1).ToLower();
        }

        /// <summary>
        /// 以指定的ContentType输出指定文件文件
        /// </summary>
        /// <param name="filepath">文件路径</param>
        /// <param name="filename">输出的文件名</param>
        /// <param name="filetype">将文件输出时设置的ContentType</param>
        public static void ResponseFile(string filepath, string filename, string filetype)
        {
            Stream iStream = null;

            // 缓冲区为10k
            byte[] buffer = new Byte[10000];

            // 文件长度
            int length;

            // 需要读的数据长度
            long dataToRead;

            try
            {
                // 打开文件
                iStream = new FileStream(filepath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);


                // 需要读的数据长度
                dataToRead = iStream.Length;

                HttpContext.Current.Response.ContentType = filetype;
                HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=" + Utils.ParseUrl.UrlEncode(filename.Trim()).Replace("+", " "));

                while (dataToRead > 0)
                {
                    // 检查客户端是否还处于连接状态
                    if (HttpContext.Current.Response.IsClientConnected)
                    {
                        length = iStream.Read(buffer, 0, 10000);
                        HttpContext.Current.Response.OutputStream.Write(buffer, 0, length);
                        HttpContext.Current.Response.Flush();
                        buffer = new Byte[10000];
                        dataToRead = dataToRead - length;
                    }
                    else
                    {
                        // 如果不再连接则跳出死循环
                        dataToRead = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                HttpContext.Current.Response.Write("Error : " + ex.Message);
            }
            finally
            {
                if (iStream != null)
                {
                    // 关闭文件
                    iStream.Close();
                }
            }
            HttpContext.Current.Response.End();
        }

        /// <summary>
        /// 返回指定目录下的非 UTF8 字符集文件
        /// </summary>
        /// <param name="Path">路径</param>
        /// <returns>文件名的字符串数组</returns>
        public static string[] FindNoUTF8File(string Path)
        {
            //System.IO.StreamReader reader = null;
            StringBuilder filelist = new StringBuilder();
            DirectoryInfo Folder = new DirectoryInfo(Path);
            //System.IO.DirectoryInfo[] subFolders = Folder.GetDirectories(); 
            /*
            for (int i=0;i<subFolders.Length;i++) 
            { 
                FindNoUTF8File(subFolders[i].FullName); 
            }
            */
            FileInfo[] subFiles = Folder.GetFiles();
            for (int j = 0; j < subFiles.Length; j++)
            {
                if (subFiles[j].Extension.ToLower().Equals(".htm"))
                {
                    FileStream fs = new FileStream(subFiles[j].FullName, FileMode.Open, FileAccess.Read);
                    bool bUtf8 = IsUTF8(fs);
                    fs.Close();
                    if (!bUtf8)
                    {
                        filelist.Append(subFiles[j].FullName);
                        filelist.Append("\r\n");
                    }
                }
            }
            return Utils.ParseString.SplitString(filelist.ToString(), "\r\n");

        }

        /// <summary>
        /// 判断文件流是否为UTF8字符集
        /// </summary>
        /// <param name="sbInputStream">文件流</param>
        /// <returns>判断结果</returns>
        private static bool IsUTF8(FileStream sbInputStream)
        {
            int i;
            byte cOctets;  // octets to go in this UTF-8 encoded character 
            byte chr;
            bool bAllAscii = true;
            long iLen = sbInputStream.Length;

            cOctets = 0;
            for (i = 0; i < iLen; i++)
            {
                chr = (byte)sbInputStream.ReadByte();

                if ((chr & 0x80) != 0) bAllAscii = false;

                if (cOctets == 0)
                {
                    if (chr >= 0x80)
                    {
                        do
                        {
                            chr <<= 1;
                            cOctets++;
                        }
                        while ((chr & 0x80) != 0);

                        cOctets--;
                        if (cOctets == 0) return false;
                    }
                }
                else
                {
                    if ((chr & 0xC0) != 0x80)
                    {
                        return false;
                    }
                    cOctets--;
                }
            }

            if (cOctets > 0)
            {
                return false;
            }

            if (bAllAscii)
            {
                return false;
            }

            return true;

        }

        /// <summary>
        /// 建立文件夹
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static void CreateDir(string path)
        {
            //return MakeSureDirectoryPathExists(name);
            System.IO.Directory.CreateDirectory(path);
        }

        /// <summary>
        /// 删除目录
        /// </summary>
        /// <param name="path">路径</param>
        /// <param name="recursive">true同时删除子目录所有文件</param>
        /// <returns></returns>
        public static void DropDir(string path, bool recursive)
        {
            System.IO.Directory.Delete(path, recursive);
        }

        /// <summary>
        /// 智能创建文件目录(任何级别目录)
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static bool CreateDirs(string dirPath)
        {
            string path = "";
            string mapPath;
            string[] dirPaths = dirPath.Replace("\\", "/").Split('/');                     //用于创建目录
            for (int i = 0; i < dirPaths.Length; i++)
            {
                if (i == 0)
                {
                    if (dirPaths[i].IndexOf(":") != -1)
                    {
                        path = dirPaths[i] + "/";
                        continue;
                    }
                    else if (dirPaths[i] == "")
                    {
                        path = "/";
                        continue;
                    }
                }

                if (dirPaths[i] != "")
                {
                    path += dirPaths[i] + "/";

                    mapPath = Utils.ParseUrl.GetMapPath(path);
                    if (!DirExists(mapPath))
                    {
                        CreateDir(mapPath);
                    }
                }

            }
            return true;
        }

        /// <summary>
        /// 备份文件
        /// </summary>
        /// <param name="sourceFileName">源文件名</param>
        /// <param name="destFileName">目标文件名</param>
        /// <param name="overwrite">当目标文件存在时是否覆盖</param>
        /// <returns>操作是否成功</returns>
        public static bool BackupFile(string sourceFileName, string destFileName, bool overwrite)
        {
            if (!System.IO.File.Exists(sourceFileName))
            {
                throw new FileNotFoundException(sourceFileName + "文件不存在！");
            }
            if (!overwrite && System.IO.File.Exists(destFileName))
            {
                return false;
            }
            try
            {
                System.IO.File.Copy(sourceFileName, destFileName, true);
                return true;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// 恢复文件
        /// </summary>
        /// <param name="backupFileName">备份文件名</param>
        /// <param name="targetFileName">要恢复的文件名</param>
        /// <param name="backupTargetFileName">要恢复文件再次备份的名称,如果为null,则不再备份恢复文件</param>
        /// <returns>操作是否成功</returns>
        public static bool RestoreFile(string backupFileName, string targetFileName, string backupTargetFileName)
        {
            try
            {
                if (!System.IO.File.Exists(backupFileName))
                {
                    throw new FileNotFoundException(backupFileName + "文件不存在！");
                }
                if (backupTargetFileName != null)
                {
                    if (!System.IO.File.Exists(targetFileName))
                    {
                        throw new FileNotFoundException(targetFileName + "文件不存在！无法备份此文件！");
                    }
                    else
                    {
                        System.IO.File.Copy(targetFileName, backupTargetFileName, true);
                    }
                }
                System.IO.File.Delete(targetFileName);
                System.IO.File.Copy(backupFileName, targetFileName);
            }
            catch (Exception e)
            {
                throw e;
            }
            return true;
        }

        /// <summary>
        /// 复制文件夹内的文件到指定路径
        /// </summary>
        /// <param name="srcPath">源文件夹</param>
        /// <param name="aimPath">目录文件夹</param>
        /// <param name="isCopySubDir">true:复制子文件夹;false:只复制根文件夹下的文件</param>
        public static bool CopyDir(string srcPath, string aimPath,bool isCopySubDir)
        {
            try
            {
                if (aimPath[aimPath.Length - 1] != Path.DirectorySeparatorChar)
                {
                    aimPath += Path.DirectorySeparatorChar;
                }

                if (!DirExists(aimPath))
                {
                    CreateDirs(aimPath);
                }

                string[] fileList = Directory.GetFileSystemEntries(srcPath);
                // 遍历所有的文件和目录
                foreach (string file in fileList)
                {
                    if (Directory.Exists(file) && isCopySubDir)
                    {
                        CopyDir(file, aimPath + Path.GetFileName(file), isCopySubDir);
                    }

                    else
                    {
                        File.Copy(file, aimPath + Path.GetFileName(file), true);
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                return false;
            }
        }

        /// <summary>
        /// 获取文件夹内的所有文件
        /// </summary>
        /// <param name="srcPath"></param>
        /// <param name="isCopySubDir"></param>
        public static void GetFile(string srcPath, bool isCopySubDir)
        { }

        /// <summary>
        /// 上传文件的权限
        /// </summary>
        public struct stuUpLoadFileType
        {
            /// <summary>
            /// 允许上传的类型
            /// </summary>
            public string type;
            /// <summary>
            /// 允许上传的容量(单位：KB. 0：无限制)
            /// </summary>
            public int size;
        }

        /// <summary>
        /// 上传文件后回发的资料
        /// </summary>
        public struct stuUpLoadFile
        {
            /// <summary>
            /// 上传成功的文件名
            /// </summary>
            public string FileName;
            /// <summary>
            /// 上传成功的文件名-前缀
            /// </summary>
            public string FileNamePrefix;
            /// <summary>
            /// 上传成功的文件名-扩展名
            /// </summary>
            public string FileNameExtension;
            /// <summary>
            /// 上传成功的文件容量(单位：KB)
            /// </summary>
            public int Size;
            /// <summary>
            /// 上传成功的文件相对路径(WebPath之后的路径,不带文件名)
            /// </summary>
            public string FilePath;
            /// <summary>
            /// 上传成功的文件物理路径(不带文件名)
            /// </summary>
            public string FileMapPath;
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="webPath">网站根目录非IIS根目录</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static stuUpLoadFile[] UploadFile(HttpFileCollection files, string webPath, string filePath, int saveType)
        {
            return UploadFile(files, webPath, filePath, saveType, null, null);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="webPath">网站根目录非IIS根目录</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="stuUpLoadFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static stuUpLoadFile[] UploadFile(HttpFileCollection files, string webPath, string filePath, int saveType, stuUpLoadFileType[] fileType)
        {
            return UploadFile(files, webPath, filePath, saveType, fileType, null);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="webPath">网站根目录非IIS根目录</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="stuUpLoadFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        /// <param name="colName">指定只上传的组件名</param>
        public static stuUpLoadFile[] UploadFile(HttpFileCollection files, string webPath, string filePath, int saveType, stuUpLoadFileType[] fileType, string colName)
        {
            string fileName;                                                                //获取文件名全称
            string fileNamePrefix;                                                          //获取文件名前缀
            string fileNameExtension;                                                       //获取文件名后缀
            string fileMapPath;                                                             //获取目录绝对路径
            bool isfileExtension = false;                                                   //true表示属于允许上传的类型
            bool isHavaFileUpload = false;                                                  //检测是否有文件上传
            int fileContentLength;                                                          //文件容量

            #region 上传前,对文件进行安全检查判断

            #region 对参数进行转换小写
            if (fileType != null)
            {
                for (int i = 0; i < fileType.Length; i++)
                {
                    fileType[i].type = fileType[i].type.ToLower();
                }
            }
            #endregion

            #region 判断根目录,保存目录是否为空,及目录合法性,及"/"号转换
            if (webPath == null || webPath.Trim().Length == 0)
            {
                webPath = "/";
            }
            else
            {
                webPath = webPath.Replace("\\", "/");
                string[] webPaths = webPath.Split('/');
                webPath = "/";
                for (int i = 0; i < webPaths.Length; i++)
                {
                    if (webPaths[i] != null && webPaths[i].Trim().Length > 0)
                    {
                        webPath += webPaths[i] + "/";
                    }
                }

            }

            if (filePath == null || filePath.Trim().Length == 0)
            {
                new Terminator().Throw("保存路径没有填写,请联系管理员!");
                return null;
            }
            else
            {
                filePath = filePath.Replace("\\", "/");
                string[] filePaths = filePath.Split('/');
                filePath = "";
                for (int i = 0; i < filePaths.Length; i++)
                {
                    if (filePaths[i] != null && filePaths[i].Trim().Length > 0)
                    {
                        filePath += filePaths[i] + "/";
                    }
                }
            }

            #endregion

            #region 检查文件保存方式设置

            if (saveType > 1)
            {
                new Terminator().Throw("保存方式设置不对,请联系管理员!");
                return null;
            }

            #endregion

            #region 检查每个文件的合法检验

            for (int fileIndex = 0; fileIndex < files.Count; fileIndex++)
            {
                fileName = files[fileIndex].FileName.ToLower().Trim();                                          //获取文件名全称
                fileNamePrefix = System.IO.Path.GetFileNameWithoutExtension(fileName);                          //获取文件名前缀
                fileNameExtension = GetExtension(fileName);                                                     //获取后缀名
                fileContentLength = files[fileIndex].ContentLength / 1024;                                      //获取文件容量

                if (fileName.Length < 1)                                                                         //文件不存在时，直接跳过
                {
                    continue;
                }

                isHavaFileUpload = true;

                #region 判断文件前缀是否为空

                if (fileNamePrefix == null || fileNamePrefix == string.Empty)
                {
                    new Terminator().Throw("文件: [ " + fileName + " ] 前缀名不能为空");
                    return null;
                }

                #endregion

                #region 判断文件容量是否为0

                if (fileContentLength <= 0)
                {
                    new Terminator().Throw("文件: [ " + fileName + " ] 的大小不能为0KB");
                    return null;
                }

                #endregion

                #region 循环文件类型,长度

                if (fileType != null && fileType.Length > 0)
                {
                    isfileExtension = false;
                    for (int typeSizeIndex = 0; typeSizeIndex < fileType.Length; typeSizeIndex++)
                    {
                        #region 判断文件类型,长度是否允许上传

                        if (fileNameExtension != fileType[typeSizeIndex].type)
                        {
                            continue;
                        }

                        isfileExtension = true;

                        #region 判断文件容量是否超过上限

                        if (fileType[typeSizeIndex].size != 0)
                        {
                            if (fileContentLength > fileType[typeSizeIndex].size)
                            {
                                new Terminator().Throw("文件类型为 [ " + fileType[typeSizeIndex].type + " ] 的容量不能超过: [ " + fileType[typeSizeIndex].size + " KB ]");
                                return null;
                            }
                        }
                        #endregion

                        break;
                        #endregion
                    }

                    if (!isfileExtension)
                    {
                        new Terminator().Throw("第 [" + Convert.ToString(fileIndex + 1) + "] 个文件扩展名: [ " + fileNameExtension + " ] 不允许上传");
                        return null;
                    }
                }
                #endregion

            }

            if (!isHavaFileUpload)
            {
                new Terminator().Throw("未检查到有文件上传!");
                return null;
            }
            #endregion

            #endregion

            #region 创建文件目录(任何级别目录)
            CreateDirs(System.IO.Path.Combine(webPath, filePath));
            #endregion

            #region 上传文件操作
            ArrayList arrayList = new ArrayList();
            try
            {
                for (int fileIndex = 0; fileIndex < files.Count; fileIndex++)
                {
                    fileName = files[fileIndex].FileName.ToLower().Trim();                                          //获取文件名全称
                    fileNamePrefix = System.IO.Path.GetFileNameWithoutExtension(fileName);                          //获取文件名前缀
                    fileNameExtension = GetExtension(fileName);                                                     //获取后缀名

                    if (fileName.Length < 1)                                                                         //文件不存在时，直接跳过
                    {
                        continue;
                    }
                    stuUpLoadFile upLoadFile = new stuUpLoadFile();

                    //获取保存为的文件名
                    switch (saveType)
                    {
                        case 1:
                            fileName = DateTime.Now.ToString().Replace("-", "").Replace(" ", "").Replace(":", "") + fileIndex.ToString() + "." + fileNameExtension;
                            break;
                    }

                    fileMapPath = Utils.ParseUrl.GetMapPath(System.IO.Path.Combine(webPath, filePath));
                    files[fileIndex].SaveAs(System.IO.Path.Combine(fileMapPath, fileName));

                    upLoadFile.FileName = fileName;
                    upLoadFile.FileNamePrefix = fileNamePrefix;
                    upLoadFile.FileNameExtension = fileNameExtension;
                    upLoadFile.Size = (files[fileIndex].ContentLength > 1024) ? files[fileIndex].ContentLength / 1024 : 1;
                    upLoadFile.FilePath = filePath;
                    upLoadFile.FileMapPath = fileMapPath;
                    arrayList.Add(upLoadFile);
                }
            }

            catch (Exception Ex)
            {
                new Terminator().Throw(Ex.Message.ToString());
                return null;
            }
            #endregion

            #region 合并数据
            stuUpLoadFile[] uploadFiles = new stuUpLoadFile[arrayList.Count];
            for (int filesIndex = 0; filesIndex < arrayList.Count; filesIndex++)
            {
                uploadFiles[filesIndex] = (stuUpLoadFile)arrayList[filesIndex];
            }
            #endregion

            return uploadFiles;
        }
    }
}
