
namespace Qyn.Common.Dv
{
	/// <summary>
	/// ���ݿ���������
	/// </summary>
	public enum DbProviderEnum
	{
		Access = 0,
		SqlServer = 1
	}

	/// <summary>
	/// QueryStringֵ�ļ��
	/// </summary>
	public enum CheckGetEnum
	{
		Int = 0,
		Safety = 1
	}

	/// <summary>
	/// ʹ�ñ�ǩ
	/// </summary>
	public enum UsingTagEnum
	{
		None = 0,
		Ubb = 1,
		Html = 2
	}
}