using System;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Configuration;
using System.Web;
using System.Text;
using System.Security.Cryptography;


namespace Qyn.Common.Dv
{

	#region ��֤��ͼƬ
	/// <summary>
	/// У��ͼƬ��
	/// </summary>
	public class CodeImage : System.Web.UI.Page
	{
		#region �ֶ�
		//�����ߡ����塢�����С
		private int _width, _height, _fontSize, _impurity;
		private Color _color,_bgcolor;
		private string _fontFamily;
		private bool _bold, _italic;
		#endregion

		#region ������, ����ֶ�Ĭ��ֵ
		protected CodeImage()
		{
			this._width		= 60;
			this._height	= 20;
			this._fontSize	= 12;
			this._fontFamily= "Verdana";
			this._bold		= true;
			this._italic	= true;
			this._impurity	= 3;
			this._color = Color.Blue;
			this._bgcolor = Color.AliceBlue;
		}
		#endregion

		#region ��QueryString��ȡ����, ��������ֶ�ֵ private void FillImageProperties()
		/// <summary>
		/// ��QueryString��ȡ����, ��������ֶ�ֵ
		/// </summary>
		private void FillImageProperties()
		{
			string str = string.Empty;

			str = Fetch.Get("width");
            if (Qyn.Common.Utils.ParseRegExp.IsNumeric(str)) _width = int.Parse(str);
			if (_width > 300)
			{
				_width = 300;
			}
			str = Fetch.Get("height");
            if (Qyn.Common.Utils.ParseRegExp.IsNumeric(str)) _height = int.Parse(str);
			if (_height > 300)
			{
				_height = 300;
			}

			str = Fetch.Get("fontsize");
            if (Qyn.Common.Utils.ParseRegExp.IsNumeric(str))
			{
				_fontSize = int.Parse(str);
			}

			str = Fetch.Get("fontfamily");
			if (str.Length > 0)
			{
				_fontFamily = str;
			}

			str = Fetch.Get("bold").ToLower();
			if (str.Length > 0)
			{
				_bold = (str == "true");
			}
			
			str = Fetch.Get("italic").ToLower();
			if (str.Length > 0)
			{
				_italic = (str == "true");
			}

			str = Fetch.Get("impurity");
            if (Qyn.Common.Utils.ParseRegExp.IsNumeric(str))
			{
				_impurity = int.Parse(str);
			}

			if (_impurity > 30)
			{
				_impurity = 30;
			}
		}
		#endregion private void FillImageProperties()
 
		#region ��ȡ���������趨 	private FontStyle GetFontStyle()
		/// <summary>
		/// ��ȡ���������趨
		/// </summary>
		/// <returns></returns>
		private FontStyle GetFontStyle()
		{
			if (_bold && _italic)
			{
				return (FontStyle.Bold | FontStyle.Italic);
			}
			if (_bold)
			{
				return FontStyle.Bold;
			}
			if (_italic)
			{
				return FontStyle.Italic;
			}
			return FontStyle.Regular;
		}
		#endregion 

		#region �õ��������� private Point[] GetRandomPointGroup()
		/// <summary>
		/// �õ���������
		/// </summary>
		/// <returns></returns>
		private Point[] GetRandomPointGroup()
		{
			Point[] points = new Point[_impurity * 2];
			for (int i = 0; i < points.Length; i++)
			{
				int seed = new Random().Next(10000000, 99999999);
				int x = new Random( (seed/(i+2)) * (i+1) ).Next(0, _width);
				int y = new Random( (seed/(x+2)) * (x+1) ).Next(0, _height);

				points[i] = new Point(x, y);
			}
			return points;
		}
		#endregion

		#region ����ͼƬ private Bitmap GetneralCodeImage()
		/// <summary>
		/// ����ͼƬ
		/// </summary>
		/// <returns></returns>
		private Bitmap GetneralCodeImage()
		{
			//����λͼ
			Bitmap bmp = new Bitmap(_width, _height);
			Graphics g = Graphics.FromImage(bmp);
			g.Clear(_bgcolor);

			//�������ʶ���
			Pen pen = new Pen(Color.Blue, 1);
			pen.DashStyle  = DashStyle.DashDotDot;
			Point[] points = this.GetRandomPointGroup();
			
			//�������
			for (int i=0; i<points.Length; i+=2)
			{
				g.DrawLine(pen, points[i], points[i+1]);				
				g.DrawEllipse(
					pen,
					new Random().Next(5,10),
					new Random().Next(5,10),
					new Random().Next(5,50),
					new Random().Next(5,50)
					);
			}

			//�������������ַ�
			string textBeDraw = new Random().Next(1000, 9999).ToString();
			Qyn.Common.Utils.ParseSession.Set("verification", textBeDraw);

			//����ַ�
			g.DrawString(
					textBeDraw,
					new Font(_fontFamily, _fontSize, this.GetFontStyle()),
					new SolidBrush(_color),
					0,
					0
				);

			g.Dispose();
			return bmp;
		}
		#endregion

		#region ҳ�����룬����ͼƬ�����
		/// <summary>
		/// Page_Load
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Page_Load(object sender, EventArgs e)
		{
			FillImageProperties();
			Response.ContentType = "image/gif";
			this.GetneralCodeImage().Save(Response.OutputStream, ImageFormat.Gif);
		}
		#endregion

		#region RSA
		public   void   StartDemo()   
		{	
			try
			{
				byte[] dataToEncrypt = Encoding.ASCII.GetBytes("Ashh");
				byte[] encryptedData;
				byte[] decryptedData;

				RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();				
				string strPub = RSA.ToXmlString(false);
				string strPri = RSA.ToXmlString(true);

				encryptedData = RSAEncrypt(dataToEncrypt,RSA.ExportParameters(false), false);
				string str = Convert.ToBase64String(encryptedData);
				
				decryptedData = RSADecrypt(encryptedData,RSA.ExportParameters(true), false);
				str = Encoding.ASCII.GetString(decryptedData);
				return;
			}
			catch(ArgumentNullException)
			{				
			}
		}   

		static public byte[] RSAEncrypt(byte[] DataToEncrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
		{
			try
			{
				// ��Կ����
				RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();

				RSAKeyInfo.Modulus = Encoding.ASCII.GetBytes("2841418339");
				RSAKeyInfo.Exponent = Encoding.ASCII.GetBytes("23909");

				RSA.ImportParameters(RSAKeyInfo);
				string sKey = RSA.ToXmlString(false);
				return RSA.Encrypt(DataToEncrypt, DoOAEPPadding);
			}
			catch
			{
				return null;
			}
		}

		static public byte[] RSADecrypt(byte[] DataToDecrypt, RSAParameters RSAKeyInfo,bool DoOAEPPadding)
		{
			try
			{
				RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();

				RSA.ImportParameters(RSAKeyInfo);				
				return RSA.Decrypt(DataToDecrypt, DoOAEPPadding);
			}
			catch(CryptographicException e)
			{
				Console.WriteLine(e.ToString());

				return null;
			}
		}
		#endregion

		/// <summary>
		/// OnInit
		/// </summary>
		/// <param name="e"></param>
		override protected void OnInit(EventArgs e)
		{
			InitializeComponent();
			base.OnInit(e);
		}
		private void InitializeComponent()
		{
			this.Load += new EventHandler(this.Page_Load);
		}
	}
	#endregion
}