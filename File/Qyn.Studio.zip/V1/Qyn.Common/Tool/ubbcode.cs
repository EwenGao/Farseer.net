using System.Text;
using System.Text.RegularExpressions;

namespace Qyn.Common.Dv
{
	/// <summary>
	/// UbbCode
	/// �÷�����Ҫ����js���ô��룬�Ե���Common.js�е�ubb����
	/// </summary>
	public class UbbCode
	{
		#region Constructors
		/// <summary>
		/// Constructors
		/// </summary>
		public UbbCode()
		{
		}
		#endregion

		#region Constructions ������
		public UbbCode(string content, int usingTag, bool enableFormat)
		{
			_content		= content;
			_usingTag		= usingTag;
			_enableFormat	= enableFormat;
		}
		#endregion

		#region Fields
		private string _content;
		private int _usingTag;
		private bool _enableFormat;
		#endregion

		#region Properties
		public string Content
		{
			get
			{
				return _content;
			}
			set
			{
				_content = value;
			}
		}
		public int UsingTag
		{
			get
			{
				return _usingTag;
			}
			set
			{
				_usingTag = value;
			}
		}
		public bool EnableFormat
		{
			get
			{
				return _enableFormat;
			}
			set
			{
				_enableFormat = value;
			}
		}
		#endregion

		///
		///--- Methods ------------
		///

		#region ���ظ�����ַ 	private string HideAttachImageAddress(string content)
		/// <summary>
		/// ���ظ�����ַ
		/// </summary>
		/// <param name="content"></param>
		/// <returns></returns>
		private string HideAttachImageAddress(string content)
		{
			RegexOptions regexOptions =  RegexOptions.IgnoreCase |  RegexOptions.Multiline;

			string pattern = @"(\[uploadimage)(=left|=right|)(\][0-9]+,)[0-9a-zA-Z_\.\/\\]+(\[\/uploadimage\])";
			return Regex.Replace(content, pattern, "$1$2$3Protected$4", regexOptions);
		}
		#endregion

		#region �滻��Ҫ�滻������
		/// <summary>
		/// �滻��Ҫ�滻������
		/// </summary>
		/// <param name="input">Ҫ�滻���ַ���</param>
		/// <param name="pattern">ԭ�滻</param>
		/// <param name="replacement">Ŀ¼�滻</param>
		/// <param name="ro">����ʽѡ��</param>
		/// <returns>�����滻�������</returns>
		private string RegexReplace(string input, string[] pattern, string[] replacement, RegexOptions ro)
		{
			string s = input;
			for (int i=0; i<pattern.Length; i++)
			{
				s = Regex.Replace(s, pattern[i], replacement[i], ro);
			}
			return s;
		}

		private string replace(string input, string pattern, string replacement)
		{
			return Regex.Replace(input, pattern, replacement, RegexOptions.IgnoreCase | RegexOptions.Multiline);
		}

		private string replace(string input, string pattern, string replacement, RegexOptions regexOptions)
		{
			return Regex.Replace(input, pattern, replacement, regexOptions);
		}
		#endregion

		#region RemoveExtraLineBreaks private string RemoveExtraLineBreaks(string s)
		private string RemoveExtraLineBreaks(string s)
		{
			string[] p = new string[3];
			string[] r = new string[3];
			p[0] = @"\r";		r[0] = "";
			p[1] = @"[\n]{2,}";	r[1] = "\n\n";
			p[2] = @"\n";		r[2] = "\r\n";
			return RegexReplace(s, p, r, RegexOptions.IgnoreCase);
		}
		#endregion

		#region ����������ʽ private string SetFontStyle(string s)
		/// <summary>
		/// ����������ʽ
		/// </summary>
		/// <param name="s"></param>
		/// <returns></returns>
		private string SetFontStyle(string s)
		{
			string[] p = new string[5];
			string[] r = new string[5];
			p[0] = @"\[((\/?b)|(\/?i)|(\/?u)|(\/?h[1-6])|(\/?sub)|(\/?sup)|(\/?center))\]";
			r[0] = "<$1>";
			p[1] = @"\[color=(#[A-Fa-f0-9]{3}|#[A-Fa-f0-9]{6}|[a-zA-Z]{3,12})\]";
			r[1] = "<span style='color:$1'>";
			p[2] = @"\[size=(1[1-9])\]";
			r[2] = "<span style='font-size:$1px'>";
			p[3] = @"\[face=([^\]]+)\]";
			r[3] = "<span style='font-family:$1'>";
			p[4] = @"\[\/(color|size|face)\]";
			r[4] = "</span>";
			return RegexReplace(s, p, r, RegexOptions.IgnoreCase);

		}
		#endregion

		#region XSS���� public string FilterXSS(string str)
		/// <summary>
		/// XSS����
		/// </summary>
		/// <param name="str"></param>
		/// <returns></returns>
		public string FilterXSS(string str)
		{
			if(str.Length == 0) return str;
			string key = @"(?:expression|xss:|function|meta|window\.|script|js:|about:|file:|Document\.|vbs:|frame|cookie|on(finish|mouse|Exit=|error|click|key|load|focus|Blur|link|layer|style|base|html|xhtml|xml))";			
			key = @"<(?:(?:.[^>]*" + key  + "[^>]*)|" + key + ")>";
			str = Regex.Replace(str,key,"",RegexOptions.IgnoreCase);
			return str;
		}
		#endregion

		#region ��ȡ���ӵ�ַ private string FindUrl(string s)
		/// <summary>
		/// ��ȡ���ӵ�ַ
		/// </summary>
		/// <param name="s"></param>
		/// <returns></returns>
		private string FindUrl(string s)
		{
			string[] p = new string[7];
			string[] r = new string[7];

			p[0] = @"\[url=([^\[]{5,})\](.+?)\[\/url\]";

			r[0] = "<a href='$1' target='_blank'>$2</a>";
			p[1] = @"\[url\]([^\[]{5,})\[\/url\]";
			r[1] = "<a href='$1' target='_blank'>$1</a>";

			p[2] = @"\[email\]([^\s@]+@[^\[\.]+\.[^\[]+)\[\/email\]";
			r[2] = "<a href='mailto:$1'>$1</a>";
			p[3] = @"\[email=([^\s@]+@[^\[\.]+\.[^\[]+)\]([^\[]+)\[\/email\]";
			r[3] = "<a href='mailto:$1'>$2</a>";

			p[4] = @"([^>=\]])((http|https|ftp|rtsp|mms):(\/\/|\\\\)[A-Za-z0-9%\-_@]+\.[A-Za-z0-9%\-_@]+[A-Za-z0-9\.\/=\?%\-&_~`@:\+!;]*)";
			r[4] = "$1<a href='$2' target='_blank'>$2</a>";

			p[5] = @"(^(http|https|ftp|rtsp|mms):(\/\/|\\\\)[A-Za-z0-9%\-_@]+\.[A-Za-z0-9%\-_@]+[A-Za-z0-9\.\/=\?%\-&_~`@:\+!;]*)";
			r[5] = "<a href='$1' target='_blank'>$1</a>";

			p[6] = @"(^|\n)(www\.[A-Za-z0-9%\-_@]+[A-Za-z0-9\.\/=\?%\-&_~`@:\+!;]+)";
			r[6] = "<a href='http://$2' target='_blank'>$2</a>";

			return RegexReplace(s, p, r, RegexOptions.IgnoreCase);
		}
		#endregion

		#region ȷ�����ӵ�ַ private string FixRelativePath(string content)
		/// <summary>
		/// ȷ�����ӵ�ַ
		/// </summary>
		/// <param name="content"></param>
		/// <returns></returns>
		private string FixRelativePath(string content)
		{
			RegexOptions ro = RegexOptions.IgnoreCase;
			string s = Regex.Replace(content, @" (href|src)=\'(javascript|vbscript|script):([^\']*)\'", " $1='$3'", ro);
			s = Regex.Replace(s, @" (href|src)=\'(\/|[a-zA-Z]+:)([^\']*)\'", " $1='$2$3'", ro);
			s = Regex.Replace(s, @" (href|src)=\'([^\']*)\'", " $1='" + Utils.ParseUrl.PathUpSeek + "/$2'", ro);
			return s;
		}
		#endregion

		#region public string GetServerSideSimpleUbbContent(string content)
		public string GetServerSideSimpleUbbContent(string content)
		{
			string result = this.HideAttachImageAddress(content);
			result = this.RemoveExtraLineBreaks(result);

			result = this.SetFontStyle(result);

			result = this.FindUrl(result);
			result = this.FixRelativePath(result);
			return result;
		}
		#endregion

		#region public string GetSignatureContent(string content)
		public string GetSignatureContent(string content)
		{
			string result = this.HideAttachImageAddress(content);
			result = this.RemoveExtraLineBreaks(result);
			result = Utils.ParseEncode.HtmlEncode(result);
			result = this.SetFontStyle(result);
			result = this.FindUrl(result);
			result = this.FixRelativePath(result);
			return result;
		}
		#endregion

		#region private string format(string s)
		private string format(string s)
		{
			string[] p = new string[7];
			string[] r = new string[7];
			p[0] = @"\r";
			r[0] = "";
			p[1] = @"[\v\t�� ]*\n[\v\t�� ]*";
			r[1] = "\n";
			p[2] = @"(\n+)";
			r[2] = "$1����";
			p[3] = @"[\n]{2,}";
			r[3] = "\n\n";
			p[4] = @"\n";
			r[4] = "\r\n";
			p[5] = @"(����!)";
			r[5] = "";
			p[6] = @"����(\[uploadimage)";
			r[6] = "$1";
			return RegexReplace(s, p, r, RegexOptions.IgnoreCase);
		}
		#endregion

		#region private string textEncode(string s)
		//text encode
		private string textEncode(string s)
		{
			StringBuilder sb = new StringBuilder(s);
			sb.Replace("&", "&amp;");
			sb.Replace("<", "&lt;");
			sb.Replace(">", "&gt;");
			return sb.ToString();
		}
		#endregion

		#region 	private string htmlEncode(string str)
		//html encode
		private string htmlEncode(string str)
		{
				string s = replace(str, @"&", "&amp;");
				s = replace(s, @"[ ��]*\r", "");
				s = replace(s, @"  ", "&nbsp; ");
				s = replace(s, @"\t", "&nbsp; &nbsp; ");
				s = replace(s, "\"", "&quot;");
				s = replace(s, @"\'", "&#39;");
				s = replace(s, @"<", "&lt;");
				s = replace(s, @">", "&gt;");
				s = replace(s, "\n", "<BR>");
				return shitEncode(s);
		}
		#endregion

		#region private string shitEncode(string s)
		private string shitEncode(string s)
		{
			return replace(s, @"(���|��b|���|fuck|shit|����|����|����|��)", "**");
		}
		#endregion

		#region private string protectMedia(string s)
		//Protected Media
		private string protectMedia(string s)
		{
			// Protected flash
			s = replace(s, @"\[flash=([0-9]+),([0-9]+)\](.*)\[\/flash\]","<a href='$3' target='_blank'>$3[ȫ�����͡����ѣ��˴���֧�ֶ�ý���ǩ]</a>");
			// Protected media
			s = replace(s, @"\[mp=([0-9]+),([0-9]+),([true|false|1|0]+)\](.*)\[\/mp\]","<a href='$4' target='_blank'>$4[���´�������  ���ѣ��˴���֧�ֶ�ý���ǩ]</a>");
			// Protected real
			s = replace(s, @"\[rm=([0-9]+),([0-9]+),([true|false|1|0]+)\](.*)\[\/rm\]","<a href='$4' target='_blank'>$4[���´�������  ���ѣ��˴���֧�ֶ�ý���ǩ]</a>");
			//
			s = replace(s, @"\[url\]([^\[<]{5,})\[\/url\]", "<a href='$1' target='_blank'>$1</a>");
			s = replace(s, @"\[url=([^\[<]{5,})\]([.*]*)([^\[<]+)\[\/url\]", "<a href='$1' target='_blank'>$3</a>");
			return s;
		}
		#endregion

		#region private string protectHtml(string s)
		//Protected Html
		private string protectHtml(string s)
		{
			string[] p = new string[6];
			string[] r = new string[6];
			p[0] = @"<(\/?script)([^>]*)>";
			r[0] = "&lt;$1$2&gt;";
			p[1] = @"<(\/?applet)([^>]*)>";
			r[1] = "&lt;$1$2&gt;";
			p[2] = @"(javascript|vbscript|script)[\s]*:";
			r[2] = "none:";
			p[3] = @"<([%\?]{1})";
			r[3] = "&lt;$1";
			p[4] = @"([%\?]{1})>";
			r[4] = "$1&gt;";
			p[5] = @"<!\-\-[\s]*#[\s]*include";
			r[5] = "<!-- include";			
			return shitEncode(RegexReplace(s, p, r, RegexOptions.IgnoreCase));
		}
		#endregion

		#region 	private string SupportUbb(string str)
		private string SupportUbb(string str)
		{
			return regExp(this.FindUrl(htmlEncode(str)));
		}
		#endregion

		#region private string SupportHtml(string str)
		private string SupportHtml(string str)
		{
			return regExp(str);
		}
		#endregion

		#region private string regExp(string str)
		//Regex
		private string regExp(string str)
		{
			string s = replace(str, @"\[((\/?b)|(\/?i)|(\/?u)|(\/?h[1-6])|(\/?sub)|(\/?sup)|(\/?center))\]", "<$1>");
			s = replace(s, @"\[color=((#[A-Fa-f0-9]{3})|(#[A-Fa-f0-9]{6})|[a-zA-Z]{3,12})\]", "<span style='color:$1'>");
			s = replace(s, @"\[size=([1-3][0-9])\]", "<span style='font-size:$1px'>");
			s = replace(s, @"\[face=([^\[]+)\]", "<span style='font-family:$1'>");
			s = replace(s, @"\[\/(color|size|face)\]", "</span>");
			//image
			s = replace(s, @"\[img\]([^\[]{5,})\[\/img\]", "<img src='$1' class='image-from-ubb' border='0' alt='image' onload='resizeimage(this);' style='cursor:hand'  />");
			s = replace(s, @"\[img=(left|right)\]([^\[]{5,})\[\/img\]", "<img src='$2' align='$1' class='image-from-ubb' border='0' alt='image' onload='resizeimage(this);'  style='cursor:hand'/>");
			
			//line
			s = replace(s, @"\[line\/\]", "<hr size='1' color='#cccccc' noshade='noshade' />");
			s = replace(s, @"\[line\]\s*(\d{1})\s*,\s*((#[A-Fa-f0-9]{3})|(#[A-Fa-f0-9]{6})|[A-Za-z]{3,12})\s*\[\/line\]", "<hr size='$1' color='$2' noshade='noshade' />");
			//url
			s = replace(s, @"\[url\]([^\[<]{5,})\[\/url\]", "<a href='$1' target='_blank'>$1</a>");

			s = replace(s, @"\[url=([^\[<]{5,})\](.+?)\[\/url\]", "<a href='$1' target='_blank'>$2</a>");

			//email
			s = replace(s, @"\[email\]([^\s@]+@[^\[\.]+\.[^\[]+)\[\/email\]", "<a href='mailto:$1'>$1</a>");
			s = replace(s, @"\[email=([^\s@]+@[^\[\.]+\.[^\[]+)\]([^\[]+)\[\/email\]", "<a href='mailto:$1'>$2</a>");
			//flash
			s = replace(s, @"\[flash=([0-9]+),([0-9]+)\](.*)\[\/flash\]","<embed src='$3' width='$1' height='$2' quality='high' type='application/x-shockwave-flash'></embed><br /><a href='$3' target='_blank'>[ȫ�����͡����ѣ�Flash�п��ܰ�������ȫ����]</a>");
			//media
			s = replace(s, @"\[mp=([0-9]+),([0-9]+),([true|false|1|0]+)\](.*)\[\/mp\]","<object align='middle' classid='clsid:22d6f312-b0f6-11d0-94ab-0080c74c7e95' class='object' id='mediaplayer' width='$1' height='$2'><param name='AUTOSTART' value='$3' /><param name='showstatusbar' value='-1' /><param name='filename' value='$4' /><embed type='application/x-oleobject' codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#version=5,1,52,701' filename='mp' src='$4' width='$1' height='$2'></embed></object>");

			//real
			s = replace(s, @"\[rm=([0-9]+),([0-9]+),([true|false|1|0]+)\](.*)\[\/rm\]","<object classid='clsid:cfcdaa03-8be4-11cf-b84b-0020afbbccfa' class='object' id='raocx' width='$1' height='$2'><param name='src' value='$4'><param name='console' value='clip1' /><param name='controls' value='imagewindow' /><param name='autostart' value='$3' /></object><br /><object classid='clsid:cfcdaa03-8be4-11cf-b84b-0020afbbccfa' height='32' id='video2' width='$1'><param name='src' value='$4' /><param name='autostart' value='$3' /><param name='controls' value='controlpanel' /><param name='console' value='clip1' /></object><br />");
			//code
			s = replace(s, @"\[(\/?)code\]", "[$1CODE]");

			//quote
			s = replace(s, @"\[quotetitle\]([^\[]*)\[\/quotetitle\]", "��&nbsp;<span style='position:relative;top:10px;' class='highlight bg1'>$1</span>");
			s = replace(s, @"\[quote\](<br \/>|&nbsp;)*", "<div class='quote'>");
			s = replace(s, @"\[align=(left|center|right*)\](.*?)\[\/align\]","<div align=\"$1\">$2</div>");
			s = replace(s, @"(<br \/>)*\[\/quote\]", "</div>");

			return this.showCodeBlock(s);
		}
		#endregion

		#region private string codeHighLightCSharp(string str)
		//Set Code Highlight (CSharp)
		private string codeHighLightCSharp(string str)
		{
			string s = replace(str, @"(^|\s|<br \/>|;\s*|\)\s*)(private|protected|internal|public|using|namespace|class|interface|struct|event|virtual|abstract|static|delegate|override|new|readonly|return|break|continue|goto|case|default|sealed|throw)", "$1<span style='color:blue'>$2</span>", RegexOptions.Multiline);
			s = replace(s, @"(else\s+if|if|switch|try|catch|finally|while|for|for\s+each|do|typeof|sizeof)(\s*\(|\s*\{)", "<span style='color:blue'>$1</span>$2");
			s = replace(s, @"(\s+|;\s*|=\s*|\(\s*|,\s*)(null|int|string|void|bool|long|short|byte|char|decimal|double|enum|event|float|object|sbyte|base|this|ulong|ushort|DateTime|true|false|get|set|var)(\s+|\.|\[|\s*\)|\s*;)", "$1<span style='color:blue'>$2</span>$3", RegexOptions.Multiline);
			s = replace(s, @"(\}\s*|\]\s*|\s*\)|^|\s+|<br \/>)(else|is|as|in|is)(\s*\{|\s*\(|$|\s+|<br \/>)", "$1<span style='color:blue'>$2</span>$3");
			s = replace(s, "&quot;", "\"");
			s = replace(s, "\\\\\\\"", "��������", RegexOptions.Multiline);
			s = replace(s, "(\"[^\"]*\")", "<span style='color:#ff00ff'>$1</span>");
			s = replace(s, "��������", "\\\"", RegexOptions.Multiline);
			s = replace(s, @"<span style=\'color:blue\'>class<\/span>(\s*=)", "class$1");
			
			int i = 0;	//define start index
			while ( (i = s.IndexOf("//", i)) != -1)
			{
				if (s.IndexOf("<BR>", i) == -1) break;

				s = s.Substring(0, i) + "<span style='color:green'>" + replace(s.Substring(i, s.IndexOf("<BR>", i) - i), @"<span style=\'color:#?[0-9a-zA-Z]+\'>([^<]+)<\/span>", "$1") + "</span>" + s.Substring(s.IndexOf("<BR>", i));
				i = s.IndexOf("<BR>", i);
			}

			i = 0;	//reset start index
			while ((i = s.IndexOf("/*", i)) != -1)
			{
				if (s.IndexOf("*/", i + 2) == -1) break;

				s = s.Substring(0, i) + "<span style='color:green'>" + replace(s.Substring(i, s.IndexOf("*/", i + 2) + 2 - i), @"<span style=\'color:#?[0-9a-zA-Z]+\'>([^<]+)<\/span>", "$1") + "</span>" + s.Substring(s.IndexOf("*/", i + 2) + 2);
				i = s.IndexOf("*/", i + 2);
			}

			return s;	
		}
		#endregion

		#region private string showCodeBlock(string str)
		//Set Code Block
		private string showCodeBlock(string str)
		{
			string[] arr = Regex.Split(str, @"\[CODE\]",  RegexOptions.IgnoreCase);
			string quoterBegin = "��&nbsp;<span style='position:relative;top:10px;' class='highlight bg1'>������ش���";
			quoterBegin    += " &nbsp; <a id='sender_$index' href=\"javascript:ubb.setCodeSourceDisplayMode('sender_$index', 'codesource_$index')\">[ȫ��ģʽ]</a></span>";
			quoterBegin    += "<div class='grid bg3' style='width:96%; padding:10px 10px 9px 10px; line-height:18px; font-family:���� !important; font-size:12px !important;' id='codesource_$index'>";
			int codeBlockIndex = 0;
			for (int i=0; i<arr.Length; i++)
			{
				string[] subArr = Regex.Split(arr[i], @"\[/CODE\]",  RegexOptions.IgnoreCase);
				if (subArr.Length == 1) continue;

				if (subArr[0].Split('{').Length > 1 && subArr[0].Split(';').Length > 4)
				{
					subArr[0] = codeHighLightCSharp(subArr[0]);	//��������﷨�����������ȥ��
				}
				
				subArr[0] = replace(quoterBegin, @"\$index", codeBlockIndex.ToString()) + subArr[0];
				codeBlockIndex ++;
				arr[i] = join(subArr, "</div>");
			}
			return join(arr, "");
		}
		#endregion

		#region  private string showCodeBlock(string str)
		private string join(string[] arr, string sp)
		{
			string rs = "";
			for (int i = 0; i < arr.Length; i++)
			{
				if(rs == "")
					rs = arr[i];
				else
					rs += sp + arr[i];
			}
			return rs;
		}
		#endregion

		

		#region private string fixRelativePath(string str, string pathUpSeek)
		//fix relative path
		private string fixRelativePath(string str, string pathUpSeek)
		{
			string s = replace(str, @" (href|src)=\'(javascript|vbscript|script):([^\']*)\'", " $1='$3'");
			s = replace(str, @" (href|src)=\'(\/|[a-zA-Z]+:)([^\']*)\'", " $1='$2$3'");
			return s;
		}
		#endregion

	}
}