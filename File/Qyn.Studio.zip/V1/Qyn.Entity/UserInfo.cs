﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class UserInfo
    {
        public class Info_UserInfo
        {
            /// <summary>
            /// 会员ID
            /// </summary>
            public int Id = 0;
            /// <summary>
            /// 帐号ID
            /// </summary>
            public string C_PARTY_ID;
            /// <summary>
            /// 真实姓名
            /// </summary>
            public string SHORT_NAME;
            /// <summary>
            /// 是否
            /// </summary>
            public bool IS_LINE;
            /// <summary>
            /// 是否禁言
            /// </summary>
            public bool IsSend;
            /// <summary>
            /// 是否禁登
            /// </summary>
            public bool IsLG;
            /// <summary>
            /// 是否激活
            /// </summary>
            public bool IsLine;
            /// <summary>
            /// 退钱总金额
            /// </summary>
            public decimal EX_ALL_MONEY;
            /// <summary>
            /// 钱
            /// </summary>
            public decimal Money;
            /// <summary>
            /// 充值总金额
            /// </summary>
            public decimal MAX_IN_MONEY;
            /// <summary>
            /// 输的次数
            /// </summary>
            public int ALL_NUM_EXPENSE;
            /// <summary>
            /// 玩的次数
            /// </summary>
            public int PLAY_NUM;
            /// <summary>
            /// 赢的总金额
            /// </summary>
            public decimal ALL_MONEY_WIN;
            /// <summary>
            /// 输的总金额
            /// </summary>
            public decimal ALL_MONEY_EXPENSE;
            /// <summary>
            /// 赢的次数
            /// </summary>
            public int ALL_NUM_WIN;
            /// <summary>
            /// 游戏名
            /// </summary>
            public string NAME_CN;
            /// <summary>
            /// 等级
            /// </summary>
            public int GRADE;
            /// <summary>
            /// 注册的IP地址
            /// </summary>
            public string LOGIN_IP;
            /// <summary>
            /// 推广员ID
            /// </summary>
            public string PARTENER_PARTY_ID;
            /// <summary>
            /// EMAIL
            /// </summary>
            public string EMAIL;
            /// <summary>
            /// MSN
            /// </summary>
            public string MSN;
            /// <summary>
            /// 移动电话
            /// </summary>
            public string TEL;
        }

        public class Modify_UserInfo
        {
            /// <summary>
            /// 条件从句:会员ID
            /// </summary>
            public int Condition_Id = 0;
            /// <summary>
            /// 是否
            /// </summary>
            public bool IS_LINE;
            /// <summary>
            /// 是否禁言
            /// </summary>
            public bool IsSend;
            /// <summary>
            /// 是否禁登
            /// </summary>
            public bool IsLG;
            /// <summary>
            /// 是否激活
            /// </summary>
            public bool IsLine;
            /// <summary>
            /// 退钱总金额
            /// </summary>
            public decimal EX_ALL_MONEY;
            /// <summary>
            /// 钱
            /// </summary>
            public decimal Money;
            /// <summary>
            /// 充值总金额
            /// </summary>
            public decimal MAX_IN_MONEY;
            /// <summary>
            /// 输的次数
            /// </summary>
            public int ALL_NUM_EXPENSE;
            /// <summary>
            /// 玩的次数
            /// </summary>
            public int PLAY_NUM;
            /// <summary>
            /// 赢的总金额
            /// </summary>
            public decimal ALL_MONEY_WIN;
            /// <summary>
            /// 输的总金额
            /// </summary>
            public decimal ALL_MONEY_EXPENSE;
            /// <summary>
            /// 赢的次数
            /// </summary>
            public int ALL_NUM_WIN;
            /// <summary>
            /// 等级
            /// </summary>
            public int GRADE;
            /// <summary>
            /// 注册的IP地址
            /// </summary>
            public string LOGIN_IP;
            /// <summary>
            /// 推广员ID
            /// </summary>
            public string PARTENER_PARTY_ID;
            /// <summary>
            /// EMAIL
            /// </summary>
            public string EMAIL;
            /// <summary>
            /// 移动电话
            /// </summary>
            public string TEL;
        }
    }
}
