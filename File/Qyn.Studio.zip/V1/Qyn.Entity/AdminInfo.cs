﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;

namespace Qyn.Entity
{
    #region 管理员信息描述类

    public class AdminInfo
    {
        #region 私有字段
        private int m_ID;
        private string m_UserName;
        private string m_PassWord;
        private string m_LastLoginTime;
        private string m_AddIP;
        private string m_AddAdminUser;
        private string m_AddTime;
        private string m_LastLoginIP;
        private string m_LoginCount;
        private string m_Purview;
        #endregion

        #region 属性
        public int ID
        {
            get { return m_ID; }
            set { m_ID = value; }
        }
        public string UserName
        {
            get { return m_UserName; }
            set { m_UserName = value; }
        }
        public string PassWord
        {
            get { return m_PassWord; }
            set { m_PassWord = value; }
        }
        public string LastLoginTime
        {
            get { return m_LastLoginTime; }
            set { m_LastLoginTime = value; }
        }
        public string AddIP
        {
            get { return m_AddIP; }
            set { m_AddIP = value; }
        }
        public string AddAdminUser
        {
            get { return m_AddAdminUser; }
            set { m_AddAdminUser = value; }
        }
        public string AddTime
        {
            get { return m_AddTime; }
            set { m_AddTime = value; }
        }
        public string LastLoginIP
        {
            get { return m_LastLoginIP; }
            set { m_LastLoginIP = value; }
        }
        public string LoginCount
        {
            get { return m_LoginCount; }
            set { m_LoginCount = value; }
        }
        public string Purview
        {
            get { return m_Purview; }
            set { m_Purview = value; }
        }
        #endregion
    }

    #endregion
}
