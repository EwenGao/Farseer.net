﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class LeaveWordsInfo
    {
        #region 私有字段
        /// <summary>
        /// 记录ID
        /// </summary>
        private int l_Id;

        /// <summary>
        /// 提问日期
        /// </summary>
        private string l_Date;

        /// <summary>
        /// 提问者ID
        /// </summary>
        private int l_UserId;

        /// <summary>
        /// 提问者姓名
        /// </summary>
        private string l_UserName;
        /// <summary>
        /// 提问标题
        /// </summary>
        private string l_Caption;
        /// <summary>
        /// 提问内容
        /// </summary>
        private string l_UserContent;

        /// <summary>
        /// 管理员ID
        /// </summary>
        private int l_AdminId;

        /// <summary>
        /// 管理员姓名
        /// </summary>
        private string l_AdminUser;

        /// <summary>
        /// 管理员回复内容
        /// </summary>
        private string l_AdminContent;

        /// <summary>
        /// 管理员回复日期
        /// </summary>
        private string l_AdminDate;

        #endregion

        #region 共公字段
        /// <summary>
        /// 管理员姓名
        /// </summary>
        public string AdminUser
        {
            get { return l_AdminUser; }
            set { l_AdminUser = value; }
        }
        /// <summary>
        /// 管理员ID
        /// </summary>
        public int AdminId
        {
            get { return l_AdminId; }
            set { l_AdminId = value; }
        }


        /// <summary>
        /// 提问标题
        /// </summary>
        public string Caption
        {
            get { return l_Caption; }
            set { l_Caption = value; }
        }  


        /// <summary>
        /// 用户提问内容
        /// </summary>
        public string UserContent
        {
            get { return l_UserContent; }
            set { l_UserContent = value; }
        }
        /// <summary>
        /// 提问者姓名
        /// </summary>
        public string UserName
        {
            get { return l_UserName; }
            set { l_UserName = value; }
        }
        
      
        /// <summary>
        /// 提问者ID
        /// </summary>
        public int UserId
        {
            get { return l_UserId; }
            set { l_UserId = value; }
        }
        /// <summary>
        /// 提问日期
        /// </summary>
        public string Date
        {
            get { return l_Date; }
            set { l_Date = value; }
        }

        /// <summary>
        /// 记录ID
        /// </summary>
        public int Id
        {
            get { return l_Id; }
            set { l_Id = value; }
        }

        /// <summary>
        /// 管理员回复内容
        /// </summary>
        public string AdminContent
        {
            get { return l_AdminContent; }
            set { l_AdminContent = value; }
        }

        /// <summary>
        /// 管理员回复日期
        /// </summary>
        public string AdminDate
        {
            get { return l_AdminDate; }
            set { l_AdminDate = value; }
        }
        #endregion
    }
}
