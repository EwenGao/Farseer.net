﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
	public class CategoryInfo
	{
		#region 私有字段
			/// <summary>
			/// 类ID
			/// </summary>
			private int m_Id;
			
			/// <summary>
			/// 所属ID
			/// </summary>
			private int m_ParentId;
			
			/// <summary>
			/// 类名
			/// </summary>
			private string m_Name;
			
			/// <summary>
			/// 广告(大)
			/// </summary>
			private string m_AdImagesBig="";
			
			/// <summary>
			/// 广告(中)
			/// </summary>
            private string m_AdImagesMedium = "";
			
			/// <summary>
			/// 广告(小)
			/// </summary>
            private string m_AdImagesSmall = "";


            /// <summary>
            /// 广告(大)链接ID
            /// </summary>
            private int m_AdBigID;
            /// <summary>
            /// 广告(中)链接ID
            /// </summary>
            private int m_AdMediumID;


		#endregion

		#region 公共属性
			/// <summary>
			/// 类ID
			/// </summary>
			public int Id
			{
				get { return m_Id; }
				set { m_Id = value; }
			}

			/// <summary>
			/// 所属ID
			/// </summary>
			public int ParentId
			{
				get { return m_ParentId; }
				set { m_ParentId = value; }
			}

			/// <summary>
			/// 类名
			/// </summary>
			public string Name
			{
				get { return m_Name; }
				set { m_Name = value; }
			}

			/// <summary>
			/// 广告(大)
			/// </summary>
			public string AdImagesBig
			{
				get { return m_AdImagesBig; }
				set { m_AdImagesBig = value; }
			}

			/// <summary>
			/// 广告(中)
			/// </summary>
			public string AdImagesMedium
			{
				get { return m_AdImagesMedium; }
				set { m_AdImagesMedium = value; }
			}

			/// <summary>
			/// 广告(小)
			/// </summary>
			public string AdImagesSmall
			{
				get { return m_AdImagesSmall; }
				set { m_AdImagesSmall = value; }
			}

            /// <summary>
            /// 广告(大)链接ID
            /// </summary>
            public int AdBigID
            {
                get { return m_AdBigID; }
                set { m_AdBigID = value; }
            }
            /// <summary>
            /// 广告(中)链接ID
            /// </summary>
            public int AdMediumID
            {
                get { return m_AdMediumID; }
                set { m_AdMediumID = value; }
            }


		#endregion
	}
}