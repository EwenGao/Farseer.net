using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class VoucherInfo
    {
        /// <summary>
        /// ��ֵ��Ϣ
        /// </summary>
        public class Get_Info
        {
            /// <summary>
            /// ��¼ID
            /// </summary>
            public int U_CHARGE_ID;

            /// <summary>
            /// ��׼����
            /// </summary>
            public string DATE_APPLY;

            /// <summary>
            /// ����ʺ�
            /// </summary>
            public string C_PARTY_ID;

            /// <summary>
            /// �ύ����
            /// </summary>
            public string DATE_CREATE;

            /// <summary>
            /// ������
            /// </summary>
            public decimal MONEY_APPLY;

            /// <summary>
            /// Ӧ��ֵ���
            /// </summary>
            public decimal MONEY_SHOULE;

            /// <summary>
            /// ���ӱ���
            /// </summary>
            public int RATE_SUBJOIN;

            /// <summary>
            /// ���ӽ��
            /// </summary>
            public decimal MOENY_SUBJOIN;

            /// <summary>
            /// ʵ�ʽ�Ӱ�쵽�û������ܽ���ֶΣ�
            /// </summary>
            public decimal MOENY_ACTUAL;

            /// <summary>
            /// ��ע
            /// </summary>
            public string REMARK;

            /// <summary>
            /// ����ԱID
            /// </summary>
            public string OP_PARTY_ID;

            /// <summary>
            /// �Ƿ��Ѵ���
            /// </summary>
            public bool IS_OP;

            /// <summary>
            /// ��������
            /// </summary>
            public string BANK_NAME;

            /// <summary>
            /// ���к���
            /// </summary>
            public string BANK_NUMBER;

            /// <summary>
            /// ����
            /// </summary>
            public string BANK_DESC;

            /// <summary>
            /// ����������
            /// </summary>
            public string CHARGE_NAME;
        }

        public class Modify_Info
        {
            /// <summary>
            /// ��¼ID
            /// </summary>
            public int U_CHARGE_ID;
        }
    }
}
