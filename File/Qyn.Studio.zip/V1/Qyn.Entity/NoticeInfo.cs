﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class NoticeInfo
    {
        /// <summary>
        /// 公告信息
        /// </summary>
        public class Info_Notice 
        {
            /// <summary>
            /// 公告的Id
            /// </summary>
            public int Id;

            /// <summary>
            /// 公告标题
            /// </summary>
            public string Title;

            /// <summary>
            /// 公告内容
            /// </summary>
            public string Content;

            /// <summary>
            /// 公告日期
            /// </summary>
            public string Date;

            /// <summary>
            /// 添加人帐号
            /// </summary>
            public string AdminName;

        }

        /// <summary>
        /// 添加公告
        /// </summary>
        public class Add_Notice 
        {
            /// <summary>
            /// 公告标题
            /// </summary>
            public string Title;

            /// <summary>
            /// 公告内容
            /// </summary>
            public string Content;

            /// <summary>
            /// 公告日期
            /// </summary>
            public string Date;

            /// <summary>
            /// 添加人帐号
            /// </summary>
            public string AdminName;

        }

        /// <summary>
        /// 修改公告
        /// </summary>
        public class Modify_Notice 
        {
            /// <summary>
            /// 修改公告的Id
            /// </summary>
            public int Condition_Id;

            /// <summary>
            /// 公告标题
            /// </summary>
            public string Title;

            /// <summary>
            /// 公告内容
            /// </summary>
            public string Content;

            /// <summary>
            /// 公告日期
            /// </summary>
            public string Date;

            /// <summary>
            /// 修改人帐号
            /// </summary>
            public string AdminName;

        }
    }
}
