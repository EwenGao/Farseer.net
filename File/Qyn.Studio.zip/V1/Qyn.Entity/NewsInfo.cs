﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
	public class NewsInfo
	{
		#region 私有字段
			/// <summary>
			/// 新闻Id
			/// </summary>
			private int m_Id;
			
			/// <summary>
			/// 新闻标题
			/// </summary>
			private string m_Caption;

			/// <summary>
			/// 新闻内容
			/// </summary>
			private string m_Content;

			/// <summary>
			/// 新闻日期
			/// </summary>
			private string m_Date;

			/// <summary>
			/// 新闻点击率
			/// </summary>
			private int m_BrowseCount;

			/// <summary>
			/// 管理员ID
			/// </summary>
			private int m_AdminId;

			/// <summary>
			/// 管理员名字
			/// </summary>
			private string m_AdminName;
			

		#endregion

		#region 公共属性
			/// <summary>
			/// 新闻Id
			/// </summary>
			public int Id
			{
				get { return m_Id; }
				set { m_Id = value; }
			}
			/// <summary>
			/// 新闻标题
			/// </summary>
			public string Caption
			{
				get { return m_Caption; }
				set { m_Caption = value; }
			}
			/// <summary>
			/// 新闻内容
			/// </summary>
			public string Content
			{
				get { return m_Content; }
				set { m_Content = value; }
			}
			/// <summary>
			/// 新闻日期
			/// </summary>
			public string Date
			{
				get { return m_Date; }
				set { m_Date = value; }
			}
			/// <summary>
			/// 新闻点击率
			/// </summary>
			public int BrowseCount
			{
				get { return m_BrowseCount; }
				set { m_BrowseCount = value; }
			}
			/// <summary>
			/// 管理员ID
			/// </summary>
			public int AdminId
			{
				get { return m_AdminId; }
				set { m_AdminId = value; }
			}
			/// <summary>
			/// 管理员名字
			/// </summary>
			public string AdminName
			{
				get { return m_AdminName; }
				set { m_AdminName = value; }
			}
		#endregion
	}
}
