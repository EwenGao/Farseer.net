﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    /// <summary>
    /// 订单号信息
    /// </summary>
    public class OrderDetailInfo
    {

        #region 字段
        /// <summary>
        /// 订单号Id
        /// </summary>
        private int m_Id;
        
        /// <summary>
        /// 订单号
        /// </summary>
        private string m_OrderNumber;
        
        /// <summary>
        /// 商品Id
        /// </summary>
        private int m_ProductId;
        
        /// <summary>
        /// 商品数量
        /// </summary>
        private int m_Quantity;
        
        /// <summary>
        /// 商品单价
        /// </summary>
        private int m_Price;

        /// <summary>
        /// 商品小计
        /// </summary>
        private int m_SubTotal;

        /// <summary>
        /// 商品颜色
        /// </summary>
        private string  m_o_Color;

        #endregion


        


        #region 属性
        /// <summary>
        /// 订单号Id
        /// </summary>
        public int Id
        {
            get { return m_Id; }
            set { m_Id = value; }
        }

        /// <summary>
        /// 订单号
        /// </summary>
        public string OrderNumber
        {
            get { return m_OrderNumber; }
            set { m_OrderNumber = value; }
        }

        /// <summary>
        /// 商品Id
        /// </summary>
        public int ProductId
        {
            get { return m_ProductId; }
            set { m_ProductId = value; }
        }

        /// <summary>
        /// 商品数量
        /// </summary>
        public int Quantity
        {
            get { return m_Quantity; }
            set { m_Quantity = value; }
        }

        /// <summary>
        /// 商品单价
        /// </summary>
        public int Price
        {
            get { return m_Price; }
            set { m_Price = value; }
        }


        /// <summary>
        /// 商品小计
        /// </summary>
        public int SubTotal
        {
            get { return m_SubTotal; }
            set { m_SubTotal = value; }
        }


        /// <summary>
        /// 商品颜色
        /// </summary>
        public string Color
        {
            get { return m_o_Color; }
            set { m_o_Color = value; }
        }
        

        #endregion
    }
}
