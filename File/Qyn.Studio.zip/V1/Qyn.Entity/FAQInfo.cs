﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    /// <summary>
    /// 问答管理
    /// </summary>
    public class FAQInfo
    {
        /// <summary>
        /// 问答信息
        /// </summary>
        public class Info_FAQ
        {
            /// <summary>
            /// 记录ID
            /// </summary>
            public int FAQId;
            /// <summary>
            /// 问题标题
            /// </summary>
            public string FAQCaption;
            /// <summary>
            /// 提问内容
            /// </summary>
            public string FAQAsk;
            /// <summary>
            /// 管理员回答
            /// </summary>
            public string FAQResult;
            /// <summary>
            /// 提问者名字
            /// </summary>
            public string FAQClientName;
            /// <summary>
            /// 回答者名字
            /// </summary>
            public string FAQEmployeeName;
            /// <summary>
            /// 提问时间
            /// </summary>
            public string FAQAskDate;
            /// <summary>
            /// 回答时间
            /// </summary>
            public string FAQResultDate;
        }

        /// <summary>
        /// 回复问题
        /// </summary>
        public class Revert_FAQ
        {
            /// <summary>
            /// 记录ID
            /// </summary>
            public int Condition_FAQId;
            /// <summary>
            /// 管理员回答
            /// </summary>
            public string FAQResult;
            /// <summary>
            /// 回答者ID
            /// </summary>
            public string FAQEmployeeName;
            /// <summary>
            /// 回答时间
            /// </summary>
            public string FAQResultDate;
        }
    }
}
