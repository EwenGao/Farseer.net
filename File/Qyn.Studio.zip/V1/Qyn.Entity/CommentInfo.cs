using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class CommentInfo
    {
        #region ˽���ֶ�
            /// <summary>
            /// ��¼ID
            /// </summary>
            private int m_Id;
            
            /// <summary>
            /// ��Ʒ����ID
            /// </summary>
            private int m_ProductId;
           
            /// <summary>
            /// ��������
            /// </summary>
            private string m_Date;
            
            /// <summary>
            /// ������ID
            /// </summary>
            private int m_UserId;
            
            /// <summary>
            /// ����������
            /// </summary>
            private string m_UserName;
            
            /// <summary>
            /// �û���������
            /// </summary>
            private string m_UserContent;
            
            /// <summary>
            /// ����ԱID
            /// </summary>
            private int m_AdminId;
            
            /// <summary>
            /// ����Ա����
            /// </summary>
            private string m_AdminUser;
            
            /// <summary>
            /// ����Ա�ظ�����
            /// </summary>
            private string m_AdminContent;

			/// <summary>
			/// ����Ա�ظ�����
			/// </summary>
			private string m_AdminDate;

        #endregion

        #region �����ֶ�
            /// <summary>
            /// ����Ա����
            /// </summary>
            public string AdminUser
            {
                get { return m_AdminUser; }
                set { m_AdminUser = value; }
            }
            /// <summary>
            /// ����ԱID
            /// </summary>
            public int AdminId
            {
                get { return m_AdminId; }
                set { m_AdminId = value; }
            }
            /// <summary>
            /// �û���������
            /// </summary>
            public string UserContent
            {
                get { return m_UserContent; }
                set { m_UserContent = value; }
            }
            /// <summary>
            /// ����������
            /// </summary>
            public string UserName
            {
                get { return m_UserName; }
                set { m_UserName = value; }
            }
            /// <summary>
            /// ������ID
            /// </summary>
            public int UserId
            {
                get { return m_UserId; }
                set { m_UserId = value; }
            }
            /// <summary>
            /// ��������
            /// </summary>
            public string Date
            {
                get { return m_Date; }
                set { m_Date = value; }
            }
            /// <summary>
            /// ��Ʒ����ID
            /// </summary>
            public int ProductId
            {
                get { return m_ProductId; }
                set { m_ProductId = value; }
            }
            /// <summary>
            /// ��¼ID
            /// </summary>
            public int Id
            {
                get { return m_Id; }
                set { m_Id = value; }
            }

            /// <summary>
            /// ����Ա�ظ�����
            /// </summary>
            public string AdminContent
            {
                get { return m_AdminContent; }
                set { m_AdminContent = value; }
            }

			/// <summary>
			/// ����Ա�ظ�����
			/// </summary>
			public string AdminDate
			{
				get { return m_AdminDate; }
				set { m_AdminDate = value; }
			}
        #endregion
        
    }
}
