﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
	public class CartInfo
	{
		#region 私有字段
			/// <summary>
			/// 购物车ID
			/// </summary>
			private int m_Id = 0;

			/// <summary>
			/// 商品Id
			/// </summary>
			private int m_ProductId = 0;

			/// <summary>
			/// 商品名
			/// </summary>
			private string m_ProductName = "";

            /// <summary>
            /// 商品图片(小)
            /// </summary>
            private string m_ImageSmall = "";
            
			/// <summary>
			/// 商品实价
			/// </summary>
			private decimal m_RealPrice = 0;

			/// <summary>
			/// 商品数量
			/// </summary>
			private int m_ProductCount = 1;

			/// <summary>
			/// 商品结帐
			/// </summary>
			private decimal m_SumPrice = 0;


            /// <summary>
            /// 商品结帐
            /// </summary>
            private string  m_Color ="";
		#endregion

		#region 公共字段
		/// <summary>
		/// 购物车Id
		/// </summary>
		public int Id
		{
			get { return m_Id; }
			set { m_Id = value; }
		}
		/// <summary>
		/// 商品Id
		/// </summary>
		public int ProductId
		{
			get { return m_ProductId; }
			set { m_ProductId = value; }
		}
		/// <summary>
		/// 商品名字
		/// </summary>
		public string ProductName
		{
			get { return m_ProductName; }
			set { m_ProductName = value; }
		}

        /// <summary>
        /// 商品图片(小)
        /// </summary>
        public string ImageSmall
        {
            get { return m_ImageSmall; }
            set { m_ImageSmall = value; }
        }

		/// <summary>
		/// 商品实价
		/// </summary>
		public decimal RealPrice
		{
			get { return m_RealPrice; }
			set { m_RealPrice = value; }
		}
		/// <summary>
		/// 商品数量
		/// </summary>
		public int ProductCount
		{
			get { return m_ProductCount; }
			set { m_ProductCount = value; }
		}
		/// <summary>
		/// 商品总价
		/// </summary>
		public decimal SumPrice
		{
			get { return m_SumPrice; }
			set { m_SumPrice = value; }
		}

        /// <summary>
        /// 商品颜色
        /// </summary>
        public string Color
        {
            get { return m_Color; }
            set { m_Color = value; }
        }

        #endregion
	}
}
