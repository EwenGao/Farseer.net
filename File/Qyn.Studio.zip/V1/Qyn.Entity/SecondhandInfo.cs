﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class SecondhandInfo
    {
        #region 私有字段

        /// <summary>
        /// 二手货ID
        /// </summary>
        private int m_ID;

        /// <summary>
        /// 帖子标识ID，0为第一个帖子
        /// </summary>
        private int m_PostID;

        /// <summary>
        /// 二手货编号
        /// </summary>
        private string m_SecondhandNum;

        /// <summary>
        /// 发表日期
        /// </summary>
        private string m_Date;

        /// <summary>
        /// 用户Id
        /// </summary>
        private int m_UserId;

        /// <summary>
        /// 评价标题
        /// </summary>
        private string m_Caption;

        /// <summary>
        /// 评价内容
        /// </summary>
        private string m_Content;

        /// <summary>
        /// 商品图片
        /// </summary>
        private string m_ProductImages;

        #endregion

        #region 公共属性

        /// <summary>
        /// 二手货ID
        /// </summary>
        public int ID
        {
            get { return m_ID; }
            set { m_ID = value; }
        }

        /// <summary>
        /// 帖子标识ID，0为第一个帖子
        /// </summary>
        public int PostID
        {
            get { return m_PostID; }
            set { m_PostID = value; }
        }

        /// <summary>
        /// 二手货编号
        /// </summary>
        public string SecondhandNum
        {
            get { return m_SecondhandNum; }
            set { m_SecondhandNum = value; }
        }

        /// <summary>
        /// 发表日期
        /// </summary>
        public string Date
        {
            get { return m_Date; }
            set { m_Date = value; }
        }

        /// <summary>
        /// 用户Id
        /// </summary>
        public int UserId
        {
            get { return m_UserId; }
            set { m_UserId = value; }
        }

        /// <summary>
        /// 评价标题
        /// </summary>
        public string Caption
        {
            get { return m_Caption; }
            set { m_Caption = value; }
        }

        /// <summary>
        /// 评价内容
        /// </summary>
        public string Content
        {
            get { return m_Content; }
            set { m_Content = value; }
        }

        /// <summary>
        /// 商品图片
        /// </summary>
        public string ProductImages
        {
            get { return m_ProductImages; }
            set { m_ProductImages = value; }
        }

        #endregion
    }
}
