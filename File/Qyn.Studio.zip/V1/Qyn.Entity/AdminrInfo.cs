﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class AdminInfo
    {
        /// <summary>
        /// 管理员信息
        /// </summary>
        public class Info_Admin
        {
            /// <summary>
            /// 管理员ID
            /// </summary>
            public int Id = 0;

            /// <summary>
            /// 管理员名称
            /// </summary>
            public string AdminName;

            /// <summary>
            /// 管理员登陆名(只用于登陆)
            /// </summary>
            public string LoginName;

            /// <summary>
            /// 密码
            /// </summary>
            public string PassWord;

            /// <summary>
            /// 是否可以继续使用
            /// </summary>
            public bool IsEnable;

            /// <summary>
            /// 注册日期
            /// </summary>
            public string RegisterDate;

            /// <summary>
            /// 备注
            /// </summary>
            public string Remark;
        }

        /// <summary>
        /// 添加管理员
        /// </summary>
        public class Add_Admin
        {
            /// <summary>
            /// 管理员名称(超级管理员才可以修改)
            /// </summary>
            public string AdminName;

            /// <summary>
            /// 管理员登陆名(只用于登陆)
            /// </summary>
            public string LoginName;

            /// <summary>
            /// 密码
            /// </summary>
            public string PassWord;

            /// <summary>
            /// 注册日期
            /// </summary>
            public string RegisterDate;

            /// <summary>
            /// 备注
            /// </summary>
            public string Remark;
        }

        /// <summary>
        /// 修改管理员
        /// </summary>
        public class Modify_Admin
        {
            /// <summary>
            /// 条件从句:管理员ID
            /// </summary>
            public int Condition_Id = 0;

            /// <summary>
            /// 管理员名称(超级管理员才可以修改)
            /// </summary>
            public string AdminName;

            /// <summary>
            /// 管理员登陆名(只用于登陆)
            /// </summary>
            public string LoginName;

            /// <summary>
            /// 密码
            /// </summary>
            public string PassWord;

            /// <summary>
            /// 是否可以继续使用
            /// </summary>
            public bool IsEnable;

            /// <summary>
            /// 注册日期
            /// </summary>
            public string RegisterDate;

            /// <summary>
            /// 备注
            /// </summary>
            public string Remark;
        }

        /// <summary>
        /// 管理员状态
        /// </summary>
        public enum Admin_Status
        {
            /// <summary>
            /// 密码错误
            /// </summary>
            ErrorPassWord = 0,

            /// <summary>
            /// 帐号被冻结
            /// </summary>
            Freeze = 1,

            /// <summary>
            /// 权限为管理员
            /// </summary>
            IsAdmin = 2,

            /// <summary>
            /// 权限为推广员
            /// </summary>
            IsSpreader = 3
        }

    }
}
