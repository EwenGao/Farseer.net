﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
	/// <summary>
	/// 商品信息描述
	/// </summary>
	public class ProductInfo
	{
		#region 私有字段

			/// <summary>
			/// 商品Id
			/// </summary>
			private int m_Id=0;

			/// <summary>
			/// 商品名字
			/// </summary>
			private string m_Name="";

			/// <summary>
			/// 类别名
			/// </summary>
            private string m_CategoryName = "";

			/// <summary>
			/// 商品数量
			/// </summary>
            private int m_Quantity = 0;

			/// <summary>
			/// 商品价格
			/// </summary>
			private string  m_Price="";

            /// <summary>
            /// 商品生产地
            /// </summary>
            private string m_Yieldly ="";

			/// <summary>
			/// 是否特价商品
			/// </summary>
			private bool m_Cheap =false;

			/// <summary>
			/// 商品图片大
			/// </summary>
            private string m_ImageBig = "";

			/// <summary>
			/// 商品图片中
			/// </summary>
            private string m_ImageMedium = "";

			/// <summary>
			/// 商品图片小
			/// </summary>
            private string m_ImageSmall = "";

			/// <summary>
			/// 商品推荐
			/// </summary>
			private bool m_Recommend =false;

			/// <summary>
			/// 商品类型
			/// </summary>
			private int m_CategoryId = 0;

			/// <summary>
			/// 商品照片组,用|号分隔
			/// </summary>
            private string m_Images = "";

			/// <summary>
			/// 商品参数组,用|号分隔
			/// </summary>
            private string m_Parameters = "";

			/// <summary>
			/// 商品上市时间
			/// </summary>
            private string m_MarketDate = "1900-01-01";

			/// <summary>
			/// 商品添加者Id
			/// </summary>
			private int m_AdderId=0;

            /// <summary>
            /// 商品添加者
            /// </summary>
            private string m_Adder="";

			/// <summary>
			/// 商品添加时间
			/// </summary>
			private string m_AddTime="1900-01-01";

			/// <summary>
			/// 商品最后浏览时间
			/// </summary>
			private string m_LastBrowseTime="1900-01-01";

			/// <summary>
			/// 商品最后交易者Id
			/// </summary>
			private int m_LastTradeUserId=0;

            /// <summary>
            /// 商品最后交易者
            /// </summary>
            private string m_LastTradeUser="";

			/// <summary>
			/// 商品最后交易时间
			/// </summary>
			private string m_LastTradeTime="1900-01-01";

			/// <summary>
			/// 商品简介
			/// </summary>
			private string m_Introduction="";

			/// <summary>
			/// 商品显示状态
			/// </summary>
			private bool m_Status =true;

			/// <summary>
			/// 商品积分
			/// </summary>
			private int m_Integral =0;
			
			/// <summary>
			/// 浏览次数
			/// </summary>
			private int m_BrowseCount =0 ;

			/// <summary>
			/// 购买次数
			/// </summary>
			private int m_BuyCount =0;

			/// <summary>
			/// 商品评论次数
			/// </summary>
			private int m_CommentCount = 0;

		#endregion

		#region	公共属性

			/// <summary>
			/// 商品Id
			/// </summary>
			public int Id
			{
				get { return m_Id; }
				set { m_Id = value; }
			}
				
			/// <summary>
			/// 商品名字
			/// </summary>
			public string Name
			{
				get { return m_Name; }
				set { m_Name = value; }
			}

			/// <summary>
			/// 类别名
			/// </summary>
			public string CategoryName
			{
				get { return m_CategoryName; }
				set { m_CategoryName = value; }
			}
			
			/// <summary>
			/// 商品数量
			/// </summary>
			public int Quantity
			{
				get { return m_Quantity; }
				set { m_Quantity = value; }
			}

			/// <summary>
			/// 商品价格
			/// </summary>
			public string  Price
			{
				get { return m_Price; }
				set { m_Price = value; }
			}

            /// <summary>
            /// 商品生产地
            /// </summary>
            public string Yieldly
            {
                get { return m_Yieldly; }
                set { m_Yieldly = value; }
            }

			/// <summary>
			/// 是否特价商品
			/// </summary>
			public bool Cheap
			{
				get { return m_Cheap; }
				set { m_Cheap = value; }
			}
				
			/// <summary>
			/// 商品图片大
			/// </summary>
			public string ImageBig
			{
				get { return m_ImageBig; }
				set { m_ImageBig = value; }
			}
				
			/// <summary>
			/// 商品图片中
			/// </summary>
			public string ImageMedium
			{
				get { return m_ImageMedium; }
				set { m_ImageMedium = value; }
			}

			/// <summary>
			/// 商品图片小
			/// </summary>
			public string ImageSmall
			{
				get { return m_ImageSmall; }
				set { m_ImageSmall = value; }
			}
				
			/// <summary>
			/// 商品推荐
			/// </summary>
			public bool Recommend
			{
				get { return m_Recommend; }
				set { m_Recommend = value; }
			}

			/// <summary>
			/// 商品类型
			/// </summary>
			public int CategoryId
			{
				get { return m_CategoryId; }
				set { m_CategoryId = value; }
			}

			/// <summary>
			/// 商品照片组,用|号分隔
			/// </summary>
			public string Images
			{
				get { return m_Images; }
				set { m_Images = value; }
			}

			/// <summary>
			/// 商品参数组,用|号分隔
			/// </summary>
			public string Parameters
			{
				get { return m_Parameters; }
				set { m_Parameters = value; }
			}

			/// <summary>
			/// 商品上市时间
			/// </summary>
			public string MarketDate
			{
				get { return m_MarketDate; }
				set { m_MarketDate = value; }
			}

			/// <summary>
			/// 商品添加者Id
			/// </summary>
			public int AdderId
			{
				get { return m_AdderId; }
				set { m_AdderId = value; }
			}

            /// <summary>
            /// 商品添加者
            /// </summary>
            public string Adder
            {
                get { return m_Adder; }
                set { m_Adder = value; }
            }

			/// <summary>
			/// 商品上架时间
			/// </summary>
			public string AddTime
			{
				get { return m_AddTime; }
				set { m_AddTime = value; }
			}
				
			/// <summary>
			/// 商品最后浏览时间
			/// </summary>
			public string LastBrowseTime
			{
				get { return m_LastBrowseTime; }
				set { m_LastBrowseTime = value; }
			}

			/// <summary>
			/// 商品最后交易时间
			/// </summary>
			public string LastTradeTime
			{
				get { return m_LastTradeTime; }
				set { m_LastTradeTime = value; }
			}

			/// <summary>
			/// 商品最后交易者Id
			/// </summary>
			public int LastTradeUserId
			{
				get { return m_LastTradeUserId; }
				set { m_LastTradeUserId = value; }
			}

            /// <summary>
            /// 商品最后交易者
            /// </summary>
            public string LastTradeUser
            {
                get { return m_LastTradeUser; }
                set { m_LastTradeUser = value; }
            }

			/// <summary>
			/// 商品简介
			/// </summary>
			public string Introduction
			{
				get { return m_Introduction; }
				set { m_Introduction = value; }
			}

			/// <summary>
			/// 商品显示状态
			/// </summary>
			public bool Status
			{
				get { return m_Status; }
				set { m_Status = value; }
			}
			
			/// <summary>
			/// 商品积分
			/// </summary>
			public int Integral
			{
				get { return m_Integral; }
				set { m_Integral = value; }
			}

			/// <summary>
			/// 浏览次数
			/// </summary>
			public int BrowseCount
			{
				get { return m_BrowseCount; }
				set { m_BrowseCount = value; }
			}

			/// <summary>
			/// 购买次数
			/// </summary>
			public int BuyCount
			{
				get { return m_BuyCount; }
				set { m_BuyCount = value; }
			}

			/// <summary>
			/// 商品评论次数
			/// </summary>
			public int CommentCount
			{
				get { return m_CommentCount; }
				set { m_CommentCount = value; }
			}
		#endregion
		
	}
}
