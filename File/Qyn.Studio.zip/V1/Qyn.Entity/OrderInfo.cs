﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
	/// <summary>
	/// 订单信息
	/// </summary>
	public class OrderInfo
	{
		#region 私有字段
			/// <summary>
			/// 订单Id
			/// </summary>
			private int m_Id;

            /// <summary>
            /// 订单号
            /// </summary>
            private string m_OrderNumber;
           
            /// <summary>
			/// 商品总价
			/// </summary>
            private decimal m_TotalPrice;

			/// <summary>
			/// 用户Id
			/// </summary>
			private int m_UserId;

			/// <summary>
			/// 用户名
			/// </summary>
			private int m_UserName;

			/// <summary>
			/// 订购日期
			/// </summary>
			private string m_Date;

			/// <summary>
			/// 订单状态
            /// <para>      0:未审核          </para>
            /// <para>      1:审核中          </para>
            /// <para>      2:处理中          </para>
            /// <para>      3:处理完毕        </para>
			/// </summary>
			private byte m_OrderStatus;
        
            /// <summary>
            /// 付款状态
            /// <para>      0:未付款          </para>
            /// <para>      1:支付宝中        </para>
            /// <para>      2:已收款          </para>
            /// </summary>
            private byte m_MoneyStatus;
            
            /// <summary>
            /// 发货状态
            /// <para>      0:未发货          </para>
            /// <para>      1:已发货          </para>
            /// <para>      2:已收货          </para>
            /// </summary>  
            private byte m_ConsignmentStatus;

            /// <summary>
            /// 交易状态
            /// <para>      0:支付宝          </para>
            /// <para>      1:银行转帐        </para>
            /// <para>      2:其它方式        </para>
            /// </summary>
            private byte m_TradeStatus;

			/// <summary>
			/// 管理员处理Id
			/// </summary>
			private int m_AdminId;

			/// <summary>
			/// 管理员姓名
			/// </summary>
			private int m_AdminName;

			/// <summary>
			/// 处理日期
			/// </summary>
			private string m_AdminDate;

            /// <summary>
            /// 收货人姓名
            /// </summary>
            private string m_RealName;
            

            /// <summary>
            /// 收货人性别
            /// </summary>
            private int m_Sex;
           

            /// <summary>
            /// 收货人地址
            /// </summary>
            private string m_Address;
            

            /// <summary>
            /// 收货人邮政编码
            /// </summary>
            private string m_PostCode;
            
            /// <summary>
            /// 收货人电话
            /// </summary>
            private string m_Phone;
           

            /// <summary>
            /// 收货人手机
            /// </summary>
            private string m_MobilePhone;
            

            /// <summary>
            /// 收货人E-Mail
            /// </summary>
            private string m_Email;

           

		#endregion

		#region 公共属性
		/// <summary>
			/// 订单Id
			/// </summary>
			public int Id
			{
				get { return m_Id; }
				set { m_Id = value; }
			}

            /// <summary>
            /// 订单号
            /// </summary>
            public string OrderNumber
            {
                get { return m_OrderNumber; }
                set { m_OrderNumber = value; }
            }


            /// <summary>
            /// 商品总价
            /// </summary>
            public decimal TotalPrice
            {
                get { return m_TotalPrice; }
                set { m_TotalPrice = value; }
            }

			/// <summary>
			/// 用户Id
			/// </summary>
			public int UserId
			{
				get { return m_UserId; }
				set { m_UserId = value; }
			}
			/// <summary>
			/// 用户名
			/// </summary>
			public int UserName
			{
				get { return m_UserName; }
				set { m_UserName = value; }
			}

			/// <summary>
			/// 订购日期
			/// </summary>
			public string Date
			{
				get { return m_Date; }
				set { m_Date = value; }
			}
            /// <summary>
            /// 订单状态
            /// <para>      0:未审核          </para>
            /// <para>      1:审核中          </para>
            /// <para>      2:处理中          </para>
            /// <para>      3:处理完毕        </para>
            /// </summary>
			public byte OrderStatus
			{
				get { return m_OrderStatus; }
				set { m_OrderStatus = value; }
			}

            /// <summary>
            /// 付款状态
            /// <para>      0:未付款          </para>
            /// <para>      1:支付宝中        </para>
            /// <para>      2:已收款          </para>
            /// </summary>
            public byte MoneyStatus
            {
                get { return m_MoneyStatus; }
                set { m_MoneyStatus = value; }
            }

            /// <summary>
            /// 发货状态
            /// <para>      0:未发货          </para>
            /// <para>      1:已发货          </para>
            /// <para>      2:已收货          </para>
            /// </summary> 
            public byte ConsignmentStatus
            {
                get { return m_ConsignmentStatus; }
                set { m_ConsignmentStatus = value; }
            }
            /// <summary>
            /// 交易状态
            /// <para>      0:支付宝          </para>
            /// <para>      1:银行转帐        </para>
            /// <para>      2:其它方式        </para>
            /// </summary>
            public byte TradeStatus
            {
                get { return m_TradeStatus; }
                set { m_TradeStatus = value; }
            }

			/// <summary>
			/// 管理员处理Id
			/// </summary>
			public int AdminId
			{
				get { return m_AdminId; }
				set { m_AdminId = value; }
			}
			/// <summary>
			/// 管理员姓名
			/// </summary>
			public int AdminName
			{
				get { return m_AdminName; }
				set { m_AdminName = value; }
			}
			/// <summary>
			/// 处理日期
			/// </summary>
			public string AdminDate
			{
				get { return m_AdminDate; }
				set { m_AdminDate = value; }
			}

            /// <summary>
            /// 收货人姓名
            /// </summary>
            public string RealName
            {
                get { return m_RealName; }
                set { m_RealName = value; }
            }
            /// <summary>
            /// 收货人性别
            /// </summary>

            public int Sex
            {
                get { return m_Sex; }
                set { m_Sex = value; }
            }
            /// <summary>
            /// 收货人地址
            /// </summary>
            public string Address
            {
                get { return m_Address; }
                set { m_Address = value; }
            }
            /// <summary>
            /// 收货人邮政编码
            /// </summary>
            public string PostCode
            {
                get { return m_PostCode; }
                set { m_PostCode = value; }
            }
            /// <summary>
            /// 收货人电话
            /// </summary>
            public string Phone
            {
                get { return m_Phone; }
                set { m_Phone = value; }
            }
            /// <summary>
            /// 收货人手机
            /// </summary>
            public string MobilePhone
            {
                get { return m_MobilePhone; }
                set { m_MobilePhone = value; }
            }
            /// <summary>
            /// 收货人E-Mail
            /// </summary>
            public string Email
            {
                get { return m_Email; }
                set { m_Email = value; }
            }
		#endregion
	}
}
