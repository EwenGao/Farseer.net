﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
	public class OnLineUserInfo
	{
        //private static int m_UserId = -1;
        //private static string m_UserName;
        //private static string m_PassWord;
	}
}
