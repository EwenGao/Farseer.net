﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class SpreaderInfo
    {
        /// <summary>
        /// 推广员信息
        /// </summary>
        public class Info_Spreader
        {
            /// <summary>
            /// 推广员ID
            /// </summary>
            public int Id = 0;

            /// <summary>
            /// 推广员名称
            /// </summary>
            public string SpreaderName;

            /// <summary>
            /// 推广员登陆名(只用于登陆)
            /// </summary>
            public string LoginName;

            /// <summary>
            /// 密码
            /// </summary>
            public string PassWord;

            /// <summary>
            /// 是否可以继续使用
            /// </summary>
            public bool IsEnable;

            /// <summary>
            /// 注册日期
            /// </summary>
            public string RegisterDate;

            /// <summary>
            /// 备注
            /// </summary>
            public string Remark;

            /// <summary>
            /// 推广员提成
            /// </summary>
            public int Rate = 0;

            /// <summary>
            /// 网址
            /// </summary>
            public string Url = "";
        }

        /// <summary>
        /// 添加推广员
        /// </summary>
        public class Add_Spreader
        {
            /// <summary>
            /// 推广员名称(超级推广员才可以修改)
            /// </summary>
            public string SpreaderName;

            /// <summary>
            /// 推广员登陆名(只用于登陆)
            /// </summary>
            public string LoginName;

            /// <summary>
            /// 密码
            /// </summary>
            public string PassWord;

            /// <summary>
            /// 注册日期
            /// </summary>
            public string RegisterDate;

            /// <summary>
            /// 备注
            /// </summary>
            public string Remark;

            /// <summary>
            /// 推广员提成
            /// </summary>
            public int Rate = 0;

            /// <summary>
            /// 网址
            /// </summary>
            public string Url = "";
        }

        /// <summary>
        /// 修改推广员
        /// </summary>
        public class Modify_Spreader
        {
            /// <summary>
            /// 条件从句:推广员ID
            /// </summary>
            public int Condition_Id = 0;

            /// <summary>
            /// 推广员名称(超级推广员才可以修改)
            /// </summary>
            public string SpreaderName;

            /// <summary>
            /// 推广员登陆名(只用于登陆)
            /// </summary>
            public string LoginName;

            /// <summary>
            /// 密码
            /// </summary>
            public string PassWord;

            /// <summary>
            /// 是否可以继续使用
            /// </summary>
            public bool IsEnable;

            /// <summary>
            /// 注册日期
            /// </summary>
            public string RegisterDate;

            /// <summary>
            /// 备注
            /// </summary>
            public string Remark;

            /// <summary>
            /// 推广员提成
            /// </summary>
            public int Rate = 0;

            /// <summary>
            /// 网址
            /// </summary>
            public string Url = "";
        }

    }
}
