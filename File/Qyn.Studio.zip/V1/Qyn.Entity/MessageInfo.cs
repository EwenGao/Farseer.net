﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    /// <summary>
    /// 短消息描述
    /// </summary>
    public class MessageInfo
    {
        #region 私有字段
            /// <summary>
            /// 短消息Id
            /// </summary>
            private int m_Id;

            /// <summary>
            /// 发送者Id
            /// </summary>
            private int m_SenderId;

            /// <summary>
            /// 发送者姓名
            /// </summary>
            private string m_SenderName;

            /// <summary>
            /// 接收者Id
            /// </summary>
            private int m_InceptId;

            /// <summary>
            /// 接收者姓名
            /// </summary>
            private string m_InceptName;

            /// <summary>
            /// 短消息标题
            /// </summary>
            private string m_Caption;

           /// <summary>
           /// 短消息内容
           /// </summary>
            private string m_Context;

            /// <summary>
            /// 已读为True,未读为False
            /// </summary>
            private bool m_Read;

            /// <summary>
            /// 发送日期
            /// </summary>
            private string m_Date;

        #endregion

        #region 公共字段
            /// <summary>
            /// 短消息Id
            /// </summary>
            public int Id
            {
                get { return m_Id; }
                set { m_Id = value; }
            }

            /// <summary>
            /// 发送者Id
            /// </summary>
            public int SenderId
            {
                get { return m_SenderId; }
                set { m_SenderId = value; }
            }

            /// <summary>
            /// 发送者姓名
            /// </summary>
            public string SenderName
            {
                get { return m_SenderName; }
                set { m_SenderName = value; }
            }

            /// <summary>
            /// 接收者Id
            /// </summary>
            public int InceptId
            {
                get { return m_InceptId; }
                set { m_InceptId = value; }
            }

            /// <summary>
            /// 接收者姓名
            /// </summary>
            public string InceptName
            {
                get { return m_InceptName; }
                set { m_InceptName = value; }
            }

            /// <summary>
            /// 短消息标题
            /// </summary>
            public string Caption
            {
                get { return m_Caption; }
                set { m_Caption = value; }
            }

            /// <summary>
            /// 短消息内容
            /// </summary>
            public string Context
            {
                get { return m_Context; }
                set { m_Context = value; }
            }

            /// <summary>
            /// 已读为True,未读为False
            /// </summary>
            public bool Read
            {
                get { return m_Read; }
                set { m_Read = value; }
            }

            /// <summary>
            /// 发送日期
            /// </summary>
            public string Date
            {
                get { return m_Date; }
                set { m_Date = value; }
            }
        #endregion

    }
}
