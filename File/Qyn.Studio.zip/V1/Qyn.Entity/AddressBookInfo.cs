﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class AddressBookInfo
    {
        #region 私有字段
        /// <summary>
        /// 地址ID
        /// </summary>
        private int m_Id;

        /// <summary>
        /// 用户ID
        /// </summary>
        private int m_UserId;

        /// <summary>
        /// 真实姓名
        /// </summary>
        private string m_RealName;

        /// <summary>
        /// 性别
        /// </summary>
        private int m_Sex;

        /// <summary>
        /// 邮政编号
        /// </summary>
        private string m_PostCode;

        /// <summary>
        /// 地址
        /// </summary>
        private string m_Address;

        /// <summary>
        /// 固定电话
        /// </summary>
        private string m_Phone;

        /// <summary>
        /// 手机
        /// </summary>
        private string m_MobilePhone;

        /// <summary>
        /// E_mail
        /// </summary>
        private string m_Email;
        #endregion

        #region 公共属性
        /// <summary>
        /// 地址ID
        /// </summary>
        public int Id
        {
            get { return m_Id; }
            set { m_Id = value; }
        }

        /// <summary>
        /// 用户ID
        /// </summary>
        public int UserId
        {
            get { return m_UserId; }
            set { m_UserId = value; }
        }

        /// <summary>
        /// 真实姓名
        /// </summary>
        public string RealName
        {
            get { return m_RealName; }
            set { m_RealName = value; }
        }

        /// <summary>
        /// 性别
        /// </summary>
        public int Sex
        {
            get { return m_Sex; }
            set { m_Sex = value; }
        }

        /// <summary>
        /// 邮政编号
        /// </summary>
        public string PostCode
        {
            get { return m_PostCode; }
            set { m_PostCode = value; }
        }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address
        {
            get { return m_Address; }
            set { m_Address = value; }
        }

        /// <summary>
        /// 固定电话
        /// </summary>
        public string Phone
        {
            get { return m_Phone; }
            set { m_Phone = value; }
        }

        /// <summary>
        /// 手机
        /// </summary>
        public string MobilePhone
        {
            get { return m_MobilePhone; }
            set { m_MobilePhone = value; }
        }

        /// <summary>
        /// E_mail
        /// </summary>
        public string Email
        {
            get { return m_Email; }
            set { m_Email = value; }
        }
        #endregion
    }
}
