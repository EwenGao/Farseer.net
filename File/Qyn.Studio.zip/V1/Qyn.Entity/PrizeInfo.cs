﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Entity
{
    public class PrizeInfo
    {
        /// <summary>
        /// 添加奖项
        /// </summary>
        public class Add_Prize
        {

            /// <summary>
            /// 玩家ID
            /// </summary>
            public string ClientId;

            /// <summary>
            /// 管理人员ID
            /// </summary>
            public string EmployeeId;

            /// <summary>
            /// 金币
            /// </summary>
            public int WinMoney;

            /// <summary>
            /// 赢钱的等级
            /// </summary>
            public int WinLevel;

            /// <summary>
            /// 赢钱的概率，多少次后能得将
            /// </summary>
            public int WinRate;

            /// <summary>
            /// 记录创建日期
            /// </summary>
            public string DateCreate;

            /// <summary>
            /// 提前预报的次数
            /// </summary>
            public int ForcastNum;

        }
    }
}
