﻿using System;
using System.Collections.Generic;
using System.Text;
using Qyn.IConfig;
using System.Web;

using Qyn.IData;

namespace Qyn.Data
{
	/// <summary>
	/// 数据库提供驱动
	/// </summary>
	public class DataBaseProvider
	{
		/// <summary>
		/// 锁定
		/// </summary>
		public static object LockHelper = new object();

		/// <summary>
		/// 定义数据库提供接口
		/// </summary>
		private static IDataProvider myInstance = null;

		/// <summary>
		/// 获取对应的数据库提供接口，自动映射数据库
		/// </summary>
		/// <returns>返回对应数据库操作接口</returns>
		public static IDataProvider GetInstance()
		{
            if (myInstance == null)
            {
                lock (LockHelper)
                {
                    try
                    {
                        //通过获取数据库类型，来动态new一个多态接口数据库
                        myInstance = (IDataProvider)Activator.CreateInstance(Type.GetType(string.Format("Qyn.Data.{0}.DataProvider,Qyn.Data.{0}", BaseConfigs.GetBaseConfig().DbType), true, true));

                    }
                    catch
                    {
                        HttpContext context = HttpContext.Current;
                        string errorMessage = "在返回：IDataProvider 时，无法驱动" + BaseConfigs.GetBaseConfig().DbType + "数据库,请检查网站Bin文件夹内是否存在：Qyn.Data." + BaseConfigs.GetBaseConfig().DbType + ".dll文件";
                        if (context != null)
                        {
                            new Qyn.Common.Terminator().Throw(errorMessage);
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show(errorMessage, "发生错误");
                        }
                        myInstance = null;
                    }
                }
            }
			return myInstance;
		}

		/// <summary>
		/// 清空动态数据库类型接口
		/// </summary>
		public static void ResetDbProvider()
		{
			myInstance = null;

		}
	}
}
