﻿using System;
using System.Data;
using System.Data.Common;
using System.Web;
using Qyn.IConfig;
using Qyn.Common;
using System.IO;

namespace Qyn.Data
{

    #region 数据访问助手类  For NET2.0
    /// <summary>
    /// 数据访问助手类  For NET2.0
    /// </summary>
    public class DbHelper
    {
        #region 私有变量

        /// <summary>
        /// 数据库连接字符串
        /// </summary>
        protected static string m_connectionstring = null;

        /// <summary>
        /// DbFactory实例
        /// </summary>
        private static DbProviderFactory m_factory = null;

        /// <summary>
        /// Provider实例
        /// </summary>
        private static IDbProvider m_Provider = null;

        /// <summary>
        /// 查询次数统计
        /// </summary>
        private static int m_querycount = 0;

        /// <summary>
        /// 锁定
        /// </summary>
        private static object lockHelper = new object();

        /// <summary>
        /// 调试Sql语句用当Ture时，则输出Sql语句
        /// </summary>
        private static bool m_trace = false;

        /// <summary>
        /// 数据库连接
        /// </summary>
        private static DbConnection conn = null;

        /// <summary>
        /// 连接数据库不成功时,显示的出错信息
        /// </summary>
        private static string m_ConnError = "";

        #endregion

        #region 属性

        /// <summary>
        /// 数据库连接字符串
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                if (m_connectionstring == null)
                {
                    m_connectionstring = BaseConfigs.DBConnectString;
                }
                return m_connectionstring;
            }
            set
            {
                m_connectionstring = value;
            }
        }

        /// <summary>
        /// 特定数据库相关驱动提供者
        /// </summary>
        public static IDbProvider Provider
        {
            get
            {
                if (m_Provider == null)
                {
                    lock (lockHelper)
                    {
                        if (m_Provider == null)
                        {
                            try
                            {
                                m_Provider = (IDbProvider)Activator.CreateInstance(Type.GetType(string.Format("Qyn.Data.{0}Provider,Qyn.Data.{0}",BaseConfigs.GetBaseConfig().DbType), false, true));
                            }
                            catch
                            {
                                HttpContext context = HttpContext.Current;
                                m_ConnError = "在返回：IDbProvider时，无法驱动" + BaseConfigs.GetBaseConfig().DbType + "接口!请检查 [Qyn.Data." + BaseConfigs.GetBaseConfig().DbType + "] 下的" + BaseConfigs.GetBaseConfig().DbType + "Provider.cs文件";
                                if (context != null)
                                {
                                    new Qyn.Common.Terminator().Throw(m_ConnError);
                                }
                                else
                                {
                                    System.Windows.Forms.MessageBox.Show(m_ConnError, "发生错误");
                                }
                            }
                        }
                    }
                }

                return m_Provider;
            }
        }

        /// <summary>
        /// DbFactory实例
        /// </summary>
        public static DbProviderFactory Factory
        {
            get
            {
                if (m_factory == null)
                {
                    m_factory = Provider.Instance();
                }
                return m_factory;
            }
        }

        /// <summary>
        /// 查询次数统计
        /// </summary>
        public static int QueryCount
        {
            get { return m_querycount; }
            set { m_querycount = value; }
        }

        /// <summary>
        /// 调试Sql语句用当Ture时，则输出Sql语句
        /// </summary>
        public static bool Trace
        {
            get { return DbHelper.m_trace; }
            set { DbHelper.m_trace = value; }
        }

        /// <summary>
        /// 数据库连接
        /// </summary>
        public static DbConnection Conn
        {
            get { return DbHelper.conn; }
        }

        /// <summary>
        /// 连接数据库不成功时,显示的出错信息
        /// </summary>
        public static string ConnError
        {
            get { return DbHelper.m_ConnError; }
        }

        #endregion

        #region 结构
        /// <summary>
        /// 返回的类型
        /// </summary>
        enum objectType
        {
            DataSet = 2,
            DataReader = 4,
            Void = 8,
            Scalar = 16,
            DataTable = 32,
        }
        #endregion

        static DbHelper()
        {
            if (conn == null)
            {
                m_ConnError = "";
                //Open();
            }
        }

        #region 私有方法

        /// <summary>
        /// 执行数据库操作
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">参数</param>
        /// <param name="cmdType">执行方式</param>
        /// <param name="returnType">数据返回类型</param>
        /// <returns></returns>
        private static object Execute(string sql, DbParameter[] parems, CommandType cmdType, objectType returnType)
        {
            m_querycount++;
            if (m_trace) { HttpContext.Current.Response.Write(m_querycount + ": " + sql + "<br />"); }
            Open();
            try
            {
                DbCommand cmd = Factory.CreateCommand();
                cmd.Connection = conn;
                cmd.CommandText = sql;
                cmd.CommandType = cmdType;
                if (parems != null)
                {
                    for (int i = 0; i < parems.Length; i++)
                    {
                        cmd.Parameters.Add(parems[i]);
                    }
                }

                switch (returnType)
                {
                    case objectType.Void:
                        return (object)cmd.ExecuteNonQuery();

                    case objectType.Scalar:
                        return (object)cmd.ExecuteScalar();

                    case objectType.DataReader:
                        return (object)cmd.ExecuteReader();

                    case objectType.DataSet:
                        using (DbDataAdapter adapter = Factory.CreateDataAdapter())
                        {
                            adapter.SelectCommand = cmd;
                            DataSet ds = new DataSet();
                            adapter.Fill(ds);
                            return (object)ds;
                        }
                    case objectType.DataTable:
                        using (DbDataAdapter adapter = Factory.CreateDataAdapter())
                        {
                            adapter.SelectCommand = cmd;
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);
                            return (object)dt;
                        }
                    default:
                        return null;
                }
            }
            catch (Exception e)
            {
                string errorMessage = e.Message;
                HttpContext context = HttpContext.Current;
                if (errorMessage.StartsWith("无法从指定的数据表中删除") || errorMessage.StartsWith("操作必须使用一个可更新的查询"))
                {
                    errorMessage = "没有足够的权限对Access数据库进行操作。请设置系统中的 files 目录的文件系统权限（文件夹属性中的安全选项卡），添加.NET用户（默认地，Win2K为ASPNET用户，Win2003为IIS_WPG用户组），并且授予完全控制权限。";
                }
                if (context != null)
                {
                    new Qyn.Common.Terminator().Throw(errorMessage);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show(errorMessage, "发生错误");
                }
                return null;
            }
        }

        #endregion

        #region 方法(所有方法都自动调用私有方法)

        #region 执行查询,返回影响行数 public static int ExecuteNonQuery(string sql,DbParameter[] parems)

        /// <summary>
        /// 执行查询,返回影响行数
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">SQL参数</param>
        /// <returns>返回影响行数</returns>
        public static int ExecuteNonQuery(string sql, DbParameter[] parems)
        {
            return (Int32)ExecuteNonQuery(sql, parems, CommandType.Text);
        }

        #endregion

        #region 执行查询,返回影响行数 public static int ExecuteNonQuery(string sql,DbParameter[] parems,CommandType cmdType)

        /// <summary>
        /// 执行查询,返回影响行数
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">Sql参数</param>
        /// <param name="cmdType">执行方式</param>
        /// <returns>返回影响行数</returns>
        public static int ExecuteNonQuery(string sql, DbParameter[] parems, CommandType cmdType)
        {
            return (Int32)Execute(sql, parems, cmdType, objectType.Void);
        }

        #endregion


        #region 执行查询，返回实体值(Object)(第一行第一列) public static object ExecuteScalar(string sql,DbParameter[] parems)
        /// <summary>
        /// 执行查询，返回实体值(Object)(第一行第一列)
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">SQL参数</param>
        /// <returns>返回实体值(Object)</returns>
        public static object ExecuteScalar(string sql, DbParameter[] parems)
        {
            return (object)ExecuteScalar(sql, parems, CommandType.Text);

        }
        #endregion

        #region 执行查询，返回实体值(Object)(第一行第一列) public static object ExecuteScalar(string sql,DbParameter[] parems,CommandType cmdType)
        /// <summary>
        /// 执行查询，返回实体值(Object)(第一行第一列)
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">Sql参数</param>
        /// <param name="cmdType">执行方式</param>
        /// <returns>返回实体值(Object)</returns>
        public static object ExecuteScalar(string sql, DbParameter[] parems, CommandType cmdType)
        {
            return (object)Execute(sql, parems, cmdType, objectType.Scalar);

        }
        #endregion


        #region 执行查询,返回Boolean  public static bool ExecuteBoolean(string sql, DbParameter[] parems)
        /// <summary>
        /// 执行查询,返回Boolean
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">参数</param>
        /// <returns></returns>
        public static bool ExecuteBoolean(string sql, DbParameter[] parems)
        {
            if (sql.ToLower().Trim().Substring(0, 6) == "select")
            {
                new Qyn.Common.Terminator().Throw("DbHelper.cs要求更改!!!!");
                return false;
            }
            else
            {
                return ExecuteNonQuery(sql, parems) > 0;
            }
        }
        #endregion

        #region 执行查询,返回Boolean  public static bool ExecuteBoolean(string sql, DbParameter[] parems, CommandType cmdType)
        /// <summary>
        /// 执行查询,返回Boolean
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">参数</param>
        /// <param name="cmdType">执行方式</param>
        /// <returns></returns>
        public static bool ExecuteBoolean(string sql, DbParameter[] parems, CommandType cmdType)
        {
            return Convert.ToInt32(ExecuteScalar(sql, parems, cmdType)) >= 1;
        }
        #endregion


        #region 执行查询，返回一个 IDataReader 对象 public static IDataReader ExecuteReader(string sql,DbParameter[] parems)
        /// <summary>
        /// 执行查询，返回一个 IDataReader 对象
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">SQL参数</param>
        /// <returns>返回IDataReader</returns>
        public static DbDataReader ExecuteReader(string sql, DbParameter[] parems)
        {
            return ExecuteReader(sql, parems, CommandType.Text);
        }
        #endregion

        #region 执行查询，返回一个 IDataReader 对象 public static IDataReader ExecuteReader(string sql, DbParameter[] parems,CommandType cmdType)
        /// <summary>
        /// 执行查询，返回一个 IDataReader 对象
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">Sql参数</param>
        /// <param name="isProcedure">执行方式</param>
        /// <returns>返回IDataReader</returns>
        public static DbDataReader ExecuteReader(string sql, DbParameter[] parems, CommandType cmdType)
        {
            return (DbDataReader)Execute(sql, parems, cmdType, objectType.DataReader);
        }
        #endregion


        #region 执行查询，返回一个 DataSet对象 public static DataSet ExecuteDataSet(string sql,DbParameter[] parems)
        /// <summary>
        ///  执行查询，返回一个 DataSet对象
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">SQL参数</param>
        /// <returns>返回DataSet</returns>
        public static DataSet ExecuteDataSet(string sql, DbParameter[] parems)
        {
            return (DataSet)ExecuteDataSet(sql, parems, CommandType.Text);
        }
        #endregion

        #region 执行查询，返回一个 DataSet对象 public static DataSet ExecuteDataSet(string sql,DbParameter[] parems,CommandType cmdType)
        /// <summary>
        /// 执行查询，返回一个 DataSet对象
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">Sql参数</param>
        /// <param name="cmdType">执行方式</param>
        /// <returns>返回DataSet</returns>

        public static DataSet ExecuteDataSet(string sql, DbParameter[] parems, CommandType cmdType)
        {
            return (DataSet)Execute(sql, parems, cmdType, objectType.DataSet);
        }
        #endregion


        #region 执行查询，返回一个 DataTable对象 public static DataTable ExecuteDataTable(string sql,DbParameter[] parems)
        /// <summary>
        ///  执行查询，返回一个 DataTable对象
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">SQL参数</param>
        /// <returns>返回DataTable</returns>
        public static DataTable ExecuteDataTable(string sql, DbParameter[] parems)
        {
            return (DataTable)ExecuteDataTable(sql, parems, CommandType.Text);
        }
        #endregion

        #region 执行查询，返回一个 DataTable对象 public static DataTable ExecuteDataTable(string sql,DbParameter[] parems,CommandType cmdType)
        /// <summary>
        /// 执行查询，返回一个 DataTable对象
        /// </summary>
        /// <param name="sql">Sql语句</param>
        /// <param name="parems">Sql参数</param>
        /// <param name="cmdType">执行方式</param>
        /// <returns>返回DataTable</returns>

        public static DataTable ExecuteDataTable(string sql, DbParameter[] parems, CommandType cmdType)
        {
            return (DataTable)Execute(sql, parems, cmdType, objectType.DataTable);
        }
        #endregion

        #region 数据库打开关闭!!!
        public static void Close()
        {
            if (conn != null)
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                    conn = null;
                }
            }
        }

        public static bool Open()
        {
            try
            {
                if (conn == null || conn.State != ConnectionState.Open)
                {
                    conn = Factory.CreateConnection();
                    conn.ConnectionString = ConnectionString;
                    conn.Open();
                    if (conn.State != ConnectionState.Open)
                    {
                        conn = null;
                        m_ConnError = "数据库没有连接!,或IP,帐号密码错误";
                        HttpContext context = HttpContext.Current;
                        if (context != null)
                        {
                            new Qyn.Common.Terminator().Throw(m_ConnError);
                        }
                        else
                        {
                            System.Windows.Forms.MessageBox.Show(m_ConnError, "发生错误");
                        }
                        return false;
                    }
                }
                return true;
            }
            catch (Exception oExcept)
            {
                m_ConnError = oExcept.Message;
                Close();
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Qyn.Common.Terminator().Throw(m_ConnError);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show(m_ConnError, "发生错误");
                }
                return false;
            }
        }
        #endregion

        #endregion

        #region 生成参数

        public static DbParameter MakeInParam(string ParamName, DbType DbType, int Size, object Value)
        {
            return MakeParam(ParamName, DbType, Size, ParameterDirection.Input, Value);
        }

        public static DbParameter MakeOutParam(string ParamName, DbType DbType, int Size)
        {
            return MakeParam(ParamName, DbType, Size, ParameterDirection.Output, null);
        }

        public static DbParameter MakeParam(string ParamName, DbType DbType, Int32 Size, ParameterDirection Direction, object Value)
        {
            DbParameter param;

            param = Provider.MakeParam(ParamName, DbType, Size);

            param.Direction = Direction;
            if (!(Direction == ParameterDirection.Output && Value == null))
            {
                param.Value = Value;
            }
            return param;
        }

        #endregion 生成参数结束

        /// <summary>
        /// 刷新数据库提供者(清空)
        /// </summary>
        public static void ResetDbProvider()
        {
            //BaseConfigs.ResetConfig();
            DataBaseProvider.ResetDbProvider();
            m_connectionstring = null;
            m_factory = null;
            m_Provider = null;
            conn = null;
            Close();
        }
    }
    #endregion
}
