Type.registerNamespace("Qyn.Studio.Controls");

function TreeGrid() {
    this.initializeDocument = initializeDocument;
    this.InsItems = InsItems;
    this.InsColumns = InsColumns;
    this.GenerateCode = GenerateCode;
    this.ToggleTree = ToggleTree;
    this.ResetItem = ResetItem;
    this.ExpandAllTree = ExpandAllTree;
    this.RecudeAllTree = RecudeAllTree;

    var nCount = 0;
    var LastRootItem = 0;
    var ImgDir = "/App_Themes/AdminBlueTheme/Images/";

    var Doc;
    var browserVersion;
    var id = "";
    var Item = new Array();
    var ItemColumn = new Array();

    var TableOnOverColor = "";
    var TableWidth = 0;
    var TableBorder = 0;
    var TableCellPadding = 0;
    var TableCellSpacing = 1;
    var TableBgColor = "#ffffff";
    var TableClass = "";
    var TableStyle = "";
    var TableAlign = "center";
    var TableID = "QynTreeGrid";
    var TableFontColor = "#000000";
    var TableFontSize = "12px";

    var TrClass = "";
    var TrStyle = "";
    var TrAlign = "center";
    var TrBgColor = "#ffffff";
    var TrHeight = 22;
    var TrFontColor = "#000000";
    var TrFontSize = "12px";
    var TrFontBold = true;
    var TrFontItalic = false;

    var ColumnTrClass = "";
    var ColumnTrStyle = "";
    var ColumnTrAlign = "center";
    var ColumnTrBgColor = "#ffffff";
    var ColumnTrHeight = 22;
    var ColumnTrFontColor = "#000000";
    var ColumnTrFontSize = "12px";
    var ColumnTrFontBold = true;
    var ColumnTrFontItalic = false;

    function initializeDocument(
    tableWidth, tableOverColor, tableBorder, tableCellPadding, tableCellSpacing, tableBgColor, tableClass, tableStyle, tableAlign, tableID, tableFontColor, tableFontSize,
    trClass, trStyle, trAlign, trBgColor, trHeight, trFontColor, trFontSize, trFontBold, trFontItalic,
    columnTrClass, columnTrStyle, columnTrAlign, columnTrBgColor, columnTrHeight, columnTrFontColor, columnTrFontSize, columnTrFontBold, columnTrFontItalic) {
        if (document.all) { Doc = document.all; browserVersion = 1; }
        else if (document.layers) { Doc = document.layers; browserVersion = 2; }
        else if (document.getElementById) { Doc = document; browserVersion = 3; }
        else { Doc = document.all; browserVersion = 0; }

        TableWidth = tableWidth;
        TableOnOverColor = tableOverColor;
        TableBorder = tableBorder;
        TableCellPadding = tableCellPadding;
        TableCellSpacing = tableCellSpacing;
        TableBgColor = tableBgColor;
        TableClass = tableClass;
        TableStyle = tableStyle;
        TableAlign = tableAlign;
        TableID = tableID;
        TableFontColor = tableFontColor;
        TableFontSize = tableFontSize;

        TrClass = trClass;
        TrStyle = trStyle;
        TrAlign = trAlign;
        TrBgColor = trBgColor;
        TrHeight = trHeight;
        TrFontColor = trFontColor;
        TrFontSize = trFontSize;
        TrFontBold = trFontBold;
        TrFontItalic = trFontItalic;

        ColumnTrClass = columnTrClass;
        ColumnTrStyle = columnTrStyle;
        ColumnTrAlign = columnTrAlign;
        ColumnTrBgColor = columnTrBgColor;
        ColumnTrHeight = columnTrHeight;
        ColumnTrFontColor = columnTrFontColor;
        ColumnTrFontSize = columnTrFontSize;
        ColumnTrFontBold = columnTrFontBold;
        ColumnTrFontItalic = columnTrFontItalic;
    }

    function InsColumns(description, width, css, style, bgcolor, align, fontColor, fontSize, bold, italic) {
        var iLength = ItemColumn.length;
        ItemColumn[iLength] = new Array();
        ItemColumn[iLength][0] = description;
        ItemColumn[iLength][1] = width;
        ItemColumn[iLength][2] = css;
        ItemColumn[iLength][3] = style;
        ItemColumn[iLength][4] = bgcolor;
        ItemColumn[iLength][5] = align;
        ItemColumn[iLength][6] = fontColor;
        ItemColumn[iLength][7] = fontSize;
        ItemColumn[iLength][8] = bold;
        ItemColumn[iLength][9] = italic;
    }

    function InsItems(parentItem, description, hreference, target, css, style, bgColor, align, fontColor, fontSize, fontBold, fontItalic) {
        var iDepth = 0;
        var iLength = Item.length;
        if (parentItem == null) { parentItem = iLength; }
        if (Item[parentItem] != null) { iDepth = Item[parentItem][4]; iDepth++; }

        if (css == null) { css = ""; }
        if (style == null) { style = ""; }
        if (bgColor == null) { bgColor = ""; }
        if (align == null) { align = TrAlign; }
        if (fontColor == null) { fontColor = ""; }
        if (fontSize == null) { fontSize = ""; }
        if (fontBold == null) { fontBold = "false"; }
        if (fontItalic == null) { fontItalic = "false"; }

        Item[iLength] = new Array();
        Item[iLength][0] = parentItem;
        Item[iLength][1] = description;
        Item[iLength][2] = hreference;
        Item[iLength][3] = target;
        Item[iLength][4] = iDepth;
        Item[iLength][5] = true;
        Item[iLength][6] = css;
        Item[iLength][7] = style;
        Item[iLength][8] = bgColor;
        Item[iLength][9] = align;
        Item[iLength][10] = fontColor;
        Item[iLength][11] = fontSize;
        Item[iLength][12] = fontBold;
        Item[iLength][13] = fontItalic;
        nCount++;
        return iLength;
    }


    function GenerateColumnsCode() {
        DocWrite("<tr");
        if (ColumnTrClass != "") { DocWrite(" class='" + ColumnTrClass + "'"); }

        DocWrite(" style='");
        DocWrite("text-align:" + ColumnTrAlign + ";");
        if (ColumnTrBgColor != "") { DocWrite("background-color:" + ColumnTrBgColor + ";"); }
        if (ColumnTrHeight > 0) { DocWrite("height:" + ColumnTrHeight + "px;"); }
        if (ColumnTrFontColor != "") { DocWrite("color:" + ColumnTrFontColor + ";"); }
        if (ColumnTrFontSize != "") { DocWrite("font-size:" + ColumnTrFontSize + ";"); }
        if (ColumnTrFontBold) { DocWrite("font-weight:bold;"); }
        else { DocWrite("font-weight:normal;"); }
        if (ColumnTrFontItalic) { DocWrite("font-style:italic;"); }
        else { DocWrite("font-style:normal;"); }
        if (ColumnTrStyle != "") { DocWrite(ColumnTrStyle + ";"); }
        DocWrite("'>");

        for (var i = 0; i < ItemColumn.length; i++) {
            DocWrite("<td");
            if (ItemColumn[i][2] != "") { DocWrite(" class='" + ItemColumn[i][2] + "'"); }

            DocWrite(" style='");
            if (ItemColumn[i][1] > 0) { DocWrite("width:" + ItemColumn[i][1] + "px;"); }
            else if (ItemColumn[i][1] < 0) { DocWrite("width:" + ItemColumn[i][1] * -1 + "%;"); }

            if (ItemColumn[i][5] != ColumnTrAlign) { DocWrite("text-align:" + ItemColumn[i][5] + ";"); }
            if (ItemColumn[i][4] != "") { DocWrite("background-color:" + ItemColumn[i][4] + ";"); }
            if (ItemColumn[i][6] != "") { DocWrite("color:" + ItemColumn[i][6] + ";"); }
            if (ItemColumn[i][7] != "") { DocWrite("font-size:" + ItemColumn[i][7] + ";"); }
            if (ItemColumn[i][8] == "true" && !ColumnTrFontBold) { DocWrite("font-weight:bold;"); }
            else if (ItemColumn[i][8] == "false" && ColumnTrFontBold) { DocWrite("font-weight:normal;"); }
            if (ItemColumn[i][9] == "true" && !ColumnTrFontItalic) { DocWrite("font-style:italic;"); }
            else if (ItemColumn[i][9] == "false" && ColumnTrFontItalic) { DocWrite("font-style:normal;"); }

            if (ItemColumn[i][3] != "") { DocWrite(ItemColumn[i][3] + ";"); }
            DocWrite("'>");

            DocWrite(ItemColumn[i][0]);
            DocWrite("</td>");
        }
        DocWrite("</tr>");
    }


    function GenerateCode() {
        var NextItemDepth = 0;
        var CurItemDepth = 0;

        var strTableWidth;
        if (TableWidth == 0) { strTableWidth = "100%"; }
        else if (TableWidth < 0) { strTableWidth = TableWidth * -1 + "%"; }
        else { strTableWidth = TableWidth; }

        DocWrite("<table");
        if (TableID != "") { DocWrite(" ID='" + TableID + "'"); }
        DocWrite(" border='" + TableBorder + "'");
        DocWrite(" cellpadding='" + TableCellPadding + "'");
        DocWrite(" cellspacing='" + TableCellSpacing + "'");

        if (TableClass != "") { DocWrite(" class='" + TableClass + "'"); }

        DocWrite(" style='");

        if (TableWidth > 0) { DocWrite("width:" + TableWidth + "px;"); }
        else if (TableWidth < 0) { DocWrite("width:" + TableWidth * -1 + "%;"); }
        else { DocWrite("width:100%;"); }

        if (TableBgColor != "") { DocWrite("background-color:" + TableBgColor + ";"); }
        if (TableFontColor != "") { DocWrite("color:" + TableFontColor + ";"); }
        if (TableFontSize != "") { DocWrite("font-size:" + TableFontSize + ";"); }
        DocWrite("text-align:" + TableAlign + ";");
        if (TableStyle != "") { DocWrite(TableStyle + ";"); }
        DocWrite("'>");

        GenerateColumnsCode();

        for (var i = 0; i < nCount; i++) {
            var ArrItemDesc = Item[i][1].split("|");
            var ArrItemHref = Item[i][2].split("|");
            var ArrItemTarget = Item[i][3].split("|");
            var ArrItemCss = Item[i][6].split("|");
            var ArrItemStyle = Item[i][7].split("|");
            var ArrItemBgcolor = Item[i][8].split("|");
            var ArrItemAlign = Item[i][9].split("|");
            var ArrItemFontColor = Item[i][10].split("|");
            var ArrItemFontSize = Item[i][11].split("|");
            var ArrItemFontBold = Item[i][12].split("|");
            var ArrItemFontItalic = Item[i][13].split("|");

            DocWrite("<tr");
            DocWrite(" id=wsTree_" + i);
            if (TrClass != "") { DocWrite(" class='" + TrClass + "'"); }
            DocWrite(" onMouseOver=\"this.style.backgroundColor='" + TableOnOverColor + "'\" onMouseOut=\"this.style.backgroundColor='" + TrBgColor + "'\"");

            DocWrite(" style='");
            DocWrite("text-align:" + TrAlign + ";");
            if (TrBgColor != "") { DocWrite("background-color:" + TrBgColor + ";"); }
            if (TrHeight > 0) { DocWrite("height:" + TrHeight + "px;"); }
            if (TrFontColor != "") { DocWrite("color:" + TrFontColor + ";"); }
            if (TrFontSize != "") { DocWrite("font-size:" + TrFontSize + ";"); }
            if (TrFontBold) { DocWrite("font-weight:bold;"); }
            else { DocWrite("font-weight:normal;"); }
            if (TrFontItalic) { DocWrite("font-style:italic;"); }
            else { DocWrite("font-style:normal;"); }
            if (TrStyle != "") { DocWrite(TrStyle + ";"); }
            DocWrite("'>");

            DocWrite("<td");
            if (ArrItemBgcolor[0] != "") { DocWrite(" style='background-color:" + ArrItemBgcolor[0] + ";'"); }
            DocWrite(">");

            DocWrite("<table border='0' cellpadding='0' cellspacing='0' style='width:100%;height:" + TrHeight + ";");
            if (ArrItemBgcolor[0] != "") { DocWrite("background-color:" + ArrItemBgcolor[0] + ";"); }
            DocWrite("'>");

            DocWrite("<tr>");

            DocWrite("<td style='width:1%;'>");
            DocWrite(GetSpace(i, Item[i][4], false));
            DocWrite("</td>")

            DocWrite("<td style='width:1%;'>");
            DocWrite("<a href='#' onfocus='this.blur()' onclick=\"javascript:ToggleTree('" + i + "','" + GetChildItems(i) + "')\">");
            TempNodeImg = "white.gif";
            DocWrite("<img id=wsTreeNodeImg_" + i + " src='" + ImgDir + TempNodeImg + "' border='0' style='height:" + TrHeight + "'>");
            DocWrite("</a>");
            DocWrite("</td>")
            
            GenerateSubContent(i, ArrItemDesc[0], ArrItemHref[0], ArrItemTarget[0], ArrItemCss[0], ArrItemStyle[0], ArrItemBgcolor[0], ArrItemAlign[0], ArrItemFontColor[0], ArrItemFontSize[0], ArrItemFontBold[0], ArrItemFontItalic[0]);

            DocWrite("</tr></table>");
            DocWrite("</td>");

            for (var tdIndex = 1; tdIndex < ItemColumn.length; tdIndex++) {
                GenerateSubContent(i, ArrItemDesc[tdIndex], ArrItemHref[tdIndex], ArrItemTarget[tdIndex], ArrItemCss[tdIndex], ArrItemStyle[tdIndex], ArrItemBgcolor[tdIndex], ArrItemAlign[tdIndex], ArrItemFontColor[tdIndex], ArrItemFontSize[tdIndex], ArrItemFontBold[tdIndex], ArrItemFontItalic[tdIndex]);
            }

            DocWrite("</tr>");
        }
        DocWrite("</table>");

        LastRootItem = GetRootItem(nCount - 1);
    }

    function GenerateSubContent(i, caption, links, target, css, style, bgColor, align, fontColor, fontSize, fontBold, fontItalic) {
        if (css == null) { css = ""; }
        if (style == null) { style = ""; }
        if (bgColor == null) { bgColor = ""; }
        if (align == null || (align != "center" && align != "left" && align != "right" && align != "justify")) { align = TrAlign; }
        if (fontColor == null) { fontColor = ""; }
        if (fontSize == null) { fontSize = ""; }
        if (fontBold == null) { fontBold = "false"; }
        if (fontItalic == null) { fontItalic = "false"; }

        DocWrite("<td");
        if (css != "") { DocWrite(" class='" + css + "'"); }
        DocWrite(" style='");
        DocWrite("text-align:" + align + ";");
        if (bgColor != "") { DocWrite("background-color:" + bgColor + ";"); }
        if (fontColor != "") { DocWrite("color:" + fontColor + ";"); }
        if (fontSize != "") { DocWrite("font-size:" + fontSize + ";"); }

        if (fontBold == "true" && !TrFontBold) { DocWrite("font-weight:bold;"); }
        else if (fontBold == "false" && TrFontBold) { DocWrite("font-weight:normal;"); }

        if (fontItalic == "true" && !TrFontItalic) { DocWrite("font-style:italic;"); }
        else if (fontItalic == "false" && TrFontItalic) { DocWrite("font-style:normal;"); }

        if (style != "") { DocWrite(style + ";"); }

        DocWrite("'>&nbsp;&nbsp;");

        if (Item[i][2] != null && links != "" && links != "undefined" && links != null) {
            DocWrite("<a href='" + links + "'");

            if (Item[i][3] != "undefined" && Item[i][3] != null) { DocWrite(" target='" + target + "'"); }

            DocWrite(">");
        }
        DocWrite(caption);

        if (Item[i][2] != null && links != "" && links != "undefined" && links != null) { DocWrite("</a>"); }

        DocWrite("</td>");
    }

    function GetSpace(CurItem, Depth, bBlank) {
        var Space = "<img src='" + ImgDir + "white.gif' height='20' width='" + 20 * Depth + "' >";
        return Space;
    }

    function bHaveSameDepthChildItem(CurItem, Depth) {
        if (CurItem < 0 || CurItem > Item.length) { return false; }

        var PItem = Item[CurItem][0];
        var RootItem = GetRootItemEx(PItem, Depth);

        if (GetItemCount(RootItem, Depth) >= 2) { return true; }
        else { return false; }
    }

    function GetChildItems(iNode) {
        var ChildItems = "";
        var CurDepth = Item[iNode][4];

        for (var i = iNode + 1; i < Item.length; i++) {

            if (CurDepth >= Item[i][4]) { return ChildItems; }

            if (Item[i][4] > Item[iNode][4]) { ChildItems += i + ";" }
        }

        return ChildItems;
    }

    function ToggleTree(CurNode, NodeItem) {
        if (NodeItem == "") { return; }

        var NodeStatus;
        var arr = new Array();

        arr = NodeItem.split(";");

        if (Item[CurNode][5] == true) {
            ToggleDisplayLayer(arr, CurNode, "none");
            Item[CurNode][5] = false;
        } else {
            ToggleDisplayLayer(arr, CurNode, "");
            Item[CurNode][5] = true;
            ResetItem(CurNode);
        }
    }

    function ToggleDisplayLayer(ItemArray, CurNode, Display) {
        var NodeImg;
        var bShow;

        if (Display == "none") { bShow = false; }
        else { bShow = true; }

        if (!bShow) {
            NodeImg = ImgDir + "ExpandTree.gif";
        }
        else {
            NodeImg = ImgDir + "ContractTree.gif";
        }

        for (var i = 0; i < ItemArray.length - 1; i++) {
            SetTreeVisible(ItemArray[i], bShow);
            SetImgVisible(CurNode, NodeImg, 1);
        }
    }

    function ResetItem(iNode) {
        for (var i = iNode; i < Item.length; i++) {

            if (!Item[i][5]) {
                var arr = new Array();
                arr = GetChildItems(i).split(";");

                for (var j = 0; j < arr.length - 1; j++) {
                    SetTreeVisible(arr[j], false);
                }
            }
        }
    }

    function SetTreeVisible(iItem, bShow) {
        if (!bShow) {
            if (browserVersion == 1) {
                Doc["wsTree_" + iItem].style.display = "none";

            } else if (browserVersion == 3) {
                document.getElementById("wsTree_" + iItem).style.display = "none";

            } else {
                Doc["wsTree_" + iItem].visibility = "hiden";
            }

        } else {
            if (browserVersion == 1) {
                Doc["wsTree_" + iItem].style.display = "block";

            } else if (browserVersion == 3) {
                Doc.getElementById("wsTree_" + iItem).style.display = "";

            } else {
                Doc["wsTree_" + iItem].visibility = "show";
            }
        }
    }

    function SetImgVisible(iItem, ImgName, iType) {
        var ItemName;
        switch (iType) {
            case 1: ItemName = "wsTreeNodeImg_"; break;
            case 2: ItemName = "wsTreeItemImg_"; break;
            default: ItemName = "wsTreeItemImg_"; break;
        }

        if (browserVersion == 3) {
            Doc.getElementById(ItemName + iItem).src = ImgName;

        } else {
            Doc[ItemName + iItem].src = ImgName;
        }
    }

    function ExpandAllTree() {
        for (var i = Item.length - 1; i >= 0; i--) {
            Item[i][5] = false;
            ToggleTree(i, GetChildItems(i));
        }
    }

    function RecudeAllTree() {
        for (var i = Item.length - 1; i >= 0; i--) {
            Item[i][5] = true;
            ToggleTree(i, GetChildItems(i));
        }
    }

    function GetRootItem(ChildItem) {
        if (Item[ChildItem] == null) { return; }
        if (Item[ChildItem][4] == 0) {
            return ChildItem;
        } else {
            return GetRootItem(Item[ChildItem][0]);
        }
    }

    function GetRootItemEx(ChildItem, Depth) {
        if (Item[ChildItem][4] == Depth) {
            return ChildItem;
        } else {
            return GetRootItem(Item[ChildItem][0], Depth);
        }
    }

    function GetItemCount(CurItem, Depth) {
        var nRet = 0;

        for (var i = CurItem; i < Item.length; i++) {
            if (Item[i][4] < Depth) break;

            if (Item[i][4] == Depth) { nRet++; }
        }

        return nRet;
    }

    function DocWrite(strHtml) {
        var getHtml = document.getElementById("getHtml");
        if (getHtml != null) { getHtml.value += strHtml; }
        document.write(strHtml);
    }
}

function ToggleTree(CurNode, NodeItem) {
    treeGrid.ToggleTree(CurNode, NodeItem);
}
