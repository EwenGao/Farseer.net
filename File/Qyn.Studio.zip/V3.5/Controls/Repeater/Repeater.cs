﻿using System;
using System.ComponentModel;
using System.Web.UI;
using Qyn.Studio.Tools;
using Qyn.Studio.Extend;
using System.Web.UI.WebControls;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 带分页
    /// </summary>
    [ToolboxData("<{0}:Repeater ID=\"RptList\" runat=server><ItemTemplate><tr><td><%# ((string)Container.DataItem)%></td></tr></ItemTemplate><PaginationHtml><tr class=\"tdbg\" align=\"center\" style=\"height: 28px;\"><td colspan=\"12\"><Pagination /></td></tr></PaginationHtml></{0}:Repeater>")]
    public partial class Repeater : System.Web.UI.WebControls.Repeater
    {
        /// <summary>
        /// 输出Html
        /// </summary>
        /// <param name="writer">HtmlTextWriter</param>
        protected override void Render(HtmlTextWriter writer)
        {
            base.Render(writer);

            if (!IsShowNotEnough && m_PageCount < 2) { return; }

            string htmlPagination = string.Empty;
            if (PageType == eumPageType.Html)
            { htmlPagination = PagePagination.HtmlPagination(PageCount, PageIndex, PageSize, PageUrl + UrlParms, Selected, NoSelected, IsShowJump, IsShowRecordCount); }
            //else if (PageType == eumPageType.Ajax)
            //{ htmlPagination = PagePagination.AjaxPagination(PageCount, PageIndex, PageSize, PageUrl + UrlParms, Selected, NoSelected, IsShowJump, IsShowRecordCount); }
            else
            { htmlPagination = PagePagination.AspxPagination(PageCount, PageIndex, PageSize, PageUrl + UrlParms, Selected, NoSelected, IsShowJump, IsShowRecordCount); }

            if (!ChangePageSize)
            {
                htmlPagination = htmlPagination.ClearString(string.Format("pageSize={0}&", PageSize));
                htmlPagination = htmlPagination.ClearString(string.Format("?pageSize={0}", PageSize));
                htmlPagination = htmlPagination.ClearString(string.Format("pageSize={0}", PageSize));
            }

            if (Languange == LanguageType.English)
            {
                htmlPagination = htmlPagination.Replace("条记录", "RecordCount")
                                               .Replace("上一页", "Previous")
                                               .Replace("下一页", "Next")
                                               .Replace("首页", "First")
                                               .Replace("尾页", "End")
                                               .Replace("跳转", "Jump")
                                               .Replace("页", "Page");
            }
            writer.WriteLine(PaginationHtml.Replace("<Pagination />", htmlPagination).Replace("<pagination />", htmlPagination));
        }
    }
}