﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using System.Drawing;
using Qyn.Studio.Utils;
using Qyn.Studio.Configs;
using System.IO;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    [
     DefaultProperty("PageSize"),
     ToolboxData("<{0}:UpLoadFile runat=server />")
    ]
    public partial class UpLoadFile : CompositeControl
    {
        /// <summary>
        /// 输出控件视图
        /// </summary>
        /// <param name="writer"></param>
        protected override void RenderContents(HtmlTextWriter writer)
        {
            img.ImageUrl = UploadDomain + SavePath;        //显示图片

            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            if (img.Visible) { img.RenderControl(writer); }
            writer.RenderEndTag();
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            if (pnlZipped.Visible) { pnlZipped.RenderControl(writer); }

            txtFilePath.RenderControl(writer);

            writer.Write("<br />");
            file.RenderControl(writer);
            
            btnUpLoad.RenderControl(writer);
            
            if (!string.IsNullOrEmpty(lblMessage.Text)) { lblMessage.RenderControl(writer); }

            writer.RenderEndTag();
        }

        /// <summary>
        /// 初始化控件
        /// </summary>
        protected override void CreateChildControls()
        {
            Controls.Clear();
            pnlZipped = new Panel();
            pnlZipped.ID = "pnlZipped";
            Controls.Add(pnlZipped);

            chkIsZipped = new CheckBox();
            chkIsZipped.ID = "chkIsZipped";
            chkIsZipped.Text = "压缩图片";
            pnlZipped.Controls.Add(chkIsZipped);

            lblZippedWidth = new Label();
            lblZippedWidth.ID = "lblZippedWidth";
            lblZippedWidth.Text = "   宽度：";
            pnlZipped.Controls.Add(lblZippedWidth);

            txtZippedWidth = new TextBox();
            txtZippedWidth.ID = "txtZippedWidth";
            txtZippedWidth.Text = "0";
            txtZippedWidth.Width = 40;
            pnlZipped.Controls.Add(txtZippedWidth);

            lblZippedHeight = new Label();
            lblZippedHeight.ID = "lblZippedHeight";
            lblZippedHeight.Text = "   高度：";
            pnlZipped.Controls.Add(lblZippedHeight);

            txtZippedHeight = new TextBox();
            txtZippedHeight.ID = "txtZippedHeight";
            txtZippedHeight.Text = "0";
            txtZippedHeight.Width = 40;
            pnlZipped.Controls.Add(txtZippedHeight);

            txtFilePath = new TextBox();
            txtFilePath.ID = "txtSavePath";
            txtFilePath.Width = 250;
            Controls.Add(txtFilePath);

            file = new FileUpload();
            file.ID = "filePath";
            file.Width = 320;
            Controls.Add(file);

            img = new System.Web.UI.WebControls.Image();
            img.ID = "imgPath";
            Controls.Add(img);

            btnUpLoad = new Button();
            btnUpLoad.ID = "btnUpLoad";
            btnUpLoad.Text = "上传";
            btnUpLoad.CommandName = "OnUpLoad";
            Controls.Add(btnUpLoad);

            lblMessage = new Label();
            lblMessage.ID = "lblMessage";
            Controls.Add(lblMessage);

            //告诉编译器，控件已经初始化了
            ChildControlsCreated = true;


        }
    }
}