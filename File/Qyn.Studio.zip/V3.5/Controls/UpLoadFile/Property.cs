﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;

using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using System.Drawing;
using Qyn.Studio.Utils;
using Qyn.Studio.Configs;
using System.IO;
using System.Web;


namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    public partial class UpLoadFile : CompositeControl
    {
        /// <summary>
        /// 文件上传后，保存的路径
        /// </summary>
        private TextBox txtFilePath { get; set; }
        /// <summary>
        /// 文件上传控件
        /// </summary>
        private FileUpload file { get; set; }
        /// <summary>
        /// 图片显示控件
        /// </summary>
        private System.Web.UI.WebControls.Image img { get; set; }
        /// <summary>
        /// 上传按扭
        /// </summary>
        private Button btnUpLoad { get; set; }

        /// <summary>
        /// 提示信息
        /// </summary>
        private Label lblMessage { get; set; }

        /// <summary>
        /// 是否启用压缩
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue("false"),
        Description("是否启用压缩"),
        Browsable(true)
        ]
        public bool IsShowZipped { get { return pnlZipped.Visible; } set { pnlZipped.Visible = value; } }
        private CheckBox chkIsZipped { get; set; }
        private Label lblZippedWidth { get; set; }
        public TextBox txtZippedWidth { get; set; }
        private Label lblZippedHeight { get; set; }
        public TextBox txtZippedHeight { get; set; }
        private Panel pnlZipped { get; set; }

        /// <summary>
        /// 初始化
        /// </summary>
        public UpLoadFile()
        {
            if (HttpContext.Current != null && GeneralConfigs.ConfigInfo != null)
            {
                UploadDomain = QynRequest.GetDomain() + "/";
                UploadMapPath = ParseUrl.GetMapPath("/");
                UploadDirectory = GeneralConfigs.ConfigInfo.UploadDirectory;
            }
            else { UploadDomain = UploadMapPath = UploadDirectory = string.Empty; }
            EnsureChildControls();
        }

        /// <summary>
        /// 保存到数据库的路径
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("保存到数据库的路径"),
        Browsable(true)
        ]
        public string SavePath
        {
            get { return txtFilePath.Text; }
            set { txtFilePath.Text = value; }
        }

        /// <summary>
        /// 图片显示根
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("图片显示根"),
        Browsable(true)
        ]
        public string UploadDomain { get; set; }

        /// <summary>
        /// 传入服务器的物理路径
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("传入服务器的物理路径"),
        Browsable(true)
        ]
        public string UploadMapPath { get; set; }

        /// <summary>
        /// 传入服务器的根文件夹
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("传入服务器的根文件夹"),
        Browsable(true)
        ]
        public string UploadDirectory { get; set; }

        /// <summary>
        /// 是否显示图片预览
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("是否显示图片预览"),
        Browsable(true)
        ]
        public bool IsShowImage
        {
            get { return img.Visible; }
            set { img.Visible = value; }
        }

        /// <summary>
        /// 是否显示路径文本框
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("是否显示路径文本框"),
        Browsable(true)
        ]
        public bool IsShowFilePath
        {
            get { return txtFilePath.Visible; }
            set { txtFilePath.Visible = value; }
        }

        /// <summary>
        /// 保存方式
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("保存方式"),
        Browsable(true)
        ]
        public Qyn.Studio.Tools.UpLoadFile.SaveType SaveType { get; set; }

        /// <summary>
        /// 上传的文件权限
        /// </summary>
        [
        Category("UpLoadFile"),
        DefaultValue(""),
        Description("上传的文件权限"),
        Browsable(true)
        ]
        public List<Qyn.Studio.Tools.UpLoadFile.stuUpLoadFileType> UpLoadFileTypeList { get; set; }


    }
}
