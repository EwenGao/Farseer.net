﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Web.UI;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 导航控件
    /// </summary>
    [
     DefaultProperty("QynNavigation"),
     ToolboxData("<{0}:Navigation runat=server />")
    ]
    public class Navigation : Control
    {
        /// <summary>
        /// 输出Html
        /// </summary>
        /// <param name="writer">HtmlTextWriter</param>
        protected override void Render(HtmlTextWriter writer)
        {
            string str = @"
    <span>后台管理</span><span> &gt;&gt; </span>
";
            writer.WriteLine(str);
        }
    }
}
