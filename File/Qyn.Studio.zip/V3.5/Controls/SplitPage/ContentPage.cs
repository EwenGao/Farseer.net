﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using System.Drawing;
using Qyn.Studio.Utils;
using Qyn.Studio.Configs;
using System.IO;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 文章分页组件
    /// </summary>
    [
     ToolboxData("<{0}:ContentPage runat=\"server\" ID=\"ContentPage\" DivID=\"ContentPage\"  IndexClass=\"quotes\"/>")
    ]
    public class ContentPage : Control
    {
        /// <summary>
        /// 文章内容
        /// </summary>
        public string Contents { set; get; }
        /// <summary>
        /// 文章页数
        /// </summary>
        private int PageCount;
        /// <summary>
        /// 分页数组
        /// </summary>
        private string[] PageArr;

        #region Div
        #region Height
        private string divHeight = string.Empty;
        /// <summary>
        /// Div高度
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div高度"),
        Browsable(true)
        ]
        public string DivHeight
        {
            get { return divHeight; }
            set { divHeight = value; }
        }
        #endregion

        #region Width
        private string divWidth = string.Empty;
        /// <summary>
        /// Div宽度
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div宽度"),
        Browsable(true)
        ]
        public string DivWidth
        {
            get { return divWidth; }
            set { divWidth = value; }
        }
        #endregion

        #region Color
        private string divColor = string.Empty;
        /// <summary>
        /// Div前景色
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div前景色"),
        Browsable(true)
        ]
        public string DivColor
        {
            get { return divColor; }
            set { divColor = value; }
        }
        #endregion

        #region BackgroundColor
        private string divBackgroundColor = string.Empty;
        /// <summary>
        /// Div背景色
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div背景色"),
        Browsable(true)
        ]
        public string DivBackgroundColor
        {
            get { return divBackgroundColor; }
            set { divBackgroundColor = value; }
        }
        #endregion

        #region BorderWidth
        private string divBorderWidth = string.Empty;
        /// <summary>
        /// Div边框宽度
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div边框宽度"),
        Browsable(true)
        ]
        public string DivBorderWidth
        {
            get { return divBorderWidth; }
            set { divBorderWidth = value; }
        }
        #endregion

        #region FontSize
        private string divFontSize = string.Empty;
        /// <summary>
        /// Div字体大小
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div字体大小"),
        Browsable(true)
        ]
        public string DivFontSize
        {
            get { return divFontSize; }
            set { divFontSize = value; }
        }
        #endregion

        #region FontFamily
        private string divFontFamily = string.Empty;
        /// <summary>
        /// Div字体样式
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("Div字体样式"),
        Browsable(true)
        ]
        public string DivFontFamily
        {
            get { return divFontFamily; }
            set { divFontFamily = value; }
        }
        #endregion

        #region Class
        private string divClass = string.Empty;
        /// <summary>
        /// DivClassName
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivClassName"),
        Browsable(true)
        ]
        public string DivClass
        {
            get { return divClass; }
            set { divClass = value; }
        }
        #endregion

        #region Style
        private string divStyle = string.Empty;
        /// <summary>
        /// DivStyle
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivStyle"),
        Browsable(true)
        ]
        public string DivStyle
        {
            get { return divStyle; }
            set { divStyle = value; }
        }
        #endregion

        #region ID
        private string divID = string.Empty;
        /// <summary>
        /// DivID
        /// </summary>
        [
        Category("Div"),
        DefaultValue("ContentPage"),
        Description("DivID"),
        Browsable(true)
        ]
        public string DivID
        {
            get { return divID; }
            set { divID = value; }
        }
        #endregion

        #region Name
        private string divName = string.Empty;
        /// <summary>
        /// DivName
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("DivName"),
        Browsable(true)
        ]
        public string DivName
        {
            get { return divName; }
            set { divName = value; }
        }
        #endregion

        #region IndexClass
        private string indexClass = string.Empty;
        /// <summary>
        /// DivName
        /// </summary>
        [
        Category("Div"),
        DefaultValue(""),
        Description("IndexClass"),
        Browsable(true)
        ]
        public string IndexClass
        {
            get { return indexClass; }
            set { indexClass = value; }
        }
        #endregion

        #endregion

        protected override void Render(HtmlTextWriter writer)
        {
            if (!string.IsNullOrEmpty(DivWidth)) { writer.AddStyleAttribute(HtmlTextWriterStyle.Width, DivWidth); }
            if (!string.IsNullOrEmpty(DivHeight)) { writer.AddStyleAttribute(HtmlTextWriterStyle.Height, DivHeight); }
            if (!string.IsNullOrEmpty(DivColor)) { writer.AddStyleAttribute(HtmlTextWriterStyle.Color, DivColor); }
            if (!string.IsNullOrEmpty(DivBackgroundColor)) { writer.AddStyleAttribute(HtmlTextWriterStyle.BackgroundColor, DivBackgroundColor); }
            if (!string.IsNullOrEmpty(DivBorderWidth)) { writer.AddStyleAttribute(HtmlTextWriterStyle.BorderWidth, DivBorderWidth); }
            if (!string.IsNullOrEmpty(DivFontSize)) { writer.AddStyleAttribute(HtmlTextWriterStyle.FontSize, DivFontSize); }
            if (!string.IsNullOrEmpty(DivFontFamily)) { writer.AddStyleAttribute(HtmlTextWriterStyle.FontFamily, DivFontFamily); }
            if (!string.IsNullOrEmpty(DivStyle)) { writer.AddAttribute(HtmlTextWriterAttribute.Style, DivStyle); }
            if (!string.IsNullOrEmpty(DivID)) { writer.AddAttribute(HtmlTextWriterAttribute.Id, DivID); }
            if (!string.IsNullOrEmpty(DivName)) { writer.AddAttribute(HtmlTextWriterAttribute.Name, DivName); }
            if (!string.IsNullOrEmpty(DivClass)) { writer.AddAttribute(HtmlTextWriterAttribute.Class, DivClass); }
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
            for (int i = 0; i < PageArr.Length; i++)
            {
                writer.AddAttribute(HtmlTextWriterAttribute.Id, "CPChild" + i.ToString());
                writer.AddAttribute(HtmlTextWriterAttribute.Name, "CPChild");
                if (i != 0) { writer.AddStyleAttribute(HtmlTextWriterStyle.Display, "none"); }
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.Write(PageArr[i]);
                writer.RenderEndTag();
                writer.WriteLine();
            }
            writer.RenderEndTag();
            if (PageCount > 1)
            {
                writer.AddAttribute("id", "CPindex" + divID);
                if (!string.IsNullOrEmpty(indexClass)) writer.AddAttribute(HtmlTextWriterAttribute.Class, indexClass);
                writer.RenderBeginTag(HtmlTextWriterTag.Div);
                writer.RenderBeginTag(HtmlTextWriterTag.A);
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "Pagination");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write("首页");
                writer.RenderEndTag();
                writer.RenderEndTag();
                writer.Write("&nbsp;&nbsp;");
                for (int i = 0; i < PageArr.Length; i++)
                {
                    writer.RenderBeginTag(HtmlTextWriterTag.A);
                    if (i != 0) { writer.AddAttribute(HtmlTextWriterAttribute.Class, "Pagination"); }
                    else
                    {
                        writer.AddAttribute(HtmlTextWriterAttribute.Class, "current");
                    }
                    writer.RenderBeginTag(HtmlTextWriterTag.Span);
                    writer.Write((i + 1).ToString());
                    writer.RenderEndTag();
                    writer.RenderEndTag();
                    writer.Write("&nbsp;&nbsp;");
                }

                writer.RenderBeginTag(HtmlTextWriterTag.A);
                writer.AddAttribute(HtmlTextWriterAttribute.Class, "Pagination");
                writer.RenderBeginTag(HtmlTextWriterTag.Span);
                writer.Write("尾页");
                writer.RenderEndTag();
                writer.RenderEndTag();
                writer.RenderEndTag();
                writer.AddAttribute("language", "javascript");
                writer.AddAttribute("type", "text/javascript");
                writer.RenderBeginTag(HtmlTextWriterTag.Script);
                writer.Write("(function(obj){var arrdiv=obj.getElementsByTagName(\"div\");var arra=document.getElementById(\"CPindex\"+obj.id).getElementsByTagName(\"a\");for(var i=0;i<arrdiv.length;i++){(function(j){arra[j+1].onclick=function(){scrollTo(0,0);for(var t=0;t<arra.length;t++){if(arra[t]==arra[j+1]){arra[t].getElementsByTagName(\"span\")[0].className = \"current\";}else{ arra[t].getElementsByTagName(\"span\")[0].className = \"Pagination\";}}for(var t=0;t<arrdiv.length;t++){if(t==j){arrdiv[t].style.cssText=\"\";}else{arrdiv[t].style.display=\"none\";}}} ");
                writer.WriteLine();
                writer.Write("if(j==0)arra[j].onclick=arra[j+1].onclick; if(j==arrdiv.length-1)arra[j+2].onclick=arra[j+1].onclick;})(i);}})(document.getElementById('" + divID + "'));");
                writer.RenderEndTag();
            }
        }
        /// <summary>
        /// 初始化控件
        /// </summary>
        protected override void CreateChildControls()
        {
            Controls.Clear();
            if (Contents.Length != 0)
            {
                PageArr = Contents.Split(new string[] { "[NextPage]" }, StringSplitOptions.RemoveEmptyEntries);
                PageCount = PageArr.Length;
            }
            else
            {
                PageArr = new string[] { };
                PageCount = 0;
            }
            //告诉编译器，控件已经初始化了
            ChildControlsCreated = true;
        }
    }
}
