﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.ComponentModel;
using System.Web.UI.WebControls;
using Qyn.Studio.Base;


[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls.DropDownList
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    public partial class DropDownList
    {
        /// <summary>
        /// 分类实体类
        /// </summary>
        public List<BaseCateInfo> ListCateInfo
        { get { return ViewState["ListCateInfo"] == null ? new List<BaseCateInfo>() : (List<BaseCateInfo>)ViewState["ListCateInfo"]; } set { ViewState["ListCateInfo"] = value; } }

        /// <summary>
        /// 选中的值
        /// </summary>
        public List<object> ListSelected
        { get { return ViewState["ListSelected"] == null ? new List<object>() : (List<object>)ViewState["ListSelected"]; } set { ViewState["ListSelected"] = value; } }
    }

}
