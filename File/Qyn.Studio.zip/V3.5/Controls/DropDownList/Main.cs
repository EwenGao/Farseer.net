﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.ComponentModel;
using System.Web.UI.WebControls;
using Qyn.Studio.Utils;
using Qyn.Studio.Extend;
using Qyn.Studio.Base;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls.DropDownList
{
    /// <summary>
    /// 上传文件组件
    /// </summary>
    [
     DefaultProperty("PageSize"),
     ToolboxData("<{0}:DropDownList runat=server />")
    ]
    public partial class DropDownList : CompositeControl
    {
        /// <summary>
        /// 输出控件视图
        /// </summary>
        /// <param name="writer"></param>
        public override void RenderControl(HtmlTextWriter writer)
        {
            foreach (Control con in Controls)
            {
                con.RenderControl(writer);
            }
        }

        /// <summary>
        /// 初始化控件
        /// </summary>
        protected override void CreateChildControls()
        {
            Controls.Clear();
            AddSubDropDownList(0);
            //告诉编译器，控件已经初始化了
            ChildControlsCreated = true;

        }

        /// <summary>
        /// 添加DropDownList
        /// </summary>
        /// <param name="parentID"></param>
        protected void AddSubDropDownList(int parentID)
        {
            if (ListCateInfo == null) { return; }
            List<BaseCateInfo> lstCateInfo = ListCateInfo.Where(o => o.ParentID == parentID).ToList<BaseCateInfo>();
            if (lstCateInfo != null && lstCateInfo.Count > 0)
            {
                System.Web.UI.WebControls.DropDownList ddl = new System.Web.UI.WebControls.DropDownList();
                ddl.SelectedIndexChanged += new System.EventHandler(ddl_SelectedIndexChanged);
                ddl.AutoPostBack = true;
                ddl.ID = "qddl_" + Controls.Count.ToString();

                ParseBind.WebControl(ddl, lstCateInfo);

                Controls.Add(ddl);

                if (ListSelected == null || ListSelected.Count < Controls.Count)
                { AddSelected(ddl.Items[0].Value); }

                //ParseBind.WebControlSelectedItem(ddl, ListSelected[Controls.Count - 1]);
                ddl_SelectedIndexChanged(ddl, null);
            }

            //if (Controls.Count > 0) { ddl_SelectedIndexChanged(Controls[Controls.Count - 1], null); }
        }

        /// <summary>
        /// DropDownList事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            System.Web.UI.WebControls.DropDownList ddl = sender as System.Web.UI.WebControls.DropDownList;
            int value = ddl.SelectedValue.ConvertType(0);

            SetSelected(ddl.ID.ClearString("qddl_").ConvertType(0), ddl.SelectedValue);

            if (value > 0) { AddSubDropDownList(value); }

        }

        /// <summary>
        /// 添加选中的值
        /// </summary>
        /// <param name="value"></param>
        protected void AddSelected(object value)
        {
            List<object> lst = ListSelected;
            lst.Add(value);
            ListSelected = lst;
        }

        /// <summary>
        /// 设置选中值的选项
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        protected void SetSelected(int index, object value)
        {
            List<object> lst = ListSelected;
            lst[index] = value;
            ListSelected = lst;
        }

        #region IPostBackEventHandler Members

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventArgument"></param>
        public void RaisePostBackEvent(string eventArgument)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

}
