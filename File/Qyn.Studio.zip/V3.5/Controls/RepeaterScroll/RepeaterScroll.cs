﻿using System;
using System.ComponentModel;
using System.Web.UI;
using Qyn.Studio.Tools;
using Qyn.Studio.Extend;
using System.Web.UI.WebControls;

[assembly: TagPrefix("Qyn.Studio.Controls", "Qyn")]
namespace Qyn.Studio.Controls
{
    /// <summary>
    /// 滚动图片
    /// </summary>
    [ToolboxData("<{0}:RepeaterScroll ID=\"RptScrollList\" runat=server><li></li></{0}:RepeaterScroll>")]
    public class RepeaterScroll : Control
    {
        #region Direction
        private eumDirection direction = eumDirection.Top;
        /// <summary>
        /// 滚动方向
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue(0),
        Description("滚动方向"),
        Browsable(true)
        ]
        public eumDirection Direction
        {
            get { return direction; }
            set { direction = value; }
        }
        #endregion

        #region Speed
        private int speed = 65;
        /// <summary>
        /// 滚动速度
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue(0),
        Description("滚动速度"),
        Browsable(true)
        ]
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }
        #endregion

        #region Width
        private int width = 200;
        /// <summary>
        /// DIV宽度
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue(0),
        Description("DIV宽度"),
        Browsable(true)
        ]
        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        #endregion

        #region Height
        private int height = 500;
        /// <summary>
        /// DIV高度
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue(0),
        Description("DIV高度"),
        Browsable(true)
        ]
        public int Height
        {
            get { return height; }
            set { height = value; }
        }
        #endregion

        #region DivID
        private string divID = "DivID";
        /// <summary>
        /// Div的ID，最外层
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue("divContent"),
        Description("Div的ID，最外层"),
        Browsable(true)
        ]
        public string DivID
        {
            get { return divID; }
            set { divID = value; }
        }
        #endregion

        #region DivSubTopID
        private string divSubTopID = "DivSubTopID";
        /// <summary>
        /// 内层的上层
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue("DivSubTopID"),
        Description("内层的上层"),
        Browsable(true)
        ]
        public string DivSubTopID
        {
            get { return divSubTopID; }
            set { divSubTopID = value; }
        }
        #endregion

        #region DivSubBottomID
        private string divSubBottomID = "DivSubBottomID";
        /// <summary>
        /// 内层的下层
        /// </summary>
        [
        Category("滚动样式"),
        DefaultValue("DivSubBottomID"),
        Description("内层的下层"),
        Browsable(true)
        ]
        public string DivSubBottomID
        {
            get { return divSubBottomID; }
            set { divSubBottomID = value; }
        }
        #endregion

        /// <summary>
        /// 滚动方向
        /// </summary>
        public enum eumDirection
        {
            /// <summary>
            /// 从下向上
            /// </summary>
            Top,
            /// <summary>
            /// 从上向下
            /// </summary>
            Bottm,
            /// <summary>
            /// 从右向左
            /// </summary>
            Left,
            /// <summary>
            /// 从左向右
            /// </summary>
            Right
        }

        /// <summary>
        /// 输出Html
        /// </summary>
        /// <param name="writer">HtmlTextWriter</param>
        protected override void Render(HtmlTextWriter writer)
        {
            StringPlus str = new StringPlus();
            str.AppendFormatLine("<div id=\"{0}\" style=\"overflow: hidden; width: {1}px; height: {2}px\">", DivID, Width, Height);
            str.AppendFormatLine("<div id=\"{0}\" style=\"overflow: hidden\">", DivSubTopID);
            str.AppendLine("<ul>");
            writer.WriteLine(str.Value);
            str.Clear();
            base.Render(writer);
            str.AppendLine("</ul>");
            str.AppendLine("</div>");
            str.AppendFormatLine("<div id=\"{0}\">", DivSubBottomID);
            str.AppendLine("</div>");
            str.AppendLine("</div>");

            str.AppendLine("<script type=\"text/javascript\">");

            str.AppendFormatLine("{0}.innerHTML = {1}.innerHTML;", DivSubBottomID, DivSubTopID);
            str.AppendFormatLine("var divPicMove = 0;");

            str.AppendLine("function Marquee() {");

            #region 设置移动方向
            if (Direction == eumDirection.Top)
            {
                str.AppendLine(DivID + ".scrollTop++;");
                str.AppendLine("if (divPicMove == " + DivID + ".scrollTop) { " + DivID + ".scrollTop -= " + DivSubTopID + ".offsetHeight; }");
                str.AppendLine("divPicMove = " + DivID + ".scrollTop;");
            }
            else if (Direction == eumDirection.Right)
            {
                str.AppendLine(DivID + ".scrollLeft--;");
                str.AppendLine("if (divPicMove == " + DivID + ".scrollLeft) { " + DivID + ".scrollLeft += " + DivSubBottomID + ".offsetWidth; }");
                str.AppendLine("divPicMove = " + DivID + ".scrollLeft;");
            }
            else if (Direction == eumDirection.Bottm)
            {
                str.AppendLine(DivID + ".scrollTop--;");
                str.AppendLine("if (divPicMove == " + DivID + ".scrollTop) { " + DivID + ".scrollTop += " + DivSubBottomID + ".offsetHeight }");
                str.AppendLine("divPicMove = " + DivID + ".scrollTop;");
            }
            else
            {
                str.AppendLine(DivID + ".scrollLeft++;");
                str.AppendLine("if (divPicMove == " + DivID + ".scrollLeft) { " + DivID + ".scrollLeft -= " + DivSubTopID + ".offsetWidth }");
                str.AppendLine("divPicMove = " + DivID + ".scrollLeft;");
            }
            #endregion

            str.AppendLine("}");
            str.AppendLine("var MyMar2 = setInterval(Marquee, " + Speed + ");");

            str.AppendLine(DivID + ".onmouseover = function() { clearInterval(MyMar2) }");
            str.AppendLine(DivID + ".onmouseout = function() { MyMar2 = setInterval(Marquee, " + Speed + ") }");

            str.AppendLine("</script>");
            writer.WriteLine(str.Value);
            str.Clear();
        }
    }
}