﻿
namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 配置文件
    /// </summary>
    public class SystemConfig
    {
        #region 用户Cookies
        /// <summary>
        /// 用户ID
        /// </summary>
        public static readonly string UserID = "UserID";

        /// <summary>
        /// 用户名
        /// </summary>
        public static readonly string UserName = "UserName";

        #endregion

        #region 管理员Cookies
        /// <summary>
        /// 管理员ID的Cookies
        /// </summary>
        public static readonly string AdminID = "AdminID";

        /// <summary>
        /// 管理员名称的Cookies
        /// </summary>
        public static readonly string AdminName = "AdminName";

        #endregion

        /// <summary>
        /// 用户登陆验证码的
        /// </summary>
        public static readonly string UserVerifyCode = "UserCode";

        /// <summary>
        /// 管理员登陆验证码的
        /// </summary>
        public static readonly string AdminVerifyCode = "AdminCode";

        /// <summary>
        /// 管理员主题，一般只用于调试状态
        /// </summary>
        public static readonly string Themes = "AdminThemes";
    }
}
