﻿using System;
using System.IO;
using System.Web;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 配置管理工具
    /// </summary>
    public class BaseConfigs<T> where T : new()
    {
        /// <summary>
        /// 锁对象
        /// </summary>
        private static object m_LockHelper = new object();

        /// <summary>
        /// 配置文件路径
        /// </summary>
        private static string filePath;

        /// <summary> 
        /// 刷新计时器
        /// </summary>
        protected static System.Timers.Timer m_DbConfigTimer;

        /// <summary>
        /// 配置变量
        /// </summary>
        protected static T m_ConfigInfo;

        /// <summary>
        /// Config修改时间
        /// </summary>
        protected static DateTime FileOldChange;

        /// <summary>
        /// 获取配置文件所在路径
        /// </summary>
        protected static string FilePath
        {
            get
            {
                if (filePath.IsNullOrEmpty())
                {
                    string fileName = string.Format("{0}.config", typeof(T).Name.EndsWith("Config", true, null) ? typeof(T).Name.Substring(0, typeof(T).Name.Length - 6) : typeof(T).Name);
                    if (HttpContext.Current != null) { fileName = HttpContext.Current.Request.PhysicalApplicationPath + "/App_Data/" + fileName; }
                    else { fileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data/" + fileName); }
                    filePath = fileName;
                }
                return filePath;
            }
        }

        /// <summary>
        /// 配置变量
        /// </summary>
        public static T ConfigInfo
        {
            get
            {
                if (m_ConfigInfo == null) { ResetConfig(); }
                return m_ConfigInfo;
            }
        }

        static BaseConfigs()
        {
            m_DbConfigTimer = new System.Timers.Timer();
            m_DbConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);            //委托Timer_Elapsed事件          //读取Config文件.
            AutoResetOpen(true, 1);
            ResetConfig();
        }

        /// <summary>
        /// Timer_Elapsed
        /// </summary>
        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }

        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {
            m_ConfigInfo = LoadConfig(ref FileOldChange, true);
        }

        /// <summary>
        /// 开启自动检测Config
        /// </summary>
        /// <param name="isOpen">true：开启,false:关闭</param>
        /// <param name="time">单位：分</param>
        public static void AutoResetOpen(bool isOpen, int time)
        {
            time = time * 1000 * 60;
            if (isOpen)
            {
                m_DbConfigTimer = new System.Timers.Timer(time);
                m_DbConfigTimer.AutoReset = true;                                                           //连续运行Time
                m_DbConfigTimer.Enabled = true;                                                             //激活事件
                m_DbConfigTimer.Start();
            }
            else
            {
                if (m_DbConfigTimer != null)
                {
                    m_DbConfigTimer.AutoReset = false;
                    m_DbConfigTimer.Enabled = false;
                    m_DbConfigTimer.Close();
                }
            }
        }

        /// <summary>
        /// 加载(反序列化)指定对象类型的配置对象
        /// </summary>
        /// <param name="fileOldChange">文件使用时间</param>
        /// <param name="checkTime">是否检查并更新传递进来的"文件加载时间"变量</param>
        protected static T LoadConfig(ref DateTime fileOldChange, bool checkTime)
        {
            //不存在则自动接创建
            if (!File.Exists(FilePath))
            {
                SaveConfig(new T());
                fileOldChange = DateTime.Now;
                return new T();
            }

            if (checkTime) { fileOldChange = File.GetLastWriteTime(FilePath); }

            lock (m_LockHelper) { return SerializationHelper<T>.Load(FilePath); }

        }

        /// <summary>
        /// 保存(序列化)指定路径下的配置文件
        /// </summary>
        /// <param name="t">Config配置</param>
        public static bool SaveConfig(T t)
        {
            bool result = SerializationHelper<T>.Save(t, FilePath);
            ResetConfig();
            return result;
        }
    }
}
