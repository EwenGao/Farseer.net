﻿using System;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 全局
    /// </summary>
    public class GeneralConfigs : BaseConfigs<GeneralConfig> { }

    /// <summary>
    /// 网站基本设置描述类, 加[Serializable]标记为可序列化
    /// </summary>
    [Serializable]
    public class GeneralConfig
    {
        /// <summary>
        /// 是否调试
        /// </summary>
        public bool DeBug = false;
        /// <summary>
        /// 网站标题
        /// </summary>
        public string WebTitle = "感谢使用Qyn V3.6 FrameWork";

        #region Cookies配置
        /// <summary>
        /// Cookies前缀
        /// </summary>
        public string CookiesPrefix = "QynV3-5";
        /// <summary>
        /// Cookies超时时间(分钟)
        /// </summary>
        public int CookiesTimeOut = 20;

        /// <summary>
        /// Cookies域，不填，则自动当前域
        /// </summary>
        public string CookiesDomain = "";
        #endregion
        #region Session配置
        /// <summary>
        /// Session前缀
        /// </summary>
        public string SessionPrefix = "QynV3-5";
        /// <summary>
        /// Session超时时间(分钟)
        /// </summary>
        public int SessionTimeOut = 20;
        #endregion
        #region 前台路径配置
        /// <summary>
        /// 前台网站应用程序目录(相对于IIS)
        /// </summary>
        public string WebDirectory = "/";
        /// <summary>
        /// 前台登陆地址
        /// </summary>
        public string WebLoginUrl = "/Login.aspx";
        /// <summary>
        /// 前台退出地址
        /// </summary>
        public string WebLogoutUrl = "/Logout.ashx";
        #endregion
        #region 后台路径配置
        /// <summary>
        /// 后台网站应用程序目录(相对于IIS)
        /// </summary>
        public string AdminDirectory = "/Manage/";
        /// <summary>
        /// 后台登陆地址
        /// </summary>
        public string AdminLoginUrl = "/Manage/Login.aspx";
        /// <summary>
        /// 后台退出地址
        /// </summary>
        public string AdminLogoutUrl = "/Manage/Logout.ashx";
        #endregion
        #region 上传路径配置
        /// <summary>
        /// 上传文件的目录
        /// </summary>
        public string UploadDirectory = "UpLoadFile/";
        #endregion
    }
}
