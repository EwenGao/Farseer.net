﻿using System;
using System.Collections.Generic;
using Qyn.Studio.Data;

namespace Qyn.Studio.Configs
{
    /// <summary>
    /// 全局
    /// </summary>
    public class DbConfigs : BaseConfigs<DbConfig> { }

    /// <summary>
    /// 默认数据库路径
    /// </summary>
    [Serializable]
    public class DbConfig
    {
        /// <summary>
        /// 数据库连接列表，从/App_Data/Db.Configs读取回来
        /// </summary>
        public List<DbList> DataBaseList = new List<DbList>();
    }

    /// <summary>
    /// 数据库连接配置
    /// </summary>
    public class DbList
    {
        /// <summary>
        /// 数据库连接串
        /// </summary>
        public string Server = ".";

        /// <summary>
        /// 数据库帐号
        /// </summary>
        public string UserID = "sa";

        /// <summary>
        /// 数据库密码
        /// </summary>
        public string PassWord = "123456";

        /// <summary>
        /// 数据库类型
        /// </summary>
        public DataBaseType DataType = DataBaseType.SqlServer;

        /// <summary>
        /// 数据库版本
        /// </summary>
        public string DataVer = "2005";

        /// <summary>
        /// 最小连接池
        /// </summary>
        public int PoolMinSize = 16;

        /// <summary>
        /// 最大连接池
        /// </summary>
        public int PoolMaxSize = 100;

        /// <summary>
        /// 数据库目录
        /// </summary>
        public string Catalog = "Table";

        /// <summary>
        /// 数据库表前缀
        /// </summary>
        public string TablePrefix = "";

        /// <summary>
        /// 数据库连接时间限制，单位秒
        /// </summary>
        public int ConnectTimeout = 30;

        /// <summary>
        /// 数据库执行时间限制，单位秒
        /// </summary>
        public int CommandTimeout = 30;
    }
}
