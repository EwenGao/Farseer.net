﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.ORM;


namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存分类逻辑层
    /// </summary>
    /// <typeparam name="TInfo"></typeparam>
    /// <typeparam name="TProvider"></typeparam>
    public class BaseCateLogic<TInfo, TProvider> : BaseCacheLogic<TInfo, TProvider>
        where TProvider : BaseProvider<TInfo>, new()
        where TInfo : BaseCateInfo, new()
    {
        /// <summary>
        /// IProvider
        /// </summary>
        private static BaseProvider<TInfo> Provider = new TProvider();
        private static string Key = typeof(TProvider).FullName;
        private static Mapping Map = ModelCache.GetInfo(typeof(TInfo));

        /// <summary>
        /// 获取指定ParentID的ID列表
        /// </summary>
        /// <param name="isContainsSub">是否获取子节点</param>
        /// <param name="parentID"></param>
        public static List<int> GetSubIDList(int parentID, bool isContainsSub)
        {
            List<int> lst = new List<int>();
            foreach (int i in GetList(o => o.ParentID == parentID).Select(o => o.ID).ToList())
            {
                lst.Add(i);
                if (!isContainsSub) { continue; }
                lst.AddRange(GetSubIDList(i, isContainsSub));
            }
            return lst;
        }

        /// <summary>
        /// 获取分类ID
        /// </summary>
        /// <param name="caption">分类标题</param>
        /// <returns></returns>
        public static int GetID(string caption)
        {
            return GetValue("ID","Caption", caption).ConvertType(0);
        }

        /// <summary>
        /// 获取分类ID
        /// </summary>
        /// <param name="caption">分类标题</param>
        /// <param name="isNullAdd">true:不存在则自动创建</param>
        /// <returns></returns>
        public static int GetID(string caption,bool isNullAdd)
        {
            int ID = GetID(caption);
            if (ID < 1 && isNullAdd) { AddInfo(new TInfo() { Caption = caption, ParentID = 0 }, out ID); }
            return ID;
        }

        /// <summary>
        /// 获取根节点ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static int GetFirstID(int ID)
        {
            int parentID = -1;
            TInfo info = GetInfo(ID);
            if (info != null)
            {
                if (info.ParentID > 0)
                {
                    parentID = GetFirstID(info.ParentID);
                }
                else { parentID = info.ID; }
            }
            return parentID;
        }

        /// <summary>
        /// 获取上一级ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static int GetParentID(int ID)
        {
            TInfo info = GetInfo(ID);
            if (info != null) { return info.ParentID; }
            return 0;
        }

        /// <summary>
        /// 获取所有上级ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public static List<int> GetParentIDList(int ID)
        {
            List<int> lst = new List<int>();
            TInfo info = GetInfo(ID);
            if (info == null) { return lst; }

            lst.AddRange(GetParentIDList(info.ParentID));

            return lst;
        }

        /// <summary>
        /// 绑定到DropDownList
        /// </summary>
        /// <param name="ddl">要绑定的ddl控件</param>
        /// <param name="selectedValue">默认选则值</param>
        /// <param name="RemoveID">不加载的节点（包括子节点）</param>
        public static void Bind(DropDownList ddl, int selectedValue, int RemoveID)
        {
            Bind(ddl, selectedValue, RemoveID, null);
        }

        /// <summary>
        /// 绑定到DropDownList
        /// </summary>
        /// <param name="ddl">要绑定的ddl控件</param>
        /// <param name="selectedValue">默认选则值</param>
        /// <param name="RemoveID">不加载的节点（包括子节点）</param>
        /// <param name="match">筛选条件</param>
        public static void Bind(DropDownList ddl, int selectedValue, int RemoveID, Predicate<TInfo> match)
        {
            ddl.Items.Clear();

            BindFor(ddl, 0, 0, RemoveID, match);

            if (selectedValue > 0) { ParseBind.WebControlSelectedItem(ddl, selectedValue); }
        }

        /// <summary>
        /// 递归绑定
        /// </summary>
        private static void BindFor(DropDownList ddl, int parentID, int tagNum, int RemoveID, Predicate<TInfo> match)
        {
            List<TInfo> lst = GetList(match); if (lst == null || lst.Count == 0) { return; }
            lst = lst.FindAll(o => o.ParentID == parentID); if (lst == null || lst.Count == 0) { return; }

            foreach (TInfo info in lst)
            {
                if (info.ID == RemoveID) { continue; }
                ddl.Items.Add(new ListItem() { Value = info.ID.ToString(), Text = ParseString.FillTag(tagNum, "　") + "├─" + info.Caption });
                BindFor(ddl, info.ID, tagNum + 1, RemoveID, match);
            }
        }

    }
}
