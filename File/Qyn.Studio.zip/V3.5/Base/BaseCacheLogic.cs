﻿using System;
using System.Collections.Generic;
using System.Linq;
using Qyn.Studio.Controls;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using Qyn.Studio.Utils;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    public partial class BaseCacheLogic<TInfo, TProvider>
        where TProvider : BaseProvider<TInfo>, new()
        where TInfo : BaseInfo, new()
    {
        private static BaseProvider<TInfo> Provider = new TProvider();
        private static string Key = typeof(TProvider).FullName;
        private static Mapping Map = ModelCache.GetInfo(typeof(TInfo));
    }
}
