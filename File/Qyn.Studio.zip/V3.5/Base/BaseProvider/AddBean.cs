﻿using System.Data;

using Qyn.Studio.Extend;
using System.Collections.Generic;
using Qyn.Studio.ORM;
using System.Reflection;
using Qyn.Studio.Tools;
using Qyn.Studio.Data;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 返回修改的参数列表
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        private List<IDbDataParameter> GetAddParameter(TInfo info)
        {
            Mapping map = ModelCache.GetInfo(info.GetType());

            List<IDbDataParameter> lst = new List<IDbDataParameter>();

            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                if (!kic.Value.IsAdd) { continue; }

                lst.Add(NewParam(kic.Value.UsedName, kic.Key.GetValue(info, null)));
            }

            return lst;
        }

        /// <summary>
        /// 插入记录的通用方法（支持标识键插入）
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>是否插入成功</returns>
        public bool AddInfoByIdentity(TInfo info)
        {
            List<IDbDataParameter> parms = GetAddParameter(info);

            KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(Map.IndexName);
            parms.Insert(0, NewParam(Map.IndexName, kic.Key.GetValue(info, null)));

            if (parms.Count == 0) return false;

            //要更新的表
            StringPlus sql = new StringPlus();
            sql.AppendFormat("SET IDENTITY_INSERT [{0}] ON ; ", TableName);
            sql.AppendFormat("INSERT INTO [{0}]", TableName);

            #region 要插入的值
            string fields, values;
            fields = values = "(";
            foreach (IDbDataParameter param in parms)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";

            sql.AppendFormat(fields + " VALUES " + values);
            #endregion

            sql.AppendFormat(" SET IDENTITY_INSERT [{0}] OFF ; ", TableName);
            using (IDbProvider db = NewDbProvider())
            {
                return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
            }
        }

        /// <summary>
        /// 插入记录
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        public bool AddInfo(TInfo info, out int identity)
        {
            List<IDbDataParameter> parms = GetAddParameter(info);
            if (parms.Count == 0) { identity = -1; return false; }

            //要插入的表
            StringPlus sql = new StringPlus();
            sql.AppendFormat("INSERT INTO [{0}]", TableName);

            #region 要插入的值
            string fields, values;
            fields = values = "(";
            foreach (IDbDataParameter param in parms)
            {
                fields += string.Format("[{0}],", param.ParameterName.Substring(1));
                values += string.Format("{0},", param.ParameterName);
            }
            fields = fields.Substring(0, fields.Length - 1) + ")";
            values = values.Substring(0, values.Length - 1) + ")";

            sql.AppendFormat(fields + " VALUES " + values);
            #endregion

            using (IDbProvider db = NewDbProvider())
            {
                if (DataType == DataBaseType.SqlServer)
                {
                    if (!Map.IndexName.IsNullOrEmpty() && !Map.GetPropertyInfo().Value.IsAdd)
                    {
                        sql.Append(";SELECT @@IDENTITY");
                        identity = db.ExecuteScalar(CommandType.Text, sql.Value, parms.ToArray()).ConvertType(0);
                    }
                    else
                    {
                        identity = db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray());
                    }
                }
                else
                {
                    identity = db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray());
                }
            }
            return identity > 0;
        }
    }
}
