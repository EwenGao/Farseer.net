﻿using System.Data;
using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using System;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 删除单条记录(单条件)
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：True，失败：False</returns>
        public bool DropInfo(string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("DELETE FROM [{0}] WHERE [{1}] = @Value", TableName, conditionFieldName);

                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 删除单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：True，失败：False</returns>
        public bool DropInfo(string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("DELETE FROM [{0}]  {1}", TableName, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql) > 0;

            }
        }
    }
}
