﻿using System.Data;

using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using System;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 获取数量
        /// </summary>
        public int GetCount()
        {
            return GetCount(string.Empty);
        }

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public int GetCount(string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT Count(0) FROM [{0}] {1}", TableName, ParseHacker.Condition(condition));

                return db.ExecuteScalar(CommandType.Text, sql).ConvertType(0);

            }
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public int GetCount(string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT Count(0) FROM [{0}] WHERE [{1}] = @Value", TableName, conditionFieldName);

                return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);

            }
        }

        /// <summary>
        /// 获取数量(用Like方式)
        /// </summary>
        /// <param name="containsFieldName"></param>
        /// <param name="containsFieldValue"></param>
        /// <param name="condition"></param>
        /// <returns></returns>
        public int GetCountByLike(string containsFieldName, object containsFieldValue, string condition)
        {
            if (containsFieldValue is Enum) { containsFieldValue = (int)containsFieldValue; }

            string sql = string.Empty;

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", containsFieldValue)
                };

                switch (this.DataType)
                {
                    case DataBaseType.Access:
                        {
                            sql = string.Format("SELECT Count(0) FROM [{0}] WHERE instr([{1}],@Value) >0 {2}", TableName, containsFieldName, condition);
                            break;
                        }
                    default:
                        {
                            sql = string.Format("SELECT Count(0) FROM [{0}] WHERE CHARINDEX(@Value,[{1}]) >0 {2}", TableName, containsFieldName, condition);
                            break;
                        }
                }

                return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);

            }
        }

        /// <summary>
        /// 获取数量(用Like方式)
        /// </summary>
        /// <param name="containsFieldName"></param>
        /// <param name="containsFieldValue"></param>
        /// <param name="condition"></param>
        /// <returns></returns>
        public int GetCountByIndex(string containsFieldName, object containsFieldValue, string condition)
        {
            if (containsFieldValue is Enum) { containsFieldValue = (int)containsFieldValue; }

            string sql = string.Empty;

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", containsFieldValue)
                };

                switch (this.DataType)
                {
                    case DataBaseType.Access:
                        {
                            sql = string.Format("SELECT Count(0) FROM [{0}] WHERE instr([{1}],@Value) >0 {2}", TableName, containsFieldName, condition);
                            break;
                        }
                    case DataBaseType.SqlServer:
                        {
                            sql = string.Format("SELECT Count(0) FROM [{0}] WHERE CONTAINS({1},@Value) {2}", TableName, containsFieldName, condition);
                            break;
                        }
                    default:
                        {
                            sql = string.Format("SELECT Count(0) FROM [{0}] WHERE CHARINDEX(@Value,[{1}]) >0 {2}", TableName, containsFieldName, condition);
                            break;
                        }
                }

                return db.ExecuteScalar(CommandType.Text, sql, parms).ConvertType(0);

            }
        }
    }
}
