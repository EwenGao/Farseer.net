﻿using System.Data;

using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using Qyn.Studio.ORM;
using System;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        public DataTable GetDataTable(int pageIndex, int pageSize, string[] fieldNames, string sort, string condition, out int recordCount)
        {
            recordCount = GetCount(condition);
            sort = ParseHacker.Sort(sort);
            condition = ParseHacker.Condition(condition);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY " + ModelCache.GetInfo(typeof(TInfo)).IndexName + " ASC"; }
            string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM [{2}] {3}) a WHERE Row BETWEEN {4} AND {5}",
                        strFields, sort, TableName, condition, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize);
            }
            else
            {
                sql = string.Format("SELECT TOP {1} {0} FROM (SELECT TOP {2} {0} FROM [{3}] {4} {5}) a  {6}",
                    strFields, pageSize, pageSize * pageIndex, TableName, condition, sort, sort2);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                dt = db.GetDataTable(CommandType.Text, sql);
            }


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="recordCount">返回记录总数</param>
        public DataTable GetDataTable(int pageIndex, int pageSize, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            recordCount = GetCount(conditionFieldName, conditionFieldValue);
            sort = ParseHacker.Sort(sort);

            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }


            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");
            string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT {0} FROM (SELECT *,ROW_NUMBER() OVER({1}) as Row FROM [{2}] WHERE [{3}] = @Value) a WHERE Row BETWEEN {4} AND {5}",
                         strFields, sort, TableName, conditionFieldName, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize);
            }
            else
            {
                if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
                sql = string.Format("SELECT TOP {1} {0} FROM (SELECT TOP {2} * FROM [{3}] WHERE [{4}] = @Value {5}) a  {6}", strFields, pageSize, pageSize * pageIndex, TableName, conditionFieldName, sort, sort2);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                dt = db.GetDataTable(CommandType.Text, sql, parms);
            }


            return isReverse ? dt.Reverse() : dt;
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public DataTable GetDataTable(int top, string[] fieldNames, string sort, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string strTop = top > 0 ? "TOP " + top : string.Empty;
                string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

                string sql = string.Format("SELECT {0} {1} FROM [{2}] {3} {4}", strTop, strFields, TableName, ParseHacker.Condition(condition), ParseHacker.Sort(sort));

                return db.GetDataTable(CommandType.Text, sql);
            }
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public DataTable GetDataTable(int top, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string strTop = top > 0 ? "TOP " + top : string.Empty;
                string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

                string sql = string.Format("SELECT {0} {1} FROM [{2}] WHERE [{3}] = @Value {4}", strTop, strFields, TableName, conditionFieldName, ParseHacker.Sort(sort));

                return db.GetDataTable(CommandType.Text, sql, parms);
            }
        }

        /// <summary>
        /// 获取随机符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">返回多少条记录</param>
        /// <param name="condition">SQL条件语句</param>
        public DataTable GetListByRandom(int top, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT {0} * FROM [{1}] {2} order by newid()", top > 0 ? "TOP " + top : "", TableName, ParseHacker.Condition(condition));

                return db.GetDataTable(CommandType.Text, sql);
            }
        }

        /// <summary>
        /// 获取随机符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">返回多少条记录</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public DataTable GetListByRandom(int top, string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT {0} * FROM [{1}] WHERE [{2}] = @Value order by newid()", top > 0 ? "TOP " + top : "", TableName, conditionFieldName);

                return db.GetDataTable(CommandType.Text, sql, parms);
            }
        }

        /// <summary>
        /// Like查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">分页大小</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序</param>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <param name="recordCount">记录</param>
        public DataTable GetListByLike(int pageIndex, int pageSize, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue, string condition, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

            recordCount = GetCountByLike(conditionFieldName, conditionFieldValue, condition);

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }
            sort = ParseHacker.Sort(sort);

            DataTable dt;
            string sql = string.Empty;
            bool isReverse = false;
            if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; }
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM [{2}] WHERE CHARINDEX(@Value,[{3}]) >0 {6}) a WHERE Row BETWEEN {4} AND {5}",
                         strFields, sort, TableName, conditionFieldName, (pageIndex - 1) * pageSize + 1, pageIndex * pageSize, condition);
            }
            else if (base.DataType == DataBaseType.Access)
            {
                sql = string.Format("SELECT TOP {0} {1} FROM (SELECT TOP {2} {1} FROM [{3}] WHERE INSTR([{4}],@Value) >0 {7} {5}) a  {6}", pageSize, strFields, pageSize * pageIndex, TableName, conditionFieldName, sort, sort2, condition);
                isReverse = true;
            }
            else
            {
                sql = string.Format("SELECT TOP {0} {1} FROM (SELECT TOP {2} {1} FROM [{3}] WHERE CHARINDEX(@Value,[{4}]) >0 {7} {5}) a  {6}", pageSize, strFields, pageSize * pageIndex, TableName, conditionFieldName, sort, sort2, condition);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue)
                };

                dt = db.GetDataTable(CommandType.Text, sql, parms);
            }

            return isReverse ? dt.Reverse() : dt;
        }
    }
}
