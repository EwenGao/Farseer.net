﻿using System;
using System.Data;

using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using Qyn.Studio.ORM;
using System.Collections.Generic;
using System.Reflection;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 返回修改的参数列表
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        private List<IDbDataParameter> GetModifyParameter(TInfo info)
        {
            Mapping map = ModelCache.GetInfo(info.GetType());

            List<IDbDataParameter> lst = new List<IDbDataParameter>();

            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                if (!kic.Value.IsModify) { continue; }

                lst.Add(NewParam(kic.Value.UsedName, kic.Key.GetValue(info, null)));
            }

            return lst;
        }

        /// <summary>
        /// 更改多个字段的方法(单条件)
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public bool ModifyInfo(TInfo info, string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            List<IDbDataParameter> parms = GetModifyParameter(info);
            if (parms.Count == 0) return false;

            //要更新的表
            StringPlus sql = new StringPlus();
            sql.AppendFormat("UPDATE [{0}] SET ", TableName);

            //要更新的字段
            foreach (IDbDataParameter parm in parms)
            {
                sql.AppendFormat("[{0}] = @{0} ,", parm.ParameterName.Substring(1));
            }
            sql.DelLastChar(",");

            //要更新的条件
            sql.AppendFormat(" WHERE [{0}] = @ConditionValue", conditionFieldName);
            parms.Add(NewParam("@ConditionValue", conditionFieldValue));

            using (IDbProvider db = NewDbProvider())
            {
                return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
            }
        }

        /// <summary>
        /// 更改多个字段的方法(多条件)
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="condition">SQL条件语句</param>
        public bool ModifyInfo(TInfo info, string condition)
        {
            List<IDbDataParameter> parms = GetModifyParameter(info);
            if (parms.Count == 0) return false;

            //要更新的表
            StringPlus sql = new StringPlus();
            sql.AppendFormat("UPDATE [{0}] SET ", TableName);

            //要更新的字段
            foreach (IDbDataParameter parm in parms)
            {
                sql.AppendFormat("[{0}] = @{0} ,", parm.ParameterName.Substring(1));
            }
            sql.DelLastChar(",");


            sql.AppendFormat(" {0}", ParseHacker.Condition(condition));

            using (IDbProvider db = NewDbProvider())
            {
                return db.ExecuteNonQuery(CommandType.Text, sql.Value, parms.ToArray()) > 0;
            }
        }

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        public bool ModifyValue(string fieldName, object fieldValue, string condition)
        {
            if (fieldValue is Enum) { fieldValue = (int)fieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", fieldValue) 

                };
                string sql = string.Format("UPDATE [{0}] SET [{1}] = @Value {2}", TableName, fieldName, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public bool ModifyValue(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            if (fieldValue is Enum) { fieldValue = (int)fieldValue; }
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@FieldValue", fieldValue),
                    NewParam("@ConditionValue", conditionFieldValue) 

                };
                string sql = string.Format("UPDATE [{0}] SET [{1}] = @FieldValue WHERE [{2}] = @ConditionValue", TableName, fieldName, conditionFieldName);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public bool ModifyAdd(string fieldName, int fieldValue, string condition)
        {
            if (fieldValue is Enum) { fieldValue = (int)fieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("UPDATE [{0}] SET [{1}] = {1} + {2} {3}", TableName, fieldName, fieldValue, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql, null) > 0;
            }
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 

                };
                string sql = string.Format("UPDATE [{0}] SET [{1}] = {1} + {2} WHERE [{3}] = @Value", TableName, fieldName, fieldValue, conditionFieldName);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

    }
}
