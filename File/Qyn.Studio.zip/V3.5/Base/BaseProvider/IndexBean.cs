﻿using System.Collections.Generic;
using System.Data;

using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using System;
namespace Qyn.Studio.Base
{
    /// <summary>
    /// 全文索引
    /// </summary>
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        public List<TInfo> GetListByIndex(int pageIndex, int pageSize, string[] fieldNames, string sort, string containsFieldName, object containsFieldValue, string condition, out int recordCount)
        {
            if (pageIndex < 1) { pageIndex = 1; }
            if (pageSize < 1) { pageSize = 10; }

            if (containsFieldValue is Enum) { containsFieldValue = (int)containsFieldValue; }

            string strFields = (fieldNames != null && fieldNames.Length > 0) ? fieldNames.ToString(",") : "*";

            recordCount = GetCountByIndex(containsFieldName, containsFieldValue, condition);

            if (!string.IsNullOrEmpty(condition)) { condition = string.Format("AND {0}", ParseHacker.Condition(condition).Substring(6)); }
            sort = ParseHacker.Sort(sort);

            List<TInfo> list;
            string sql = string.Empty;
            bool isReverse = false;
            string sort2 = sort.Replace(" DESC", " [倒序]").Replace("ASC", "DESC").Replace("[倒序]", "ASC");

            if (base.DataType == DataBaseType.SqlServer && (base.DataVer == "2005" || base.DataVer == "2008"))
            {
                sql = string.Format("SELECT {0} FROM (SELECT {0},ROW_NUMBER() OVER({1}) as Row FROM [{2}] WHERE CONTAINS({3},@Value) {6}) a WHERE Row BETWEEN {4} AND {5}",
                         strFields, sort, TableName, containsFieldName, (pageIndex - 1) * pageSize, pageIndex * pageSize, condition);
            }
            else if (base.DataType == DataBaseType.Access)
            {
                if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
                sql = string.Format("SELECT TOP {1} {0} FROM (SELECT TOP {2} {0} FROM [{3}] WHERE INSTR([{4}],@Value) >0 {7} {5}) a  {6}",
                    strFields, pageSize, pageSize * pageIndex, TableName, containsFieldName, sort, sort2, condition);
                isReverse = true;
            }
            else
            {
                if (string.IsNullOrEmpty(sort)) { sort = "ORDER BY ID ASC"; sort2 = "ORDER BY ID DESC"; }
                sql = string.Format("SELECT TOP {1} {0} FROM (SELECT TOP {2} {0} FROM [{3}] WHERE CONTAINS([{4}],@Value) {7} {5}) a  {6}",
                    strFields, pageSize, pageSize * pageIndex, TableName, containsFieldName, sort, sort2, condition);
                isReverse = true;
            }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", containsFieldValue)
                };

                list = db.GetDataTable(CommandType.Text, sql, parms).ToList<TInfo>();
            }

            if (isReverse) { list.Reverse(); }
            return list;
        }
    }
}
