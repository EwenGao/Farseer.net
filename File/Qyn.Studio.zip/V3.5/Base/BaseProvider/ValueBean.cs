﻿using System.Data;

using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using System;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public object GetValue(string fieldName, string conditionFieldName, object conditionFieldValue)
        {
            if (conditionFieldValue is Enum) { conditionFieldValue = (int)conditionFieldValue; }

            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT TOP 1 {0} FROM [{1}] WHERE [{2}] = @Value", fieldName, TableName, conditionFieldName);

                return db.ExecuteScalar(CommandType.Text, sql, parms);

            }
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        public object GetValue(string fieldName, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT TOP 1 {0} FROM [{1}] {2}", fieldName, TableName, ParseHacker.Condition(condition));
                return db.ExecuteScalar(CommandType.Text, sql);
            }
        }
    }
}
