﻿using System.Data;

using Qyn.Studio.Utils;
using Qyn.Studio.Data;
using System;

namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo>
    {
        /// <summary>
        /// 重置标识字段
        /// </summary>
        public void ResetIdentity()
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("dbcc checkident({0},reseed,0)", Map.ClassUsedName);
                db.ExecuteScalar(CommandType.Text, sql);
            }
        }
    }
}
