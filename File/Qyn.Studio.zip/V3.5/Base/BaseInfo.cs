﻿using System;
using System.Data;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using System.Collections.Specialized;
using System.Web;
using System.Reflection;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;
using System.Windows.Forms;
using System.Linq;
using Qyn.Studio.Tools;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 实体类基类信息
    /// </summary>
    [Serializable]
    public class BaseInfo : ICloneable
    {
        /// <summary>
        /// 编号
        /// </summary>
        [Tip("编号"), IsIndex()]
        public int ID { get; set; }

        /// <summary>
        /// 克隆出一个新的对像
        /// </summary>
        /// <typeparam name="T">对像，必需继续于BaseInfo</typeparam>
        /// <returns></returns>
        public T Clone<T>() where T : BaseInfo
        {
            return this.MemberwiseClone() as T;
        }

        /// <summary>
        /// 克隆出一个新的对像
        /// </summary>
        /// <returns></returns>
        public object Clone()
        {
            return this.MemberwiseClone();
        }

        /// <summary>
        /// 获取Request提交过来的值，绑定到实体类
        /// </summary>
        /// <param name="request">Page.Form</param>
        /// <param name="prefix">继承母版页时，服务器控件包含的前缀</param>
        /// <returns>返回受影响的值</returns>
        public int SetValue(NameValueCollection request, string prefix)
        {
            //返回错误
            string ErrorMessage = string.Empty;

            if (request == null) { request = HttpContext.Current.Request.Form; }
            int count = 0;
            Mapping map = ModelCache.GetInfo(this.GetType());

            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                string reqName = kic.Key.Name;
                string reqNameByPrefix = prefix + kic.Key.Name;

                if (request[reqName] == null && request[reqNameByPrefix] == null) { continue; }
                string value;

                if (prefix.IsNullOrEmpty()) { value = request[reqName]; }
                else
                {
                    if (request[reqNameByPrefix] == null) { value = (request[reqName] ?? string.Empty).Trim(); }
                    else { value = (request[reqNameByPrefix] ?? string.Empty).Trim(); }
                }

                #region 属性基本类型判断
                if (kic.Value.IsMustFill)
                {
                    if (kic.Key.PropertyType == typeof(int))
                    {
                        if (!value.IsType<int>()) { ErrorMessage = kic.Value.Tip + "的值必需为整形类型。"; }
                    }
                    else if (kic.Key.PropertyType == typeof(DateTime))
                    {
                        if (!value.IsType<DateTime>()) { ErrorMessage = kic.Value.Tip + "的值必需为日期类型。"; }
                    }
                }
                #endregion

                kic.Key.SetValue(this, ParseType.ConvertType(value, kic.Key.PropertyType), null);
                count++;
            }

            if (!ErrorMessage.IsNullOrEmpty()) { new Terminator().Alert(ErrorMessage); return 0; }
            return count;
        }

        /// <summary>
        /// 检测实体类值状况
        /// </summary>
        /// <param name="isAdd">true为只检测实体类属性:IsAdd()，反之，则检测IsModify()</param>
        public virtual bool Check(bool isAdd)
        {
            //返回错误
            string ErrorMessage = string.Empty;

            Mapping map = ModelCache.GetInfo(this.GetType());
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                if (isAdd) { if (!kic.Value.IsAdd) { continue; } }
                else { if (!kic.Value.IsModify) { continue; } }

                object value = kic.Key.GetValue(this, null);
                //不检测枚举
                //if (value.GetType().IsEnum) { continue; }
                if (kic.Value.IsMustFill && (value == null || value.ToString().IsNullOrEmpty())) { ErrorMessage = kic.Value.Tip + "的值不能为空。"; }
                if (value == null) { continue; }

                #region 判断长度
                if (kic.Value.MinLength > 0 && !value.ToString().IsNullOrEmpty())
                {
                    if (value.IsType<String>())
                    {
                        if (value.ToString().Length < kic.Value.MinLength) { ErrorMessage = kic.Value.Tip + "的字符长度，不能小于" + kic.Value.MinLength + "个字符"; }
                    }
                    else
                    {
                        if (value.ConvertType(0) < kic.Value.MinLength) { ErrorMessage = kic.Value.Tip + "的值，不能小于" + kic.Value.MinLength; }
                    }
                }

                if (kic.Value.MaxLength > 0)
                {
                    if (value.IsType<String>())
                    {
                        if (value.ToString().Length > kic.Value.MaxLength) { ErrorMessage = kic.Value.Tip + "的字符长度，不能大于" + kic.Value.MaxLength + "个字符"; }
                    }
                    else
                    {
                        if (value.ConvertType(0) > kic.Value.MaxLength) { ErrorMessage = kic.Value.Tip + "的值，不能大于" + kic.Value.MaxLength; }
                    }
                }
                #endregion

            }
            if (!ErrorMessage.IsNullOrEmpty()) { new Terminator().Alert(ErrorMessage); return false; }
            return true;
        }
    }
}
