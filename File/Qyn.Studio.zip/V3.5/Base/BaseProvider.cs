﻿using Qyn.Studio.Configs;
using Qyn.Studio.Data;
using Qyn.Studio.ORM;
namespace Qyn.Studio.Base
{
    public partial class BaseProvider<TInfo> : DbHelper
        where TInfo : BaseInfo, new()
    {
        /// <summary>
        /// 表名
        /// </summary>
        public string TableName { get; set; }

        /// <summary>
        /// 索引字段
        /// </summary>
        public string IndexFields { get; set; }

        /// <summary>
        /// 构造函数（默认Db.Config第一个配置）
        /// </summary>
        public BaseProvider() { TableName = ModelCache.GetInfo(typeof(TInfo)).ClassUsedName; IndexFields = ModelCache.GetInfo(typeof(TInfo)).IndexName; }

        /// <summary>
        /// 构造函数（指定Db.Config的配置）
        /// </summary>
        /// <param name="dbList">Db.Config配置</param>
        public BaseProvider(DbList dbList) : base(dbList) { TableName = ModelCache.GetInfo(typeof(TInfo)).ClassUsedName; IndexFields = ModelCache.GetInfo(typeof(TInfo)).IndexName; }

        /// <summary>
        /// 构造函数（指定完整的连接字符串）
        /// </summary>
        /// <param name="connetionString">连接字符串</param>
        /// <param name="datatype">数据库类型</param>
        /// <param name="dataVer">数据库版本</param>
        /// <param name="commandTimeout">数据库执行时间，单位秒</param>
        public BaseProvider(string connetionString, DataBaseType datatype, string dataVer, int commandTimeout) : base(connetionString, datatype, dataVer, commandTimeout) { TableName = ModelCache.GetInfo(typeof(TInfo)).ClassUsedName; IndexFields = ModelCache.GetInfo(typeof(TInfo)).IndexName; }

        /// <summary>
        /// 
        /// </summary>
        public Mapping Map = ModelCache.GetInfo(typeof(TInfo));
    }
}
