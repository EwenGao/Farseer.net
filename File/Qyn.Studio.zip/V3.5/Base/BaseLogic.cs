﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using Qyn.Studio.Controls;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 逻辑层基类工具
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    /// <typeparam name="TProvider">DAL层</typeparam>
    public partial class BaseLogic<TInfo, TProvider> 
        where TProvider : BaseProvider<TInfo>, new()
        where TInfo : BaseInfo,new()
    {
        private static BaseProvider<TInfo> Provider = new TProvider();
        private static Mapping Map = ModelCache.GetInfo(typeof(TInfo));

    }
}
