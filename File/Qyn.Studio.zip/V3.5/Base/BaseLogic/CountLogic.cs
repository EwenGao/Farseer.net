﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public static int GetCount(string condition)
        {
            return Provider.GetCount(condition);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static int GetCount(string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetCount(conditionFieldName, conditionFieldValue);
        }
    }
}
