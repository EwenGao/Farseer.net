﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="ID">ID值</param>
        public static object GetValue(string fieldName, int ID)
        {
            return Provider.GetValue(fieldName, Map.IndexName, ID);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        public static object GetValue(string fieldName, string condition)
        {
            return Provider.GetValue(fieldName, condition);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static object GetValue(string fieldName, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetValue(fieldName, conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="ID">主键标识</param>
        public static string Caption(int ID)
        {
            return (string)Provider.GetValue("Caption", Map.IndexName, ID) ?? string.Empty;
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="ID">主键标识</param>
        public static string Caption(string conditionFieldName, object ID)
        {
            return (string)Provider.GetValue("Caption", conditionFieldName, ID) ?? string.Empty;
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public static string Caption(string condition)
        {
            return (string)Provider.GetValue("Caption", condition) ?? string.Empty;
        }
    }
}
