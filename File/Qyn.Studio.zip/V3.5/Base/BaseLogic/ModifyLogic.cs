﻿using System.Collections.Generic;
using System.Data;
using System.Linq;
using Qyn.Studio.Controls;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 修改数据
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        public static bool ModifyInfo(TInfo info)
        {
            return Provider.ModifyInfo(info, Map.IndexName, Map.PropertyList.First(o => o.Value.IsIndex).Key.GetValue(info, null));
        }

        /// <summary>
        /// 修改数据
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static bool ModifyInfo(TInfo info, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.ModifyInfo(info, conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 修改数据
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="condition">SQL条件语句</param>
        public static bool ModifyInfo(TInfo info, string condition)
        {
            return Provider.ModifyInfo(info, condition);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, int ID)
        {
            return Provider.ModifyValue(fieldName, fieldValue, Map.IndexName, ID);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.ModifyValue(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="lst">IN 列表</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, string conditionFieldName, List<int> lst)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, conditionFieldName, lst);
            return Provider.ModifyValue(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="lst">IN 列表</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, List<int> lst)
        {
            string condition = ParseSql.GetCondition(ParseSql.eumIn.In, Map.IndexName, lst);
            return Provider.ModifyValue(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更改一个字段数据(多条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, string condition)
        {
            return Provider.ModifyValue(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="condition">SQL条件语句</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string condition)
        {
            return Provider.ModifyAdd(fieldName, fieldValue, condition);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.ModifyAdd(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, int ID)
        {
            return Provider.ModifyAdd(fieldName, fieldValue, Map.IndexName, ID);
        }
    }
}
