﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 统计某个字段的累加值
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        public static decimal GetSum(string filedName)
        {
            return Provider.GetSum(filedName);
        }

        /// <summary>
        /// 获取数量(多条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="condition">SQL条件语句</param>
        public static decimal GetSum(string filedName, string condition)
        {
            return Provider.GetSum(filedName, condition);
        }

        /// <summary>
        /// 获取数量(单条件)
        /// </summary>
        /// <param name="filedName">要统计的字段名</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static decimal GetSum(string filedName, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetSum(filedName, conditionFieldName, conditionFieldValue);
        }
    }
}
