﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="ID">主键标识</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(int ID)
        {
            return Provider.GetInfo(Map.IndexName, ID);
        }

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetInfo(conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 获取单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(string condition)
        {
            return Provider.GetInfo(condition);
        }

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetNextInfo(string conditionFieldName, int conditionFieldValue, string condition)
        {
            return Provider.GetNextInfo(conditionFieldName, conditionFieldValue, condition);
        }

        /// <summary>
        /// 获取下一条记录
        /// </summary> 
        /// <param name="ID">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetNextInfo(int ID, string condition)
        {
            return Provider.GetNextInfo(Map.IndexName, ID, condition);
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetPreviousInfo(string conditionFieldName, int conditionFieldValue, string condition)
        {
            return Provider.GetPreviousInfo(conditionFieldName, conditionFieldValue, condition);
        }

        /// <summary>
        /// 获取上一条记录
        /// </summary>
        /// <param name="ID">条件字段值</param>
        /// <param name="condition">条件</param>
        public static TInfo GetPreviousInfo(int ID, string condition)
        {
            return Provider.GetPreviousInfo(Map.IndexName, ID, condition);
        }

        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        /// <returns></returns>
        public static TInfo GetLikeInfo(string conditionFieldName, string conditionFieldValue, string condition)
        {
            return Provider.GetLikeInfo(conditionFieldName, conditionFieldValue, condition);
        }
    }
}
