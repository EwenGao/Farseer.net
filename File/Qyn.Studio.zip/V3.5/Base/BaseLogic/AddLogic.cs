﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 插入记录的通用方法（支持标识键插入）
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>是否插入成功</returns>
        public static bool AddInfoByIdentity(TInfo info)
        {
            return Provider.AddInfoByIdentity(info);
        }

        /// <summary>
        /// 添加数据
        /// 循环所有IsAdd=True的属性
        /// </summary>
        /// <param name="info">实体类</param>
        public static bool AddInfo(TInfo info)
        {
            int identity;
            return Provider.AddInfo(info, out identity);
        }

        /// <summary>
        /// 添加数据
        /// 循环所有IsAdd=True的属性
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        public static bool AddInfo(TInfo info, out int identity)
        {
            return Provider.AddInfo(info, out identity);
        }

        /// <summary>
        /// 添加数据批量
        /// 循环所有IsAdd=True的属性
        /// </summary>
        /// <param name="lst">实体类批量</param>
        /// <returns>返回新标识ID</returns>
        public static void AddList(List<TInfo> lst)
        {
            foreach (TInfo info in lst)
            {
                AddInfo(info);
            }
        }
    }
}
