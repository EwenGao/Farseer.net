﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Controls;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        #region GetDataTable
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        /// <param name="condition">SQL条件语句</param>
        public static DataTable GetDataTable(Repeater rpt, string[] fieldNames, string sort, string condition)
        {
            int recordCount;
            rpt.PageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            rpt.PageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            DataTable dt = Provider.GetDataTable(rpt.PageIndex, rpt.PageSize, fieldNames, sort, condition, out recordCount);
            rpt.PageCount = recordCount;
            return dt;
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static DataTable GetDataTable(Repeater rpt, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue)
        {
            int recordCount;
            rpt.PageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            rpt.PageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            DataTable dt = Provider.GetDataTable(rpt.PageIndex, rpt.PageSize, fieldNames, sort, conditionFieldName, conditionFieldValue, out recordCount);
            rpt.PageCount = recordCount;
            return dt;
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        /// <param name="condition">SQL条件语句</param>
        public static DataTable GetDataTable(int top, string[] fieldNames, string sort, string condition)
        {
            return Provider.GetDataTable(top, fieldNames, sort, condition);
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static DataTable GetDataTable(int top, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue)
        {
            return Provider.GetDataTable(top, fieldNames, sort, conditionFieldName, conditionFieldValue);
        }
        #endregion

        #region GetList
        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="fieldNames">要查找的字段名称，多个用,号分隔</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        public static List<TInfo> GetList(Repeater rpt, string[] fieldNames, string sort, string condition)
        {
            return GetDataTable(rpt, fieldNames, sort, condition).ToList<TInfo>();
        }

        /// <summary>
        /// 通用的分页方法(单条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序(NullOrEmpty时为索引字段降序排列)</param>
        public static List<TInfo> GetList(Repeater rpt, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue)
        {
            return GetDataTable(rpt, fieldNames, sort, conditionFieldName, conditionFieldValue).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(多条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(int top, string[] fieldNames, string sort, string condition)
        {
            return GetDataTable(top, fieldNames, sort, condition).ToList<TInfo>();
        }

        /// <summary>
        /// 获取符合条件的列表(单条件，带限定显示字段)
        /// </summary>
        /// <param name="top">top数量</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        public static List<TInfo> GetList(int top, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue)
        {
            return GetDataTable(top, fieldNames, sort, conditionFieldName, conditionFieldValue).ToList<TInfo>();
        }

        #endregion

        /// <summary>
        /// 模糊搜索
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="sort">排序</param>
        /// <param name="conditionFieldName">条件字段</param>
        /// <param name="conditionFieldValue">条件值</param>
        /// <param name="condition">条件</param>
        public static List<TInfo> GetListByLike(Repeater rpt, string[] fieldNames, string sort, string conditionFieldName, object conditionFieldValue, string condition)
        {
            int recordCount;

            rpt.PageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            rpt.PageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            List<TInfo> lst = Provider.GetListByLike(rpt.PageIndex, rpt.PageSize, fieldNames, sort, conditionFieldName, conditionFieldValue, condition, out recordCount).ToList<TInfo>();
            rpt.PageCount = recordCount;
            return lst;
        }
    }
}
