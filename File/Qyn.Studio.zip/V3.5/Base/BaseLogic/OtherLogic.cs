﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 重置标识字段
        /// </summary>
        public static void ResetIdentity()
        {
            Provider.ResetIdentity();
        }
    }
}
