﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ID">索引值</param>
        public static bool DropInfo(int ID)
        {
            return Provider.DropInfo(Map.IndexName, ID);
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="lstIDs">索引值</param>
        public static void DropInfo(List<int> lstIDs)
        {
            foreach (int ID in lstIDs)
            {
                DropInfo(ID);
            }
        }

        /// <summary>
        /// 删除单条记录(单条件)
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static bool DropInfo(string conditionFieldName, object conditionFieldValue)
        {
            return Provider.DropInfo(conditionFieldName, conditionFieldValue);
        }

        /// <summary>
        /// 删除单条记录(多条件)
        /// </summary>
        /// <param name="condition">SQL条件语句</param>
        public static bool DropInfo(string condition)
        {
            return Provider.DropInfo(condition);
        }
    }
}
