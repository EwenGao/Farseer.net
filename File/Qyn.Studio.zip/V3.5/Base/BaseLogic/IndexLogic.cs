﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Base
{
    public partial class BaseLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 全文检索查找
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="fieldNames">要显示的字段</param>
        /// <param name="containsFieldName">条件字段名</param>
        /// <param name="containsFieldValue">条件字段值</param>
        /// <param name="sort">排序</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="recordCount">返回记录总数</param>
        public static List<TInfo> GetListByIndex(int pageIndex, int pageSize, string[] fieldNames, string sort, string containsFieldName, object containsFieldValue, string condition, out int recordCount)
        {
            return Provider.GetListByIndex(pageIndex, pageSize, fieldNames, sort, containsFieldName, containsFieldValue, condition, out  recordCount);
        }
    }
}
