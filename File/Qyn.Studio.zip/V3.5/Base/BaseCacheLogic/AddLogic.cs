﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    public partial class BaseCacheLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 插入记录的通用方法（支持标识键插入）
        /// </summary>
        /// <param name="info">实体类</param>
        /// <returns>是否插入成功</returns>
        public static bool AddInfoByIdentity(TInfo info)
        {
            List<TInfo> lst = GetList();
            bool result = Provider.AddInfoByIdentity(info);
            if (result) { lst.Add(info); }
            return result;
        }

        /// <summary>
        /// 添加数据
        /// 循环所有IsAdd=True的属性
        /// </summary>
        /// <param name="info">实体类</param>
        public static bool AddInfo(TInfo info)
        {
            int identity;

            return AddInfo(info, out identity);
        }

        /// <summary>
        /// 添加数据
        /// 循环所有IsAdd=True的属性
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="identity">返回插入行的自动编号列的值 如果没有值则返回0</param>
        public static bool AddInfo(TInfo info, out int identity)
        {
            List<TInfo> lst = GetList();
            bool result = Provider.AddInfo(info, out identity);
            if (result) 
            {
                KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(Map.IndexName);
                kic.Key.SetValue(info, identity, null);
                lst.Add(info); 
            }
            return result;
        }

        /// <summary>
        /// 添加数据批量
        /// 循环所有IsAdd=True的属性
        /// </summary>
        /// <param name="lst">实体类批量</param>
        /// <returns>返回新标识ID</returns>
        public static void AddList(List<TInfo> lst)
        {
            foreach (TInfo info in lst)
            {
                AddInfo(info);
            }
        }
    }
}
