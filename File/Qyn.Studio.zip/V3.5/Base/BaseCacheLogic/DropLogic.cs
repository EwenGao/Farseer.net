﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;
using Qyn.Studio.Utils;
using System.Reflection;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    /// <typeparam name="TInfo">实体类</typeparam>
    /// <typeparam name="TProvider">DAL层</typeparam>
    public partial class BaseCacheLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ID">索引值</param>
        public static bool DropInfo(object ID)
        {
            return DropInfo(Map.IndexName, ID);
        }

        /// <summary>
        /// 删除单条记录(单条件)
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static bool DropInfo(string conditionFieldName, object conditionFieldValue)
        {
            bool result = Provider.DropInfo(conditionFieldName, conditionFieldValue);
            if (result)
            {
                //获取属性
                KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(conditionFieldName);
                List<TInfo> lstInfo = GetList();
                for (int i = 0; i < lstInfo.Count; i++)
                {
                    if (kic.Key.GetValue(lstInfo[i], null).ToString() == conditionFieldValue.ToString())
                    {
                        lstInfo.RemoveAt(i);
                        i--;
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="lstIDs">索引值</param>
        public static void DropInfo(List<int> lstIDs)
        {
            foreach (int ID in lstIDs)
            {
                DropInfo(ID);
            }
        }
    }
}
