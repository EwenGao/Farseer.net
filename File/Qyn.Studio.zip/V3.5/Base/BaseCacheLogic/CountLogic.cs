﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    public partial class BaseCacheLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 获取数量
        /// </summary>
        /// <returns></returns>
        public static int GetCount()
        {
            return GetList().Count;
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <returns></returns>
        public static int GetCount(Predicate<TInfo> match)
        {
            int count = 0;
            List<TInfo> lst = GetList();
            if (match != null) { lst = lst.FindAll(match); }

            if (lst != null) { count = lst.Count; }
            return count;
        }
    }
}
