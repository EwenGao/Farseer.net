﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;
using System.Reflection;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    public partial class BaseCacheLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="ID">主键标识</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(object ID)
        {
            return GetInfo(Map.IndexName, ID);
        }

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(string conditionFieldName, object conditionFieldValue)
        {
            //获取索引的属性
            KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(conditionFieldName);
            List<TInfo> lstInfo = GetList();
            for (int i = 0; i < lstInfo.Count; i++)
            {
                if (kic.Key.GetValue(lstInfo[i], null).ToString() == conditionFieldValue.ToString())
                {
                    return lstInfo[i];
                }
            }
            return default(TInfo);
        }

        /// <summary>
        /// 获取单条记录(单条件)
        /// </summary>
        /// <param name="match">匿名委托</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public static TInfo GetInfo(Predicate<TInfo> match)
        {
            return GetList().Find(match);
        }
    }
}
