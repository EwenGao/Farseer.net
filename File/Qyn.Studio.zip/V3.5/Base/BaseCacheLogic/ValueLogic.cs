﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.ORM;
using System.Reflection;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    public partial class BaseCacheLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 获取第一条第一个字段的数据(多条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="ID">ID值</param>
        public static object GetValue(string fieldName, object ID)
        {
            return GetValue(fieldName, Map.IndexName, ID);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(单条件)
        /// </summary>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static object GetValue(string fieldName, string conditionFieldName, object conditionFieldValue)
        {
            //获取索引的属性
            KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(conditionFieldName);

            List<TInfo> lstInfo = GetList();
            for (int i = 0; i < lstInfo.Count; i++)
            {
                if (kic.Key.GetValue(lstInfo[i], null).ToString() == conditionFieldValue.ToString())
                {
                    return Map.GetPropertyInfo(fieldName).Key.GetValue(lstInfo[i], null);
                }
            }
            return null;
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="ID">主键标识</param>
        public static string Caption(int ID)
        {
            return (string)GetValue("Caption", Map.IndexName, ID) ?? string.Empty;
        }

        /// <summary>
        /// 获取标题名称
        /// </summary>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="ID">主键标识</param>
        public static string Caption(string conditionFieldName, object ID)
        {
            return (string)GetValue("Caption", conditionFieldName, ID) ?? string.Empty;
        }
    }
}
