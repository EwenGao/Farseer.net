﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Qyn.Studio.ORM;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Base
{
    public partial class BaseCacheLogic<TInfo, TProvider>
    {
        /// <summary>
        /// 修改数据
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        public static bool ModifyInfo(TInfo info)
        {
            return ModifyInfo(info, Map.IndexName, Map.GetPropertyInfo().Key.GetValue(info, null));
        }

        /// <summary>
        /// 修改数据
        /// 循环ModelAttribute.eumPropertyType.B的所有属性
        /// </summary>
        /// <param name="info">实体类</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        public static bool ModifyInfo(TInfo info, string conditionFieldName, object conditionFieldValue)
        {
            bool result = Provider.ModifyInfo(info, conditionFieldName, conditionFieldValue);
            if (result)
            {
                //获取索引的属性
                KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(conditionFieldName);
                List<TInfo> lstInfo = GetList();
                for (int i = 0; i < lstInfo.Count; i++)
                {
                    if (kic.Key.GetValue(lstInfo[i], null).ToString() == conditionFieldValue.ToString()) 
                    {
                        foreach (KeyValuePair<PropertyInfo, ModelAttribute> dic in Map.PropertyList)
                        {
                            if (!dic.Value.IsModify) { continue; }

                            object fieldValue = dic.Key.GetValue(info, null);

                            dic.Key.SetValue(lstInfo[i], fieldValue, null); 
                        }
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, object ID)
        {
            return ModifyValue(fieldName, fieldValue, Map.IndexName, ID);
        }

        /// <summary>
        /// 更改一个字段数据(单条件)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool ModifyValue(string fieldName, object fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            bool result = Provider.ModifyValue(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
            if (result)
            {
                //获取索引的属性
                KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(conditionFieldName);
                List<TInfo> lstInfo = GetList();
                for (int i = 0; i < lstInfo.Count; i++)
                {
                    if (kic.Key.GetValue(lstInfo[i], null).ToString() == conditionFieldValue.ToString())
                    { Map.GetPropertyInfo(fieldName).Key.SetValue(lstInfo[i], fieldValue, null); }
                }
            }
            return result;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="conditionFieldName">条件字段名</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, string conditionFieldName, object conditionFieldValue)
        {
            bool result = Provider.ModifyAdd(fieldName, fieldValue, conditionFieldName, conditionFieldValue);
            if (result)
            {
                //获取索引的属性
                KeyValuePair<PropertyInfo, ModelAttribute> kic = Map.GetPropertyInfo(conditionFieldName);

                List<TInfo> lstInfo = GetList();
                for (int i = 0; i < lstInfo.Count; i++)
                {
                    if (kic.Key.GetValue(lstInfo[i], null).ToString() == conditionFieldValue.ToString())
                    {
                        int value = Map.GetPropertyInfo(fieldName).Key.GetValue(lstInfo[i], null).ConvertType(0);
                        Map.GetPropertyInfo(fieldName).Key.SetValue(lstInfo[i], value += fieldValue, null);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 更新数据(在原字段值上+ -值)
        /// </summary>
        /// <param name="fieldName">字段名</param>
        /// <param name="fieldValue">字段值</param>
        /// <param name="ID">主键标识</param>
        /// <returns></returns>
        public static bool ModifyAdd(string fieldName, int fieldValue, int ID)
        {
            return ModifyAdd(fieldName, fieldValue, Map.IndexName, ID);
        }
    }
}
