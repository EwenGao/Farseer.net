﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Studio.Controls;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 带缓存逻辑基类
    /// </summary>
    public partial class BaseCacheLogic<TInfo, TProvider>
    {

        /// <summary>
        /// 获取数据列表(读取数据库)
        /// </summary>
        public static List<TInfo> GetTrueList()
        {
            List<TInfo> lst = Provider.GetDataTable(0, null, string.Empty, string.Empty).ToList<TInfo>();
            ParseCache.Add<List<TInfo>>(Key, lst);
            return lst;
        }


        /// <summary>
        /// 获取数据列表
        /// </summary>
        public static List<TInfo> GetList()
        {
            List<TInfo> lst = ParseCache.Get<List<TInfo>>(Key);
            if (lst == null) { return GetTrueList(); }
            return lst;
        }

        /// <summary>
        /// 获取数据列表
        /// </summary>
        /// <param name="match">匿名委托</param>
        public static List<TInfo> GetList(Predicate<TInfo> match)
        {
            List<TInfo> lst = GetList();
            if (match != null) { lst = lst.FindAll(match); }
            return lst;
        }

        /// <summary>
        /// 获取数据列表
        /// </summary>
        /// <param name="match">匿名委托</param>
        public static List<TInfo> GetList(Predicate<TInfo> match, string fieldName, ReverserInfo.eumDirectionType sort)
        {
            List<TInfo> lst = GetList(match);
            if (!fieldName.IsNullOrEmpty())
            {
                lst.Sort(new Reverser<TInfo>(typeof(TInfo), fieldName, sort));
            }
            return lst;
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="match">匿名委托</param>
        /// <param name="fieldName">要排序的字段</param>
        /// <param name="sort">排序方式</param>
        public static List<TInfo> GetList(Repeater rpt, Predicate<TInfo> match, string fieldName, ReverserInfo.eumDirectionType sort)
        {
            rpt.PageIndex = rpt.PageIndex < 1 ? 1 : rpt.PageIndex;
            rpt.PageSize = rpt.PageSize < 1 ? 20 : rpt.PageSize;

            List<TInfo> lst = GetList();
            if (match != null) { lst = lst.FindAll(match); }

            if (!fieldName.IsNullOrEmpty())
            {
                lst.Sort(new Reverser<TInfo>(typeof(TInfo), fieldName, sort));
            }
            rpt.PageCount = lst.Count;
            return ParseList.Pagination(lst, rpt);
        }

        /// <summary>
        /// 通用的分页方法(多条件)
        /// </summary>
        /// <param name="rpt">Repeater带分页控件</param>
        /// <param name="match">匿名委托</param>
        public static List<TInfo> GetList(Repeater rpt, Predicate<TInfo> match)
        {
            return GetList(rpt, match, null, ReverserInfo.eumDirectionType.DESC);
        }
    }
}
