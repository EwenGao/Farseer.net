﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Qyn.Studio.Utils;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using System.Reflection;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 操作XML基类
    /// PropertyType {A:属性；B：元素}
    /// </summary>
    /// <typeparam name="Info">实体类</typeparam>
    public class BaseXml<Info>
    {
        /// <summary>
        /// XML路径
        /// </summary>
        /// <param name="xmlPath">路径</param>
        public BaseXml(string xmlPath)
        {
            XmlPath = xmlPath.ToLower();// ParseFile.ConvertPath(xmlPath.ToLower()).Replace("//", "/");
            Key = ParseEncrypt.MD5(typeof(Info).FullName + "_" + XmlPath);
            ParseFile.CreateDirs(xmlPath);
        }

        /// <summary>
        /// 缓存Key
        /// </summary>
        private string Key;

        /// <summary>
        /// 设置Xml的路径
        /// </summary>
        public string XmlPath { get; set; }

        /// <summary>
        /// 缓存所有配置
        /// </summary>
        private List<Info> LstXml
        {
            get
            {
                //if (Qyn.Studio.Configs.GeneralConfigs.ConfigInfo.DeBug) { Load(); }
                return ParseCache.Get<List<Info>>(Key);
            }
            set { ParseCache.Add(Key, value); }
        }

        /// <summary>
        /// 移除空元素
        /// </summary>
        /// <param name="element"></param>
        private void RemoveEmptyElement(XElement element)
        {
            bool isNeedSave = false;
            List<XElement> lstElement = element.Elements().ToList();
            for (int i = 0; i < lstElement.Count; i++)
            {
                if (lstElement[i].Attributes().Count() == 0 && lstElement[i].Elements().Count() == 0)
                { lstElement[i].Remove(); isNeedSave = true; }
            }
            if (isNeedSave) { element.Save(XmlPath); }
        }

        /// <summary>
        /// 读取XML文档(直接读取xml文档)
        /// 路径不存，或者返回Null时，会自动创建xml
        /// </summary>
        public XElement Load()
        {
            XElement element;
            if (!ParseFile.FileExists(XmlPath)) { element = Create(); }
            else
            {
                element = XElement.Load(XmlPath);
                if (element == null) { element = Create(); }
            }

            RemoveEmptyElement(element);

            LstXml = element.ToList<Info>();
            return element;
        }

        /// <summary>
        /// 创建XML文件
        /// </summary>
        public XElement Create()
        {
            string name = ModelCache.GetInfo(typeof(Info)).ClassUsedName + "s";

            XDocument doc = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XElement(name));

            doc.Save(XmlPath);
            return doc.Element(name);
        }

        /// <summary>
        /// 获取列表
        /// </summary>
        public List<Info> GetList()
        {
            if (LstXml == null) { Load(); }
            return LstXml;
        }

        /// <summary>
        /// 获取列表
        /// </summary>
        public List<Info> GetList(Predicate<Info> match)
        {
            return GetList().FindAll(match) ?? new List<Info>();
        }

        /// <summary>
        /// 获取单条记录
        /// </summary>
        /// <param name="match">o=>匿名委托</param>
        /// <returns>成功：实体类，失败：Null</returns>
        public Info GetInfo(Predicate<Info> match)
        {
            if (GetList() == null) { return default(Info); }
            return GetList().Find(match);
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="match">o=>匿名委托</param>
        public int GetCount(Predicate<Info> match)
        {
            if (GetList() == null) { return 0; }
            List<Info> lst = GetList().FindAll(match);
            if (lst == null) { return 0; }
            return lst.Count;
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        public int GetCount()
        {
            if (GetList() == null) { return 0; }
            return GetList().Count;
        }

        /// <summary>
        /// 添加XML
        /// 如果索引是数字类型，且为0的情况下。索引为当前数量 + 1
        /// 如果索引值有相同内容时，则会自动移除该节点
        /// </summary>
        /// <param name="info">实体类</param>
        public bool AddInfo(Info info)
        {
            XElement element = Load();

            Mapping map = ModelCache.GetInfo(typeof(Info));
            List<object> lst = new List<object>();

            //判断是否已存在相同索引的元素

            #region 添加所有属性变量为节点元素
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                if (!kic.Value.IsAdd) { continue; }

                object value = kic.Key.GetValue(info, null) ?? string.Empty;
                if (value.IsType<List<int>>()) { value = value.ConvertType<List<int>>().ToString(","); }

                //如果是索引
                if (kic.Value.IsIndex)
                {
                    //当索引的值为0时，自动计算当前List的数量 + 1;
                    if (value.IsType<int>() && value.ConvertType(0) == 0)
                    {
                        value = GetList().Count > 0
                        ? kic.Key.GetValue(GetList()[(GetList().Count) - 1], null).ConvertType(0) + 1
                        : 1;

                        kic.Key.SetValue(info, value, null);
                    }

                    //如果存在该条记录，则移除
                    element = Remove(value.ToString());
                }

                if (kic.Value.PropertyType == eumPropertyType.A) { lst.Add(new XAttribute(kic.Value.UsedName, value)); }
                else { lst.Add(new XElement(kic.Value.UsedName, value)); }
            }
            #endregion

            element.Add(new XElement(map.ClassUsedName, lst.ToArray()));
            element.Save(XmlPath);
            Load();
            return true;
        }

        /// <summary>
        /// 修改XML
        /// </summary>
        /// <param name="info">实体类</param>
        public bool ModifyInfo(Info info)
        {
            XElement element = Load();
            if (element == null) { element = Create(); }

            Mapping map = ModelCache.GetInfo(typeof(Info));

            //索引属性
            KeyValuePair<PropertyInfo, ModelAttribute> kicIndexProperty = map.PropertyList.First(o => o.Value.IsIndex);

            //获取实体类中的索引值
            string entityIndexValue = kicIndexProperty.Key.GetValue(info, null).ToString();

            //查找记录
            XElement el;
            try
            {
                if (kicIndexProperty.Value.PropertyType == eumPropertyType.A)
                {
                    el = element.Elements().First(o => o.Attribute(map.IndexName).Value == entityIndexValue);
                }
                else
                {
                    el = element.Elements().First(o => o.Element(map.IndexName).Value == entityIndexValue);
                }
            }
            catch { el = null; }
            if (el == null) { return false; }

            #region 修改所有字段变量为节点属性
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                if (!kic.Value.IsModify) { continue; }

                //获取实体类属性的赋值
                object value = kic.Key.GetValue(info, null);

                if (value.IsType<List<int>>()) { value = value.ConvertType<List<int>>().ToString(","); }

                //判断实体类属性是XML的属性还是元素
                if (kic.Value.PropertyType == eumPropertyType.A)
                {
                    if (el.Attribute(kic.Value.UsedName) == null) { }
                    el.SetAttributeValue(kic.Value.UsedName, value);
                }
                else
                {
                    if (el.Element(kic.Value.UsedName) == null) { }
                    el.SetElementValue(kic.Value.UsedName, value);
                }


            #endregion
            }
            element.Save(XmlPath);
            Load();

            return true;
        }

        /// <summary>
        /// 修改XML
        /// </summary>
        /// <param name="indexValue">索引值</param>
        /// <param name="propertyType">条件类型</param>
        /// <param name="contidionName">条件节点名称</param>
        /// <param name="contidiongValue">条件节点值</param>
        public bool ModifyValue(object indexValue, eumPropertyType propertyType, string contidionName, string contidiongValue)
        {
            XElement element = Load();
            if (element == null) { element = Create(); }

            Mapping map = ModelCache.GetInfo(typeof(Info));

            //查找记录
            XElement el;
            try
            {
                if (map.PropertyList.First(o => o.Value.IsIndex).Value.PropertyType == eumPropertyType.A)
                {
                    el = element.Elements().First(o => o.Attribute(map.IndexName).Value == indexValue.ToString());
                }
                else
                {
                    el = element.Elements().First(o => o.Element(map.IndexName).Value == indexValue.ToString());
                }
            }
            catch { el = null; }
            if (el == null) { return false; }

            if (propertyType == eumPropertyType.A) { el.SetAttributeValue(contidionName, contidiongValue); }
            else { el.SetElementValue(contidionName, contidiongValue); }

            element.Save(XmlPath);
            Load();

            return true;
        }

        /// <summary>
        /// 在原来的基础下，+指定的数值
        /// </summary>
        /// <param name="indexValue">索引值</param>
        /// <param name="propertyType">条件类型</param>
        /// <param name="contidionName">条件节点名称</param>
        /// <param name="contidiongValue">条件节点值</param>
        public bool ModifyAdd(object indexValue, eumPropertyType propertyType, string contidionName, int contidiongValue)
        {
            XElement element = Load();
            if (element == null) { element = Create(); }

            Mapping map = ModelCache.GetInfo(typeof(Info));

            //查找记录
            XElement el;
            try
            {
                if (map.PropertyList.First(o => o.Value.IsIndex).Value.PropertyType == eumPropertyType.A)
                {
                    el = element.Elements().First(o => o.Attribute(map.IndexName).Value == indexValue.ToString());
                }
                else
                {
                    el = element.Elements().First(o => o.Element(map.IndexName).Value == indexValue.ToString());
                }
            }
            catch { el = null; }
            if (el == null) { return false; }

            if (propertyType == eumPropertyType.A)
            {
                int value = 0;
                XAttribute xAttribute = el.Attribute(contidionName);
                if (xAttribute != null) { value = xAttribute.Value.ConvertType(0); }
                value += contidiongValue;
                el.SetAttributeValue(contidionName, value);
            }
            else
            {
                int value = 0;
                XElement xElement = el.Element(contidionName);
                if (xElement != null) { value = xElement.Value.ConvertType(0); }
                value += contidiongValue;
                el.SetElementValue(contidionName, value);
            }
            element.Save(XmlPath);
            Load();

            return true;
        }

        /// <summary>
        /// 移除元素
        /// </summary>
        public XElement Remove(string indexValue)
        {
            XElement element = Load();
            if (element == null) { element = Create(); }

            Mapping map = ModelCache.GetInfo(typeof(Info));

            //索引属性
            KeyValuePair<PropertyInfo, ModelAttribute> kicIndexProperty = map.PropertyList.First(o => o.Value.IsIndex);

            //判断索引是属性，还是元素
            bool isAttribute = kicIndexProperty.Value.PropertyType == eumPropertyType.A;

            foreach (XElement el in element.Elements())
            {
                string xmlIndexValue = isAttribute ? el.Attribute(map.IndexName).Value : el.Element(map.IndexName).Value;

                if (xmlIndexValue == indexValue) { el.Remove(); }
            }
            element.Save(XmlPath);
            return Load();
        }
    }

    /// <summary>
    /// XML扩展方法
    /// </summary>
    public static class XmlExtend
    {
        /// <summary>
        /// 将XML转成实体
        /// </summary>
        public static List<T> ToList<T>(this XElement element)
        {
            Mapping orm = ModelCache.GetInfo(typeof(T));
            List<T> list = new List<T>();
            Type type;

            T t;

            foreach (XElement el in element.Elements())
            {
                t = (T)Activator.CreateInstance(typeof(T));

                //赋值字段
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in orm.PropertyList)
                {
                    type = kic.Key.PropertyType;

                    if (kic.Value.PropertyType == eumPropertyType.A)
                    {
                        if (el.Attribute(kic.Value.UsedName) == null) { continue; }
                        kic.Key.SetValue(t, ParseType.ConvertType(el.Attribute(kic.Value.UsedName).Value, type), null);
                    }
                    else if (kic.Value.PropertyType == eumPropertyType.B)
                    {
                        if (el.Element(kic.Value.UsedName) == null) { continue; }
                        kic.Key.SetValue(t, ParseType.ConvertType(el.Element(kic.Value.UsedName).Value, type), null);
                    }
                }
                list.Add(t);
            }
            return list;
        }
    }
}
