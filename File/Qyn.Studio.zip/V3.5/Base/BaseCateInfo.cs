﻿using System;
using System.Data;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;

namespace Qyn.Studio.Base
{
    /// <summary>
    /// 实体类基类信息
    /// </summary>
    [Serializable]
    public class BaseCateInfo : BaseInfo
    {
        /// <summary>
        /// 所属ID
        /// </summary>
        [Tip("上级分类"), IsAdd(), IsModify()]
        public int ParentID { get; set; }

        /// <summary>
        /// 显示名称
        /// </summary>
        [Tip("名称"), IsAdd(), IsModify(), IsMustFill(), Length(2, 255), PropertyType(eumPropertyType.B)]
        public string Caption { get; set; }
    }
}
