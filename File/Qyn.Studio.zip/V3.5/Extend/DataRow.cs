﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using Qyn.Studio.ORM;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// DataRow扩展工具
    /// </summary>
    public static class DataRowExtend
    {
        /// <summary>
        /// 将DataRowCollection转成List[DataRow]
        /// </summary>
        /// <param name="drc">DataRowCollection</param>
        /// <returns></returns>
        public static List<DataRow> ToRows(this DataRowCollection drc)
        {
            List<DataRow> lstRow = new List<DataRow>();

            if (drc == null) { return lstRow; }

            foreach (DataRow dr in drc)
            {
                lstRow.Add(dr);
            }

            return lstRow;
        }

        /// <summary>
        /// 将DataRow转成实体类
        /// </summary>
        /// <typeparam name="T">实体类</typeparam>
        /// <param name="dr">DataRow</param>
        /// <returns></returns>
        public static T ToInfo<T>(this DataRow dr)
        {
            T t = (T)Activator.CreateInstance(typeof(T));
            Mapping orm = ModelCache.GetInfo(typeof(T));

            //赋值字段
            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in orm.PropertyList)
            {
                if (dr.Table.Columns.Contains(kic.Value.UsedName)) 
                {
                    kic.Key.SetValue(t, ParseType.ConvertType(dr[kic.Value.UsedName].ToString(), kic.Key.PropertyType), null);
                }
            }
            return t;
        }
    }
}
