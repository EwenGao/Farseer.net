﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// ListItemCollection
    /// </summary>
    public static class ListItemExtend
    {
        /// <summary>
        /// 将ListItem 转换为List
        /// </summary>
        /// <typeparam name="T">指定要转换的类型</typeparam>
        /// <param name="lstItem">ListItemCollection</param>
        public static List<T> ToList<T>(this ListItemCollection lstItem)
        {
            List<T> lst = new List<T>();
            foreach (ListItem item in lstItem)
            {
                lst.Add(item.Value.ConvertType<T>());
            }
            return lst;
        }
    }
}
