﻿using System.Collections;
using Qyn.Studio.Utils;
using System.Collections.Generic;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// List扩展工具
    /// </summary>
    public static class ListExtend
    {
        /// <summary>
        /// 将List转换成字符串
        /// </summary>
        /// <param name="lst">要拼接的LIST</param>
        /// <param name="sign">分隔符</param>
        /// <returns></returns>
        public static string ToString(this IList lst,string sign)
        {
            return ParseList.ToString(lst, sign);
        }

        /// <summary>
        /// List克隆
        /// </summary>
        /// <typeparam name="T">List类型</typeparam>
        /// <param name="lst">原List</param>
        /// <returns></returns>
        public static List<T> Clone<T>(this List<T> lst)
        {
            List<T> newList = new List<T>();
            newList.AddRange(lst);
            return newList;
        }
    }
}
