﻿using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// 数组的扩展方法
    /// </summary>
    public static class ArrayExtend
    {
        /// <summary>
        /// 将数组转换成用符号连接的字符串
        /// </summary>
        public static string ToString<T>(this T[] obj, string sign)
        {
            return ParseArray.ToString(obj, sign);
        }
    }
}
