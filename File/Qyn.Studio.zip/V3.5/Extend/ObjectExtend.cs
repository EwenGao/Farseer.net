﻿using System;

using Qyn.Studio.Utils;
using System.Collections.Generic;
using System.Xml.Linq;
using Qyn.Studio.ORM;
using System.Reflection;
using System.Web;
using System.Collections.Specialized;
using Qyn.Studio.Tools;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Object扩展工具
    /// </summary>
    public static class ObjectExtend
    {
        /// <summary>
        /// 将对像转换为T类型
        /// </summary>
        public static T ConvertType<T>(this object obj, T defValue)
        {
            return ParseType.ConvertType<T>(obj, defValue);
        }

        /// <summary>
        /// 将对像转换为T类型
        /// </summary>
        public static T ConvertType<T>(this object obj)
        {
            return ParseType.ConvertType<T>(obj);
        }

        /// <summary>
        /// 判断是否T类型
        /// </summary>
        public static bool IsType<T>(this object obj)
        {
            return ParseIsType.IsType<T>(obj);
        }

        /// <summary>
        /// 获取枚举中文
        /// </summary>
        public static string GetName(this Enum eum)
        {
            return ParseEnum.GetDescription(eum.GetType(), eum.ToString());
        }

        /// <summary>
        /// 条件相等，输出字符串
        /// </summary>
        public static string ToString(this bool b, bool result, string str)
        {
            return ParseString.BoolToString(b, result, str);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static List<UpLoadFile.stuUpLoadFile> Upload(this HttpFileCollection files, string filePath, UpLoadFile.SaveType saveType)
        { return new UpLoadFile().Upload(files, filePath, saveType); }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="lstFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static List<UpLoadFile.stuUpLoadFile> Upload(this HttpFileCollection files, string filePath, UpLoadFile.SaveType saveType, List<UpLoadFile.stuUpLoadFileType> lstFileType)
        { return new UpLoadFile().Upload(files, filePath, saveType, lstFileType); }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="file">获取要上传的文件</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static UpLoadFile.stuUpLoadFile Upload(this HttpPostedFile file, string filePath, UpLoadFile.SaveType saveType)
        { return new UpLoadFile().Upload(file, filePath, saveType); }


        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="file">FileUpload</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="lstFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static UpLoadFile.stuUpLoadFile Upload(this HttpPostedFile file, string filePath, UpLoadFile.SaveType saveType, List<UpLoadFile.stuUpLoadFileType> lstFileType)
        { return new UpLoadFile().Upload(file, filePath, saveType, lstFileType); }
    }
}