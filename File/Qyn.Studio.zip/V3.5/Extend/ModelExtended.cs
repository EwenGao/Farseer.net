﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;
using System.Reflection;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using Qyn.Studio.Base;
using Qyn.Studio.ORM;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// 实体类扩展方法
    /// </summary>
    public static class ModelExtended
    {
        /// <summary>
        /// 使用Lamdba表达式来描述字段名（强制命名)
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="TProperty"></typeparam>
        /// <param name="t"></param>
        /// <param name="expression"></param>
        /// <param name="value">返回值</param>
        /// <returns></returns>
        public static PropertyInfo GetFieldName<T, TProperty>(this T t, Expression<Func<T, TProperty>> expression, out TProperty value) where T : BaseInfo
        {
            value = t == null ? default(TProperty) : expression.Compile().Invoke(t);
            MemberExpression memberExpression;
            UnaryExpression unary = expression.Body as UnaryExpression;
            if (unary != null)
            {
                memberExpression = unary.Operand as MemberExpression;
            }
            else
            {
                memberExpression = expression.Body as MemberExpression;
            }
            return (PropertyInfo)memberExpression.Member;
        }

        /// <summary>
        /// 通过Lambda表达式获取字段信息
        /// </summary>
        public static PropertyInfo GetFieldInfo<T>(this T t, Expression<Func<T, Object>> expression) where T : BaseInfo
        {
            return GetFieldName<T>(expression);
        }

        /// <summary>
        /// 通过Lambda表达式获取字段在数据库里面的名字
        /// </summary>
        public static string GetFieldName<T>(this T t, Expression<Func<T, Object>> expression) where T : BaseInfo
        {
            Mapping map = ModelCache.GetInfo(t.GetType());
            PropertyInfo p = GetFieldName<T>(expression);
            return map.GetUserName(p);
        }

        /// <summary>
        /// 通过Lambda表达式获取字段信息(非扩展字段)
        /// </summary>
        public static PropertyInfo GetFieldName<T>(Expression<Func<T, Object>> expression) where T : BaseInfo
        {
            MemberExpression memberExpression;
            UnaryExpression unary = expression.Body as UnaryExpression;
            if (unary != null)
            {
                memberExpression = unary.Operand as MemberExpression;
            }
            else
            {
                memberExpression = expression.Body as MemberExpression;
            }
            return (PropertyInfo)memberExpression.Member;
        }



        /// <summary>
        /// 把表单提交过来的内容转化成为实体类
        /// </summary>
        public static T Fill<T>(this NameValueCollection request) where T : BaseInfo
        {
            return Fill<T>(request, string.Empty);
        }

        /// <summary>
        /// 把表单提交过来的内容转化成为实体类
        /// </summary>
        public static T Fill<T>(this NameValueCollection request, string prefix) where T : BaseInfo
        {
            T t = Activator.CreateInstance<T>();
            t.SetValue(request, prefix);
            return t;
        }

        /// <summary>
        /// json格式的字符串转化成为实体类
        /// 必须配合 ToJSONString 方法，不能使用自己写的tojson方法
        /// </summary>
        public static T ToObject<T>(this String json)
        {
            DataContractJsonSerializer jsr = new DataContractJsonSerializer(typeof(T));
            MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(json));
            T t = (T)jsr.ReadObject(ms);
            ms.Close();
            return t;
        }

        /// <summary>
        /// 转化对象为系统所带的JSON格式字符串
        /// </summary>
        public static string ToJSONString(this Object obj)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
            MemoryStream stream = new MemoryStream();
            serializer.WriteObject(stream, obj);
            byte[] dataBytes = new byte[stream.Length];
            stream.Position = 0;
            stream.Read(dataBytes, 0, (int)stream.Length);
            return Encoding.UTF8.GetString(dataBytes);
        }

        /// <summary>
        /// 把当前实体类转成JSON字符串
        /// </summary>
        /// <param name="t">实体类</param>
        /// <param name="fields">要使用的字段。为空表示全部</param>
        public static string ToJSON<T>(this T t, params string[] fields) where T : BaseInfo
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("({");
            Mapping map = ModelCache.GetInfo(t.GetType());

            foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in map.PropertyList)
            {
                if (!(fields.Length == 0 || fields.Contains(kic.Key.Name))) continue;
                object value = kic.Key.GetValue(t, null);
                sb.AppendFormat("{0}:\"{1}\" ,", kic.Key, GetValue(kic.Key.GetValue(t, null)));
            }
            string json = sb.ToString();
            if (json.EndsWith(",")) json = json.Substring(0, json.Length - 1);
            return json += "})";
        }


        #region ============  辅助类  ============

        /// <summary>
        /// 根据值的类型转换成JS能够识别的字符串
        /// </summary>
        private static string GetValue(object obj)
        {
            if (obj == null) return "null";
            string v = "";
            switch (obj.GetType().Name)
            {
                case "String":
                    v = obj.ToString().Trim();
                    v.Replace("\"", "\\\"");
                    v.Replace("\n", "\\n");
                    v.Replace( "\r", "\\r");
                    break;
                case "Boolean":
                    v = (bool)obj ? "true" : "false";
                    break;
                case "DateTime":
                case "TimeSpan":
                    v = obj.ToString();
                    break;
                case "Int32":
                case "Int16":
                case "Int64":
                case "Byte":
                case "Decimal":
                case "Single":
                default:
                    v = obj.ToString();
                    break;
            }
            return v;
        }

        #endregion
    }
}
