﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// Dictionary扩展工具
    /// </summary>
    public static class DictionaryExtend
    {
        /// <summary>
        /// 扩展 Dictionary 根据Value反向查找Key的方法
        /// </summary>
        public static T1 GetKey<T1, T2>(this Dictionary<T1, T2> list, T2 t2)
        {
            foreach (KeyValuePair<T1, T2> obj in list) { if (obj.Value.Equals(t2)) return obj.Key; }
            return default(T1);
        }
    }
}
