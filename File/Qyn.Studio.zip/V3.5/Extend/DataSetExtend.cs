﻿using System.Collections.Generic;
using System.Data;


namespace Qyn.Studio.Extend
{
    /// <summary>
    /// DataSet扩展工具
    /// </summary>
    public static class DataSetExtend
    {
        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(this DataSet ds)
        {
            if (ds.Tables.Count == 0) return null;
            return ds.Tables[0].ToList<T>();
        }
    }
}
