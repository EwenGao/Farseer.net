﻿using System;
using System.Collections.Generic;
using System.Data;


namespace Qyn.Studio.Extend
{
    /// <summary>
    /// IDataReader扩展工具
    /// </summary>
    public static class IDataReaderExtend
    {
        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(this IDataReader reader)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            while (reader.Read())
            {
                object obj = Activator.CreateInstance(ht, reader);
                list.Add((T)obj);
            }
            reader.Close();
            reader.Dispose();
            return list;
        }

        /// <summary>
        /// 数据填充
        /// </summary>
        public static T ToInfo<T>(this IDataReader reader)
        {
            T t = default(T);
            Type ht = typeof(T);
            if (reader.Read())
            {
                t = (T)Activator.CreateInstance(ht, reader);
            }
            reader.Close();
            reader.Dispose();
            return t;
        }
    }
}
