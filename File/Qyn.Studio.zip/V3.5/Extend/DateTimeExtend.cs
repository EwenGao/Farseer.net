﻿using System;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// DateTime扩展工具
    /// </summary>
    public static class DateTimeExtend
    {
        /// <summary>
        /// 获取短日期
        /// </summary>
        public static string ToShortDate(this DateTime time)
        {
            return time.ToString("yyyy-MM-dd");
        }
    }
}
