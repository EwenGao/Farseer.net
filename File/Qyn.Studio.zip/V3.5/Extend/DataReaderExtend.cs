﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using Qyn.Studio.ORM;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Extend
{
    /// <summary>
    /// DataReader扩展工具
    /// </summary>
    public static class DataReaderExtend
    {
        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(this IDataReader reader)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            Mapping orm = ModelCache.GetInfo(typeof(T));
            T t;

            while (reader.Read())
            {
                t = (T)Activator.CreateInstance(typeof(T));

                //赋值字段
                foreach (KeyValuePair<PropertyInfo, ModelAttribute> kic in orm.PropertyList)
                {
                    if (reader.GetOrdinal(kic.Value.UsedName) > -1)
                    {
                        kic.Key.SetValue(t, ParseType.ConvertType(reader[kic.Value.UsedName].ToString(), kic.Key.PropertyType), null);
                    }
                }

                list.Add(t);
            }
            reader.Close();
            reader.Dispose();
            return list;
        }
    }
}
