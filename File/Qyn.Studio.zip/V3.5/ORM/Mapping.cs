﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Qyn.Studio.Extend;
using System.Linq;

namespace Qyn.Studio.ORM
{
    /// <summary>
    /// ORM 映射关系
    /// </summary>
    public class Mapping
    {
        /// <summary>
        /// 关系映射
        /// </summary>
        /// <param name="type">实体类Type</param>
        public Mapping(Type type)
        {
            object[] attrs = type.GetCustomAttributes(typeof(ClassAttribute), false);
            if (attrs.Length == 0 || !(attrs[0] is ClassAttribute)) { this.ClassUsedName = type.Name; }
            else { this.ClassUsedName = ((ClassAttribute)attrs[0]).UsedName; }

            this.PropertyList = new Dictionary<PropertyInfo, ModelAttribute>();

            //属性变量的属性
            ModelAttribute modelAttribute;

            #region 属性

            //遍历所有属性变量,取得对应使用标记名称
            //无加标记时，则为不使用该变量。
            foreach (PropertyInfo propertyInfo in type.GetProperties())
            {
                modelAttribute = new ModelAttribute();

                attrs = propertyInfo.GetCustomAttributes(false);
                if (attrs.Length == 0) { continue; }

                attrs = propertyInfo.GetCustomAttributes(typeof(UsedNameAttribute), false);
                modelAttribute.UsedName = attrs.Length == 0 ? propertyInfo.Name : ((UsedNameAttribute)attrs[0]).UsedName;

                attrs = propertyInfo.GetCustomAttributes(typeof(IsIndexAttribute), false);
                modelAttribute.IsIndex = attrs.Length == 0 ? false : ((IsIndexAttribute)attrs[0]).IsIndex;

                attrs = propertyInfo.GetCustomAttributes(typeof(IsAddAttribute), false);
                modelAttribute.IsAdd = attrs.Length == 0 ? false : ((IsAddAttribute)attrs[0]).IsAdd;

                attrs = propertyInfo.GetCustomAttributes(typeof(IsModifyAttribute), false);
                modelAttribute.IsModify = attrs.Length == 0 ? false : ((IsModifyAttribute)attrs[0]).IsModify;

                attrs = propertyInfo.GetCustomAttributes(typeof(IsMustFillAttribute), false);
                modelAttribute.IsMustFill = attrs.Length == 0 ? false : ((IsMustFillAttribute)attrs[0]).IsMustFill;

                attrs = propertyInfo.GetCustomAttributes(typeof(TipAttribute), false);
                modelAttribute.Tip = attrs.Length == 0 ? string.Empty : ((TipAttribute)attrs[0]).Tip;

                attrs = propertyInfo.GetCustomAttributes(typeof(PropertyTypeAttribute), false);
                modelAttribute.PropertyType = attrs.Length == 0 ? eumPropertyType.A : ((PropertyTypeAttribute)attrs[0]).PropertyType;

                attrs = propertyInfo.GetCustomAttributes(typeof(LengthAttribute), false);
                if (attrs.Length == 0) { modelAttribute.MinLength = 0; modelAttribute.MaxLength = 0; }
                else { modelAttribute.MinLength = ((LengthAttribute)attrs[0]).MinLength; modelAttribute.MaxLength = ((LengthAttribute)attrs[0]).MaxLength; }

                if (modelAttribute.IsIndex) { IndexName = modelAttribute.UsedName; }
                //添加属变量标记名称
                PropertyList.Add(propertyInfo, modelAttribute);

            }
            #endregion
        }

        /// <summary>
        /// 获取所有属性（没有设置该属性时，则不加入）
        /// </summary>
        public readonly Dictionary<PropertyInfo, ModelAttribute> PropertyList;

        /// <summary>
        /// 获取当前属性（通过使用的userName）
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public KeyValuePair<PropertyInfo, ModelAttribute> GetPropertyInfo(string userName)
        {
            return PropertyList.First(oo => oo.Value.UsedName == userName);
        }

        /// <summary>
        /// 获取当前属性（索引值）
        /// </summary>
        /// <returns></returns>
        public KeyValuePair<PropertyInfo, ModelAttribute> GetPropertyInfo()
        {
            return PropertyList.First(oo => oo.Value.IsIndex);
        }

        /// <summary>
        /// 获取标注的名称
        /// </summary>
        /// <param name="propertyInfo">属性变量</param>
        /// <returns></returns>
        public string GetUserName(PropertyInfo propertyInfo)
        {
            return PropertyList[propertyInfo].UsedName;
        }

        /// <summary>
        /// 索引名称
        /// </summary>
        public string IndexName;

        /// <summary>
        /// 实体类所使用的名称
        /// </summary>
        public string ClassUsedName { get; set; }
    }
}
