﻿using System;
using System.Collections.Generic;
using Qyn.Studio.Extend;

namespace Qyn.Studio.ORM
{
    /// <summary>
    /// 实体类的属性标记
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class ClassAttribute : Attribute
    {
        /// <summary>
        /// 实体类的属性标记,默认直接为该类名称
        /// </summary>
        public ClassAttribute() { }

        /// <summary>
        /// 传入表名
        /// </summary>
        /// <param name="usedName"></param>
        public ClassAttribute(string usedName): this()
        {
            if (!usedName.IsNullOrEmpty()) { this.UsedName = usedName; }
        }

        /// <summary>
        /// 类的标记名称
        /// </summary>
        public string UsedName { get; set; }
    }
}
