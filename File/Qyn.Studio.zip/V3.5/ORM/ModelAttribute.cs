﻿using System;
using Qyn.Studio.Tools;
using System.Collections.Generic;

namespace Qyn.Studio.ORM
{
    /// <summary>
    /// 变量的扩展属性
    /// </summary>
    public class ModelAttribute
    {
        /// <summary>
        /// 是否为索引变量，默认为：ID
        /// </summary>
        public bool IsIndex { get; set; }

        /// <summary>
        /// 该变量使用名称，默认与变量名称一样
        /// </summary>
        public string UsedName { get; set; }

        /// <summary>
        /// 属性类型，自定义扩展属性
        /// </summary>
        public eumPropertyType PropertyType { get; set; }

        /// <summary>
        /// 是否作为添加字段
        /// </summary>
        public bool IsAdd { get; set; }

        /// <summary>
        /// 是否作为修改字段
        /// </summary>
        public bool IsModify { get; set; }

        /// <summary>
        /// 字段最大长度
        /// </summary>
        public int MaxLength { get; set; }

        /// <summary>
        /// 字段最小长度
        /// </summary>
        public int MinLength { get; set; }

        /// <summary>
        /// 出错时的提示语言
        /// </summary>
        public string Tip { get; set; }

        /// <summary>
        /// 设置为必填变量
        /// </summary>
        internal bool IsMustFill { get; set; }

        /// <summary>
        /// 上传文件的保存方式
        /// </summary>
        public UpLoadFile.SaveType SaveType { get; set; }

        /// <summary>
        /// 上传文件的权限
        /// </summary>
        public List<UpLoadFile.stuUpLoadFileType> FileType { get; set; }
    }

    /// <summary>
    /// 设置变量使用的名称
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class UsedNameAttribute : Attribute
    {
        /// <summary>
        /// 设置变量使用的名称
        /// </summary>
        /// <param name="usedName">该变量使用名称</param>
        public UsedNameAttribute(string usedName) { this.UsedName = usedName; }

        /// <summary>
        /// 设置变量使用的名称
        /// </summary>
        internal string UsedName { get; set; }
    }

    /// <summary>
    /// 设置为索引变量
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class IsIndexAttribute : Attribute
    {
        /// <summary>
        /// 设置为索引变量
        /// </summary>
        public IsIndexAttribute() { this.IsIndex = true; }

        /// <summary>
        /// 设置为索引变量
        /// </summary>
        internal bool IsIndex { get; set; }
    }

    /// <summary>
    /// 设置为可添加变量
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class IsAddAttribute : Attribute
    {
        /// <summary>
        /// 设置为可添加变量
        /// </summary>
        public IsAddAttribute() { this.IsAdd = true; }

        /// <summary>
        /// 设置为可添加变量
        /// </summary>
        internal bool IsAdd { get; set; }
    }

    /// <summary>
    /// 设置为可修改变量
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class IsModifyAttribute : Attribute
    {
        /// <summary>
        /// 设置为可修改变量
        /// </summary>
        public IsModifyAttribute() { this.IsModify = true; }

        /// <summary>
        /// 设置为可修改变量
        /// </summary>
        internal bool IsModify { get; set; }
    }

    /// <summary>
    /// 设置为必填变量
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class IsMustFillAttribute : Attribute
    {
        /// <summary>
        /// 设置为必填变量
        /// </summary>
        public IsMustFillAttribute() { this.IsMustFill = true; }

        /// <summary>
        /// 设置为必填变量
        /// </summary>
        internal bool IsMustFill { get; set; }
    }

    /// <summary>
    /// 设置变量最小/大允许长度/值
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class LengthAttribute : Attribute
    {
        /// <summary>
        /// 设置变量最小/大允许长度/值
        /// </summary>
        public LengthAttribute(int minLength, int maxLength) { this.MinLength = minLength; this.MaxLength = maxLength; }

        /// <summary>
        /// 设置变量最小允许长度/值
        /// </summary>
        internal int MinLength { get; set; }

        /// <summary>
        /// 设置变量最大允许长度/值
        /// </summary>
        internal int MaxLength { get; set; }
    }

    /// <summary>
    /// 设置变量的提示名称
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class TipAttribute : Attribute
    {
        /// <summary>
        /// 设设置变量的提示名称
        /// </summary>
        public TipAttribute(string tip) { this.Tip = tip; }

        /// <summary>
        /// 设置变量的提示名称
        /// </summary>
        internal string Tip { get; set; }
    }

    /// <summary>
    /// 设置变量的扩展属性
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class PropertyTypeAttribute : Attribute
    {
        /// <summary>
        /// 设置变量的扩展属性
        /// </summary>
        public PropertyTypeAttribute(eumPropertyType propertyType) { this.PropertyType = propertyType; }

        /// <summary>
        /// 设置变量的扩展属性
        /// </summary>
        internal eumPropertyType PropertyType { get; set; }
    }

    /// <summary>
    /// 设置变量的上传保存方式
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class SaveTypeAttribute : Attribute
    {
        /// <summary>
        /// 设置变量的上传保存方式
        /// </summary>
        public SaveTypeAttribute(UpLoadFile.SaveType saveType) { this.SaveType = saveType; }

        /// <summary>
        /// 上传保存方式
        /// </summary>
        internal UpLoadFile.SaveType SaveType { get; set; }
    }

    /// <summary>
    /// 设置变量的上传文件权限
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class FileTypeAttribute : Attribute
    {
        /// <summary>
        /// 设置变量的上传文件权限
        /// </summary>
        public FileTypeAttribute(List<UpLoadFile.stuUpLoadFileType> fileType) { this.FileType = fileType; }

        /// <summary>
        /// 设置变量的上传文件权限
        /// </summary>
        internal List<UpLoadFile.stuUpLoadFileType> FileType { get; set; }
    }
    /// <summary>
    /// 属性类型，自定义扩展属性
    /// </summary>
    public enum eumPropertyType : byte
    {
        /// <summary>
        /// 自定义扩展A
        /// </summary>
        A,
        /// <summary>
        /// 自定义扩展B
        /// </summary>
        B,
        /// <summary>
        /// 自定义扩展C
        /// </summary>
        C,
        /// <summary>
        /// 自定义扩展D
        /// </summary>
        D,
        /// <summary>
        /// 自定义扩展E
        /// </summary>
        E,
        /// <summary>
        /// 自定义扩展F
        /// </summary>
        F,
        /// <summary>
        /// 自定义扩展G
        /// </summary>
        G,
        /// <summary>
        /// 自定义扩展H
        /// </summary>
        H,
        /// <summary>
        /// 自定义扩展I
        /// </summary>
        I,
        /// <summary>
        /// 自定义扩展J
        /// </summary>
        J,
        /// <summary>
        /// 自定义扩展K
        /// </summary>
        K,
        /// <summary>
        /// 自定义扩展L
        /// </summary>
        L,
        /// <summary>
        /// 自定义扩展M
        /// </summary>
        M,
        /// <summary>
        /// 自定义扩展N
        /// </summary>
        N,
        /// <summary>
        /// 自定义扩展O
        /// </summary>
        O,
        /// <summary>
        /// 自定义扩展P
        /// </summary>
        P,
        /// <summary>
        /// 自定义扩展Q
        /// </summary>
        Q,
        /// <summary>
        /// 自定义扩展R
        /// </summary>
        R,
        /// <summary>
        /// 自定义扩展S
        /// </summary>
        S,
        /// <summary>
        /// 自定义扩展T
        /// </summary>
        T,
        /// <summary>
        /// 自定义扩展U
        /// </summary>
        U,
        /// <summary>
        /// 自定义扩展V
        /// </summary>
        V,
        /// <summary>
        /// 自定义扩展W
        /// </summary>
        W,
        /// <summary>
        /// 自定义扩展X
        /// </summary>
        X,
        /// <summary>
        /// 自定义扩展Y
        /// </summary>
        Y,
        /// <summary>
        /// 自定义扩展Z
        /// </summary>
        Z
    }
}
