using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Qyn.Studio.Configs;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;


namespace Qyn.Studio.Data
{
    /// <summary>
    /// MySql����
    /// </summary>
    public class MySqlExector : IDbProvider
    {
        /// <summary>
        /// �����ַ��� 
        /// </summary>
        public string ConnectionString { get; set; }

        /// <summary>
        /// ���ݿ�ִ��ʱ�䣬��λ��
        /// </summary>
        public int CommandTimeout { get; set; }

        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="connnection">���ݿ������ַ���</param>
        /// <param name="commandTimeout">���ݿ�ִ��ʱ�䣬��λ��</param>
        public MySqlExector(string connnection, int commandTimeout)
        {
            this.ConnectionString = connnection;
            this.CommandTimeout = commandTimeout;
        }

        /// <summary>
        /// ���Ӳ���
        /// </summary>
        /// <param name="parameters">MySqlParameterCollection�Ĳ�������</param>
        /// <param name="parmsCollection">����ֵ</param>
        private MySqlParameterCollection AddParms(MySqlParameterCollection parmsCollection, IDbDataParameter[] parameters)
        {
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    MySqlParameter parms = (MySqlParameter)parameters[i];
                    parmsCollection.Add(parms);
                }
            }
            return parmsCollection;
        }

        #region IDbExecutor ��Ա

        /// <summary>
        /// ���ص�һ�е�һ������
        /// </summary>
        /// <param name="cmdType">ִ�з�ʽ</param>
        /// <param name="cmdText">SQL���ߴ洢��������</param>
        /// <param name="parameters">����</param>
        public object ExecuteScalar(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            try
            {
                using (MySqlCommand comm = new MySqlCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    AddParms(comm.Parameters, parameters);
                    return comm.ExecuteScalar();
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// ������Ӱ�������
        /// </summary>
        /// <param name="cmdType">ִ�з�ʽ</param>
        /// <param name="cmdText">SQL���ߴ洢��������</param>
        /// <param name="parameters">����</param>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            try
            {
                using (MySqlCommand comm = new MySqlCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    AddParms(comm.Parameters, parameters);
                    return comm.ExecuteNonQuery();
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// ������Ӱ�����������ع���
        /// </summary>
        /// <param name="cmdType">ִ�з�ʽ</param>
        /// <param name="cmdText">SQL���ߴ洢��������</param>
        /// <param name="parameters">����</param>
        public int ExecuteTranSql(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            try
            {
                using (MySqlCommand comm = new MySqlCommand(cmdText, conn))
                {
                    conn.Open();
                    MySqlTransaction tran = conn.BeginTransaction();
                    comm.Transaction = tran;
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    AddParms(comm.Parameters, parameters);
                    int result = comm.ExecuteNonQuery();
                    tran.Commit();
                    return result;
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// ��������(IDataReader)
        /// </summary>
        /// <param name="cmdType">ִ�з�ʽ</param>
        /// <param name="cmdText">SQL���ߴ洢��������</param>
        /// <param name="parameters">����</param>
        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            try
            {
                using (MySqlCommand comm = new MySqlCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    AddParms(comm.Parameters, parameters);
                    return comm.ExecuteReader(CommandBehavior.CloseConnection);
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// ��������(DataSet)
        /// </summary>
        /// <param name="cmdType">ִ�з�ʽ</param>
        /// <param name="cmdText">SQL���ߴ洢��������</param>
        /// <param name="parameters">����</param>
        public DataSet GetDataSet(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            try
            {
                using (MySqlCommand comm = new MySqlCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    MySqlDataAdapter ada = new MySqlDataAdapter(comm);
                    AddParms(comm.Parameters, parameters);
                    DataSet ds = new DataSet();
                    ada.Fill(ds);
                    return ds;
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// ��������(DataTable)
        /// </summary>
        /// <param name="cmdType">ִ�з�ʽ</param>
        /// <param name="cmdText">SQL���ߴ洢��������</param>
        /// <param name="parameters">����</param>
        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            return ds.Tables.Count == 0 ? new DataTable() : ds.Tables[0];
        }
        #endregion

        /// <summary>
        /// ע��
        /// </summary>
        public void Dispose() { }
    }
}
