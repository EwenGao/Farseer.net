﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Web;
using System.Windows.Forms;
using Qyn.Studio.Configs;
using Qyn.Studio.Tools;


namespace Qyn.Studio.Data
{
    /// <summary>
    /// Access工厂
    /// </summary>
    public class OleDbExecutor : IDbProvider
    {
        /// <summary>
        /// 连接字符串 
        /// </summary>
        public string ConnectionString { get; set; }

        /// <summary>
        /// 数据库执行时间，单位秒
        /// </summary>
        public int CommandTimeout { get; set; }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="connnection">数据库连接字符串</param>
        /// <param name="commandTimeout">数据库执行时间，单位秒</param>
        public OleDbExecutor(string connnection, int commandTimeout)
        {
            this.ConnectionString = connnection;
            this.CommandTimeout = commandTimeout;
        }

        /// <summary>
        /// 添加参数
        /// </summary>
        /// <param name="parameters">OleDbParameter的参数对像</param>
        /// <param name="parmsCollection">参数值</param>
        private OleDbParameterCollection AddParms(OleDbParameterCollection parmsCollection, IDbDataParameter[] parameters)
        {
            if (parameters != null)
            {
                for (int i = 0; i < parameters.Length; i++)
                {
                    OleDbParameter parms = (OleDbParameter)parameters[i];
                    if (parms.DbType == DbType.DateTime)
                    {
                        parms.Value = string.Format("#{0}#", parms.Value.ToString());
                    }
                    parmsCollection.Add(parms);
                }
            }
            return parmsCollection;
        }

        #region IDbExector成员
        /// <summary>
        /// 返回第一行第一列数据
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public Object ExecuteScalar(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            try
            {
                using (OleDbCommand comm = new OleDbCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;
                    AddParms(comm.Parameters, parameters);
                    return comm.ExecuteScalar();
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// 返回受影响的行数
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            try
            {
                using (OleDbCommand comm = new OleDbCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;
                    AddParms(comm.Parameters, parameters);
                    return comm.ExecuteNonQuery();
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// 返回受影响行数（带回滚）
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public int ExecuteTranSql(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            try
            {
                using (OleDbCommand comm = new OleDbCommand(cmdText, conn))
                {
                    conn.Open();
                    OleDbTransaction tran = conn.BeginTransaction();
                    comm.Transaction = tran;
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    AddParms(comm.Parameters, parameters);
                    int result = comm.ExecuteNonQuery();
                    tran.Commit();
                    return result;
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// 返回数据(IDataReader)
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            try
            {
                using (OleDbCommand comm = new OleDbCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    AddParms(comm.Parameters, parameters);
                    return comm.ExecuteReader(CommandBehavior.CloseConnection);
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// 返回数据(DataSet)
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public DataSet GetDataSet(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            try
            {
                using (OleDbCommand comm = new OleDbCommand(cmdText, conn))
                {
                    conn.Open();
                    comm.CommandType = cmdType;
                    comm.CommandTimeout = CommandTimeout;

                    OleDbDataAdapter ada = new OleDbDataAdapter(comm);
                    AddParms(comm.Parameters, parameters);
                    DataSet ds = new DataSet();
                    ada.Fill(ds);
                    return ds;
                }
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        /// <summary>
        /// 返回数据(DataTable)
        /// </summary>
        /// <param name="cmdType">执行方式</param>
        /// <param name="cmdText">SQL或者存储过程名称</param>
        /// <param name="parameters">参数</param>
        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            return ds.Tables.Count == 0 ? new DataTable() : ds.Tables[0];
        }

        #endregion

        /// <summary>
        /// 注销
        /// </summary>
        public void Dispose() { }
    }

}
