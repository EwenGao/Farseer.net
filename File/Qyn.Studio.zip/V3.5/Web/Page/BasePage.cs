﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web;
using System.Web.SessionState;
using Qyn.Studio.Configs;
using Qyn.Studio.Extend;
using Qyn.Studio.Tools;
using Qyn.Studio.Utils;
using System;
using Qyn.Studio.Base;
using Qyn.Studio.ORM;
using System.Reflection;

namespace Qyn.Studio.Web.Page
{
    /// <summary>
    /// 页面基类
    /// </summary>
    public class BasePage : System.Web.UI.Page, IRequiresSessionState
    {
        /// <summary>
        /// 网站标题
        /// </summary>
        public string WebTitle { get; set; }

        #region 前台Url、Path
        /// <summary>
        /// 前台网站应用程序目录(相对于IIS)
        /// </summary>
        public string WebDirectory { get; set; }

        /// <summary>
        /// 网站登陆页面
        /// http://www.xxx.com:80/Login.aspx
        /// </summary>
        public string WebLoginUrl { get; set; }

        /// <summary>
        /// 网站退出页面
        /// </summary>
        public string WebLogoutUrl { get; set; }
        #endregion

        #region 后台Url、Path
        /// <summary>
        /// 管理平台根目录
        /// /Admin/
        /// </summary>
        public string AdminDirectory { get; set; }

        /// <summary>
        /// 管理员登陆页面
        /// /Login.aspx
        /// </summary>
        public string AdminLoginUrl { get; set; }

        /// <summary>
        /// 管理员退出页面
        /// </summary>
        public string AdminLogoutUrl { get; set; }
        #endregion

        /// <summary>
        /// HttpContext.Current.Request
        /// </summary>
        public new HttpRequest Request = HttpContext.Current.Request;
        /// <summary>
        /// HttpContext.Current.Response
        /// </summary>
        public new HttpResponse Response = HttpContext.Current.Response;

        /// <summary>
        /// 构造
        /// </summary>
        public BasePage()
        {
            WebTitle = GeneralConfigs.ConfigInfo.WebTitle;
            WebDirectory = GeneralConfigs.ConfigInfo.WebDirectory;
            WebLoginUrl = GeneralConfigs.ConfigInfo.WebLoginUrl;
            WebLogoutUrl = GeneralConfigs.ConfigInfo.WebLogoutUrl;

            AdminDirectory = GeneralConfigs.ConfigInfo.AdminDirectory;
            AdminLoginUrl = GeneralConfigs.ConfigInfo.AdminLoginUrl;
            AdminLogoutUrl = GeneralConfigs.ConfigInfo.AdminLogoutUrl;
            DeBug();

        }

        /// <summary>
        /// 调试状态
        /// </summary>
        public void DeBug()
        {
            //清空缓存
            if (GeneralConfigs.ConfigInfo.DeBug)
            {
                GeneralConfigs.ResetConfig();
                DbConfigs.ResetConfig();
                EmailConfigs.ResetConfig();
            }
        }

        #region 显示、弹出信息
        /// <summary>
        /// 显示信息
        /// </summary>
        public void ShowMsg(string message)
        {
            new Terminator().Throw(message);
        }

        /// <summary>
        /// 显示信息
        /// </summary>
        public void ShowMsg(string message, string title, string gotoUrl)
        {
            if (gotoUrl.StartsWith("?")) { gotoUrl = QynRequest.GetPageName() + gotoUrl; }
            new Terminator().Throw(message, title, string.Format("Go to Page,{0}", gotoUrl));
        }

        /// <summary>
        /// 弹出信息
        /// </summary>
        public void Alert(string message)
        {
            new Terminator().Alert(message);
        }

        /// <summary>
        /// 弹出信息
        /// </summary>
        public void Alert(string message, string gotoUrl)
        {
            if (gotoUrl.StartsWith("?")) { gotoUrl = QynRequest.GetPageName() + gotoUrl; }
            new Terminator().Alert(message, gotoUrl);
        }

        #endregion

        #region Request

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName, Encoding encoding)
        {
            return QynRequest.QS(parmsName, encoding);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public string QS(string parmsName)
        {
            return QynRequest.QS(parmsName);
        }

        /// <summary>
        /// Request.QueryString
        /// </summary>
        public T QS<T>(string parmsName, T defValue)
        {
            return QynRequest.QS(parmsName, defValue);
        }

        /// <summary>
        /// Request.Form
        /// </summary>
        public T QF<T>(string parmsName, T defValue)
        {
            return QynRequest.QS(parmsName, defValue);
        }

        /// <summary>
        /// Request.Form
        /// </summary>
        public string QF(string parmsName)
        {
            return QynRequest.QF(parmsName);
        }

        /// <summary>
        /// 先QF后QS
        /// </summary>
        /// <param name="parmsName"></param>
        /// <returns></returns>
        public string QA(string parmsName)
        {
            return QynRequest.QA(parmsName);
        }

        #endregion

        /// <summary>
        /// 转到网址
        /// </summary>
        public void GoToUrl(string url, params object[] args)
        {
            if (args != null && args.Length != 0) { url = string.Format(url, args); }
            GoToUrl(url);
        }

        /// <summary>
        /// 转到网址
        /// </summary>
        public void GoToUrl(string url)
        {
            if (url.StartsWith("?")) { url = QynRequest.GetPageName() + url; }
            Response.Redirect(url);
        }

        /// <summary>
        /// 刷新当前页
        /// </summary>
        public void Refresh()
        {
            GoToUrl("{0}?{1}", QynRequest.GetPageName(), QynRequest.GetParams());
        }

        /// <summary>
        /// 刷新整页
        /// </summary>
        /// <param name="link"></param>
        public void RefreshParent(string link)
        {
            Response.Write(string.Format("<script type=\"text/javascript\">parent.document.location.href=\"{0}\"</script>", link));
        }

        /// <summary>
        /// 返回连接参数
        /// </summary>
        /// <param name="kic">页面需要用到的参数名称、值</param>
        /// <param name="parmsName">要重新赋值的参数</param>
        /// <param name="value">新的参数值</param>
        protected string Parms(Dictionary<string, object> kic, string parmsName, object value)
        {
            string parms = string.Empty;
            foreach (KeyValuePair<string, object> kvp in kic)
            {
                parms += string.Format("{0}={1}&", kvp.Key, kvp.Key.IsEquals(parmsName) ? value : kvp.Value);
            }
            return ParseString.DelEndOf(parms, "&");
        }

        /// <summary>
        /// 返回连接参数
        /// </summary>
        /// <param name="kic">页面需要用到的参数名称、值</param>
        /// <param name="parmsName">省略key等于当前参数名称的值</param>
        protected string Parms(Dictionary<string, object> kic, string parmsName)
        {
            string parms = string.Empty;
            foreach (KeyValuePair<string, object> kvp in kic)
            {
                if (kvp.Key.IsEquals(parmsName)) { continue; }
                parms += string.Format("{0}={1}&", kvp.Key, kvp.Value);
            }
            return ParseString.DelEndOf(parms, "&");
        }

    }

    /// <summary>
    /// 接管页面UI，为了伪静态的提交
    /// </summary>
    public class FormFixerHtml32TextWriter : System.Web.UI.Html32TextWriter
    {
        private string _url; // 假的URL 
        /// <summary>
        /// 接管页面UI，为了伪静态的提交
        /// </summary>
        /// <param name="writer">TextWriter对像</param>
        public FormFixerHtml32TextWriter(TextWriter writer)
            : base(writer)
        {
            _url = HttpContext.Current.Request.RawUrl;
        }
        /// <summary>
        /// 写入属性值
        /// </summary>
        /// <param name="name">名称</param>
        /// <param name="value">值</param>
        /// <param name="encode">编码</param>
        public override void WriteAttribute(string name, string value, bool encode)
        {
            if (_url != null && string.Compare(name, "action", true) == 0) { value = _url; }
            base.WriteAttribute(name, value, encode);
        }
    }

    /// <summary>
    /// 接管页面UI，为了伪静态的提交
    /// </summary>
    public class FormFixerHtmlTextWriter : System.Web.UI.HtmlTextWriter
    {
        private string _url;
        /// <summary>
        /// 接管页面UI，为了伪静态的提交
        /// </summary>
        /// <param name="writer">TextWriter对像</param>
        public FormFixerHtmlTextWriter(TextWriter writer)
            : base(writer)
        {
            _url = HttpContext.Current.Request.RawUrl;
        }

        /// <summary>
        /// 写入属性值
        /// </summary>
        /// <param name="name">名称</param>
        /// <param name="value">值</param>
        /// <param name="encode">编码</param>
        public override void WriteAttribute(string name, string value, bool encode)
        {
            if (_url != null && string.Compare(name, "action", true) == 0) { value = _url; }
            base.WriteAttribute(name, value, encode);
        }
    }
}
