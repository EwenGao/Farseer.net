using System;


namespace Qyn.Studio.Utils
{
	/// <summary>
	/// �Ի���������з�װ
	/// </summary>
	public class ParseCache
	{
        private static System.Web.Caching.Cache webCache = System.Web.HttpRuntime.Cache;

        /// <summary>
        /// ���õ������ʱ��[��λ��������]
        /// Ĭ�ϻ�������Ϊ1440����(24Сʱ)
        /// </summary>
        public static int TimeOut = 1440;

        /// <summary>
        /// ���Ӷ���
        /// </summary>
        public static void Add<T>(string key, T t)
        {
            if (key != null && key.Length > 0 && t != null)
            {
                webCache.Insert(key, t, null, DateTime.Now.AddMinutes(TimeOut), System.Web.Caching.Cache.NoSlidingExpiration);
            }
        }

        /// <summary>
        /// ���ض���
        /// </summary>
        public static T Get<T>(string key)
        {
            if (key == null || key.Length == 0) { return default(T); }
            return (T)webCache.Get(key);

        }

        /// <summary>
        /// ɾ������
        /// </summary>
        public static void Clear(string key)
        {
            if (key == null || key.Length == 0) { return; }
            webCache.Remove(key);
        }
	}
}