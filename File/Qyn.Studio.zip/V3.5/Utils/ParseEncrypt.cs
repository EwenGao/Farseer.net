using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// ���ܹ���
    /// </summary>
    public class ParseEncrypt
    {
        /// <summary> 
        /// ����
        /// </summary> 
        public class AES
        {
            //Ĭ����Կ����
            private static byte[] Keys = { 0x41, 0x72, 0x65, 0x79, 0x6F, 0x75, 0x6D, 0x79, 0x53, 0x6E, 0x6F, 0x77, 0x6D, 0x61, 0x6E, 0x3F };
            /// <summary>
            /// AES�����ַ���
            /// </summary>
            /// <param name="encryptString">�����ܵ��ַ���</param>
            /// <param name="encryptKey">������Կ,Ҫ��Ϊ8λ</param>
            /// <returns>���ܳɹ����ؼ��ܺ���ַ���,ʧ�ܷ���Դ��</returns>
            public static string Encode(string encryptString, string encryptKey)
            {
                encryptKey = ParseString.SubString(encryptKey, 0, 32);
                encryptKey = encryptKey.PadRight(32, ' ');

                RijndaelManaged rijndaelProvider = new RijndaelManaged();
                rijndaelProvider.Key = Encoding.UTF8.GetBytes(encryptKey.Substring(0, 32));
                rijndaelProvider.IV = Keys;
                ICryptoTransform rijndaelEncrypt = rijndaelProvider.CreateEncryptor();

                byte[] inputData = Encoding.UTF8.GetBytes(encryptString);
                byte[] encryptedData = rijndaelEncrypt.TransformFinalBlock(inputData, 0, inputData.Length);

                return Convert.ToBase64String(encryptedData);
            }

            /// <summary>
            /// AES�����ַ���
            /// </summary>
            /// <param name="decryptString">�����ܵ��ַ���</param>
            /// <param name="decryptKey">������Կ,Ҫ��Ϊ8λ,�ͼ�����Կ��ͬ</param>
            /// <returns>���ܳɹ����ؽ��ܺ���ַ���,ʧ�ܷ�Դ��</returns>
            public static string Decode(string decryptString, string decryptKey)
            {
                try
                {
                    decryptKey = ParseString.SubString(decryptKey, 0, 32);
                    decryptKey = decryptKey.PadRight(32, ' ');

                    RijndaelManaged rijndaelProvider = new RijndaelManaged();
                    rijndaelProvider.Key = Encoding.UTF8.GetBytes(decryptKey);
                    rijndaelProvider.IV = Keys;
                    ICryptoTransform rijndaelDecrypt = rijndaelProvider.CreateDecryptor();

                    byte[] inputData = Convert.FromBase64String(decryptString);
                    byte[] decryptedData = rijndaelDecrypt.TransformFinalBlock(inputData, 0, inputData.Length);

                    return Encoding.UTF8.GetString(decryptedData);
                }
                catch
                {
                    return "";
                }

            }

        }

        /// <summary> 
        /// ����
        /// </summary> 
        public class DES
        {
            //Ĭ����Կ����
            private static byte[] Keys = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

            /// <summary>
            /// DES�����ַ���
            /// </summary>
            /// <param name="encryptString">�����ܵ��ַ���</param>
            /// <param name="encryptKey">������Կ,Ҫ��Ϊ8λ</param>
            /// <returns>���ܳɹ����ؼ��ܺ���ַ���,ʧ�ܷ���Դ��</returns>
            public static string Encode(string encryptString, string encryptKey)
            {
                encryptKey = ParseString.SubString(encryptKey, 0, 8);
                encryptKey = encryptKey.PadRight(8, ' ');
                byte[] rgbKey = Encoding.UTF8.GetBytes(encryptKey.Substring(0, 8));
                byte[] rgbIV = Keys;
                byte[] inputByteArray = Encoding.UTF8.GetBytes(encryptString);
                DESCryptoServiceProvider dCSP = new DESCryptoServiceProvider();
                MemoryStream mStream = new MemoryStream();
                CryptoStream cStream = new CryptoStream(mStream, dCSP.CreateEncryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                cStream.Write(inputByteArray, 0, inputByteArray.Length);
                cStream.FlushFinalBlock();
                return Convert.ToBase64String(mStream.ToArray());

            }

            /// <summary>
            /// DES�����ַ���
            /// </summary>
            /// <param name="decryptString">�����ܵ��ַ���</param>
            /// <param name="decryptKey">������Կ,Ҫ��Ϊ8λ,�ͼ�����Կ��ͬ</param>
            /// <returns>���ܳɹ����ؽ��ܺ���ַ���,ʧ�ܷ�Դ��</returns>
            public static string Decode(string decryptString, string decryptKey)
            {
                try
                {
                    decryptKey = ParseString.SubString(decryptKey, 0, 8);
                    decryptKey = decryptKey.PadRight(8, ' ');
                    byte[] rgbKey = Encoding.UTF8.GetBytes(decryptKey);
                    byte[] rgbIV = Keys;
                    byte[] inputByteArray = Convert.FromBase64String(decryptString);
                    DESCryptoServiceProvider DCSP = new DESCryptoServiceProvider();

                    MemoryStream mStream = new MemoryStream();
                    CryptoStream cStream = new CryptoStream(mStream, DCSP.CreateDecryptor(rgbKey, rgbIV), CryptoStreamMode.Write);
                    cStream.Write(inputByteArray, 0, inputByteArray.Length);
                    cStream.FlushFinalBlock();
                    return Encoding.UTF8.GetString(mStream.ToArray());
                }
                catch
                {
                    return "";
                }

            }

        }

        /// <summary>
        /// MD5����
        /// </summary>
        /// <param name="str">ԭʼ�ַ���</param>
        /// <param name="isReverse">�Ƿ���ܺ�ת�ַ���</param>
        /// <param name="ToUpper">�Ƿ���ܺ�תΪ��д</param>
        /// <returns>MD5���</returns>
        public static string MD5(string str, bool isReverse, bool ToUpper)
        {
            str = MD5(str);
            if (isReverse) { str = Reverse(str); }
            if (ToUpper) { str = str.ToUpper(); }
            return str;
        }

        /// <summary>
        /// MD5����
        /// </summary>
        /// <param name="str">ԭʼ�ַ���</param>
        /// <returns>MD5���</returns>
        public static string MD5(string str)
        {
            byte[] b = Encoding.Default.GetBytes(str);
            b = new MD5CryptoServiceProvider().ComputeHash(b);
            string ret = "";
            for (int i = 0; i < b.Length; i++)
                ret += b[i].ToString("x").PadLeft(2, '0');
            return ret;
        }

        /// <summary>
        /// SHA256����
        /// </summary>
        /// /// <param name="str">ԭʼ�ַ���</param>
        /// <returns>SHA256���</returns>
        public static string SHA256(string str)
        {
            byte[] SHA256Data = Encoding.UTF8.GetBytes(str);
            SHA256Managed Sha256 = new SHA256Managed();
            byte[] Result = Sha256.ComputeHash(SHA256Data);
            return Convert.ToBase64String(Result);  //���س���Ϊ44�ֽڵ��ַ���
        }

        /// <summary>
        /// ��ת�ַ���
        /// </summary>
        /// <param name="input">Ҫ��ת�ַ���</param>
        /// <returns></returns>
        public static string Reverse(string input)
        {
            char[] chars = input.ToUpper().ToCharArray();
            int length = chars.Length;
            char c;
            for (int index = 0; index < length / 2; index++)
            {
                c = chars[index];
                chars[index] = chars[length - 1 - index];
                chars[length - 1 - index] = c;
            }
            return new String(chars);
        }

    }
}