﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// Web控制集合操作
    /// </summary>
    public class ParseWebControls
    {
        /// <summary>
        /// 返回Repeater选中的CheckBox的ID
        /// </summary>
        /// <param name="rpt">Repeater</param>
        public static List<int> GetRepeaterCheckBoxValue(Repeater rpt)
        {
            List<int> lst = new List<int>();
            int ID;
            foreach (RepeaterItem item in rpt.Items)
            {
                CheckBox chkItem = item.FindControl("chkItem") as CheckBox;
                if (chkItem.Checked)
                {
                    ID = chkItem.ToolTip.ConvertType(0);
                    lst.Add(ID);
                }
            }
            return lst;
        }

        /// <summary>
        /// 获取ListBox的值
        /// </summary>
        /// <param name="control">ListBox</param>
        public static List<T> GetListControl<T>(ListControl control) 
        {
            List<T> lst = new List<T>();
            if (control is CheckBoxList)
            {
                foreach (ListItem item in control.Items) { if (item.Selected) { lst.Add(item.Value.ConvertType<T>()); } }
            }
            else
            {
                foreach (ListItem item in control.Items) { lst.Add(item.Value.ConvertType<T>()); }
            }
            return lst;

        }

        /// <summary>
        /// 设置ListBox的值
        /// </summary>
        /// <param name="control">ListBox</param>
        /// <param name="lst">要设置的值</param>
        public static void SetListControl<T>(ListControl control, List<T> lst) 
        {
            if (control is CheckBoxList)
            {
                foreach (ListItem item in control.Items)
                {
                    if (!item.Value.IsType<Int32>()) { continue; }
                    item.Selected = lst.Exists(o => o.ConvertType(0) == item.Value.ConvertType(0));
                }
            }
            else { foreach (T item in lst) { control.Items.Add(item.ToString()); } }
        }

    }
}
