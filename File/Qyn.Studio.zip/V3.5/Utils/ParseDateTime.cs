﻿using System;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 格式化时间
    /// </summary>
    public class ParseDateTime
    {
        /// <summary>
        /// 根据阿拉伯数字返回月份的名称(可更改为某种语言)
        /// </summary>	
        public static string[] Monthes
        {
            get
            {
                return new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            }
        }

        /// <summary>
        /// 返回指定月的最后一天
        /// </summary>
        /// <param name="year">年</param>
        /// <param name="mouth">月</param>
        public static int GetMouthLastDay(int year,int mouth)
        {
            switch (mouth)
            {
                case 1:
                    return 31;
                case 2:
                    if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
                    {
                        return 29;
                    }
                    else
                    {
                        return 28;
                    }
                case 3:
                    return 31;
                case 5:
                    return 31;
                case 7:
                    return 31;
                case 8:
                    return 31;
                case 10:
                    return 31;
                case 12:
                    return 31;
                default:
                    return 30;
            }
        }

        /// <summary>
        /// 返回去掉时间格式的时间字符串
        /// </summary>
        public static string GetDateTimeString()
        {
            return DateTime.Now.ToString().Replace("-", "").Replace("/", "").Replace(":", "").Replace(" ", "");
        }

        /// <summary>
        /// 返回去掉时间格式的路径形式
        /// </summary>
        public static string GetDateTimePath()
        {
            return DateTime.Now.ToString().Replace("-", "/").Replace(":", "").Replace(" ", "/");
        }

        /// <summary>
        /// 返回日期
        /// </summary>
        /// <returns></returns>
        public static string GetDateString()
        {
            return DateTime.Now.ToShortDateString().Replace("-", "").Replace("/", "").Trim();
        }

        /// <summary>
        /// 日期转换成数字
        /// </summary>
        public static int DateToInt(string str)
        {
            DateTime result;
            int dateTime = 0;

            if (DateTime.TryParse(str, out result))
            {
                DateTime time = Convert.ToDateTime("1970-1-1");

                TimeSpan ts = result.Subtract(time);

                dateTime = Convert.ToInt32(Math.Round(ts.TotalSeconds));

            }

            return dateTime;
        }
    }
}
