﻿using System.Text.RegularExpressions;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 防范黑客攻击的代码
    /// </summary>
    public class ParseHacker
    {
        /// <summary>
        /// 检查查询语句是否符合规则(ID = 1 AND UserName = 'steden') 非数字，要加''
        /// </summary>
        public static string Condition(string condition)
        {
            if (string.IsNullOrEmpty(condition)) condition = "1=1";

            if (condition.ToUpper().StartsWith("WHERE")) { condition = condition.Substring(6).Trim(); }

            //如果前面出现："@"字符串，则表明无需验证
            if (condition.StartsWith("@")) { return string.Format("WHERE {0}", condition.Substring(1)); }
            
            if (!condition.StartsWith("1=1")) condition = "1=1 AND " + condition;

            Regex reg = new Regex(@"^1=1((\s)(AND|OR)(\s)([A-Z]\w+?|\[[A-Z]\w+?\])(\s)([<>|=|LIKE|IN|NOT|\<|\>|\<=|\>=|\s]+)\s(\([^\)]+\)|(\'[^\']+\')|\d+|\([\d+\,]+\d\))){0,8}$");
            return reg.IsMatch(condition) ? string.Format("WHERE {0}", condition) : "WHERE 1!=1";
        }

        /// <summary>
        /// 检查排序语句是否符合规则
        /// </summary>
        public static string Sort(string sort)
        {
            if (string.IsNullOrEmpty(sort)) return string.Empty;

            sort = sort.ToUpper();

            if (sort.StartsWith("ORDER BY")) { sort = sort.Substring(9).Trim(); }
            //Regex reg = new Regex(@"^(([A-Z]\w+?|\[[A-Z]\w+?\])(\s)(ASC|DESC))((\s)\,(\s)([A-Z]\w+?|\[[A-Z]\w+?\])(\s)(ASC|DESC)){0,8}$");
            //sort = reg.IsMatch(sort) ? sort : string.Empty;

            if (!string.IsNullOrEmpty(sort)) { sort = string.Format("ORDER BY {0}", sort); }
            return sort;
        }
    }
}
