﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// DataTable工具
    /// </summary>
    public class ParseDataTable
    {
        /// <summary>
        /// 对DataTable排序
        /// </summary>
        /// <param name="dt">要排序的表</param>
        /// <param name="sort">要排序的字段</param>
        public static DataTable Sort(DataTable dt, string sort)
        {
            DataRow[] rows = dt.Select("", sort);
            DataTable tmpDt = dt.Clone();

            foreach (DataRow row in rows)
            {
                tmpDt.ImportRow(row);
            }
            return tmpDt;
        }

        /// <summary>
        /// 返回已分页的表
        /// </summary>
        /// <param name="dt">源表</param>
        /// <param name="pageSize">每页显示的记录数</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static DataTable Pagination(DataTable dt, int pageSize, int pageIndex)
        {
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            if (pageSize < 1)
            {
                pageSize = 1;
            }
            DataTable dtNew = dt.Clone();

            if (dt != null)
            {
                int firstIndex;
                int endIndex;

                #region 计算 开始索引
                if (pageIndex == 1)
                {
                    firstIndex = 0;
                }
                else
                {
                    firstIndex = pageSize * (pageIndex - 1);
                    //索引超出记录总数时，返回空的表格
                    if (firstIndex > dt.Rows.Count)
                    {
                        return dtNew;
                    }
                }
                #endregion

                #region 计算 结束索引
                endIndex = pageSize + firstIndex;
                if (endIndex > dt.Rows.Count)
                {
                    endIndex = dt.Rows.Count;
                }
                #endregion

                for (int i = firstIndex; i < endIndex; i++)
                {
                    dtNew.ImportRow(dt.Rows[i]);
                }
            }
            return dtNew;
        }

        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(DataTable dt)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            foreach (DataRow dr in dt.Rows)
            {
                T t = (T)Activator.CreateInstance(ht, dr);
                list.Add(t);
            }
            dt.Dispose();
            return list;
        }

        /// <summary>
        /// 倒序
        /// </summary>
        public static DataTable Reverse(DataTable dt)
        {
            DataRow[] rows = dt.Select("");
            DataTable tmpDt = dt.Clone();

            for (int i = dt.Rows.Count - 1; i >= 0; i--)
            {
                tmpDt.ImportRow(dt.Rows[i]);
            }
            return tmpDt;
        }

        /// <summary>
        /// 将DataTable转换为list
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static IList<T> DataTableToList<T>(DataTable dt)
        {
            if (dt == null) { return null; }
            IList<T> result = new List<T>();
            for (int j = 0; j < dt.Rows.Count; j++)
            {
                T _t = (T)Activator.CreateInstance(typeof(T));
                PropertyInfo[] propertys = _t.GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        // 属性与字段名称一致的进行赋值 
                        if (pi.Name.Equals(dt.Columns[i].ColumnName))
                        {
                            if (dt.Rows[j][i] != DBNull.Value)
                            {
                                if (pi.PropertyType.ToString() == "System.Int32")
                                {
                                    pi.SetValue(_t, Int32.Parse(dt.Rows[j][i].ToString()), null);
                                }
                                if (pi.PropertyType.ToString() == "System.DateTime")
                                {
                                    pi.SetValue(_t, Convert.ToDateTime(dt.Rows[j][i].ToString()), null);
                                }
                                if (pi.PropertyType.ToString() == "System.String")
                                {
                                    pi.SetValue(_t, dt.Rows[j][i].ToString(), null);
                                }
                                if (pi.PropertyType.ToString() == "System.Boolean")
                                {
                                    pi.SetValue(_t, Convert.ToBoolean(dt.Rows[j][i].ToString()), null);
                                }
                            }
                            else
                                pi.SetValue(_t, null, null);
                            break;
                        }
                    }
                }
                result.Add(_t);
            }
            return result;
        }

    }

    /// <summary>
    /// 实体转换辅助类
    /// </summary>
    public class ModelConvertHelper<T> where T : new()
    {

        /// <summary>
        /// DataTable转换成List
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public static IList<T> ConvertToModel(DataTable dt)
        {
            // 定义集合
            IList<T> ts = new List<T>();
            // 获得此模型的类型
            Type type = typeof(T);
            string tempName = "";
            foreach (DataRow dr in dt.Rows)
            {
                T t = new T();
                // 获得此模型的公共属性
                PropertyInfo[] propertys = t.GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    tempName = pi.Name;
                    // 检查DataTable是否包含此列
                    if (dt.Columns.Contains(tempName))
                    {
                        // 判断此属性是否有Setter
                        if (!pi.CanWrite) continue;
                        object value = dr[tempName];
                        if (value != DBNull.Value)
                            pi.SetValue(t, value, null);
                    }
                }
                ts.Add(t);
            }
            return ts;
        }
    }
}
