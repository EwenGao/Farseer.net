﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 判断类型
    /// </summary>
    public class ParseIsType
    {
        /// <summary>
        /// 检测是否符合email格式
        /// </summary>
        /// <param name="strEmail">要判断的email字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsValidEmail(string strEmail)
        {
            return Regex.IsMatch(strEmail, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }

        /// <summary>
        /// 检测是否符合email格式
        /// </summary>
        /// <param name="strEmail">要判断的email字符串</param>
        /// <returns>判断结果</returns>
        public static bool IsValidDoEmail(string strEmail)
        {
            return Regex.IsMatch(strEmail, @"^@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }

        /// <summary>
        /// 是否为ip
        /// </summary>
        public static bool IsIP(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");

        }

        /// <summary>
        /// 是否为ip
        /// </summary>
        public static bool IsIPSect(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){2}((2[0-4]\d|25[0-5]|[01]?\d\d?|\*)\.)(2[0-4]\d|25[0-5]|[01]?\d\d?|\*)$");

        }

        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strDouble">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsDoubleArray(string[] strDouble)
        {
            if (strDouble == null)
            {
                return false;
            }
            if (strDouble.Length < 1)
            {
                return false;
            }
            foreach (string id in strDouble)
            {
                if (!IsType<Int64>(id))
                {
                    return false;
                }
            }
            return true;

        }

        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strInt">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsIntArray(string[] strInt)
        {
            if (strInt == null)
            {
                return false;
            }
            if (strInt.Length < 1)
            {
                return false;
            }
            foreach (string id in strInt)
            {
                if (!IsType<Int32>(id))
                {
                    return false;
                }
            }
            return true;

        }

        /// <summary>
        /// 判断是否为base64字符串
        /// </summary>
        public static bool IsBase64String(string str)
        {
            //A-Z, a-z, 0-9, +, /, =
            return Regex.IsMatch(str, @"[A-Za-z0-9\+\/\=]");
        }

        /// <summary>
        /// 验证电话号码
        /// </summary>
        public static bool IsTel(string tel)
        {
            //匹配格式：
            //11位手机号码
            //3-4位区号，7-8位直播号码，1－4位分机号
            //如：12345678901、1234-12345678-1234
            return Regex.IsMatch(tel, @"((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)");
        }


        /// <summary>
        /// 判断类型
        /// </summary>
        /// <typeparam name="T">类型</typeparam>
        /// <param name="objValue">要判断类型的对像</param>
        /// <returns></returns>
        public static bool IsType<T>(object objValue)
        {
            if (objValue == null) { return false; }

            if (typeof(T) == typeof(Int32))
            {
                int value;
                return int.TryParse(objValue.ToString(), out value);
            }
            if (typeof(T) == typeof(Byte))
            {
                byte value;
                return byte.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Boolean))
            {
                bool value;
                return bool.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Decimal))
            {
                decimal value;
                return decimal.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Single))
            {
                float value;
                return float.TryParse(objValue.ToString(), out value);

            }
            else if (typeof(T) == typeof(Double))
            {
                double value;
                return double.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(DateTime))
            {
                DateTime value;
                return DateTime.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Int64))
            {
                long value;
                return long.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Int16))
            {
                short value;
                return short.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(DataTable))
            {
                try { DataTable dt = (DataTable)objValue; return true; }
                catch { return false; }
            }
            else if (typeof(T) == typeof(String))
            {
                try { String str = (String)objValue; return true; }
                catch { return false; }
            }
            else if (typeof(T).IsEnum)
            {
                return objValue is Enum;
            }
            else if (typeof(T) == typeof(List<int>))
            {
                return objValue as List<int> != null;
            }
            return false;
        }

        /// <summary>
        /// 是否为纯数字+Tag
        /// </summary>
        /// <param name="str">要判断的字符串</param>
        /// <param name="tag">可以包含的字符</param>
        /// <returns></returns>
        public static bool IsNumberString(string str, string tag)
        {
            foreach (char c in ParseString.ClearString(str, tag))
            {
                if (!IsType<Int32>(c)) { return false; }
            }
            return true;
        }
    }
}
