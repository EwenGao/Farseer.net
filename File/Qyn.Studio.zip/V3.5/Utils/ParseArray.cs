﻿
namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 数组工具
    /// </summary>
    public class ParseArray
    {
        /// <summary>
        /// 将数组转换成用符号连接的字符串
        /// </summary>
        public static string ToString<T>(T[] objAry, string sign)
        {
            if (objAry == null || objAry.Length == 0) { return string.Empty; }

            string str = string.Empty;

            for (int i = 0; i < objAry.Length;i++ )
            {
                str += sign + objAry[i];
            }

            return str.Substring(sign.Length);
        }
    }
}
