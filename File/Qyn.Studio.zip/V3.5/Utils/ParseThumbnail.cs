using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// Thumbnail ��ժҪ˵����
    /// </summary>
    public class ParseThumbnail
    {
        /// <summary>
        /// ��������ͼ(�вü�)
        /// </summary>
        /// <param name="oldImagePath">ԭʼͼƬ</param>
        /// <param name="newImagePath">��ͼƬ</param>
        /// <param name="width">����</param>
        /// <param name="height">�߶�</param>
        /// <param name="level">ͼƬ����: 1 - 100</param>
        /// <param name="mode">"W":ָ����,�߰�����;  "H":ָ���ߣ���������;  "Min":ȡ��Сֵ;  "Max":ȡ���ֵ; "Cut":�����ֵ�����ٲü���������</param>
        public static void MakeThumbnail(string oldImagePath, string newImagePath, int width, int height, int level, string mode)
        {
            if (mode != "Cut")
                MakeThumbnail(oldImagePath, newImagePath, width, height, mode, level);
            else
            {
                MakeThumbnail(oldImagePath, newImagePath, width, height, "Max", level);
                Cut(newImagePath, 0, 0, width, height);
            }
        }

        /// <summary>
        /// ��������ͼ(�޲ü�)
        /// </summary>
        /// <param name="oldImagePath">ԭʼͼƬ</param>
        /// <param name="newImagePath">��ͼƬ</param>
        /// <param name="width">����</param>
        /// <param name="height">�߶�</param>
        /// <param name="level">ͼƬ����: 1 - 100</param>
        /// <param name="mode">"W":ָ����,�߰�����;  "H":ָ���ߣ���������;  "Min":ȡ��Сֵ;  "Max":ȡ���ֵ; </param>
        public static void MakeThumbnail(string oldImagePath, string newImagePath, int width, int height, string mode, int level)
        {
            oldImagePath = ParseUrl.GetMapPath(oldImagePath);
            newImagePath = ParseUrl.GetMapPath(newImagePath);

            int towidth = width;
            int toheight = height;
            Image oldimage = Image.FromFile(oldImagePath);
            switch (mode)
            {
                case "W"://ָ�������߰�����                     
                    toheight = oldimage.Height * width / oldimage.Width;
                    break;
                case "H"://ָ���ߣ��������� 
                    towidth = oldimage.Width * height / oldimage.Height;
                    break;
                case "Min":  //���ȸ߶�ȡ��Сֵ
                    toheight = oldimage.Height * width / oldimage.Width;
                    if (toheight > height)
                    {
                        towidth = oldimage.Width * height / oldimage.Height;
                        toheight = height;
                    }
                    break;
                case "Max":  //���ȸ߶�ȡ���ֵ
                    toheight = oldimage.Height * width / oldimage.Width;
                    if (toheight < height)
                    {
                        towidth = oldimage.Width * height / oldimage.Height;
                        toheight = height;
                    }
                    break;
                default:
                    break;
            }
            using (Bitmap bm = new Bitmap(towidth, toheight))
            {
                using (Graphics g = Graphics.FromImage(bm))
                {
                    g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    g.Clear(Color.White);
                    g.DrawImage(oldimage, new Rectangle(0, 0, towidth, toheight), new Rectangle(0, 0, oldimage.Width, oldimage.Height), GraphicsUnit.Pixel);
                    oldimage.Dispose();
                }
                setQuality(level);
                bm.Save(newImagePath, ici, ep);
            }

        }

        /// <summary>
        /// �ü�ͼƬ
        /// </summary>
        /// <param name="pic">ͼƬ·��</param>
        /// <param name="left">��߾�</param>
        /// <param name="top">�ϱ߾�</param>
        /// <param name="width">�ü������</param>
        /// <param name="height">�ü���߶�</param>
        public static void Cut(string pic, int left, int top, int width, int height)
        {
            pic = ParseUrl.GetMapPath(pic);

            string tmpName = string.Empty;
            using (Image bm = new System.Drawing.Bitmap(width, height))
            {
                using (Image image = System.Drawing.Image.FromFile(pic))
                {
                    using (Graphics g = System.Drawing.Graphics.FromImage(bm))
                    {
                        g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

                        g.Clear(Color.White);
                        //��ָ��λ�ò��Ұ�ָ����С����ԭͼƬ��ָ������ 
                        g.DrawImage(image, new Rectangle(0, 0, width, height), new Rectangle(left, top, width, height), GraphicsUnit.Pixel);
                        tmpName = pic + ".jpg";
                        setQuality(100);
                        bm.Save(tmpName, ici, ep);

                    }
                }
                File.Delete(pic);
                File.Move(tmpName, pic);
            }
        }

        /// <summary>
        /// ˮӡλ��
        /// </summary>
        public enum MarkPlace : byte
        {
            [Description("���Ͻ�")]
            LeftTop,
            [Description("���Ͻ�")]
            RightTop,
            [Description("���½�")]
            LeftBottom,
            [Description("���½�")]
            RightBottom,
            [Description("ͼƬ����")]
            Center
        }

        /// <summary>
        /// ͼƬˮӡ
        /// </summary>
        /// <param name="pic">ԭʼͼƬ</param>
        /// <param name="markImage">ˮӡ</param>
        /// <param name="x">X����</param>
        /// <param name="y">Y����</param>
        public static void Mark(string pic, Image markImage, int x, int y)
        {
            pic = ParseUrl.GetMapPath(pic);

            string tmpName = string.Empty;
            using (Image image = Image.FromFile(pic))
            {

                if (markImage.Width > image.Width || markImage.Height > image.Height)
                {
                    markImage.Dispose();
                    return;
                }
                using (Bitmap bitmap = new Bitmap(image.Width, image.Height))
                {
                    using (Graphics g = Graphics.FromImage(bitmap))
                    {
                        g.DrawImage(image, 0, 0, image.Width, image.Height);
                        g.CompositingQuality = CompositingQuality.HighQuality;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawImage(markImage, new Rectangle(x, y, markImage.Width, markImage.Height), 0, 0, markImage.Width, markImage.Height, GraphicsUnit.Pixel);
                        markImage.Dispose();
                    }
                    tmpName = pic + ".tmp";
                    setQuality(100);
                    bitmap.Save(tmpName, ici, ep);
                }
            }
            File.Delete(pic);
            File.Move(tmpName, pic);
        }

        /// <summary>
        /// ˮӡ
        /// </summary>
        /// <param name="pic">ԭʼͼƬ</param>
        /// <param name="markImage">ˮӡ</param>
        /// <param name="place">ˮӡλ��</param>
        public static void Mark(string pic, Image markImage, MarkPlace place)
        {
            pic = ParseUrl.GetMapPath(pic);

            int x, y;
            x = y = 0;
            using (Image image = Image.FromFile(pic))
            {
                switch (place)
                {
                    case MarkPlace.RightBottom:
                        x = image.Width - markImage.Width - 2;
                        y = image.Height - markImage.Height - 2;
                        break;
                    case MarkPlace.LeftBottom:
                        x = 12;
                        y = image.Height - markImage.Height - 12;
                        break;
                    case MarkPlace.LeftTop:
                        x = y = 12;
                        break;
                    case MarkPlace.RightTop:
                        x = image.Width - markImage.Width - 12;
                        y = 12;
                        break;
                    case MarkPlace.Center:
                        x = (image.Width - markImage.Width) / 2;
                        y = (image.Height - markImage.Height) / 2;
                        break;
                }
            }
            Mark(pic, markImage, x, y);
            markImage.Dispose();
        }

        /// <summary>
        /// ͼƬˮӡ
        /// </summary>
        /// <param name="pic">ԭʼͼƬ</param>
        /// <param name="markImagePath">ˮӡ·��</param>
        /// <param name="place">ˮӡλ��</param>
        public static void Mark(string pic, string markImagePath, MarkPlace place)
        {
            using (Image mark = Image.FromFile(markImagePath))
            {
                Mark(pic, mark, place);
            }
        }

        /// <summary>
        /// ����ˮӡ
        /// </summary>
        /// <param name="pic">ԭʼͼƬ</param>
        /// <param name="text">ˮӡ����</param>
        /// <param name="place">ˮӡλ��</param>
        /// <param name="fontfamily">��������</param>
        /// <param name="fontsize">���ִ�С</param>
        /// <param name="fontcolor">������ɫ</param>
        public static void Mark(string pic, string text, MarkPlace place, string fontfamily, int? fontsize, Brush fontcolor)
        {
            using (Image txt = ToPicture(text, fontfamily, fontsize, fontcolor))
            {
                Mark(pic, txt, place);
            }

        }

        /// <summary>
        /// ת���ı�ΪBitmap
        /// </summary>
        /// <param name="text">�ı�</param>
        /// <param name="fontfamily">����</param>
        /// <param name="fontsize">�ֺ�</param>
        /// <param name="fontcolor">������ɫ</param>
        /// <returns></returns>
        public static Bitmap ToPicture(string text, string fontfamily, int? fontsize, Brush fontcolor)
        {
            if (fontcolor == null)
                fontcolor = Brushes.White;
            if (fontfamily == null)
                fontfamily = "����";
            if (fontsize == null)
                fontsize = 20;
            Font font = new Font(fontfamily, (float)fontsize);
            Bitmap bmp = new Bitmap(10, 10);
            Size ImageSize = Size.Empty;
            // ����ͼƬ��С
            using (Graphics g = Graphics.FromImage(bmp))
            {
                SizeF size = g.MeasureString(text, font, 10000);
                ImageSize.Width = (int)size.Width + 5;
                ImageSize.Height = (int)size.Height + 5;
            }
            // ����ͼƬ
            bmp = new Bitmap(ImageSize.Width, ImageSize.Height);
            // �����ı�
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.Transparent);
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.High;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                using (StringFormat f = new StringFormat())
                {
                    f.Alignment = StringAlignment.Center;
                    f.LineAlignment = StringAlignment.Center;
                    //f.FormatFlags = StringFormatFlags.NoWrap;
                    g.DrawString(text, font, fontcolor, new RectangleF(2, 2, ImageSize.Width, ImageSize.Height), f);
                }
            }
            return bmp;
        }


        /// <summary>
        /// ͼƬ����
        /// </summary>
        /// <param name="width">��������</param>
        /// <param name="height">�����߶�</param>
        /// <param name="piclist">ͼƬ����</param>
        /// <param name="textlist">�ı�����</param>
        /// <param name="path">ͼƬ����·��</param>
        public static void AppendPicture(int width, int height, List<Picture> piclist, List<Text> textlist, string path)
        {
            path = ParseUrl.GetMapPath(path);

            using (Image frm = new Bitmap(width, height))
            {
                using (Graphics g = Graphics.FromImage(frm))
                {
                    g.CompositingQuality = CompositingQuality.HighQuality;
                    g.InterpolationMode = InterpolationMode.High;
                    g.SmoothingMode = SmoothingMode.HighQuality;
                    g.Clear(Color.White);
                    Image image;
                    foreach (Picture p in piclist)
                    {
                        using (image = Image.FromFile(p.Path))
                        {
                            g.DrawImage(image, new Rectangle(p.Left, p.Top, width, height), new Rectangle(0, 0, width, height), GraphicsUnit.Pixel);
                        }
                    }
                    if (textlist.Count > 0)
                    {
                        foreach (Text p in textlist)
                        {
                            using (image = ToPicture(p.Txt, p.FontFamily, p.FontSize, p.FontColor))
                            {
                                g.DrawImage(image, new Rectangle(p.Left, p.Top, width, height), new Rectangle(0, 0, width, height), GraphicsUnit.Pixel);
                            }
                        }
                    }
                    setQuality(100);
                    frm.Save(path, ici, ep);
                }
            }
        }


        #region ����ͼƬ����
        public static ImageCodecInfo ici;
        public static EncoderParameters ep;
        public static void setQuality(int level)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();
            ici = null;
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.MimeType == "image/jpeg")
                    ici = codec;
            }
            ep = new EncoderParameters();
            ep.Param[0] = new EncoderParameter(Encoder.Quality, (long)level);
        }
        #endregion
    }

    /// <summary>
    /// ͼƬʵ��
    /// </summary>
    public class Picture
    {
        private int _left;
        private int _top;
        private string _path;
        public Picture(int left, int top, string path)
        {
            _left = left;
            _top = top;
            _path = path;
        }
        public Picture(ParseThumbnail.MarkPlace place, string path)
        {
            switch (place)
            {
                case ParseThumbnail.MarkPlace.LeftTop:
                    _left = 12;
                    _top = 60;
                    break;
                default:
                    _left = 300;
                    _top = 12;
                    break;
            }
            _path = path;
        }
        public int Left
        {
            get { return this._left; }
            set { this._left = value; }
        }
        public int Top
        {
            get { return this._top; }
            set { this._top = value; }
        }
        public string Path
        {
            get { return this._path; }
            set { this._path = value; }
        }
    }

    /// <summary>
    /// �ı�ʵ��
    /// </summary>
    public class Text
    {
        private int _left;
        private int _top;
        private string _txt;
        private string _fontfamily;
        private int? _fontsize;
        private Brush _fontcolor;
        public Text(int left, int top, string txt, string fontfamily, int? fontsize, Brush fontcolor)
        {
            _left = left;
            _top = top;
            _txt = txt;
            _fontfamily = fontfamily == null ? " ����" : fontfamily;
            _fontsize = fontsize == null ? 12 : fontsize;
            _fontcolor = fontcolor == null ? Brushes.White : fontcolor;
        }
        public int Left
        {
            get { return this._left; }
            set { this._left = value; }
        }
        public int Top
        {
            get { return this._top; }
            set { this._top = value; }
        }
        public string Txt
        {
            get { return this._txt; }
            set { this._txt = value; }
        }
        public string FontFamily
        {
            get { return this._fontfamily; }
            set { this._fontfamily = value; }
        }
        public int? FontSize
        {
            get { return this._fontsize; }
            set { this._fontsize = value; }
        }
        public Brush FontColor
        {
            get { return this._fontcolor; }
            set { this._fontcolor = value; }
        }
    }
}
