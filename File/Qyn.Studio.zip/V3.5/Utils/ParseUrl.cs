﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web;
using System.Linq;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 解释Url
    /// </summary>
    public class ParseUrl
    {
        /// <summary>
        /// 返回 URL 字符串的编码结果
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>编码结果</returns>
        public static string UrlEncode(string str)
        {
            return HttpUtility.UrlEncode(str);
        }

        /// <summary>
        /// 返回 URL 字符串的编码结果
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>解码结果</returns>
        public static string UrlDecode(string str)
        {
            return HttpUtility.UrlDecode(str);
        }

        /// <summary>
        /// 获得当前绝对路径
        /// </summary>
        /// <param name="strPath">指定的路径</param>
        /// <returns>绝对路径</returns>
        public static string GetMapPath(string strPath)
        {
            if (strPath.Length > 2 && strPath.Substring(1, 1) == ":") { return ParseFile.ConvertPath(strPath); }
            try
            {
                if (HttpContext.Current != null)
                {
                    return ParseFile.ConvertPath(HttpContext.Current.Server.MapPath(strPath));
                }
                else //非web程序引用
                {
                    return ParseFile.ConvertPath(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, strPath));
                }
            }
            catch
            { return ParseFile.ConvertPath(strPath); }
        }

        /// <summary>
        /// 检测是否是正确的Url
        /// </summary>
        /// <param name="strUrl">要验证的Url</param>
        /// <returns>判断结果</returns>
        public static bool IsURL(string strUrl)
        {
            return Regex.IsMatch(strUrl, @"^(http|https)\://([a-zA-Z0-9\.\-]+(\:[a-zA-Z0-9\.&%\$\-]+)*@)*((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|localhost|([a-zA-Z0-9\-]+\.)*[a-zA-Z0-9\-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{1,10}))(\:[0-9]+)*(/($|[a-zA-Z0-9\.\,\?\'\\\+&%\$#\=~_\-]+))*$");
        }

        /// <summary>
        /// 返回URL中结尾的文件名
        /// </summary>		
        public static string GetFilename(string url)
        {
            if (url == null)
            {
                return "";
            }
            string[] strs1 = url.Split(new char[] { '/' });
            return strs1[strs1.Length - 1].Split(new char[] { '?' })[0];
        }

        /// <summary>
        /// 返回完全域名，带端口
        /// </summary>
        /// <param name="url">来源URL</param>
        /// <returns></returns>
        public static string GetDomainUrl(string url)
        {
            string newUrl;
            //去掉 http://字符串
            newUrl = url.ToLower().Replace("\\", "/").Replace("http://", "");
            //只截取到第一个'/'符号的字符串
            newUrl = newUrl.Substring(0, newUrl.IndexOf('/'));
            newUrl = "http://" + newUrl;
            return newUrl;
        }

        /// <summary>
        /// 得到网站的真实路径
        /// </summary>
        /// <returns></returns>
        public static string GetTrueWebPath()
        {
            string forumPath = HttpContext.Current.Request.Path;
            if (forumPath.LastIndexOf("/") != forumPath.IndexOf("/"))
            {
                forumPath = forumPath.Substring(forumPath.IndexOf("/"), forumPath.LastIndexOf("/") + 1);
            }
            else
            {
                forumPath = "/";
            }
            return forumPath;

        }

        /// <summary>
        /// 获得当前页面的名称
        /// </summary>
        public static string GetPageName(string url)
        {
            url = ParseFile.ConvertPath(url.Split('?')[0]);
            return url.Split('/').Last();
        }

        /// <summary>
        /// 获取参数
        /// </summary>
        public static string GetParms(string url)
        {
            if (string.IsNullOrEmpty(url)) { return string.Empty; }

            string[] parms = url.Split('?');
            if (parms.Length == 1) { return ""; }
            url = url.ClearString(parms[0]);

            if (url.StartsWith("?")) { url = url.Substring(1); }

            //清除重复的参数
            parms = url.Split('&');
            List<string> lstParms = new List<string>();
            for (int i = 0; i < parms.Length; i++)
            {
                if (!lstParms.Exists(o => (o + "=").StartsWith(parms[i].SubString("="))))
                { lstParms.Add(parms[i]); }
            }

            return lstParms.ToString("&");
        }

        /// <summary>
        /// 参数编码
        /// </summary>
        public static string ParmsEncode(string parms)
        {
            List<string> lstParms = new List<string>();
            int index;
            foreach (string strs in parms.Split('&'))
            {
                index = strs.IndexOf('=');
                if (index > -1)
                { lstParms.Add(ParseString.SubString(strs, 0, index + 1) + UrlEncode(ParseString.SubString(strs, index + 1, -1))); }

            }
            return ParseList.ToString(lstParms, "&");
        }
    }
}
