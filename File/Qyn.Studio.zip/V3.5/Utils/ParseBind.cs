﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Qyn.Studio.Controls;
using System.Xml.Linq;
using Qyn.Studio.Base;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 绑定
    /// </summary>
    public class ParseBind
    {
        /// <summary>
        /// 枚举转ListItem
        /// </summary>
        private static List<ListItem> GetEnumList(Type enumType)
        {
            List<ListItem> lst = new List<ListItem>();

            foreach (KeyValuePair<int, string> dic in ParseEnum.GetList(enumType))
            {
                ListItem listitem = new ListItem(dic.Value, dic.Key.ToString());
                lst.Add(listitem);
            }

            return lst;
        }

        #region WebForm
        /// <summary>
        /// WebControl插入第一行提示显示项
        /// </summary>
        private static void WebControlInsertItems(ListItemCollection listItem, string defShowText, object defShowValue)
        {
            if (!string.IsNullOrEmpty(defShowText) || !string.IsNullOrEmpty(defShowValue.ToString()))
            {
                listItem.Insert(0, new ListItem() { Text = defShowText, Value = defShowValue.ToString() });
            }
        }

        /// <summary>
        /// WebControl选则指定项
        /// </summary>
        public static void WebControlSelectedItem(System.Web.UI.WebControls.ListControl control, object selectedValue)
        {
            string selValue = string.Empty;

            if (selectedValue is Enum) { selValue = Convert.ToString((int)selectedValue); }

            else { selValue = selectedValue == null ? string.Empty : selectedValue.ToString(); }

            if (control.Items.FindByValue(selValue) != null)
            {
                control.ClearSelection();
                control.Items.FindByValue(selValue).Selected = true;
            }
        }

        #region Repeater

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">System.Web.UI.WebControls.Repeater</param>
        /// <param name="type">枚举</param>
        public static void Repeater(System.Web.UI.WebControls.Repeater rpt, Type type)
        {
            rpt.DataSource = ParseEnum.GetList(type);
            rpt.DataBind();
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">System.Web.UI.WebControls.Repeater</param>
        /// <param name="Info">List列表</param>
        public static void Repeater(System.Web.UI.WebControls.Repeater rpt, IEnumerable Info)
        {
            rpt.DataSource = Info;
            rpt.DataBind();
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">Repeater</param>
        /// <param name="paginationControl">分页控件：Qyn.Studio.Controls.Pagination</param>
        /// <param name="recordCount">记录总数</param>
        /// <param name="Info">IEnumerable</param>
        public static void Repeater(System.Web.UI.WebControls.Repeater rpt, Pagination paginationControl, IEnumerable Info, int recordCount)
        {
            rpt.DataSource = Info;
            rpt.DataBind();

            paginationControl.PageCount = recordCount;
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        public static void Repeater(Qyn.Studio.Controls.Repeater rpt, IEnumerable Info)
        {
            rpt.DataSource = Info;
            rpt.DataBind();
        }

        /// <summary>
        /// IEnumerable绑定到Repeater
        /// </summary>
        /// <param name="rpt">Qyn.Studio.Controls.Repeater</param>
        /// <param name="recordCount">记录总数</param>
        /// <param name="Info">IEnumerable</param>
        public static void Repeater(Qyn.Studio.Controls.Repeater rpt, IEnumerable Info, int recordCount)
        {
            rpt.DataSource = Info;
            rpt.DataBind();

            rpt.PageCount = recordCount;
        }
        #endregion

        #region WebControl
        /// <summary>
        /// string[]绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="strs">源数据</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, string[] strs)
        {
            if (strs == null) { return; }
            foreach (string str in strs) { control.Items.Add(str); }
        }

        /// <summary>
        /// string[]绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="strs">源数据</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, string[] strs, object selectedValue)
        {
            if (strs == null) { return; }
            foreach (string str in strs) { control.Items.Add(str); }

            WebControlSelectedItem(control, selectedValue);
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info)
        {
            WebControl(control, Info, "Caption", "ID");
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="dataTextField">绑定的文本字段</param>
        /// <param name="dataValueField">绑定的值字段</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, string dataTextField, string dataValueField)
        {
            control.DataSource = Info;
            control.DataTextField = dataTextField;
            control.DataValueField = dataValueField;
            control.DataBind();
            if (control.Items.Count > 0) { control.SelectedIndex = 0; }
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="dataTextField">绑定的文本字段</param>
        /// <param name="dataValueField">绑定的值字段</param>
        /// <param name="defShowText">第一行显示的文字</param>
        /// <param name="defShowValue">第一行显示的值</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, string dataTextField, string dataValueField, string defShowText, object defShowValue, object selectedValue)
        {
            WebControl(control, Info, dataTextField, dataValueField);
            WebControlInsertItems(control.Items, defShowText, defShowValue);
            WebControlSelectedItem(control, selectedValue);
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, object selectedValue)
        {
            WebControl(control, Info, "Caption", "ID", "", "", selectedValue);
        }

        /// <summary>
        /// IEnumerable绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="Info">源数据</param>
        /// <param name="dataTextField">绑定的文本字段</param>
        /// <param name="dataValueField">绑定的值字段</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, IEnumerable Info, string dataTextField, string dataValueField, object selectedValue)
        {
            WebControl(control, Info, dataTextField, dataValueField, "", "", selectedValue);
        }

        /// <summary>
        /// Eume绑定到WebControl
        /// </summary>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, Type type)
        {
            control.DataSource = GetEnumList(type);
            control.DataValueField = "Value";
            control.DataTextField = "Text";
            control.DataBind();
            if (control.Items.Count > 0) { control.SelectedIndex = 0; }

        }

        /// <summary>
        /// Eume绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="type">枚举的Type</param>
        /// <param name="defShowText">第一行要显示的文字</param>
        /// <param name="defShowValue">第一行要显示的值</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, Type type, string defShowText, object defShowValue, object selectedValue)
        {
            WebControl(control, type);
            WebControlInsertItems(control.Items, defShowText, defShowValue);
            WebControlSelectedItem(control, selectedValue);
        }

        /// <summary>
        /// Eume绑定到WebControl
        /// </summary>
        /// <param name="control">要绑定的ddl</param>
        /// <param name="type">枚举的Type</param>
        /// <param name="selectedValue">默认选择值</param>
        public static void WebControl(System.Web.UI.WebControls.ListControl control, Type type, object selectedValue)
        {
            WebControl(control, type);
            WebControlSelectedItem(control, selectedValue);
        }

        /// <summary>
        /// 将Enum（位运算）的值，绑定到CheckBoxList中。
        /// </summary>
        /// <param name="control">CheckBoxList</param>
        /// <param name="type">枚举的Type</param>
        /// <param name="enumValue">枚举值</param>
        public static void WebControl(System.Web.UI.WebControls.CheckBoxList control, Type type, int enumValue)
        {
            WebControl(control, type);
            control.ClearSelection();

            foreach (ListItem item in control.Items)
            {
                int value = item.Value.ConvertType<int>();
                if ((enumValue & value) == value) { item.Selected = true; }
            }
        }

        /// <summary>
        /// 绑定到DropDownList
        /// </summary>
        /// <param name="ddl">要绑定的ddl控件</param>
        /// <param name="lstInfo">要进行绑定的列表</param>
        /// <param name="selectedValue">默认选则值</param>
        /// <param name="RemoveID">不加载的节点（包括子节点）</param>
        public static void CateFor(DropDownList ddl, List<BaseCateInfo> lstInfo, int selectedValue, int RemoveID)
        {
            ddl.Items.Clear();

            CateFor(ddl, lstInfo, 0, 0, RemoveID);

            if (selectedValue > 0) { ParseBind.WebControlSelectedItem(ddl, selectedValue); }
        }

        /// <summary>
        /// 递归绑定
        /// </summary>
        private static void CateFor(DropDownList ddl, List<BaseCateInfo> lstInfo, int parentID, int tagNum, int RemoveID)
        {
            if (lstInfo == null || lstInfo.Count == 0) { return; }

            List<BaseCateInfo> lstBaseCateInfo = lstInfo.FindAll(o => o.ParentID == parentID); if (lstInfo == null || lstInfo.Count == 0) { return; }

            foreach (BaseCateInfo info in lstBaseCateInfo)
            {
                if (info.ID == RemoveID) { continue; }
                ddl.Items.Add(new ListItem() { Value = info.ID.ToString(), Text = ParseString.FillTag(tagNum, "　") + "├─" + info.Caption });
                CateFor(ddl, lstInfo, info.ID, tagNum + 1, RemoveID);
            }
        }

        #endregion

        #endregion

        #region WinForm

        /// <summary>
        /// WinForm绑定
        /// </summary>
        /// <param name="control">控件</param>
        /// <param name="lst">List列表</param>
        /// <param name="displayMember">显示名称</param>
        /// <param name="valueMember">值</param>
        public static void WinControl(System.Windows.Forms.ListControl control, IEnumerable lst, string displayMember, string valueMember)
        {
            control.DisplayMember = displayMember;
            control.ValueMember = valueMember;

            control.DataSource = lst;
        }

        /// <summary>
        /// WinForm绑定
        /// </summary>
        /// <param name="control">控件</param>
        /// <param name="type">枚举类型</param>
        public static void WinControl(System.Windows.Forms.ListControl control, Type type)
        {
            control.DataSource = GetEnumList(type);
            control.ValueMember = "Value";
            control.DisplayMember = "Text";
        }

        /// <summary>
        /// WinForm绑定
        /// </summary>
        /// <param name="control">控件</param>
        /// <param name="type">枚举类型</param>
        public static void WinControl(System.Windows.Forms.DataGridViewComboBoxColumn control, Type type)
        {
            control.DataSource = GetEnumList(type);
            control.ValueMember = "Value";
            control.DisplayMember = "Text";
        }
        #endregion
    }
}
