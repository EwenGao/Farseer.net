﻿using System;
using System.Drawing;
using System.Text.RegularExpressions;
namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 颜色工具
    /// </summary>
    public class ParseColor
    {
        /// <summary>
        /// 隔行变色
        /// </summary>
        /// <param name="number">当前行数的数量</param>
        /// <param name="strColor1">单数行颜色</param>
        /// <param name="strColor2">双数行颜色</param>
        /// <returns>返回其中一个颜色</returns>
        public static string GetColor(int number, string strColor1, string strColor2)
        {
            return number % 2 == 0?strColor1:strColor2;
        }


        /// <summary>
        /// 将字符串转换为Color
        /// </summary>
        /// <param name="color"></param>
        /// <returns></returns>
        public static Color ToColor(string color)
        {
            int red, green, blue = 0;
            char[] rgb;
            color = color.TrimStart('#');
            color = Regex.Replace(color.ToLower(), "[g-zG-Z]", "");
            switch (color.Length)
            {
                case 3:
                    rgb = color.ToCharArray();
                    red = Convert.ToInt32(rgb[0].ToString() + rgb[0].ToString(), 16);
                    green = Convert.ToInt32(rgb[1].ToString() + rgb[1].ToString(), 16);
                    blue = Convert.ToInt32(rgb[2].ToString() + rgb[2].ToString(), 16);
                    return Color.FromArgb(red, green, blue);
                case 6:
                    rgb = color.ToCharArray();
                    red = Convert.ToInt32(rgb[0].ToString() + rgb[1].ToString(), 16);
                    green = Convert.ToInt32(rgb[2].ToString() + rgb[3].ToString(), 16);
                    blue = Convert.ToInt32(rgb[4].ToString() + rgb[5].ToString(), 16);
                    return Color.FromArgb(red, green, blue);
                default:
                    return Color.FromName(color);

            }
        }

    }
}
