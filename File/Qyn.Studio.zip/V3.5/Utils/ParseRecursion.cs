﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Qyn.Studio.Base;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 递归
    /// </summary>
    public class ParseRecursion
    {
        /// <summary>
        /// 获取指定ParentID的ID列表
        /// </summary>
        /// <param name="lstBaseCateInfo">递归的实体类</param>
        /// <param name="isContainsSub">是否获取子节点</param>
        /// <param name="parentID"></param>
        public static List<int> GetSubIDList(List<BaseCateInfo> lstBaseCateInfo, int parentID, bool isContainsSub)
        {
            List<int> lst = new List<int>();
            foreach (int i in lstBaseCateInfo.FindAll(o => o.ParentID == parentID).Select(o => o.ID).ToList())
            {
                lst.Add(i);
                if (!isContainsSub) { continue; }
                lst.AddRange(GetSubIDList(lstBaseCateInfo, i, isContainsSub));
            }
            return lst;
        }

        /// <summary>
        /// 获取根节点ID
        /// </summary>
        /// <param name="ID">当前分类的ID</param>
        /// <param name="lstBaseCateInfo">递归的实体类</param>
        public static int GetFirstID(List<BaseCateInfo> lstBaseCateInfo, int ID)
        {
            int parentID = -1;
            BaseCateInfo info = lstBaseCateInfo.Find(o => o.ID == ID);
            if (info != null)
            {
                if (info.ParentID > 0)
                {
                    parentID = GetFirstID(lstBaseCateInfo, info.ParentID);
                }
                else { parentID = info.ID; }
            }
            return parentID;
        }

        /// <summary>
        /// 获取上一级ID
        /// </summary>
        /// <param name="ID">当前分类的ID</param>
        /// <param name="lstBaseCateInfo">递归的实体类</param>
        public static int GetParentID(List<BaseCateInfo> lstBaseCateInfo, int ID)
        {
            BaseCateInfo info = lstBaseCateInfo.Find(o => o.ID == ID);
            if (info != null) { return info.ParentID; }
            return 0;
        }

        /// <summary>
        /// 获取所有上级ID
        /// </summary>
        /// <param name="ID">当前分类的ID</param>
        /// <param name="lstBaseCateInfo">递归的实体类</param>
        public static List<int> GetParentIDList(List<BaseCateInfo> lstBaseCateInfo, int ID)
        {
            List<int> lst = new List<int>();
            BaseCateInfo info = lstBaseCateInfo.Find(o => o.ID == ID);
            if (info == null) { return lst; }

            lst.AddRange( GetParentIDList(lstBaseCateInfo, info.ParentID));

            return lst;
        }
    }
}
