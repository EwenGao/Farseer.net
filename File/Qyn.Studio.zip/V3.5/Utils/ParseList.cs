﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// List工具
    /// </summary>
    public class ParseList
    {
        /// <summary>
        /// 对List进行分页
        /// </summary>
        public static List<T> Pagination<T>(List<T> lst, int pageIndex, int pageSize)
        {
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            if (pageSize < 1)
            {
                pageSize = 1;
            }

            List<T> newList = new List<T>();
            int firstIndex;
            int endIndex;

            #region 计算 开始索引
            if (pageIndex == 1)
            {
                firstIndex = 0;
            }
            else
            {
                firstIndex = pageSize * (pageIndex - 1);
                //索引超出记录总数时，返回空的表格
                if (firstIndex > lst.Count)
                {
                    return newList;
                }
            }
            #endregion

            #region 计算 结束索引
            endIndex = pageSize + firstIndex;
            if (endIndex > lst.Count)
            {
                endIndex = lst.Count;
            }
            #endregion

            for (int i = firstIndex; i < endIndex; i++)
            {
                newList.Add(lst[i]);
            }
            return newList;
        }

        /// <summary>
        /// 对List进行分页
        /// </summary>
        public static List<T> Pagination<T>(List<T> lst, Qyn.Studio.Controls.Repeater rpt) { rpt.PageCount = lst.Count; return Pagination(lst, rpt.PageIndex, rpt.PageSize); }

        /// <summary>
        /// 将List转换成字符串
        /// </summary>
        /// <param name="lst">要拼接的LIST</param>
        /// <param name="sign">分隔符</param>
        /// <returns></returns>
        public static string ToString(IList lst,string sign)
        {
            string str = string.Empty;

            if (lst == null || lst.Count == 0) { return str; }

            for (int i = 0; i < lst.Count; i++)
            {
                str += lst[i].ToString() + sign;
            }
            return ParseString.DelEndOf(str,sign);
        }

        /// <summary>
        /// 自动填充到指定数量
        /// </summary>
        public static IList Fill(IList lst, int maxCount,object defValue)
        {
            while (true)
            {
                if (lst.Count >= maxCount) { break; }
                lst.Add(defValue);
            }

            return lst;
        }

        /// <summary>
        /// 将集合类转换成DataTable
        /// </summary>
        /// <param name="list">集合</param>
        /// <returns></returns>
        public static DataTable ToDataTable(IList list)
        {
            DataTable result = new DataTable();
            if (list.Count > 0)
            {
                PropertyInfo[] propertys = list[0].GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    result.Columns.Add(pi.Name, pi.PropertyType);
                }

                for (int i = 0; i < list.Count; i++)
                {
                    ArrayList tempList = new ArrayList();
                    foreach (PropertyInfo pi in propertys)
                    {
                        object obj = pi.GetValue(list[i], null);
                        tempList.Add(obj);
                    }
                    object[] array = tempList.ToArray();
                    result.LoadDataRow(array, true);
                }
            }
            return result;
        }

        ///// <summary>
        ///// 将泛型集合类转换成DataTable
        ///// </summary>
        ///// <typeparam name="T">集合项类型</typeparam>
        ///// <param name="list">集合</param>
        ///// <returns>数据集(表)</returns>
        //public static DataTable ToDataTable(IList list)
        //{
        //    return ToDataTable(list, null);
        //}

        /// <summary>
        /// 将泛型集合类转换成DataTable
        /// </summary>
        /// <param name="list">集合</param>
        /// <param name="propertyName">需要返回的列的列名</param>
        /// <returns>数据集(表)</returns>
        public static DataTable ToDataTable(IList list, params string[] propertyName)
        {
            List<string> propertyNameList = new List<string>();
            if (propertyName != null)
                propertyNameList.AddRange(propertyName);

            DataTable result = new DataTable();
            if (list.Count > 0)
            {
                PropertyInfo[] propertys = list[0].GetType().GetProperties();
                foreach (PropertyInfo pi in propertys)
                {
                    if (propertyNameList.Count == 0)
                    {
                        result.Columns.Add(pi.Name, pi.PropertyType);
                    }
                    else
                    {
                        if (propertyNameList.Contains(pi.Name))
                            result.Columns.Add(pi.Name, pi.PropertyType);
                    }
                }

                for (int i = 0; i < list.Count; i++)
                {
                    ArrayList tempList = new ArrayList();
                    foreach (PropertyInfo pi in propertys)
                    {
                        if (propertyNameList.Count == 0)
                        {
                            object obj = pi.GetValue(list[i], null);
                            tempList.Add(obj);
                        }
                        else
                        {
                            if (propertyNameList.Contains(pi.Name))
                            {
                                object obj = pi.GetValue(list[i], null);
                                tempList.Add(obj);
                            }
                        }
                    }
                    object[] array = tempList.ToArray();
                    result.LoadDataRow(array, true);
                }
            }
            return result;
        }

        /// <summary>
        /// 将List进行转换
        /// </summary>
        /// <typeparam name="T">要转换的类型</typeparam>
        /// <param name="list"></param>
        /// <returns></returns>
        public static List<T> ToList<T>(IList list)
        {
            List<T> lst = new List<T>();
            foreach (var item in list)
            {
                lst.Add((T)item);
            }
            return lst;
        }
    }
}
