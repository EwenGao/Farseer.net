﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Qyn.Studio.Configs;
using System.Web.UI.WebControls;
using Qyn.Studio.Extend;

namespace Qyn.Studio.Utils
{
    /// <summary>
    /// 枚举
    /// </summary>
    public class ParseEnum
    {
        /// <summary>
        /// 缓存列表
        /// </summary>
        public static Dictionary<string, string> dicEnum = new Dictionary<string, string>();

        ///   <summary>   
        ///   获取枚举值的详细文本   
        ///   </summary>    
        public static string GetDescription(Type enumType, string enumName)
        {
            string key = string.Format("{0}.{1}", enumType.Name, enumName);

            //调试状态，不使用缓存
            if (GeneralConfigs.ConfigInfo.DeBug) { dicEnum.Clear(); }
            if (dicEnum.ContainsKey(key)) { return dicEnum[key]; }

            foreach (FieldInfo fieldInfo in enumType.GetFields())
            {
                //判断名称是否相等   
                if (fieldInfo.Name != enumName) continue;

                //反射出自定义属性   
                foreach (Attribute attr in fieldInfo.GetCustomAttributes(true))
                {
                    //类型转换找到一个Description，用Description作为成员名称   
                    System.ComponentModel.DescriptionAttribute dscript = attr as System.ComponentModel.DescriptionAttribute;
                    if (dscript != null)
                    {
                        dicEnum.Add(key, dscript.Description);
                        return dscript.Description;
                    }
                }

            }

            //如果没有检测到合适的注释，则用默认名称   
            return enumName;
        }

        /// <summary>
        /// 获取枚举列表
        /// </summary>
        public static Dictionary<int, string> GetList(Type enumType)
        {
            Dictionary<int, string> dic = new Dictionary<int, string>();
            foreach (int value in Enum.GetValues(enumType))
            {
                dic.Add(value, GetDescription(enumType, Enum.GetName(enumType, value)));
            }
            return dic;
        }

        /// <summary>
        /// 获取CheckBoxList中，选中后的枚举值
        /// </summary>
        /// <param name="control">CheckBoxList</param>
        /// <returns></returns>
        public static int GetCheckBoxListValue(CheckBoxList control)
        {
            int enumValue = 0;

            foreach (ListItem item in control.Items)
            {
                if (item.Selected) { enumValue |= item.Value.ConvertType<int>(); }
            }
            return enumValue;
        }
    }
}
