﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// 继承IComparer接口，实现同一自定义类型　对象比较
    /// </summary>
    /// <typeparam name="T">T为泛用类型</typeparam>
    public class Reverser<T> : IComparer<T>
    {
        private Type type = null;
        private ReverserInfo info;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="type">进行比较的类类型</param>
        /// <param name="name">进行比较对象的属性名称</param>
        /// <param name="direction">比较方向(升序/降序)</param>
        public Reverser(Type type, string name, ReverserInfo.eumDirectionType direction)
        {
            this.type = type;
            this.info.Name = name;
            if (direction != ReverserInfo.eumDirectionType.ASC) { this.info.DirectionType = direction; }
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="className">进行比较的类名称</param>
        /// <param name="name">进行比较对象的属性名称</param>
        /// <param name="direction">比较方向(升序/降序)</param>
        public Reverser(string className, string name, ReverserInfo.eumDirectionType direction)
        {
            try
            {
                this.type = Type.GetType(className, true);
                this.info.Name = name;
                this.info.DirectionType = direction;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="t">进行比较的类型的实例</param>
        /// <param name="name">进行比较对象的属性名称</param>
        /// <param name="direction">比较方向(升序/降序)</param>
        public Reverser(T t, string name, ReverserInfo.eumDirectionType direction)
        {
            this.type = t.GetType();
            this.info.Name = name;
            this.info.DirectionType = direction;
        }

        //必须！实现IComparer<T>的比较方法。
        int IComparer<T>.Compare(T t1, T t2)
        {
            object x = this.type.InvokeMember(this.info.Name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty, null, t1, null);
            object y = this.type.InvokeMember(this.info.Name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty, null, t2, null);
            if (this.info.DirectionType != ReverserInfo.eumDirectionType.ASC)
                Swap(ref x, ref y);
            return (new CaseInsensitiveComparer()).Compare(x, y);
        }

        //交换操作数
        private void Swap(ref object x, ref object y)
        {
            object temp = null;
            temp = x;
            x = y;
            y = temp;
        }
    }

    /// <summary>
    /// 对象比较时使用的信息类
    /// </summary>
    public struct ReverserInfo
    {
        /**/
        /// <summary>
        /// 比较的方向，如下：
        /// ASC：升序
        /// DESC：降序
        /// </summary>
        public enum eumDirectionType:byte
        {
            /// <summary>
            /// 升序
            /// </summary>
            ASC = 0,
            /// <summary>
            /// 降序
            /// </summary>
            DESC,
        };

        /// <summary>
        /// 要反映序的字段名称
        /// </summary>
        public string Name;
        /// <summary>
        /// 排序方式
        /// </summary>
        public eumDirectionType DirectionType;

        //public enum Target : byte
        //{
        //    CUSTOMER = 0,
        //    FORM,
        //    FIELD,
        //    SERVER,
        //};
        //public Target target;
    }
}
