﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;

namespace Qyn.Studio.Tools
{
    /// <summary>
    /// 上传文件
    /// </summary>
    public class UpLoadFile
    {

        /// <summary>
        /// 上传文件的权限
        /// </summary>
        public struct stuUpLoadFileType
        {
            /// <summary>
            /// 允许上传的类型
            /// </summary>
            public string type;
            /// <summary>
            /// 允许上传的容量(单位：KB. 0：无限制)
            /// </summary>
            public int size;
        }

        /// <summary>
        /// 上传文件后回发的资料
        /// </summary>
        public struct stuUpLoadFile
        {
            /// <summary>
            /// 上传成功的文件名
            /// </summary>
            public string FileName { get; set; }
            /// <summary>
            /// 上传成功的文件名-前缀
            /// </summary>
            public string FileNamePrefix { get; set; }
            /// <summary>
            /// 上传成功的文件名-扩展名
            /// </summary>
            public string FileNameExtension { get; set; }
            /// <summary>
            /// 上传成功的文件容量(单位：KB)
            /// </summary>
            public int Size { get; set; }
            /// <summary>
            /// 上传成功的文件相对路径(WebPath之后的路径,不带文件名)
            /// </summary>
            public string FilePath { get; set; }
            /// <summary>
            /// 上传成功的文件物理路径(不带文件名)
            /// </summary>
            public string FileMapPath { get; set; }
            /// <summary>
            /// 错误消息
            /// </summary>
            public string ErrorMessage { get; set; }
        }

        /// <summary>
        /// 保存方式
        /// </summary>
        public enum SaveType
        {
            /// <summary>
            /// 按日期时间
            /// </summary>
            DateTimeNow = 0,
            /// <summary>
            /// 按原文件名
            /// </summary>
            FileName = 1
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public List<stuUpLoadFile> Upload(HttpFileCollection files, string filePath, SaveType saveType)
        {
            return Upload(files, filePath, saveType, null);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="lstFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public List<stuUpLoadFile> Upload(HttpFileCollection files, string filePath, SaveType saveType, List<stuUpLoadFileType> lstFileType)
        {
            List<stuUpLoadFile> lstUpLoadFile = new List<stuUpLoadFile>();
            stuUpLoadFile upLoadFile;

            foreach (HttpPostedFile file in files)
            {
                //有文件上传时，才检测安全性
                if (!string.IsNullOrEmpty(file.FileName) && file.ContentLength > 0)
                {
                    upLoadFile = Upload(file, filePath, saveType, lstFileType);
                    if (!string.IsNullOrEmpty(upLoadFile.FileName) && upLoadFile.Size > 0 && string.IsNullOrEmpty(upLoadFile.FileMapPath))
                    {
                        lstUpLoadFile.Add(upLoadFile);
                    }
                }
            }

            return lstUpLoadFile;
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="file">获取要上传的文件</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public stuUpLoadFile Upload(HttpPostedFile file, string filePath, SaveType saveType)
        {
            return Upload(file, filePath, saveType, null);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="file">FileUpload</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="lstFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public stuUpLoadFile Upload(HttpPostedFile file, string filePath, SaveType saveType, List<stuUpLoadFileType> lstFileType)
        {
            string fileName;                                                                //获取文件名全称
            string fileNamePrefix;                                                          //获取文件名前缀
            string fileNameExtension;                                                       //获取文件名后缀
            string fileMapPath;                                                             //获取目录绝对路径
            stuUpLoadFile  uploadFile = new stuUpLoadFile();

            uploadFile.ErrorMessage = string.Empty;                                                    //清空错训提示信息

            filePath = ParseFile.ConvertPath(filePath);

            //判断根目录,保存目录是否为空
            if (string.IsNullOrEmpty(filePath)) { uploadFile.ErrorMessage = "保存路径没有填写,请联系管理员!"; return uploadFile; }

            //有文件上传时，才检测安全性
            if (!string.IsNullOrEmpty(file.FileName))// && file.ContentLength > 0
            {
                if (!CheckFile(file, lstFileType,ref uploadFile)) { return uploadFile; }
            }
            else { uploadFile.ErrorMessage = "未检测到文件上传!"; return uploadFile; }

            #region 上传文件操作
           
            try
            {
                fileName = file.FileName.ToLower().Trim();                                             //获取文件名全称
                fileNamePrefix = Path.GetFileNameWithoutExtension(fileName);                          //获取文件名前缀
                fileNameExtension = ParseFile.GetExtension(fileName);                                                     //获取后缀名

                //文件为空或者大小为0，直接跳过
                if (string.IsNullOrEmpty(file.FileName) || file.ContentLength == 0) { return uploadFile;  }

                //获取保存为的文件名
                switch (saveType)
                {
                    case SaveType.DateTimeNow:
                        {
                            fileName = string.Format("{0}.{1}", ParseDateTime.GetDateTimePath(), fileNameExtension);
                            break;
                        }
                    case SaveType.FileName:
                        {
                            fileName = file.FileName;
                            break;
                        }
                }

                #region 创建文件目录(任何级别目录)
                fileMapPath = Utils.ParseUrl.GetMapPath(filePath);
                ParseFile.CreateDirs(Path.Combine(fileMapPath, fileName).DelEndOf("/"));
                #endregion

                file.SaveAs(Path.Combine(fileMapPath, fileName).DelEndOf("/"));
                uploadFile.FileName = fileName;
                uploadFile.FileNamePrefix = fileNamePrefix;
                uploadFile.FileNameExtension = fileNameExtension;
                uploadFile.Size = (file.ContentLength > 1024) ? file.ContentLength / 1024 : 1;
                uploadFile.FilePath = filePath;
                uploadFile.FileMapPath = fileMapPath;
            }

            catch (Exception Ex)
            {
                uploadFile.ErrorMessage = Ex.Message.ToString();
                return uploadFile;
            }
            #endregion

            return uploadFile;
        }

        /// <summary>
        /// 检查每个文件的合法检验
        /// </summary>
        private bool CheckFile(HttpPostedFile file, List<stuUpLoadFileType> lstFileType, ref stuUpLoadFile uploadFile)
        {
            //获取文件名前缀
            string fileNamePrefix = Path.GetFileNameWithoutExtension(file.FileName);
            //获取文件名后缀
            string fileNameExtension = ParseFile.GetExtension(file.FileName);
            //文件容量
            int fileContentLength = file.ContentLength / 1024;

            if (string.IsNullOrEmpty(file.FileName)) { uploadFile.ErrorMessage = "文件的名称不能为空"; return false; }
            if (string.IsNullOrEmpty(fileNamePrefix)) { uploadFile.ErrorMessage = "文件: [ " + file.FileName + " ] 前缀名不能为空"; return false; }
            if (file.ContentLength > 0 && fileContentLength == 0) { fileContentLength = 1; }
            if (fileContentLength <= 0) { uploadFile.ErrorMessage = "文件: [ " + file.FileName + " ] 的大小不能为0KB"; return false; }

            //循环文件类型,长度
            if (lstFileType != null && lstFileType.Count > 0)
            {
                //true表示属于允许上传的类型
                bool isfileExtension = false;
                foreach (stuUpLoadFileType fileType in lstFileType)
                {
                    //判断文件类型,长度是否允许上传
                    if (string.Compare(fileNameExtension, fileType.type, true) != 0) { continue; }
                    isfileExtension = true;

                    //判断文件容量是否超过上限
                    if (fileType.size != 0 && fileContentLength > fileType.size) { uploadFile.ErrorMessage = string.Format("文件类型为 [ {0} ] 的容量不能超过: [ {1} KB ]", fileType.type, fileType.size); return false; }
                    break;
                }

                if (!isfileExtension) { uploadFile.ErrorMessage = string.Format("文件扩展名: [ {0} ] 不允许上传", fileNameExtension); return false; }
            }
            return true;
        }
    }
}