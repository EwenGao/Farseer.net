﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace Qyn.Studio.Tools
//{
//    public class IIS
//    {
//        public static void AppPool(string ppPoolName, eumMethodType methodType)
//        {
//            string AppPoolName = ppPoolName;
//            string method = methodType.ToString();
                
//            try
//            {                
//                DirectoryEntry appPool = new DirectoryEntry("IIS://localhost/W3SVC/AppPools");
//                DirectoryEntry findPool = appPool.Children.Find(AppPoolName, "IIsApplicationPool");
//                findPool.Invoke(method, null);
//                appPool.CommitChanges();
//                appPool.Close();
//            }
//            catch (Exception ex)
//            {
//                lbMsg.Text = string.Format("应用程序池{0}{2}失败:{1}", AppPoolName, ex.Message, method);
//            }
//        }

//        /// <summary>
//        /// 控制程序池方式
//        /// </summary>
//        public enum eumMethodType : byte
//        {
//            /// <summary>
//            /// 启动
//            /// </summary>
//            Start,
//            /// <summary>
//            /// 停止
//            /// </summary>
//            Stop,
//            /// <summary>
//            /// 回收
//            /// </summary>
//            Recycle
//        }
//    }
//}
