﻿using System;
using Qyn.Studio.Base;
using Qyn.Studio.Configs;

namespace Qyn.Studio.Combo.Admin
{
    /// <summary>
    /// 管理员套餐
    /// </summary>
    public class AdminComboProvider : BaseProvider<AdminComboInfo>
    {
        /// <summary>
        /// 管理员套餐数据库访问类
        /// </summary>
        public AdminComboProvider() : base(DbConfigs.ConfigInfo.DataBaseList[AdminComboConfigs.ConfigInfo.DbIndex]) { }
    }
}
