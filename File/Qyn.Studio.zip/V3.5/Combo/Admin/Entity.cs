﻿using System.ComponentModel;
using System.Data;
using Qyn.Studio.Base;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using System;

namespace Qyn.Studio.Combo.Admin
{
    /// <summary>
    /// 管理员实体类
    /// </summary>
    [AdminAttribute()]
    public class AdminComboInfo : BaseInfo
    {
        /// <summary>
        /// 管理员称
        /// </summary>
        [AdminNameAttribute()]
        public string AdminName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [PassWordAttribute()]
        public string PassWord { get; set; }

        /// <summary>
        /// 登陆状态
        /// </summary>
        public enum eumLoginType : byte
        {
            /// <summary>
            /// 管理员不能为空！
            /// </summary>
            [Description("管理员不能为空！")]
            IsEmptyAdminName,
            /// <summary>
            /// 密码不能为空！
            /// </summary>
            [Description("密码不能为空！")]
            IsEmptyPassWord,
            /// <summary>
            /// 验证码不能为空！
            /// </summary>
            [Description("验证码不能为空！")]
            IsEmptyVerifyCode,
            /// <summary>
            /// 验证码有误！
            /// </summary>
            [Description("验证码有误！")]
            VerifyCodeError,
            /// <summary>
            /// 帐户异常
            /// </summary>
            [Description("帐户异常")]
            Abnormal,
            /// <summary>
            /// 管理员不存在
            /// </summary>
            [Description("管理员不存在")]
            AdminNameError,
            /// <summary>
            /// 密码错误
            /// </summary>
            [Description("密码错误")]
            PassWordError,
            /// <summary>
            /// 帐号已冻结
            /// </summary>
            [Description("帐号已冻结")]
            FrozenError,
            /// <summary>
            /// 成功
            /// </summary>
            [Description("成功")]
            Sucess

        }
    }

     /// <summary>
    /// 表名
    /// </summary>
    internal class AdminAttribute : ClassAttribute
    {
        /// <summary>
        /// 传入表名
        /// </summary>
        public AdminAttribute() : base(AdminComboConfigs.ConfigInfo.TableName) { }
    }

    /// <summary>
    /// 密码属性
    /// </summary>
    internal class PassWordAttribute : UsedNameAttribute
    {
        /// <summary>
        /// 传入密码字段
        /// </summary>
        public PassWordAttribute() : base(AdminComboConfigs.ConfigInfo.PassWord) { }
    }

    /// <summary>
    /// 管理员称属性
    /// </summary>
    internal class AdminNameAttribute : UsedNameAttribute
    {
        /// <summary>
        /// 传入帐号字段
        /// </summary>
        public AdminNameAttribute() : base(AdminComboConfigs.ConfigInfo.AdminName) { }
    }
}
