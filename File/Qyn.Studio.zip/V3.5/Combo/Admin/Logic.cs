﻿using Qyn.Studio.Base;
using Qyn.Studio.Configs;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Tools;
using System.Web;
using System.Collections.Generic;

namespace Qyn.Studio.Combo.Admin
{
    /// <summary>
    /// 管理员套餐
    /// </summary>
    public class AdminComboLogic : BaseLogic<AdminComboInfo, AdminComboProvider>
    {
        /// <summary>
        /// 管理员登陆操作(带验证码判断)
        /// </summary>
        /// <param name="adminName">管理员</param>
        /// <param name="passWord">密码</param>
        /// <param name="code">验证码，使用ParseSession.Get(SystemConfig.AdminID)</param>
        public static AdminComboInfo.eumLoginType Login(string adminName, string passWord, string code)
        {
            if (string.IsNullOrEmpty(code)) { return AdminComboInfo.eumLoginType.IsEmptyVerifyCode; }

            string verifyCode = ParseSession.Get(SystemConfig.AdminVerifyCode);
            ParseSession.Set(SystemConfig.AdminVerifyCode,ParseRandom.GetRandom(10000,99999));
            if (!code.IsEquals(verifyCode)) { return AdminComboInfo.eumLoginType.VerifyCodeError; }

            return Login(adminName, passWord);
        }

        /// <summary>
        /// 管理员登陆操作
        /// </summary>
        /// <param name="adminName">管理员</param>
        /// <param name="passWord">密码</param>
        public static AdminComboInfo.eumLoginType Login(string adminName, string passWord)
        {
            if (string.IsNullOrEmpty(adminName)) { return AdminComboInfo.eumLoginType.IsEmptyAdminName; }
            if (string.IsNullOrEmpty(passWord)) { return AdminComboInfo.eumLoginType.IsEmptyPassWord; }

            AdminComboInfo info = GetInfo(AdminComboConfigs.ConfigInfo.AdminName, adminName);
            if (info == null) { return AdminComboInfo.eumLoginType.AdminNameError; }
            if (!info.PassWord.Equals(passWord)) { return AdminComboInfo.eumLoginType.PassWordError; }
            WriteCookies(info);
            return AdminComboInfo.eumLoginType.Sucess;
        }

        /// <summary>
        /// 获取登陆信息
        /// </summary>
        public static AdminComboInfo GetCookies()
        {
            AdminComboInfo info = new AdminComboInfo();

            if (GeneralConfigs.ConfigInfo.DeBug)
            {
                info.ID = 9999999;
                info.AdminName = "系统调试员";
            }
            else
            {
                info.ID = ParseCookies.Get(SystemConfig.AdminID, 0);
                info.AdminName = ParseCookies.Get(SystemConfig.AdminName, "游客");
                WriteCookies(info);
            }
            return info;
        }

        /// <summary>
        /// 写入登陆信息
        /// </summary>
        public static void WriteCookies(AdminComboInfo info)
        {
            if (info == null) { info = new AdminComboInfo() { ID = -1 }; }

            ParseCookies.Set(SystemConfig.AdminID, info.ID);
            ParseCookies.Set(SystemConfig.AdminName, info.AdminName);
        }

        /// <summary>
        /// 判断登陆状态
        /// </summary>
        public static bool IsLogin()
        {
            AdminComboInfo adminInfo = GetCookies();

            if (adminInfo != null && adminInfo.ID > 0 && !adminInfo.AdminName.IsNullOrEmpty()) { return true; }

            return false;
        }

        /// <summary>
        /// 检测登陆
        /// </summary>
        public static void CheckLogin()
        {
            //登陆页面时,不检测登陆状态!
            if ((QynRequest.GetPath() + QynRequest.GetPageName()).IsEquals(GeneralConfigs.ConfigInfo.AdminLoginUrl))
            {
                if (IsLogin()) { HttpContext.Current.Response.Redirect(QynRequest.GetPath()); return; }
            }
            else if (!IsLogin()) { HttpContext.Current.Response.Redirect(GeneralConfigs.ConfigInfo.AdminLoginUrl); return; }
        }
    }
}
