﻿using Qyn.Studio.Configs;

namespace Qyn.Studio.Combo.Admin
{
    /// <summary>
    /// 管理员套餐配置工具
    /// </summary>
    public class AdminComboConfigs : BaseConfigs<AdminComboConfig> { }

    /// <summary>
    /// 管理员套餐配置
    /// </summary>
    public class AdminComboConfig
    {
        /// <summary>
        /// ID字段
        /// </summary>
        public string ID = "ID";
        /// <summary>
        /// 管理员字段
        /// </summary>
        public string AdminName = "AdminName";
        /// <summary>
        /// 密码字段
        /// </summary>
        public string PassWord = "PassWord";
        /// <summary>
        /// 表名
        /// </summary>
        public string TableName = "Admin";
        /// <summary>
        /// 数据库配置索引
        /// </summary>
        public int DbIndex = 0;
    }
}
