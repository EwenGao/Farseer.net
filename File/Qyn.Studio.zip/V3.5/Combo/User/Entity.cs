﻿using System.ComponentModel;
using System.Data;
using Qyn.Studio.Base;
using Qyn.Studio.Extend;
using Qyn.Studio.ORM;
using System;

namespace Qyn.Studio.Combo.User
{
    /// <summary>
    /// 用户实体类
    /// </summary>
    [UserAttribute()]
    public class UserComboInfo : BaseInfo
    {
        /// <summary>
        /// 用户称
        /// </summary>
        [UserNameAttribute()]
        public string UserName { get; set; }

        /// <summary>
        /// 密码
        /// </summary>
        [PassWordAttribute()]
        public string PassWord { get; set; }

        /// <summary>
        /// 登陆状态
        /// </summary>
        public enum eumLoginType : byte
        {
            /// <summary>
            /// 用户不能为空！
            /// </summary>
            [Description("用户不能为空！")]
            IsEmptyUserName,
            /// <summary>
            /// 密码不能为空！
            /// </summary>
            [Description("密码不能为空！")]
            IsEmptyPassWord,
            /// <summary>
            /// 验证码不能为空！
            /// </summary>
            [Description("验证码不能为空！")]
            IsEmptyVerifyCode,
            /// <summary>
            /// 验证码有误！
            /// </summary>
            [Description("验证码有误！")]
            VerifyCodeError,
            /// <summary>
            /// 帐户异常
            /// </summary>
            [Description("帐户异常")]
            Abnormal,
            /// <summary>
            /// 用户不存在
            /// </summary>
            [Description("用户不存在")]
            UserNameError,
            /// <summary>
            /// 密码错误
            /// </summary>
            [Description("密码错误")]
            PassWordError,
            /// <summary>
            /// 帐号已冻结
            /// </summary>
            [Description("帐号已冻结")]
            FrozenError,
            /// <summary>
            /// 成功
            /// </summary>
            [Description("成功")]
            Sucess

        }
    }

    /// <summary>
    /// 表名
    /// </summary>
    internal class UserAttribute : ClassAttribute
    {
        /// <summary>
        /// 传入表名
        /// </summary>
        public UserAttribute() : base(UserComboConfigs.ConfigInfo.TableName) { }
    }

    /// <summary>
    /// 密码属性
    /// </summary>
    internal class PassWordAttribute : UsedNameAttribute
    {
        /// <summary>
        /// 传入密码字段
        /// </summary>
        public PassWordAttribute() : base(UserComboConfigs.ConfigInfo.PassWord) { }
    }

    /// <summary>
    /// 用户称属性
    /// </summary>
    internal class UserNameAttribute : UsedNameAttribute
    {
        /// <summary>
        /// 传入帐号字段
        /// </summary>
        public UserNameAttribute() : base(UserComboConfigs.ConfigInfo.UserName) { }
    }
}
