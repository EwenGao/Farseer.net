﻿using Qyn.Studio.Configs;

namespace Qyn.Studio.Combo.User
{
    /// <summary>
    /// 用户套餐配置工具
    /// </summary>
    public class UserComboConfigs : BaseConfigs<UserComboConfig> { }

    /// <summary>
    /// 用户套餐配置
    /// </summary>
    public class UserComboConfig
    {
        /// <summary>
        /// ID字段
        /// </summary>
        public string ID = "ID";
        /// <summary>
        /// 用户字段
        /// </summary>
        public string UserName = "UserName";
        /// <summary>
        /// 密码字段
        /// </summary>
        public string PassWord = "PassWord";
        /// <summary>
        /// 表名
        /// </summary>
        public string TableName = "Members_Users";
        /// <summary>
        /// 数据库配置索引
        /// </summary>
        public int DbIndex = 0;
    }
}
