﻿using Qyn.Studio.Base;
using Qyn.Studio.Configs;
using Qyn.Studio.Extend;
using Qyn.Studio.Utils;
using Qyn.Studio.Tools;
using System.Web;
using System.Collections.Generic;

namespace Qyn.Studio.Combo.User
{
    /// <summary>
    /// 用户套餐
    /// </summary>
    public class UserComboLogic : BaseLogic<UserComboInfo, UserComboProvider>
    {
        /// <summary>
        /// 用户登陆操作(带验证码判断)
        /// </summary>
        /// <param name="UserName">用户</param>
        /// <param name="passWord">密码</param>
        /// <param name="code">验证码，使用ParseSession.Get(SystemConfig.UserID)</param>
        public static UserComboInfo.eumLoginType Login(string UserName, string passWord, string code)
        {
            if (string.IsNullOrEmpty(code)) { return UserComboInfo.eumLoginType.IsEmptyVerifyCode; }

            string verifyCode = ParseSession.Get(SystemConfig.UserVerifyCode);
            ParseSession.Set(SystemConfig.UserVerifyCode, ParseRandom.GetRandom(10000, 99999));

            if (!code.IsEquals(verifyCode)) { return UserComboInfo.eumLoginType.VerifyCodeError; }

            return Login(UserName, passWord);
        }

        /// <summary>
        /// 用户登陆操作
        /// </summary>
        /// <param name="UserName">用户</param>
        /// <param name="passWord">密码</param>
        public static UserComboInfo.eumLoginType Login(string UserName, string passWord)
        {
            if (string.IsNullOrEmpty(UserName)) { return UserComboInfo.eumLoginType.IsEmptyUserName; }
            if (string.IsNullOrEmpty(passWord)) { return UserComboInfo.eumLoginType.IsEmptyPassWord; }

            UserComboInfo info = GetInfo(UserComboConfigs.ConfigInfo.UserName, UserName);
            if (info == null) { return UserComboInfo.eumLoginType.UserNameError; }
            if (!info.PassWord.Equals(passWord)) { return UserComboInfo.eumLoginType.PassWordError; }
            WriteCookies(info);
            return UserComboInfo.eumLoginType.Sucess;
        }

        /// <summary>
        /// 获取登陆信息
        /// </summary>
        public static UserComboInfo GetCookies()
        {
            UserComboInfo info = new UserComboInfo();

            info.ID = ParseCookies.Get(SystemConfig.UserID, 0);
            info.UserName = ParseCookies.Get(SystemConfig.UserName, "游客");
            WriteCookies(info);

            return info;
        }

        /// <summary>
        /// 写入登陆信息
        /// </summary>
        public static void WriteCookies(UserComboInfo info)
        {
            if (info == null) { info = new UserComboInfo() { ID = -1 }; }

            ParseCookies.Set(SystemConfig.UserID, info.ID);
            ParseCookies.Set(SystemConfig.UserName, info.UserName);
        }

        /// <summary>
        /// 判断登陆状态
        /// </summary>
        public static bool IsLogin()
        {
            UserComboInfo UserInfo = GetCookies();

            if (UserInfo != null && UserInfo.ID > 0 && !UserInfo.UserName.IsNullOrEmpty()) { return true; }

            return false;
        }

        /// <summary>
        /// 检测登陆
        /// </summary>
        public static void CheckLogin()
        {
            //登陆页面时,不检测登陆状态!
            if ((QynRequest.GetPath() + QynRequest.GetPageName()).IsEquals(GeneralConfigs.ConfigInfo.WebLoginUrl))
            {
                if (IsLogin()) { HttpContext.Current.Response.Redirect(QynRequest.GetPath()); return; }
            }
            //else if (!IsLogin()) { HttpContext.Current.Response.Redirect(GeneralConfigs.ConfigInfo.WebLoginUrl); return; }
        }

        /// <summary>
        /// 判断用户名是否存在
        /// </summary>
        /// <param name="userName">用户名称</param>
        /// <returns></returns>
        public static bool IsExits(string userName)
        {
            return GetCount(UserComboConfigs.ConfigInfo.UserName, userName) > 0;
        }
    }
}
