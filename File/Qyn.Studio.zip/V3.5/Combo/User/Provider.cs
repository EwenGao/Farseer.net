﻿using System;
using Qyn.Studio.Base;
using Qyn.Studio.Configs;

namespace Qyn.Studio.Combo.User
{
    /// <summary>
    /// 用户套餐
    /// </summary>
    public class UserComboProvider : BaseProvider<UserComboInfo>
    {
        /// <summary>
        /// 用户套餐数据库访问类
        /// </summary>
        public UserComboProvider() : base(DbConfigs.ConfigInfo.DataBaseList[UserComboConfigs.ConfigInfo.DbIndex]) { }
    }
}
