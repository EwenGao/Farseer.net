﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Qyn.Data;
using System.Data;
using Qyn.Common.Utils;

namespace Qyn.Data.Sql
{
    internal class BaseProvider : DbHelper
    {
        internal BaseProvider() { }
        internal BaseProvider(string connetionString) : base(connetionString) { }
        internal BaseProvider(string connetionString, DataBaseType type) : base(connetionString, type) { }

        /// <summary>
        /// 通用的分页方法
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        /// <param name="tableName">表名</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        internal DataTable GetList(int pageIndex, int pageSize, string tableName, string condition, string sort)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms =
                {
                    NewParam("@PageIndex", pageIndex),
                    NewParam("@PageSize", pageSize),
                    NewParam("@Condition", ParseHacker.Condition(condition)),
                    NewParam("@TableName", tableName),
                    NewParam("@Field", "*"),
                    NewParam("@Sort", sort)
                };

                return db.GetDataTable(CommandType.StoredProcedure, "c_PagePagination", parms);
            }
        }

        /// <summary>
        /// 通用的分页方法(不带条件)
        /// </summary>
        /// <param name="pageIndex">分页索引</param>
        /// <param name="pageSize">每页显示记录数</param>
        ///  <param name="tableName">表名</param>
        /// <param name="sort">排序</param>
        internal DataTable GetList(int pageIndex, int pageSize, string tableName, string sort)
        {
            return GetList(pageIndex, pageSize, tableName, null, sort);
        }

        /// <summary>
        /// 获取符合条件的列表
        /// </summary>
        /// <param name="top">显示记录数</param>
        /// <param name="tableName">表名</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        internal DataTable GetList(int top, string tableName, string condition, string sort)
        {
            if (!string.IsNullOrEmpty(sort) && sort.ToLower().StartsWith("order by")) sort = "ORDER BY " + sort;

            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT {0} * FROM [{1}] WHERE {2} {3}", top == 0 ? "" : "TOP " + top, tableName, ParseHacker.Condition(condition), sort);

                return db.GetDataTable(CommandType.Text, sql);
            }
        }

        /// <summary>
        /// 获取符合条件的列表
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="condition">SQL条件语句</param>
        /// <param name="sort">排序</param>
        internal DataTable GetList(string tableName, string condition, string sort)
        {
            return GetList(0, tableName, condition, sort);
        }

        /// <summary>
        /// 获取符合条件的列表
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="sort">排序</param>
        internal DataTable GetList(string tableName, string sort)
        {
            return GetList(0, tableName, null, sort);
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(形式：select [Field] from [tableName] where [conditionFieldName] = @[conditionFieldValue])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="fieldName">查询字段</param>
        /// <param name="conditionFieldName">条件字段名称，只能是int主键</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        internal T GetInfo<T>(string tableName, string fieldName, string conditionFieldName, int conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT {0} FROM [{1}] WHERE [{2}] = @Value", fieldName, tableName, conditionFieldName);

                object obj = db.ExecuteScalar(CommandType.Text, sql, parms);
                return ParseType.ConvertType<T>(obj, default(T));

            }
        }

        /// <summary>
        /// 获取第一条第一个字段的数据(形式：select [Field] from [tableName] where [condition])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="fieldName">查询字段</param>
        /// <param name="condition">SQL条件语句</param>
        internal T GetInfo<T>(string tableName, string fieldName, string condition)
        {

            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT TOP 1 {0} FROM [{1}] WHERE [{2}]", fieldName, tableName, ParseHacker.Condition(condition));
                object obj = db.ExecuteScalar(CommandType.Text, sql);
                return ParseType.ConvertType<T>(obj, default(T));

            }
        }

        /// <summary>
        /// 获取单条记录(形式：select * from [tableName] where [conditionFieldName] = @[conditionFieldValue])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="conditionFieldName">条件字段名称，只能是int主键</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        internal IDataReader GetInfo(string tableName, string conditionFieldName, int conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("SELECT TOP 1 * FROM [{0}] WHERE [{1}] = @Value", tableName, conditionFieldName);

                return db.GetReader(CommandType.Text, sql, parms);

            }
        }

        /// <summary>
        /// 获取单条记录(形式：select * from [tableName] where [condition])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="condition">SQL条件语句</param>
        internal IDataReader GetInfo(string tableName, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT * FROM [{0}] WHERE [{1}]", tableName, ParseHacker.Condition(condition));
                return db.GetReader(CommandType.Text, sql);

            }
        }

        /// <summary>
        /// 删除单条记录(形式：delete from [tableName] where [conditionFieldName] = @[conditionFieldValue])
        /// 该操作为真实删除,请谨慎操作
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="conditionFieldName">条件字段名称，只能是int主键</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        internal bool Delete(string tableName, string conditionFieldName, int conditionFieldValue)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@Value", conditionFieldValue) 
                };

                string sql = string.Format("DELETE FROM [{0}] WHERE [{1}] = @Value", tableName, conditionFieldName);

                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 删除单条记录(形式：delete from [tableName] where [condition])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="condition">SQL条件语句</param>
        internal bool Delete(string tableName, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("DELETE FROM [{0}] WHERE [{1}]", tableName, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql) > 0;

            }
        }

        /// <summary>
        /// 逻辑删除/恢复(形式：update [tableName] set [deleteFieldName] = @isDelete[] where [conditionFieldName] = @[conditionFieldValue])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="conditionFieldName">条件字段名称，只能是int主键</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="deleteFieldName">删除标识字段名</param>
        /// <param name="isDelete">是否删除标识值</param>
        internal bool Delete(string tableName, string conditionFieldName, int conditionFieldValue, string deleteFieldName, bool isDelete)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@IsDelete", isDelete),
                    NewParam("@Value", conditionFieldValue)
                };

                string sql = string.Format("UPDATE [{0}] SET {1} = @IsDelete WHERE [{2}] = @Value AND {1} != @IsDelete", tableName, deleteFieldName, conditionFieldName);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 逻辑删除/恢复(形式：update [tableName] set [deleteFieldName] = @isDelete[] where [conditionFieldName] = @[conditionFieldValue])
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="conditionFieldName">条件字段名称，只能是int主键</param>
        /// <param name="conditionFieldValue">条件字段值</param>
        /// <param name="deleteFieldName">删除标识字段名</param>
        /// <param name="isDelete">是否删除标识值</param>
        internal bool Delete(string tableName, string condition, string deleteFieldName, bool isDelete)
        {
            using (IDbProvider db = NewDbProvider())
            {
                IDbDataParameter[] parms = 
                {
                    NewParam("@IsDelete", isDelete)
                };

                string sql = string.Format("UPDATE [{0}] SET {1} = @IsDelete WHERE {2}", tableName, deleteFieldName, ParseHacker.Condition(condition));
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="tableName">表名</param>
        internal int GetCount(string tableName)
        {
            return GetCount(tableName, null);
        }

        /// <summary>
        /// 获取数量
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="condition">SQL条件语句</param>
        internal int GetCount(string tableName, string condition)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string sql = string.Format("SELECT Count(0) FROM [{0}] WHERE {1}", tableName, ParseHacker.Condition(condition));

                return (int)db.ExecuteScalar(CommandType.Text, sql);

            }
        }

        /// <summary>
        /// 添加数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="lst">参数列表</param>
        internal bool Insert(string tableName, List<InsertParms> lstParms)
        {
            using (IDbProvider db = NewDbProvider())
            {
                string field = "";
                string value = "";

                if (lstParms == null) { return false; }

                IDbDataParameter[] parms = new IDbDataParameter[lstParms.Count];

                for (int i = 0; i < lstParms.Count; i++)
                {
                    field += string.Format(",{0}", lstParms[i].FieldName);
                    value += string.Format(",@{0}", lstParms[i].FieldName);
                    parms[i] = NewParam("@" + lstParms[i].FieldName, lstParms[i].Value);
                }

                if (lstParms.Count > 0)
                {
                    field = field.Substring(1);
                    value = value.Substring(1);
                }

                string sql = string.Format("INSERT INTO [{0}] ({1})VALUES({2})", tableName, field, value);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }

        /// <summary>
        /// 更新数据
        /// </summary>
        /// <param name="tableName">表名</param>
        /// <param name="lst">参数列表</param>
        /// <param name="condition">条件,参数名的值要放到ParmsWithouCondition结构（UserName = @UserName AND PassWord = @PassWord）</param>
        /// <returns></returns>
        internal bool Update(string tableName, List<UpdateParms> lstParms, string condition)
        {
            if (string.IsNullOrEmpty(condition)) { condition = "1=1"; }

            else
            {
                if (condition.ToLower().StartsWith("where")) { condition = condition.Substring(6).Trim(); }

                if (!condition.StartsWith("1=1")) condition = "1=1 AND " + condition;
            }

            using (IDbProvider db = NewDbProvider())
            {
                string field = "";

                if (lstParms == null) { return false; }

                IDbDataParameter[] parms = new IDbDataParameter[lstParms.Count];

                for (int i = 0; i < lstParms.Count; i++)
                {
                    if (!lstParms[i].IsCondition) { field += string.Format(",{0} = @{0}", lstParms[i].FieldName); }
                    parms[i] = NewParam("@" + lstParms[i].FieldName, lstParms[i].Value);
                }

                if (lstParms.Count > 0) { field = field.Substring(1); }

                string sql = string.Format("UPDATE [{0}] SET {1} WHERE {2}", tableName, field, condition);
                return db.ExecuteNonQuery(CommandType.Text, sql, parms) > 0;
            }
        }
    }

    /// <summary>
    /// SQL参数，要跟据参数在SQL的位置进行排序
    /// </summary>
    public struct UpdateParms
    {
        /// <summary>
        /// 字段名称
        /// </summary>
        public string FieldName { get; set; }
        /// <summary>
        /// 值
        /// </summary>
        public object Value { get; set; }

        /// <summary>
        /// 用途（true：条件）
        /// </summary>
        public bool IsCondition { get; set; }
    }

    /// <summary>
    /// SQL参数，要跟据参数在SQL的位置进行排序(不带是否在条件中使用的结构)
    /// </summary>
    public struct InsertParms
    {
        /// <summary>
        /// 字段名称
        /// </summary>
        public string FieldName { get; set; }
        /// <summary>
        /// 值
        /// </summary>
        public object Value { get; set; }
    }
}
