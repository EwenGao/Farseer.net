﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Qyn.Common.Utils
{
    public class ParseForm
    {
        /// <summary>
        /// 检查是否存在该类型的子窗体
        /// </summary>
        /// <param name="ChildTypeName">窗体名称</param>
        /// <returns>是否存在</returns>
        public static bool isExist(Form form,string ChildTypeName)
        {
            bool b_result = false;

            foreach (Form frm in form.MdiChildren)
            {
                if (frm.GetType().Name == ChildTypeName)
                {
                    frm.Activate();
                    b_result = true;
                    break;
                }
            }

            return b_result;
        }
    }
}
