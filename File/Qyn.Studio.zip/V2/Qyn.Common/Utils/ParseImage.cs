﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Web;

namespace Qyn.Common.Utils
{
    public class ParseImage
    {
        public static void SaveImageByRequest(string imageUrl, string savePath,ImageFormat imgFormat)
        {
            WebRequest wreq = WebRequest.Create(imageUrl);
            HttpWebResponse wresp = (HttpWebResponse)wreq.GetResponse();
            Stream s = wresp.GetResponseStream();
            Image img = Image.FromStream(s);
            img.Save(savePath, imgFormat);   //保存 
        }

        public static void SaveImageByClient(string imageUrl, string savePath, ImageFormat imgFormat)
        {
            WebClient my = new WebClient();
            byte[] mybyte = my.DownloadData(imageUrl);
            MemoryStream ms = new MemoryStream(mybyte);
            System.Drawing.Image img;
            img = System.Drawing.Image.FromStream(ms);
            img.Save(savePath, imgFormat);   //保存

            //如果是真实的图片地址直接用 
            //my.DownloadFile("http://www.xueit.com/eimg/uploadfile/downpig/20098/098215331763.gif","D:\\a.gif");   //保存 
            //直接可以保存

        }

        /// <summary>
        /// 用HttpContext.Current.Response.BinaryWrite输出
        /// </summary>
        /// <param name="imageUrl"></param>
        /// <returns></returns>
        public static byte[] Write(string imageUrl)
        {
            //下面直接输出 
            //HttpContext.Current.Response.ClearContent();
            //HttpContext.Current.Response.ContentType = "image/gif";
            //HttpContext.Current.Response.BinaryWrite(mybyte);

            return new WebClient().DownloadData(imageUrl);
        }

    }
}
