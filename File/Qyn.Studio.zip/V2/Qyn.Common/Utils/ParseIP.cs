﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Web;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 解释IP
    /// </summary>
	public class ParseIP
	{
        /// <summary>
        /// 返回指定IP是否在指定的IP数组所限定的范围内, IP数组内的IP地址可以使用*表示该IP段任意, 例如192.168.1.*
        /// </summary>
        /// <param name="ip"></param>
        /// <param name="iparray"></param>
        /// <returns></returns>
        public static bool InIPArray(string ip, string[] iparray)
        {

            string[] userip = Utils.ParseString.SplitString(ip, @".");
            for (int ipIndex = 0; ipIndex < iparray.Length; ipIndex++)
            {
                string[] tmpip = Utils.ParseString.SplitString(iparray[ipIndex], @".");
                int r = 0;
                for (int i = 0; i < tmpip.Length; i++)
                {
                    if (tmpip[i] == "*")
                    {
                        return true;
                    }

                    if (userip.Length > i)
                    {
                        if (tmpip[i] == userip[i])
                        {
                            r++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    else
                    {
                        break;
                    }

                }
                if (r == 4)
                {
                    return true;
                }


            }
            return false;

        }

        /// <summary>
        /// 获取真取IP
        /// </summary>
        /// <returns></returns>
        public static string GetIP()
        {
            string ip;
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                ip = Tools.QynRequest.GetIP();
            }
            else
            {
                string strHostName = System.Net.Dns.GetHostName();
                //ip = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();

                IPHostEntry ipHost = Dns.Resolve(strHostName);
                IPAddress ipAddr = ipHost.AddressList[0];
                ip = ipAddr.ToString();
            }

            return ip;
        }
	}
}
