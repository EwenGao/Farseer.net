﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 解释Url
    /// </summary>
    public class ParseUrl
    {
        /// <summary>
        /// 返回 URL 字符串的编码结果
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>编码结果</returns>
        public static string UrlEncode(string str)
        {
            return HttpUtility.UrlEncode(str);
        }

        /// <summary>
        /// 返回 URL 字符串的编码结果
        /// </summary>
        /// <param name="str">字符串</param>
        /// <returns>解码结果</returns>
        public static string UrlDecode(string str)
        {
            return HttpUtility.UrlDecode(str);
        }

        /// <summary>
        /// 获得当前绝对路径
        /// </summary>
        /// <param name="strPath">指定的路径</param>
        /// <returns>绝对路径</returns>
        public static string GetMapPath(string strPath)
        {
            if (strPath.IndexOf(':') != -1) { return strPath; }

            if (HttpContext.Current != null)
            {
                return HttpContext.Current.Server.MapPath(strPath);
            }
            else //非web程序引用
            {
                return System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, strPath);
            }
        }

        /// <summary>
        /// 检测是否是正确的Url
        /// </summary>
        /// <param name="strUrl">要验证的Url</param>
        /// <returns>判断结果</returns>
        public static bool IsURL(string strUrl)
        {
            return Regex.IsMatch(strUrl, @"^(http|https)\://([a-zA-Z0-9\.\-]+(\:[a-zA-Z0-9\.&%\$\-]+)*@)*((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|localhost|([a-zA-Z0-9\-]+\.)*[a-zA-Z0-9\-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{1,10}))(\:[0-9]+)*(/($|[a-zA-Z0-9\.\,\?\'\\\+&%\$#\=~_\-]+))*$");
        }

        /// <summary>
        /// 返回URL中结尾的文件名
        /// </summary>		
        public static string GetFilename(string url)
        {
            if (url == null)
            {
                return "";
            }
            string[] strs1 = url.Split(new char[] { '/' });
            return strs1[strs1.Length - 1].Split(new char[] { '?' })[0];
        }

        /// <summary>
        /// 返回完全域名，带端口
        /// </summary>
        /// <param name="url">来源URL</param>
        /// <returns></returns>
        public static string GetDomainUrl(string url)
        {
            string newUrl;
            //去掉 http://字符串
            newUrl = url.ToLower().Replace("\\", "/").Replace("http://", "");
            //只截取到第一个'/'符号的字符串
            newUrl = newUrl.Substring(0, newUrl.IndexOf('/'));
            newUrl = "http://" + newUrl;
            return newUrl;
        }

        /// <summary>
        /// 得到网站的真实路径
        /// </summary>
        /// <returns></returns>
        public static string GetTrueWebPath()
        {
            string forumPath = HttpContext.Current.Request.Path;
            if (forumPath.LastIndexOf("/") != forumPath.IndexOf("/"))
            {
                forumPath = forumPath.Substring(forumPath.IndexOf("/"), forumPath.LastIndexOf("/") + 1);
            }
            else
            {
                forumPath = "/";
            }
            return forumPath;

        }

        /// <summary>
        /// 获得当前页面的名称
        /// </summary>
        public static string GetPageName(string url)
        {
            string pageName = "";
            string strUrl =url.Replace("\\", "/");

            if (strUrl.Split('/').Length > 1)
            {
                strUrl = strUrl.Split('/')[strUrl.Split('/').Length -1];

                if (!strUrl.StartsWith("?") && strUrl.IndexOf('.') > -1)
                {
                    string[] urlArrSub = strUrl.IndexOf('?') > -1 ? strUrl.Substring(0, strUrl.IndexOf('?') ).Split('.') : strUrl.Split('.');

                    if (urlArrSub[urlArrSub.Length - 1].Trim().Length > 0)
                    {
                        pageName = string.Format("{0}.{1}", urlArrSub[urlArrSub.Length - 2], urlArrSub[urlArrSub.Length - 1]);
                    }

                }
            }
            return pageName;
        }
    }
}
