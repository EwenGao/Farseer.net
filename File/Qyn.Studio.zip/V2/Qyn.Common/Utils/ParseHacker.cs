﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 防范黑客攻击的代码
    /// </summary>
    public class ParseHacker
    {
        /// <summary>
        /// 检查查询语句是否符合规则(ID = 1 AND UserName = 'steden') 非数字，要加''
        /// </summary>
        public static string Condition(string condition)
        {
            //如果前面出现："IsSafe = "字符串，则表明无需验证
            if (!string.IsNullOrEmpty(condition) && condition.StartsWith("IsSafe = ")) { return condition.Substring(9); }

            if (string.IsNullOrEmpty(condition)) condition = "1=1";

            if (condition.ToLower().StartsWith("where")) { condition = condition.Substring(6).Trim(); }
            
            if (!condition.StartsWith("1=1")) condition = "1=1 AND " + condition;

            Regex reg = new Regex(@"^1=1((\s)(AND|OR)(\s)([A-Z]\w+?|\[[A-Z]\w+?\])(\s)(<>|=|LIKE|IN|\<|\>)\s(\([^\)]+\)|(\'[^\']+\')|\d+|\([\d+\,]+\d\))){0,8}$");
            return reg.IsMatch(condition) ? condition : "1!=1";
        }

        /// <summary>
        /// 检查排序语句是否符合规则
        /// </summary>
        public static string Sort(string sort)
        {
            if (string.IsNullOrEmpty(sort)) return sort;
            Regex reg = new Regex(@"^(([A-Z]\w+?|\[[A-Z]\w+?\])(\s)(ASC|DESC))((\s)\,(\s)([A-Z]\w+?|\[[A-Z]\w+?\])(\s)(ASC|DESC)){0,8}$");
            return reg.IsMatch(sort) ? sort : string.Empty;
        }
    }
}
