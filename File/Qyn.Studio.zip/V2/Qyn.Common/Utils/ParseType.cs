﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using System.Data;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 类型转换
    /// </summary>
    public class ParseType
    {
        /// <summary> 
        /// 将某个对像转换成指定对像
        /// </summary>
        public static T ConvertType<T>(object objValue,T defValue)
        {
            if (objValue == null) { return defValue; }

            T t = defValue;

            if (typeof(T) == typeof(Int32))
            {
                int value;
                if (int.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(Boolean))
            {
                bool value;
                if (bool.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(Decimal))
            {
                decimal value;
                if (decimal.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(Single))
            {
                float value;
                if (float.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(Double))
            {
                double value;
                if (double.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(DateTime))
            {
                DateTime value;
                if (DateTime.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(Int64))
            {
                long value;
                if (long.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(Int16))
            {
                short value;
                if (short.TryParse(objValue.ToString(), out value))
                {
                    t = (T)(object)value;
                }
            }
            else if (typeof(T) == typeof(DataTable))
            {
                try
                {
                    t = (T)(object)(DataTable)objValue;

                }
                catch { }
            }
            else if (typeof(T) == typeof(String))
            {
                try
                {
                    t = (T)(object)Convert.ToString(objValue);

                }
                catch { }
            }
            return t;
        }

        /// <summary>
        /// 转换为简体中文
        /// </summary>
        public static string ToSChinese(string str)
        {
            return Strings.StrConv(str, VbStrConv.SimplifiedChinese, 0);
        }

        /// <summary>
        /// 转换为繁体中文
        /// </summary>
        public static string ToTChinese(string str)
        {
            return Strings.StrConv(str, VbStrConv.TraditionalChinese, 0);
        }

        /// <summary>
        /// 将全角数字转换为数字
        /// </summary>
        /// <param name="SBCCase"></param>
        /// <returns></returns>
        public static string SBCCaseToNumberic(string SBCCase)
        {
            char[] c = SBCCase.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                byte[] b = System.Text.Encoding.Unicode.GetBytes(c, i, 1);
                if (b.Length == 2)
                {
                    if (b[1] == 255)
                    {
                        b[0] = (byte)(b[0] + 32);
                        b[1] = 0;
                        c[i] = System.Text.Encoding.Unicode.GetChars(b)[0];
                    }
                }
            }
            return new string(c);
        }

        /// <summary>
        /// 将字符串转换为Color
        /// </summary>
        /// <param name="color"></param>
        /// <returns></returns>
        public static Color ToColor(string color)
        {
            int red, green, blue = 0;
            char[] rgb;
            color = color.TrimStart('#');
            color = Regex.Replace(color.ToLower(), "[g-zG-Z]", "");
            switch (color.Length)
            {
                case 3:
                    rgb = color.ToCharArray();
                    red = Convert.ToInt32(rgb[0].ToString() + rgb[0].ToString(), 16);
                    green = Convert.ToInt32(rgb[1].ToString() + rgb[1].ToString(), 16);
                    blue = Convert.ToInt32(rgb[2].ToString() + rgb[2].ToString(), 16);
                    return Color.FromArgb(red, green, blue);
                case 6:
                    rgb = color.ToCharArray();
                    red = Convert.ToInt32(rgb[0].ToString() + rgb[1].ToString(), 16);
                    green = Convert.ToInt32(rgb[2].ToString() + rgb[3].ToString(), 16);
                    blue = Convert.ToInt32(rgb[4].ToString() + rgb[5].ToString(), 16);
                    return Color.FromArgb(red, green, blue);
                default:
                    return Color.FromName(color);

            }
        }

        /// <summary>
        /// string[]型转为string型
        /// </summary>
        public static string StrArrayToString(string[] strArray)
        {
            string str = "";
            if (strArray != null)
            {
                for (int i = 0; i < strArray.Length; i++)
                {
                    str += strArray[i];
                }
            }
            return str;
        }

    }
}
