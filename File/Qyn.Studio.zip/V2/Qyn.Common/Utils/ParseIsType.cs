﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Text.RegularExpressions;
using System.Data;

namespace Qyn.Common.Utils
{
    /// <summary>
    /// 判断类型
    /// </summary>
    public class ParseIsType
    {
        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip">Ip</param>
        /// <returns></returns>
        public static bool IsIP(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(2[0-4]\d|25[0-5]|[01]?\d\d?)$");

        }

        /// <summary>
        /// 是否为ip
        /// </summary>
        /// <param name="ip">Ip</param>
        /// <returns></returns>
        public static bool IsIPSect(string ip)
        {
            return Regex.IsMatch(ip, @"^((2[0-4]\d|25[0-5]|[01]?\d\d?)\.){2}((2[0-4]\d|25[0-5]|[01]?\d\d?|\*)\.)(2[0-4]\d|25[0-5]|[01]?\d\d?|\*)$");

        }

        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strNumber">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsDoubleArray(string[] strDouble)
        {
            if (strDouble == null)
            {
                return false;
            }
            if (strDouble.Length < 1)
            {
                return false;
            }
            foreach (string id in strDouble)
            {
                if (!IsType<Int64>(id))
                {
                    return false;
                }
            }
            return true;

        }

        /// <summary>
        /// 判断给定的字符串数组(strNumber)中的数据是不是都为数值型
        /// </summary>
        /// <param name="strNumber">要确认的字符串数组</param>
        /// <returns>是则返加true 不是则返回 false</returns>
        public static bool IsIntArray(string[] strInt)
        {
            if (strInt == null)
            {
                return false;
            }
            if (strInt.Length < 1)
            {
                return false;
            }
            foreach (string id in strInt)
            {
                if (!IsType<Int32>(id))
                {
                    return false;
                }
            }
            return true;

        }
      
        public static bool IsType<T>(object objValue)
        {
            if (objValue == null) { return false; }

            if (typeof(T) == typeof(Int32))
            {
                int value;
                return int.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Boolean))
            {
                bool value;
                return bool.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Decimal))
            {
                decimal value;
                return decimal.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Single))
            {
                float value;
                return float.TryParse(objValue.ToString(), out value);

            }
            else if (typeof(T) == typeof(Double))
            {
                double value;
                return double.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(DateTime))
            {
                DateTime value;
                return DateTime.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Int64))
            {
                long value;
                return long.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(Int16))
            {
                short value;
                return short.TryParse(objValue.ToString(), out value);
            }
            else if (typeof(T) == typeof(DataTable))
            {
                try
                {
                   DataTable dt = (DataTable)objValue;
                   return true;
                }
                catch { return false; }
            }
            else if (typeof(T) == typeof(String))
            {
                try
                {
                    String str = (String)objValue;
                    return true;
                }
                catch { return false; }
            }
            return false;
        }
    }
}
