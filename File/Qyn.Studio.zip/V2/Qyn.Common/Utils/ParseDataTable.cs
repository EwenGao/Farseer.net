﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Qyn.Common.Utils
{
    public class ParseDataTable
    {
        /// <summary>
        /// 对DataTable排序
        /// </summary>
        /// <param name="dt">要排序的表</param>
        /// <param name="sort">要排序的字段</param>
        public static DataTable Sort(DataTable dt, string sort)
        {
            DataRow[] rows = dt.Select("", sort);
            DataTable tmpDt = dt.Clone();

            foreach (DataRow row in rows)
            {
                tmpDt.ImportRow(row);
            }
            return tmpDt;
        }

        /// <summary>
        /// 返回已分页的表
        /// </summary>
        /// <param name="dt">源表</param>
        /// <param name="pageSize">每页显示的记录数</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static DataTable Pagination(DataTable dt, int pageSize, int pageIndex)
        {
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            if (pageSize < 1)
            {
                pageSize = 1;
            }
            DataTable dtNew = dt.Clone();

            if (dt != null)
            {
                int firstIndex;
                int endIndex;

                #region 计算 开始索引
                if (pageIndex == 1)
                {
                    firstIndex = 0;
                }
                else
                {
                    firstIndex = pageSize * (pageIndex - 1);
                    //索引超出记录总数时，返回空的表格
                    if (firstIndex > dt.Rows.Count)
                    {
                        return dtNew;
                    }
                }
                #endregion

                #region 计算 结束索引
                endIndex = pageSize + firstIndex;
                if (endIndex > dt.Rows.Count)
                {
                    endIndex = dt.Rows.Count;
                }
                #endregion

                for (int i = firstIndex; i < endIndex; i++)
                {
                    dtNew.ImportRow(dt.Rows[i]);
                }
            }
            return dtNew;
        }

        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(DataTable dt)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            foreach (DataRow dr in dt.Rows)
            {
                T t = (T)Activator.CreateInstance(ht, dr);
                list.Add(t);
            }
            dt.Dispose();
            return list;
        }
    }
}
