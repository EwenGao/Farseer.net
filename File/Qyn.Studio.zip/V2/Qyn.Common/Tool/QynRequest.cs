using System;
using System.Web;

using Qyn.Common.Utils;

namespace Qyn.Common.Tools
{
	/// <summary>
	/// Request������
	/// </summary>
	public class QynRequest
	{
        public enum SubmitType
        {
            Get = 0,
            Post =1,
            All =255
        }

        /// <summary>
        /// ��ȡUrl��ʽ
        /// </summary>
        public enum UrlType
        {
            /// <summary>
            /// ������http://localhost:1480/WebSite2/Default.aspx?UserID=1 
            /// </summary>
            Full = 0,
            /// <summary>
            /// ������http://localhost:1480/
            /// </summary>
            Domain = 1,
            /// <summary>
            /// ·����/WebSite2/
            /// </summary>
            Path = 2,
            /// <summary>
            /// ҳ������: Default.aspx
            /// </summary>
            PageName = 3,
            /// <summary>
            /// ������UserID=1&UserName=Steden
            /// </summary>
            Params = 4,
            /// <summary>
            /// ��һ��ҳ���ַ
            /// </summary>
            Previous = 5
        }

		/// <summary>
		/// �жϵ�ǰҳ���Ƿ���յ����ύ����
		/// </summary>
		public static bool IsSubmit(SubmitType type)
		{
            bool result =false;
            switch (type)
            {
                case SubmitType.Get:
                    result = HttpContext.Current.Request.HttpMethod.Equals("GET");
                    break;

                case SubmitType.Post:
                    result = HttpContext.Current.Request.HttpMethod.Equals("POST");
                    break;

                case SubmitType.All:
                    result = IsSubmit(SubmitType.Get) || IsSubmit(SubmitType.Post);
                    break;
            }
            return result;
		}

		/// <summary>
		/// ����ָ���ķ�����������Ϣ
		/// </summary>
		/// <param name="strName">������������</param>
		/// <returns>������������Ϣ</returns>
		public static string GetServerString(string strName)
		{
			//
			if (HttpContext.Current.Request.ServerVariables[strName] == null)
			{
				return "";
			}
			return HttpContext.Current.Request.ServerVariables[strName].ToString();
		}

        /// <summary>
        /// �õ���ǰ��������ͷ
        /// </summary>
        /// <returns></returns>
        public static string GetCurrentFullHost()
        {
            HttpRequest request = System.Web.HttpContext.Current.Request;
            if (!request.Url.IsDefaultPort)
            {
                return string.Format("{0}:{1}", request.Url.Host, request.Url.Port.ToString());
            }
            return request.Url.Host;
        }

        /// <summary>
        /// �õ�����ͷ
        /// </summary>
        /// <returns></returns>
        public static string GetHost()
        {
            return HttpContext.Current.Request.Url.Host;
        }

        /// <summary>
        /// �ж��Ƿ�����������������
        /// </summary>
        /// <returns>�Ƿ�����������������</returns>
        public static bool IsSearchEnginesGet()
        {
            if (HttpContext.Current.Request.UrlReferrer == null)
            {
                return false;
            }
            string[] SearchEngine = { "google", "yahoo", "msn", "baidu", "sogou", "sohu", "sina", "163", "lycos", "tom", "yisou", "iask", "soso", "gougou", "zhongsou" };
            string tmpReferrer = HttpContext.Current.Request.UrlReferrer.ToString().ToLower();
            for (int i = 0; i < SearchEngine.Length; i++)
            {
                if (tmpReferrer.IndexOf(SearchEngine[i]) >= 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// ����URL
        /// </summary>
        public static string GetUrl(UrlType type)
        {
            string url = "";

            switch (type)
            {
                case UrlType.Full:
                    url = HttpContext.Current.Request.Url.ToString();
                    break;

                case UrlType.Domain:
                    url = string.Format("http://{0}", HttpContext.Current.Request.Url.Authority);
                    break;

                case UrlType.Path:
                    {
                        url = HttpContext.Current.Request.Url.AbsolutePath.ToLower();
                        string pageName = GetUrl(UrlType.PageName);
                        if ( url.EndsWith(pageName) ) 
                        {
                            url = url.Substring(0, url.Length - pageName.Length); 
                        }
                    }
                    break;

                case UrlType.PageName:
                    url = ParseUrl.GetPageName(GetUrl(UrlType.Full));
                    break;

                case UrlType.Params:
                    {
                        string fullUrl = GetUrl(UrlType.Full);
                        if (fullUrl.IndexOf('?') != -1)
                        {
                            url = fullUrl.Substring(fullUrl.IndexOf('?') + 1);
                        }
                        
                    }
                    break;

                case UrlType.Previous:
                    url = Convert.ToString(((object)HttpContext.Current.Request.UrlReferrer) ?? "");
                    break;
            }
            return url.ToLower();
        }

		/// <summary>
		/// ���ر�����Url�������ܸ���
		/// </summary>
		/// <returns></returns>
		public static int GetParamCount()
		{
			return HttpContext.Current.Request.Form.Count + HttpContext.Current.Request.QueryString.Count;
		}
		
		/// <summary>
		/// ���ָ��Url�����������float����ֵ, ���ж�Url�����Ƿ�Ϊȱʡֵ, ��ΪTrue�򷵻ر���������ֵ
		/// </summary>
		/// <param name="strName">Url���������</param>
		/// <param name="defValue">ȱʡֵ</param>
		/// <returns>Url�����������int����ֵ</returns>
        public static T GetValue<T>(string strName, T defValue, SubmitType type)
		{
            T value = defValue;
            object obj = (object)value;

            switch (type)
            {
                case SubmitType.Get:
                    {
                        obj = HttpContext.Current.Request.QueryString[strName];

                        break;
                    }
                case SubmitType.Post:
                    obj = HttpContext.Current.Request.Form[strName];
                    break;

                case SubmitType.All:
                    obj = Convert.ToString((object)GetValue<T>(strName, defValue, SubmitType.Post)) == Convert.ToString(obj) ?
                            GetValue<T>(strName, defValue, SubmitType.Get) :
                            GetValue<T>(strName, defValue, SubmitType.Post);
                    break;
            }

            value = ParseType.ConvertType<T>(obj, defValue);
            return value;
		}

        /// <summary>
        /// ���ָ��Url�����������float����ֵ, ���ж�Url�����Ƿ�Ϊȱʡֵ, ��ΪTrue�򷵻ر���������ֵ
        /// </summary>
        /// <param name="strName">Url���������</param>
        /// <param name="defValue">ȱʡֵ</param>
        /// <returns>Url�����������int����ֵ</returns>
        public static string GetValue(string strName, SubmitType type)
        {

            switch (type)
            {
                case SubmitType.Get:
                    {
                        return HttpContext.Current.Request.QueryString[strName] ?? "";
                    }
                case SubmitType.Post:
                    {
                        return HttpContext.Current.Request.Form[strName] ?? "";
                    }
                case SubmitType.All:
                    {
                        return GetValue(strName, SubmitType.Post) == null ?
                                GetValue(strName, SubmitType.Get) :
                                GetValue(strName, SubmitType.Post);
                    }
                default:
                    return "";
            }
        }

		/// <summary>
		/// ��õ�ǰҳ��ͻ��˵�IP
		/// </summary>
		/// <returns>��ǰҳ��ͻ��˵�IP</returns>
		public static string GetIP()
		{
			string result = String.Empty;

			result = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
			if (null == result || result == String.Empty)
			{
				result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
			}

			if (null == result || result == String.Empty)
			{
				result = HttpContext.Current.Request.UserHostAddress;
			}

            if (null == result || result == String.Empty || !Utils.ParseIsType.IsIP(result))
			{
				return "0.0.0.0";
			}

			return result;

		}

        /// <summary>
        /// �жϵ�ǰ�����Ƿ��������������
        /// </summary>
        /// <returns>��ǰ�����Ƿ��������������</returns>
        public static bool IsBrowserGet()
        {
            string[] BrowserName = { "ie", "opera", "netscape", "mozilla", "konqueror", "firefox" };
            string curBrowser = HttpContext.Current.Request.Browser.Type.ToLower();
            for (int i = 0; i < BrowserName.Length; i++)
            {
                if (curBrowser.IndexOf(BrowserName[i]) >= 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// �ж��Ƿ����ϴ����ļ�
        /// </summary>
        /// <returns>�Ƿ����ϴ����ļ�</returns>
        public static bool IsPostFile()
        {
            for (int i = 0; i < HttpContext.Current.Request.Files.Count; i++)
            {
                if (HttpContext.Current.Request.Files[i].FileName != "")
                {
                    return true;
                }
            }
            return false;
        }

		/// <summary>
		/// �����û��ϴ����ļ�
		/// </summary>
		/// <param name="path">����·��</param>
		public static void SaveRequestFile(string path)
		{
			if (HttpContext.Current.Request.Files.Count > 0)
			{
				HttpContext.Current.Request.Files[0].SaveAs(path);
			}
		}

	}
}
