﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Qyn.Common.Utils;
using System.IO;
using System.Reflection;

namespace Qyn.Common.Tools
{
    /// <summary>
    /// DataTable 与 Xml 的转换
    /// 必需设置好XmlPath路径及NewDataTable
   /// </summary>
   /// <typeparam name="T"></typeparam>
    public class DataTableXml<T>
    {
        protected List<T> lst;

        protected List<T> Lst
        {
            get { return lst; }
            set { lst = value; SaveXml(lst); }
        }

        /// <summary>
        /// 格式化
        /// </summary>
        private DataTable NewDataTable { get; set; }

        /// <summary>
        /// XML路径
        /// </summary>
        public string XmlPath { get; set; }

        protected DataTableXml(string xmlPath, DataTable newFormatDataTable)
        {
            XmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, xmlPath);
            NewDataTable = newFormatDataTable.Clone();
            Lst = LoadXml();
        }

        /// <summary>
        /// 读取配置文件
        /// </summary>
        /// <returns></returns>
        public List<T> LoadXml()
        {
            DataTable dt = new DataTable();
            if (!ParseFile.FileExists(XmlPath)) { return new List<T>(); }

            dt.ReadXml(XmlPath);
            if (dt.Columns.Count != NewDataTable.Columns.Count) { return  new List<T>(); }

            return ParseDataTable.ToList<T>(dt);
            
        }

        /// <summary>
        /// 保存配置文件
        /// </summary>
        private void SaveXml(List<T> lst)
        {
            DataTable dt = NewDataTable.Clone();
            object[] obj;

            foreach (T t in lst)
            {
                //获取该类的所有public属性
                List<PropertyInfo> lstPropertyInfo = ParseClass<T>.GetProperties();
                obj = new object[dt.Columns.Count];
                
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    for (int j = 0; j < lstPropertyInfo.Count; j++) 
                    {
                        if (string.Compare(dt.Columns[i].Caption, lstPropertyInfo[j].Name,false) == 0 ) 
                        { 
                            obj[i] = lstPropertyInfo[j].GetValue(t, null);
                            break;
                        }
                    }
                }
                dt.Rows.Add(obj);
            }
            
            dt.WriteXml(XmlPath,XmlWriteMode.WriteSchema);
        }
    }
}
