﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Common.Tools
{
    public class PagePagination
    {
        /// <summary>
        /// 分页函数
        /// </summary>
        /// <param name="recordCount">总记录数</param>
        /// <param name="pageSize">每页记录数</param>
        /// <param name="pageIndex">当前页数</param>
        /// <param name="jsFunctionName">ajax函数名</param>
        public static string AjaxPagination(int recordCount, int pageSize, int pageIndex, string jsFunctionName)
        {
            //总页数
            int allCurrentPage = 0;
            //下一页
            int next = 0;
            //上一页
            int pre = 0;
            //开始页码
            int startCount = 0;
            //结束页码
            int endCount = 0;
            string currentPageStr = "";

            if (pageIndex < 1)
            {
                pageIndex = 1;
            }

            //计算总页数
            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            next = pageIndex + 1;
            pre = pageIndex - 1;

            //中间页起始序号
            startCount = (pageIndex + 5) > allCurrentPage ? allCurrentPage - 9 : pageIndex - 4;

            //中间页终止序号
            endCount = pageIndex < 5 ? 10 : pageIndex + 5;

            //为了避免输出的时候产生负数，设置如果小于1就从序号1开始
            if (startCount < 1)
            {
                startCount = 1;
            }

            //页码+5的可能性就会产生最终输出序号大于总页码，那么就要将其控制在页码数之内
            if (allCurrentPage < endCount)
            {
                endCount = allCurrentPage;
            }

            #region 首页
            currentPageStr += "<a href=\"#\" onclick=\"javascript:" + jsFunctionName + "(" + pageSize + ",1);\" title=\"首页\">首页</a>";
            #endregion

            #region 上一页

            currentPageStr += pageIndex > 1 ? "&nbsp;&nbsp;<a href=\"#\" onclick=\"javascript:" + jsFunctionName + "(" + pageSize + "," + pre + ");\" title=\"上一页\">上一页</a>" : "&nbsp;&nbsp;上一页";

            #endregion

            #region 记录
            currentPageStr += "&nbsp;&nbsp;第 " + pageIndex + " 页&nbsp;&nbsp;共 " + allCurrentPage + " 页&nbsp;&nbsp;共 " + recordCount + " 条记录";
            #endregion

            #region 下一页

            currentPageStr += pageIndex != allCurrentPage ? "&nbsp;&nbsp;<a href=\"#\" onclick=\"javascript:" + jsFunctionName + "(" + pageSize + "," + next + ");\" title=\"下一页\">下一页</a>" : "&nbsp;&nbsp;下一页";

            #endregion

            #region 尾页
            currentPageStr += "&nbsp;&nbsp;<a href=\"#\" onclick=\"javascript:" + jsFunctionName + "(" + pageSize + "," + endCount + ");\" title=\"尾页\">尾页</a>";
            #endregion

            #region 页码列表
            //当页码数大于1时, 则显示页码
            if (endCount > 1)
            {
                currentPageStr += "&nbsp;&nbsp;<select id='selPagination' name='selPagination' onchange=\"javascript:qyn_jumpMenuPagination(this);\">";
                string selected = "";
                //中间页处理, 这个增加时间复杂度，减小空间复杂度
                for (int i = startCount; i <= endCount; i++)
                {
                    selected = i == pageIndex ? "selected=\"selected\"" : "";
                    currentPageStr += "<option value=\"" + pageSize.ToString() + "|" + i.ToString() + "\" " + selected + ">第" + i + "页</option>";
                }
                currentPageStr += "</select>";
            }
            #endregion

            #region 页数选择

            currentPageStr += "&nbsp;&nbsp;每页显示<input id=\"txtPageSize\" name=\"txtPageSize\" type=\"text\" value=\"" + pageSize + "\" size=\"5\" onchange=\"javascript:GetDataList(20,1)\"/ style=\"text-align:center\">条数据";

            #endregion

            #region order
                //if (endCount > 1)
                //{
                //    currentPageStr += "&nbsp; &nbsp; &nbsp; &nbsp;";
                //}
                #endregion

                return currentPageStr;

        }

        /// <summary>
        /// 分页函数
        /// </summary>
        /// <param name="recordCount">总记录数</param>
        /// <param name="pageSize">每页记录数</param>
        /// <param name="pageIndex">当前页数</param>
        /// <param name="jsFunctionName">ajax函数名</param>
        public static string HtmlPagination(int recordCount, int pageSize, int pageIndex, string pageName,string cssSelected,string cssNoSelected)
        {
            //总页数
            int allCurrentPage = 0;
            //下一页
            int next = 0;
            //上一页
            int pre = 0;
            //开始页码
            int startCount = 0;
            //结束页码
            int endCount = 0;
            string currentPageStr = "";

            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            pageName += pageName.IndexOf('?') != -1 ? "&" : "?";

            //计算总页数
            if (pageSize != 0)
            {
                allCurrentPage = (recordCount / pageSize);
                allCurrentPage = ((recordCount % pageSize) != 0 ? allCurrentPage + 1 : allCurrentPage);
                allCurrentPage = (allCurrentPage == 0 ? 1 : allCurrentPage);
            }
            next = pageIndex + 1;
            pre = pageIndex - 1;

            //中间页起始序号
            startCount = (pageIndex + 5) > allCurrentPage ? allCurrentPage - 9 : pageIndex - 4;

            //中间页终止序号
            endCount = pageIndex < 5 ? 10 : pageIndex + 5;

            //为了避免输出的时候产生负数，设置如果小于1就从序号1开始
            if (startCount < 1)
            {
                startCount = 1;
            }

            //页码+5的可能性就会产生最终输出序号大于总页码，那么就要将其控制在页码数之内
            if (allCurrentPage < endCount)
            {
                endCount = allCurrentPage;
            }

            #region 记录
            currentPageStr += string.Format("<strong>{0}</strong>条记录&nbsp;&nbsp;<strong>{1}</strong>/<strong>{2}</strong>页", recordCount, pageIndex, allCurrentPage);
            currentPageStr += "&nbsp;&nbsp;";
            #endregion

            #region 首页
            currentPageStr += string.Format("<a href=\"{0}pageSize={1}&pageIndex=1 \" title=\"首页\"><span class=\"{2}\">首页</span></a>", pageName, pageSize,  cssNoSelected);
            currentPageStr += "&nbsp;&nbsp;";
            #endregion

            #region 上一页

            if (pageIndex > 1)
            {
                currentPageStr += string.Format("<a href=\"{0}pageSize={1}&pageIndex={2} \" title=\"上一页\" ><span class=\"{3}\">上一页</span></a>", pageName, pageSize, pre, cssNoSelected);
            }
            else
            {
                currentPageStr += string.Format("<span class=\"Pagination\">上一页</span>");
            }
            currentPageStr += "&nbsp;&nbsp;";
            #endregion

            #region 页码列表
            //当页码数大于0时, 则显示页码
            if (endCount > 0)
            {
                //中间页处理, 这个增加时间复杂度，减小空间复杂度
                for (int i = startCount; i <= endCount; i++)
                {
                    currentPageStr += string.Format("<a href=\"{0}pageSize={1}&pageIndex={2} \" title=\"第{2}页\"><span class=\"{3}\">{2}</span></a> ", pageName, pageSize, i, i == pageIndex ? cssSelected : cssNoSelected);
                }
                currentPageStr += "&nbsp;&nbsp;";
            }
            #endregion

            #region 下一页
            if (pageIndex != allCurrentPage)
            {
                currentPageStr += string.Format("<a href=\"{0}pageSize={1}&pageIndex={2} \" title=\"下一页\" ><span class=\"{3}\">下一页</span></a>", pageName, pageSize, next, cssNoSelected);
            }
            else
            {
                currentPageStr += string.Format("<span class=\"{0}\">下一页</span>",cssNoSelected);
            }
            currentPageStr += "&nbsp;&nbsp;";
            #endregion

            #region 尾页
            currentPageStr += string.Format("<a href=\"{0}pageSize={1}&pageIndex={2} \" title=\"尾页\" ><span class=\"{3}\">尾页</span></a>", pageName, pageSize, allCurrentPage, cssNoSelected);
            //currentPageStr += "&nbsp;&nbsp;";
            #endregion

            #region 页码列表
            //当页码数大于1时, 则显示页码
           /* if (endCount > 1)
            {
                currentPageStr += "<select id='selPagination' name='selPagination' onchange=\"javascript:qyn_jumpMenuPagination(this);\">";
                string selected = "";
                
                //中间页处理, 这个增加时间复杂度，减小空间复杂度
                for (int i = startCount; i <= endCount; i++)
                {
                    selected = i == pageIndex ? "selected=\"selected\"" : "";
                    currentPageStr += string.Format("<option value=\"{0}|{1}\" {2}>第{1}页</option>", pageSize,i,selected);
                }
                currentPageStr += "</select>";
            }*/
            #endregion

            #region 页数选择

            //currentPageStr += string.Format("每页显示<input id=\"txtPageSize\" name=\"txtPageSize\" type=\"text\" value=\"{0}\" size=\"5\" onchange=\"javascript:GetDataList(20,1)\"/ style=\"text-align:center\">条数据", pageSize);
            //currentPageStr += "&nbsp;&nbsp;";
            #endregion

            #region order
            //if (endCount > 1)
            //{
            //    currentPageStr += "&nbsp; &nbsp; &nbsp; &nbsp;";
            //}
            #endregion

            return currentPageStr;

        }
    }
}
