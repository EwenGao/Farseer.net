﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Qyn.Common.Utils;
using System.Collections;

namespace Qyn.Common.Tool
{
    /// <summary>
    /// 上传文件
    /// </summary>
   public class UpLoadFile
    {
        /// <summary>
        /// 上传文件的权限
        /// </summary>
        public struct stuUpLoadFileType
        {
            /// <summary>
            /// 允许上传的类型
            /// </summary>
            public string type;
            /// <summary>
            /// 允许上传的容量(单位：KB. 0：无限制)
            /// </summary>
            public int size;
        }

        /// <summary>
        /// 上传文件后回发的资料
        /// </summary>
        public struct stuUpLoadFile
        {
            /// <summary>
            /// 上传成功的文件名
            /// </summary>
            public string FileName;
            /// <summary>
            /// 上传成功的文件名-前缀
            /// </summary>
            public string FileNamePrefix;
            /// <summary>
            /// 上传成功的文件名-扩展名
            /// </summary>
            public string FileNameExtension;
            /// <summary>
            /// 上传成功的文件容量(单位：KB)
            /// </summary>
            public int Size;
            /// <summary>
            /// 上传成功的文件相对路径(WebPath之后的路径,不带文件名)
            /// </summary>
            public string FilePath;
            /// <summary>
            /// 上传成功的文件物理路径(不带文件名)
            /// </summary>
            public string FileMapPath;
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="webPath">网站根目录非IIS根目录</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static stuUpLoadFile[] UploadFile(HttpFileCollection files, string webPath, string filePath, int saveType)
        {
            return UploadFile(files, webPath, filePath, saveType, null, null);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="webPath">网站根目录非IIS根目录</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="stuUpLoadFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        public static stuUpLoadFile[] UploadFile(HttpFileCollection files, string webPath, string filePath, int saveType, stuUpLoadFileType[] fileType)
        {
            return UploadFile(files, webPath, filePath, saveType, fileType, null);
        }

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="files">获取要上传的文件</param>
        /// <param name="webPath">网站根目录非IIS根目录</param>
        /// <param name="filePath">要保存的文件路径,</param>
        /// <param name="stuUpLoadFileType">允许上传的文件类型,大小,单位为KB,Size=0表示无任何限制</param>
        /// <param name="saveType">保存方式：1:按时间取名</param>
        /// <param name="colName">指定只上传的组件名</param>
        public static stuUpLoadFile[] UploadFile(HttpFileCollection files, string webPath, string filePath, int saveType, stuUpLoadFileType[] fileType, string colName)
        {
            string fileName;                                                                //获取文件名全称
            string fileNamePrefix;                                                          //获取文件名前缀
            string fileNameExtension;                                                       //获取文件名后缀
            string fileMapPath;                                                             //获取目录绝对路径
            bool isfileExtension = false;                                                   //true表示属于允许上传的类型
            bool isHavaFileUpload = false;                                                  //检测是否有文件上传
            int fileContentLength;                                                          //文件容量

            #region 上传前,对文件进行安全检查判断

            #region 对参数进行转换小写
            if (fileType != null)
            {
                for (int i = 0; i < fileType.Length; i++)
                {
                    fileType[i].type = fileType[i].type.ToLower();
                }
            }
            #endregion

            #region 判断根目录,保存目录是否为空,及目录合法性,及"/"号转换
            if (webPath == null || webPath.Trim().Length == 0)
            {
                webPath = "/";
            }
            else
            {
                webPath = webPath.Replace("\\", "/");
                string[] webPaths = webPath.Split('/');
                webPath = "/";
                for (int i = 0; i < webPaths.Length; i++)
                {
                    if (webPaths[i] != null && webPaths[i].Trim().Length > 0)
                    {
                        webPath += webPaths[i] + "/";
                    }
                }

            }

            if (filePath == null || filePath.Trim().Length == 0)
            {
                new Tools.Terminator().Throw("保存路径没有填写,请联系管理员!");
                return null;
            }
            else
            {
                filePath = filePath.Replace("\\", "/");
                string[] filePaths = filePath.Split('/');
                filePath = "";
                for (int i = 0; i < filePaths.Length; i++)
                {
                    if (filePaths[i] != null && filePaths[i].Trim().Length > 0)
                    {
                        filePath += filePaths[i] + "/";
                    }
                }
            }

            #endregion

            #region 检查文件保存方式设置

            if (saveType > 1)
            {
                new Tools.Terminator().Throw("保存方式设置不对,请联系管理员!");
                return null;
            }

            #endregion

            #region 检查每个文件的合法检验

            for (int fileIndex = 0; fileIndex < files.Count; fileIndex++)
            {
                fileName = files[fileIndex].FileName.ToLower().Trim();                                          //获取文件名全称
                fileNamePrefix = System.IO.Path.GetFileNameWithoutExtension(fileName);                          //获取文件名前缀
                fileNameExtension = ParseFile.GetExtension(fileName);                                                     //获取后缀名
                fileContentLength = files[fileIndex].ContentLength / 1024;                                      //获取文件容量

                if (fileName.Length < 1)                                                                         //文件不存在时，直接跳过
                {
                    continue;
                }

                isHavaFileUpload = true;

                #region 判断文件前缀是否为空

                if (fileNamePrefix == null || fileNamePrefix == string.Empty)
                {
                    new Tools.Terminator().Throw("文件: [ " + fileName + " ] 前缀名不能为空");
                    return null;
                }

                #endregion

                #region 判断文件容量是否为0

                if (fileContentLength <= 0)
                {
                    new Tools.Terminator().Throw("文件: [ " + fileName + " ] 的大小不能为0KB");
                    return null;
                }

                #endregion

                #region 循环文件类型,长度

                if (fileType != null && fileType.Length > 0)
                {
                    isfileExtension = false;
                    for (int typeSizeIndex = 0; typeSizeIndex < fileType.Length; typeSizeIndex++)
                    {
                        #region 判断文件类型,长度是否允许上传

                        if (fileNameExtension != fileType[typeSizeIndex].type)
                        {
                            continue;
                        }

                        isfileExtension = true;

                        #region 判断文件容量是否超过上限

                        if (fileType[typeSizeIndex].size != 0)
                        {
                            if (fileContentLength > fileType[typeSizeIndex].size)
                            {
                                new Tools.Terminator().Throw("文件类型为 [ " + fileType[typeSizeIndex].type + " ] 的容量不能超过: [ " + fileType[typeSizeIndex].size + " KB ]");
                                return null;
                            }
                        }
                        #endregion

                        break;
                        #endregion
                    }

                    if (!isfileExtension)
                    {
                        new Tools.Terminator().Throw("第 [" + Convert.ToString(fileIndex + 1) + "] 个文件扩展名: [ " + fileNameExtension + " ] 不允许上传");
                        return null;
                    }
                }
                #endregion

            }

            if (!isHavaFileUpload)
            {
                new Tools.Terminator().Throw("未检查到有文件上传!");
                return null;
            }
            #endregion

            #endregion

            #region 创建文件目录(任何级别目录)
            ParseFile.CreateDirs(System.IO.Path.Combine(webPath, filePath));
            #endregion

            #region 上传文件操作
            ArrayList arrayList = new ArrayList();
            try
            {
                for (int fileIndex = 0; fileIndex < files.Count; fileIndex++)
                {
                    fileName = files[fileIndex].FileName.ToLower().Trim();                                          //获取文件名全称
                    fileNamePrefix = System.IO.Path.GetFileNameWithoutExtension(fileName);                          //获取文件名前缀
                    fileNameExtension = ParseFile.GetExtension(fileName);                                                     //获取后缀名

                    if (fileName.Length < 1)                                                                         //文件不存在时，直接跳过
                    {
                        continue;
                    }
                    stuUpLoadFile upLoadFile = new stuUpLoadFile();

                    //获取保存为的文件名
                    switch (saveType)
                    {
                        case 1:
                            fileName = DateTime.Now.ToString().Replace("-", "").Replace(" ", "").Replace(":", "") + fileIndex.ToString() + "." + fileNameExtension;
                            break;
                    }

                    fileMapPath = Utils.ParseUrl.GetMapPath(System.IO.Path.Combine(webPath, filePath));
                    files[fileIndex].SaveAs(System.IO.Path.Combine(fileMapPath, fileName));

                    upLoadFile.FileName = fileName;
                    upLoadFile.FileNamePrefix = fileNamePrefix;
                    upLoadFile.FileNameExtension = fileNameExtension;
                    upLoadFile.Size = (files[fileIndex].ContentLength > 1024) ? files[fileIndex].ContentLength / 1024 : 1;
                    upLoadFile.FilePath = filePath;
                    upLoadFile.FileMapPath = fileMapPath;
                    arrayList.Add(upLoadFile);
                }
            }

            catch (Exception Ex)
            {
                new Tools.Terminator().Throw(Ex.Message.ToString());
                return null;
            }
            #endregion

            #region 合并数据
            stuUpLoadFile[] uploadFiles = new stuUpLoadFile[arrayList.Count];
            for (int filesIndex = 0; filesIndex < arrayList.Count; filesIndex++)
            {
                uploadFiles[filesIndex] = (stuUpLoadFile)arrayList[filesIndex];
            }
            #endregion

            return uploadFiles;
        }
    }
}
