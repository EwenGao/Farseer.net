using System;
using System.IO;
using System.Xml.Serialization;
using System.Web;
using System.Windows.Forms;

namespace Qyn.Common.Tools
{
	/// <summary>
	/// SerializationHelper ��ժҪ˵����
	/// </summary>
	public class SerializationHelper
	{
		/// <summary>
		/// �����л�
		/// </summary>
		/// <param name="type">��������</param>
        /// <param name="filePath">�ļ�·��</param>
		/// <returns></returns>
		public static T Load<T>(T t, string filePath)
		{
            T m_T=default(T);
            string __filePath = filePath.IndexOf(":") > -1 ? Utils.ParseUrl.GetMapPath(filePath) : filePath;
			FileStream fs = null;
			try
			{
                fs = new FileStream(__filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                XmlSerializer serializer = new XmlSerializer(t.GetType());
				m_T= (T)serializer.Deserialize(fs);
			}
			catch(Exception ex)
			{
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
			}
			finally
			{
				if(fs != null)
					fs.Close();
			}
            return m_T;
		}


		/// <summary>
		/// ���л�
		/// </summary>
		/// <param name="obj">����</param>
		/// <param name="filename">�ļ�·��</param>
        public static bool Save<T>(T t, string filePath)
		{
            string __filePath =  Utils.ParseUrl.GetMapPath(filePath);
            Utils.ParseFile.CreateDirs(__filePath.Substring(0, __filePath.LastIndexOf("/")));
            bool succeed = false;
			FileStream fs = null;
			try
			{
                fs = new FileStream(__filePath, FileMode.Create, FileAccess.Write, FileShare.ReadWrite);
				XmlSerializer serializer = new XmlSerializer(t.GetType());
                serializer.Serialize(fs, t);
                succeed = true;
			}
			catch(Exception ex)
			{
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
			}
			finally
			{
				if(fs != null)
					fs.Close();
			}
            return succeed;

		}
	}
}
