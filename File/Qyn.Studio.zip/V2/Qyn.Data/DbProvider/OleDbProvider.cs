﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Web;
using System.Windows.Forms;

using Qyn.ExtensionMethods;
using Qyn.Common.Tools;

namespace Qyn.Data
{
    public class OleDbExecutor : IDbProvider
    {
        public OleDbExecutor() { }

        public OleDbExecutor(string connnection)
        {
            this.ConnectionString = connnection;
        }

        string _connectinString;
        /// <summary>
        /// 连接字符串 
        /// </summary>
        public string ConnectionString
        {
            get { return _connectinString; }
            set { _connectinString = value; }
        }

        #region IDbExector成员

        public Object ExecuteScalar(CommandType cmmType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmmType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((OleDbParameter)parameters[i]);
                return comm.ExecuteScalar();
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "发生错误");
                }
                return null;
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
        }

        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((OleDbParameter)parameters[i]);
                return comm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "发生错误");
                }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return 0;
        }

        public int ExecuteTranSql(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = null;
            OleDbTransaction tran = null;
            int result = 0;
            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                comm = new OleDbCommand(cmdText, conn);
                comm.Transaction = tran;
                comm.CommandType = cmdType;

                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((OleDbParameter)parameters[i]);
                result = comm.ExecuteNonQuery();
                tran.Commit();
            }
            catch (OleDbException ex)
            {
                if (tran != null) tran.Rollback();
                result = 0;
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "发生错误");
                }
            }
            finally
            {
                if (tran != null) tran.Commit();
                comm.Dispose();
            }
            return result;
        }


        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((OleDbParameter)parameters[i]);
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "发生错误");
                }
                return null;
            }
        }

        public DataSet GetDataSet(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            OleDbConnection conn = new OleDbConnection(this.ConnectionString);
            OleDbCommand comm = new OleDbCommand(cmdText, conn);
            comm.CommandType = cmdType;
            OleDbDataAdapter ada = new OleDbDataAdapter(comm);
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((OleDbParameter)parameters[i]);
                DataSet ds = new DataSet();
                ada.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "发生错误");
                }
            }
            finally
            {
                comm.Parameters.Clear();
                ada.Dispose();
                comm.Dispose();
                conn.Dispose();
            }
            return new DataSet();
        }

        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            if (ds.Tables.Count == 0) { return new DataTable(); }
            return ds.Tables[0];
        }


        public void Dispose() { }
        #endregion

    }

}
