using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using System.Web;
using System.Windows.Forms;

using Qyn.ExtensionMethods;
using Qyn.Common.Tools;

namespace Qyn.Data
{
    public class MySqlExector : IDbProvider
    {
        public MySqlExector() { }


        public MySqlExector(string connection)
        {
            _connectinString = connection;
        }


        string _connectinString;
        /// <summary>
        /// �����ַ��� 
        /// </summary>
        public string ConnectionString
        {
            get { return _connectinString; }
            set { _connectinString = value; }
        }


        #region IDbExecutor ��Ա

        public object ExecuteScalar(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((MySqlParameter)parameters[i]);
                return comm.ExecuteScalar();
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
                return null;
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
        }

        public int ExecuteNonQuery(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((MySqlParameter)parameters[i]);
                return comm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
                return 0;
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
        }

        public int ExecuteTranSql(CommandType cmdType, string cmdText , params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = null;
            MySqlTransaction tran = null;

            int result = 0;
            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                comm = new MySqlCommand(cmdText, conn);
                comm.Transaction = tran;
                comm.CommandType = cmdType;
                
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((MySqlParameter)parameters[i]);
                result = comm.ExecuteNonQuery();
                tran.Commit();
            }
            catch (MySqlException ex)
            {
                if (ex.Number != 1205 && tran != null) tran.Rollback();
                result = 0;
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
            }
            finally
            {
                if (tran != null)  tran.Commit();
                comm.Dispose();
            }
            return result;
        }

        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((MySqlParameter)parameters[i]);
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
                return null;
            }
        }

        public DataSet GetDataSet(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            MySqlConnection conn = new MySqlConnection(this.ConnectionString);
            MySqlCommand comm = new MySqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            MySqlDataAdapter ada = new MySqlDataAdapter(comm);
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((MySqlParameter)parameters[i]);
                DataSet ds = new DataSet();
                ada.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
            }
            finally
            {
                comm.Parameters.Clear();
                ada.Dispose();
                comm.Dispose();
                conn.Dispose();
            }
            return new DataSet();
        }

        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            if (ds.Tables.Count == 0) { return new DataTable(); }
            return ds.Tables[0];
        }

        public DataRow GetDataRow(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataTable dt = GetDataTable(cmdType, cmdText, parameters);
            if (dt.Rows.Count == 0) { return new DataTable().NewRow(); }
            return dt.Rows[0];
        }

        public List<DataRow> GetDataRowList(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataTable dt = GetDataTable(cmdType, cmdText, parameters);

            if (dt.Rows.Count == 0) { return new List<DataRow>(); }

            return dt.Rows.ToRows();
        }
        #endregion

        #region IDisposable ��Ա

        public void Dispose()
        {
           
        }

        #endregion
    }
}
