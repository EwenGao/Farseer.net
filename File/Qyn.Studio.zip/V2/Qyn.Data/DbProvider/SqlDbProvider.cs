using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Windows.Forms;

using Qyn.ExtensionMethods;
using Qyn.Common.Tools;

namespace Qyn.Data
{
	/// <summary>
	/// Sql Server���ݴ�ȡ����
	/// </summary>
    public class SqlDbProvider : IDbProvider
	{
		public SqlDbProvider(){	}

        public SqlDbProvider(string connectString)
		{
			this.ConnectionString = connectString;
		}

        private string ConnectionString;

		#region	IDbExector ��Ա

		public Object ExecuteScalar(CommandType cmdType,string cmdText,params IDbDataParameter[] parameters)
		{
			SqlConnection conn = new SqlConnection(this.ConnectionString);
			SqlCommand comm = new SqlCommand(cmdText,conn);
			comm.CommandType = cmdType;
			try
			{
				conn.Open();
				if(parameters != null)
					for(int i=0;i<parameters.Length;i++)
						comm.Parameters.Add((SqlParameter)parameters[i]);
				return comm.ExecuteScalar();
			}
			catch(Exception ex)
			{
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
                return null;
			}
			finally
			{
				comm.Dispose();
				conn.Dispose();
			}				
		}


		public int ExecuteNonQuery(CommandType cmdType,string cmdText,params IDbDataParameter[] parameters)
		{
            SqlConnection conn = new SqlConnection(this.ConnectionString);
            SqlCommand comm = new SqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((SqlParameter)parameters[i]);
                return comm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
            }
            finally
            {
                comm.Dispose();
                conn.Dispose();
            }
            return 0;
		}

        public int ExecuteTranSql(CommandType cmdType, string cmdText,  params IDbDataParameter[] parameters)
        {
            SqlConnection conn = new SqlConnection(this.ConnectionString);
            SqlCommand comm = null;
            SqlTransaction tran = null;

            int result = 0;
            try
            {
                conn.Open();
                tran = conn.BeginTransaction();
                comm = new SqlCommand(cmdText, conn);
                comm.Transaction = tran;
                comm.CommandType = cmdType;

                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((SqlParameter)parameters[i]);
                result  = comm.ExecuteNonQuery();
                tran.Commit();
            }
            catch (SqlException ex)
            {
                if (ex.Number !=1205 && tran != null) tran.Rollback();
                result = 0;
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
            }
            finally
            {
                comm.Dispose();
            }
            return result;
        }


        public IDataReader GetReader(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            SqlConnection conn = new SqlConnection(this.ConnectionString);
            SqlCommand comm = new SqlCommand(cmdText, conn);
            comm.CommandType = cmdType;
            try
            {
                conn.Open();
                if (parameters != null)
                    for (int i = 0; i < parameters.Length; i++)
                        comm.Parameters.Add((SqlParameter)parameters[i]);
                return comm.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception ex)
            {
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
                return null;
            }
            finally
            {
                comm.Dispose();
            }
        }

		public DataSet GetDataSet(CommandType cmdType,string cmdText,params IDbDataParameter[] parameters)
		{
			SqlConnection conn = new SqlConnection(this.ConnectionString);
			SqlCommand comm = new SqlCommand(cmdText,conn);
			comm.CommandType = cmdType;
			SqlDataAdapter ada = new SqlDataAdapter(comm);
			try
			{
				conn.Open();
				if(parameters != null)
					for(int i=0;i<parameters.Length;i++)
						comm.Parameters.Add((SqlParameter)parameters[i]);
				DataSet ds = new DataSet();
				ada.Fill(ds);
				return ds;
			}
			catch(Exception ex)
			{
                HttpContext context = HttpContext.Current;
                if (context != null)
                {
                    new Terminator().Throw(ex.Message);
                }
                else
                {
                    MessageBox.Show(ex.Message, "��������");
                }
			}
			finally
			{
				comm.Parameters.Clear();
				ada.Dispose();
				comm.Dispose();
				conn.Dispose();
			}
            return new DataSet();
		}

        public DataTable GetDataTable(CommandType cmdType, string cmdText, params IDbDataParameter[] parameters)
        {
            DataSet ds = GetDataSet(cmdType, cmdText, parameters);
            if (ds.Tables.Count == 0) { return new DataTable(); }
            return ds.Tables[0];
        }

		public void Dispose(){	}

		#endregion	


        #region ======= ˽�з��� =======

        /// <summary>
        /// �������ݵ��µı���
        /// </summary>
        /// <param name="connString">Ŀ�����ݿ�������ַ���</param>
        /// <param name="tabName">����</param>
        /// <param name="sourceData">����Դ</param>
        public static void BulkCopy(string connString, string tabName, object sourceData)
        {
          
            using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connString))
            {
                try
                {
                    bulkCopy.DestinationTableName = "dbo." + tabName;
                    switch (sourceData.GetType().Name)
                    {
                        case "DataTable":
                            bulkCopy.WriteToServer((DataTable)sourceData);
                            break;
                        case "DataRow[]":
                            bulkCopy.WriteToServer((DataRow[])sourceData);
                            break;
                        case "IDataReader":
                             bulkCopy.WriteToServer((IDataReader)sourceData);
                            break;
                    }

                }
                catch(Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (sourceData.GetType().Name == "IDataReader")
                    {
                        ((IDataReader)sourceData).Close();
                    }
                }
            }

           
        }



        #endregion
    }
}
