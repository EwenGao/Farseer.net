using System;

namespace Qyn.Data
{
	/// <summary>
	/// ���ݴ洢����
	/// �õ������ַ��������洢��ʵ��
	/// </summary>
	public class DbFactory
	{

        public static IDbProvider CreateExecutor(string connectString)
		{
            return new SqlDbProvider(connectString);
		}

        public static IDbProvider CreateExecutor(DataBaseType dataType, string connectinString)
        {
            IDbProvider executor;
            switch (dataType)
            {
                case DataBaseType.Access:
                    executor = new OleDbExecutor(connectinString);
                    break;
                case DataBaseType.MySql:
                    executor = new MySqlExector(connectinString);
                    break;
                default:
                    executor = CreateExecutor(connectinString);
                    break;
            }
            return executor;
        }

		public DbFactory()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
	}
}
