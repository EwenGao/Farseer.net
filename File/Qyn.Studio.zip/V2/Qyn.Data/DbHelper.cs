﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

using Qyn.Configs;

namespace Qyn.Data
{
    public class DbHelper
    {
        private string m_ConnectionString;
        
        private DataBaseType m_DataType;

        /// <summary>
        /// 数据库类型
        /// </summary>
        protected DataBaseType DataType
        {
            get { return m_DataType; }
            set { m_DataType = value; }
        }

        /// <summary>
        /// 数据库连接的字符串
        /// </summary>
        protected string ConnectString
        {
            get { return m_ConnectionString; }
            set { m_ConnectionString = value; }
        }

        protected DbHelper()
       {
           m_ConnectionString = DbConfigs.ConfigInfo.Default_DbConnectString;
       }

        protected DbHelper(string connectionString)
       {
           m_ConnectionString = connectionString;
       }

        protected DbHelper(string connectionString, DataBaseType dataType)
       {
           m_ConnectionString = connectionString;
       }

       /// <summary>
       /// 创建一个数据库连接
       /// </summary>
       /// <returns></returns>
       protected IDbConnection NewConnection()
       {
           IDbConnection connection;
           switch (DataType)
           {
               case DataBaseType.Access:
                   connection = new OleDbConnection(ConnectString);
                   break;
               case DataBaseType.MySql:
                   connection = new MySqlConnection(ConnectString);
                   break;
               default:
                   connection = new SqlConnection(this.ConnectString);
                   break;
           }
           
           return connection;
       }

       /// <summary>
       /// 创建一个数据库参数对象
       /// </summary>
       /// <param name="name">参数名称</param>
       /// <param name="valu">参数值</param>
       /// <param name="type">参数类型</param>
       /// <param name="len">参数长度</param>
       /// <param name="output">是否是输出值</param>
       protected IDbDataParameter NewParam(string name, object valu, DbType type, int len, bool output)
       {
           IDbDataParameter param;
           switch (DataType)
           {
               case DataBaseType.Access:
                   param = new OleDbParameter();
                   break;
               case DataBaseType.MySql:
                   param = new MySqlParameter();
                   break;
               default:
                   param = new SqlParameter();
                   break;
           }
           param.DbType = type;
           param.ParameterName = name;
           param.Value = valu;
           if (len > 0) param.Size = len;
           if (output) param.Direction = ParameterDirection.Output;
           return param;
       }

       /// <summary>
       /// 创建一个数据库参数对象
       /// </summary>
       protected IDbDataParameter NewParam(string name, object valu, DbType type, int len)
       {
           return this.NewParam(name, valu, type, len, false);
       }

       /// <summary>
       /// 创建一个数据库参数对象
       /// </summary>
       protected IDbDataParameter NewParam(string name, object valu)
       {
           switch (valu.GetType().Name)
           {
               case "String":
                   return this.NewParam(name, valu, DbType.String, 0);
               case "DateTime":
                   return this.NewParam(name, valu, DbType.DateTime, 8);
               case "Boolean":
                   return this.NewParam(name, valu, DbType.Boolean, 1);
               case "Int32":
                   return this.NewParam(name, valu, DbType.Int32, 4);
               case "Int16":
                   return this.NewParam(name, valu, DbType.Int16, 2);
               case "Decimal":
                   return this.NewParam(name, valu, DbType.Decimal, 8);
               case "Byte":
                   return this.NewParam(name, valu, DbType.Byte, 1);
               default:
                   return this.NewParam(name, valu, DbType.String, 0);
           }
       }

       /// <summary>
       /// 创建一个数据库执行对象
       /// </summary>
       /// <returns></returns>
       protected IDbProvider NewDbProvider()
       {
           return DbFactory.CreateExecutor(this.DataType, this.ConnectString);
       }


       #region IDisposable 成员

       public void Dispose()
       {
           // TODO:  添加 DataAgent.Dispose 实现
       }

       #endregion
    }

    /// <summary>
    /// 数据库类型
    /// </summary>
    public enum DataBaseType
    {
        SqlServer = 1,
        Access = 2,
        MySql = 3
    }
}
