﻿using System;
using System.IO;
using System.Xml.Serialization;
using System.Text;
using System.Web;
using System.Windows.Forms;

using Qyn.Common.Utils;
using Qyn.Common.Tools;

namespace Qyn.Configs
{

    /// <summary>
    /// 文件配置管理基类
    /// </summary>
    public class DefaultConfigFileManager
    {
        /// <summary>
        /// 锁对象
        /// </summary>
        private static object m_LockHelper = new object();

        /// <summary>
        /// 加载(反序列化)指定对象类型的配置对象
        /// </summary>
        /// <param name="checkTime">是否检查并更新传递进来的"文件加载时间"变量</param>
        public static T LoadConfig<T>(ref DateTime fileoldchange, string configFilePath, T t, bool checkTime)
        {
            T m_T=default(T);

            if (checkTime)                                                                       //是否检查并更新传递进来的"文件加载时间"变量
            {
                DateTime m_filenewchange = System.IO.File.GetLastWriteTime(configFilePath);    //保存文件最后修改的时间

                //当程序运行中config文件发生变化时则对config重新赋值
                if (fileoldchange != m_filenewchange)                                           //如果保存的修改时间与上一次修改时间不致,表明此文件已更改过
                {
                    fileoldchange = m_filenewchange;                                            //重新获取时间值.
                }
            }


            lock (m_LockHelper)
            {
                m_T = SerializationHelper.Load<T>(t,configFilePath);               //反序列化(加载)Config文件
            }

            return m_T;
        }

        /// <summary>
        /// 保存(序列化)指定路径下的配置文件
        /// </summary>
        public static bool Serializable<T>(string configFilePath, T t )
        {
            return SerializationHelper.Save<T>(t, configFilePath);
        }

        /// <summary>
        /// 获取配置文件所在路径
        /// </summary>
        public static string GetConfigFilePath(string fileName)
        {
            string m_ConfigFilePath;
            HttpContext context = HttpContext.Current;
            if (context != null)
            {
                m_ConfigFilePath = context.Server.MapPath("~/App_Data/" + fileName);
            }
            else
            {
                m_ConfigFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Config/" + fileName);
            }
            m_ConfigFilePath = m_ConfigFilePath.Replace("\\", "/");

            return m_ConfigFilePath;
        }

        /// <summary>
        /// 自动创建Info文件
        /// </summary>
        public static bool AutoCreateInfo<T>(string configFilePath, T t)
        {
            if (!File.Exists(configFilePath))
            {
                return Serializable<T>(configFilePath,  t);
            }
            return true;
        }
    }
}
