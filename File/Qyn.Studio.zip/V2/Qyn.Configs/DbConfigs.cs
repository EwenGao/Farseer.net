﻿using System;
using Qyn.ConfigInfo;

namespace Qyn.Configs
{
    /// <summary>
    /// 基本设置类
    /// </summary>
    public class DbConfigs
    {
        /// <summary> 
        /// 刷新计时器
        /// </summary>
        private static System.Timers.Timer m_DbConfigTimer;

        /// <summary>
        /// 配置变量
        /// </summary>
        private static DbConfigInfo m_ConfigInfo;

        /// <summary>
        /// 文件名
        /// </summary>
        public static string FileName;

        /// <summary>
        /// 文件路径
        /// </summary>
        private static string FilePath;

        /// <summary>
        /// Config修改时间
        /// </summary>
        public static DateTime FileOldChange;

        /// <summary>
        /// 配置变量
        /// </summary>
        public static DbConfigInfo ConfigInfo
        {
            get
            {
                if (m_ConfigInfo == null)
                {
                    m_ConfigInfo = (DbConfigInfo)DefaultConfigFileManager.LoadConfig(ref FileOldChange, FilePath, new DbConfigInfo(), true);
                }
                return m_ConfigInfo;
            }
        }

        /// <summary>
        /// 静态构造函数初始化相应实例和定时器
        /// </summary>
        static DbConfigs()
        {
            FileName = "Db.config";
            m_DbConfigTimer = new System.Timers.Timer();
            m_DbConfigTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);            //委托Timer_Elapsed事件          //读取Config文件.

            ResetConfig();
        }

        /// <summary>
        /// Timer_Elapsed
        /// </summary>
        private static void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            ResetConfig();
        }

        /// <summary>
        /// 重设配置类实例
        /// </summary>
        public static void ResetConfig()
        {

            FilePath = DefaultConfigFileManager.GetConfigFilePath(FileName);
            DefaultConfigFileManager.AutoCreateInfo(FilePath, new DbConfigInfo());

            FileOldChange = System.IO.File.GetLastWriteTime(FilePath);
            

            AutoResetOpen(true, 60);
        }

        /// <summary>
        /// 保存配置实例
        /// </summary>
        public static bool SaveConfig(DbConfigInfo dbConfigInfo)
        {
            bool result = DefaultConfigFileManager.Serializable(FilePath, dbConfigInfo);
            if (result) { m_ConfigInfo = null; }
            return result;
        }

        /// <summary>
        /// 开启自动检测Config
        /// </summary>
        /// <param name="isOpen">true：开启,false:关闭</param>
        public static void AutoResetOpen(bool isOpen, double time)
        {
            time = time * 1000;
            if (isOpen)
            {
                m_DbConfigTimer = new System.Timers.Timer(time);
                m_DbConfigTimer.AutoReset = true;                                                           //连续运行Time
                m_DbConfigTimer.Enabled = true;                                                             //激活事件
                m_DbConfigTimer.Start();
            }
            else
            {
                if (m_DbConfigTimer != null)
                {
                    m_DbConfigTimer.AutoReset = false;
                    m_DbConfigTimer.Enabled = false;
                    m_DbConfigTimer.Close();
                }
            }
        }

    }
}
