﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

using System.Data;

namespace Qyn.Cache
{
    public class QynCache
    {
        private static System.Web.Caching.Cache webCache = System.Web.HttpRuntime.Cache;

        /// <summary>
        /// 设置到期相对时间[单位：／分钟]
        /// 默认缓存存活期为1440分钟(24小时)
        /// </summary>
        public static int TimeOut = 1440;

        /// <summary>
        /// 添加对像
        /// </summary>
        public static void Add<T>(string key, T t)
        {
            if (key != null && key.Length > 0 && t != null)
            {
                webCache.Insert(key, t, null, DateTime.Now.AddMinutes(TimeOut), System.Web.Caching.Cache.NoSlidingExpiration);
            }
        }

        /// <summary>
        /// 返回对像
        /// </summary>
        public static T Get<T>(string key)
        {
            if (key == null || key.Length == 0) { return default(T); }
            return (T)webCache.Get(key);

        }

        /// <summary>
        /// 删除对像
        /// </summary>
        public static void Clear(string key)
        {
            if (key == null || key.Length == 0) { return ; }
            webCache.Remove(key);
        }
    }
}
