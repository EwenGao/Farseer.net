﻿using System;

namespace Qyn.ConfigInfo
{
    /// <summary>
    /// 基本设置描述类, 加[Serializable]标记为可序列化
    /// </summary>
    [Serializable]
    public class BaseConfigInfo
    {
        #region 私有字段

        /// <summary>
        /// 网站路径
        /// </summary>
        private string m_WebPath = "/wwwroot/";

        /// <summary>
        /// 是否调试
        /// </summary>
        private bool m_DeBug = false;

        /// <summary>
        /// 前台模板名称
        /// </summary>
        private string m_WebTemplates = "Default";

        /// <summary>
        /// 前台页面伪aspx后缀名
        /// </summary>
        private string m_WebPageExtension = ".qyn";

        /// <summary>
        /// 后台模板名称
        /// </summary>
        private string m_AdminTemplates = "Default";

        /// <summary>
        /// 后台页面伪aspx后缀名
        /// </summary>
        private string m_AdminPageExtension = ".qynx";


        #endregion

        #region 属性

        /// <summary>
        /// 网站路径
        /// </summary>
        public string WebPath
        {
            get { return m_WebPath; }
            set { m_WebPath = value; }
        }

        /// <summary>
        /// 是否调试
        /// </summary>
        public bool DeBug
        {
            get { return m_DeBug; }
            set { m_DeBug = value; }
        }

        /// <summary>
        /// 前台模板名称
        /// </summary>
        public string WebTemplates
        {
            get { return m_WebTemplates; }
            set { m_WebTemplates = value; }
        }

        /// <summary>
        /// 前台页面伪aspx后缀名
        /// </summary>
        public string WebPageExtension
        {
            get { return m_WebPageExtension; }
            set { m_WebPageExtension = value; }
        }

        /// <summary>
        /// 后台模板名称
        /// </summary>
        public string AdminTemplates
        {
            get { return m_AdminTemplates; }
            set { m_AdminTemplates = value; }
        }

        /// <summary>
        /// 后台页面伪aspx后缀名
        /// </summary>
        public string AdminPageExtension
        {
            get { return m_AdminPageExtension; }
            set { m_AdminPageExtension = value; }
        }
        #endregion
    }
}
