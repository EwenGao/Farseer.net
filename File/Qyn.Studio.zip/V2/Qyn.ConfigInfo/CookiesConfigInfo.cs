﻿using System;

namespace Qyn.ConfigInfo
{
	/// <summary>
	/// 网站基本设置描述类, 加[Serializable]标记为可序列化
	/// </summary>
	[Serializable]
    public class CookiesConfigInfo
    {
        #region 私有字段

        private string m_Cookies_User_Id = "UserId";             //用户ID的Cookies标识
        private string m_Cookies_User_Name = "UserName";         //用户名的Cookies标识
        private string m_Cookies_User_GroupId = "UserGroupId";       //用户组ID的Cookies标识
        private string m_Cookies_User_GroupName = "UserGroupName";   //用户组名称的Cookies标识
        private string m_Cookies_User_NewPMCount = "NewPMCount";     //新短消息的Cookies标识
        private string m_Cookies_User_ShoppingState = "ShoppingState";//允许购物状态的Cookies标识
        private int m_Cookies_User_TimeOut = 20;                     //用户在线超时时间
       
        private string m_Cookies_Admin_Id = "AdminId";           //管理员ID的Cookies
        private string m_Cookies_Admin_Name = "AdminName";       //管理员名称的Cookies
        private string m_Cookies_Admin_Purview = "AdminPurview"; //管理员权限的Cookies
        private int m_Cookies_Admin_TimeOut = 20;                     //管理员在线超时时间

        private string m_Session_User_VerifyCode = "UserCode";   //用户登陆验证码的Session
        private string m_Session_Admin_VerifyCode = "AdminCode";      //管理员登陆验证码的Session

        #endregion

        #region 属性

		
        /// <summary>
        /// 用户ID的Cookies
        /// </summary>
        public string Cookies_User_Id
        {
            get { return m_Cookies_User_Id; }
            set { m_Cookies_User_Id = value; }
        }

        /// <summary>
        /// 用户名的Cookies
        /// </summary>
        public string Cookies_User_Name
        {
            get { return m_Cookies_User_Name ; }
            set { m_Cookies_User_Name = value; }
        }

        /// <summary>
        /// 用户组ID的Cookies标识
        /// </summary>
        public string Cookies_User_GroupId
        {
            get { return m_Cookies_User_GroupId; }
            set { m_Cookies_User_GroupId = value; }
        }

        /// <summary>
        /// 用户组名称的Cookies标识
        /// </summary>
        public string Cookies_User_GroupName
        {
            get { return m_Cookies_User_GroupName; }
            set { m_Cookies_User_GroupName = value; }
        }

        /// <summary>
        /// 新短消息的Cookies标识
        /// </summary>
        public string Cookies_User_NewPMCount
        {
            get { return m_Cookies_User_NewPMCount; }
            set { m_Cookies_User_NewPMCount = value; }
        }

        /// <summary>
        /// 允许购物状态的Cookies标识
        /// </summary>
        public string Cookies_User_ShoppingState
        {
            get { return m_Cookies_User_ShoppingState; }
            set { m_Cookies_User_ShoppingState = value; }
        }

        /// <summary>
        /// 用户在线超时时间
        /// </summary>
        public int Cookies_User_TimeOut
        {
            get { return m_Cookies_User_TimeOut; }
            set { m_Cookies_User_TimeOut = value; }
        }

        /// <summary>
        /// 用户登陆验证码的Session
        /// </summary>
        public string Session_User_VerifyCode
        {
            get { return m_Session_User_VerifyCode; }
            set { m_Session_User_VerifyCode = value; }
        }

        /// <summary>
        /// 管理员登陆验证码的Session
        /// </summary>
        public string Session_Admin_VerifyCode
        {
            get { return m_Session_Admin_VerifyCode; }
            set { m_Session_Admin_VerifyCode = value; }
        }

        /// <summary>
        /// 管理员ID的Cookies
        /// </summary>
        public string Cookies_Admin_Id
        {
            get { return m_Cookies_Admin_Id; }
            set { m_Cookies_Admin_Id = value; }
        }

        /// <summary>
        /// 管理员名称的Cookies
        /// </summary>
        public string Cookies_Admin_Name
        {
            get { return m_Cookies_Admin_Name; }
            set { m_Cookies_Admin_Name = value; }
        }

        /// <summary>
        /// 管理员权限的Cookies
        /// </summary>
        public string Cookies_Admin_Purview
        {
            get { return m_Cookies_Admin_Purview; }
            set { m_Cookies_Admin_Purview = value; }
        }

        /// <summary>
        /// 管理员在线超时时间
        /// </summary>
        public int Cookies_Admin_TimeOut
        {
            get { return m_Cookies_Admin_TimeOut; }
            set { m_Cookies_Admin_TimeOut = value; }
        }
        #endregion
    }
}
