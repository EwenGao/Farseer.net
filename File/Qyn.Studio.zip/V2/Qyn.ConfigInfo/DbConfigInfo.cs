﻿using System;

namespace Qyn.ConfigInfo
{
    /// <summary>
    /// 基本设置描述类, 加[Serializable]标记为可序列化
    /// </summary>
    [Serializable]
    public class DbConfigInfo
    {

        /// <summary>
        /// 数据库连接串
        /// </summary>
        public string Default_DbConnectString = "Data Source=.;User ID=sa;Password=123456;Initial Catalog=qyn;Pooling=true";

        /// <summary>
        /// 数据库类型
        /// </summary>
        public string Default_DbType = "SqlServer";

        /// <summary>
        /// 数据库版本
        /// </summary>
        public string Default_DbVer = "2005";

        /// <summary>
        /// 数据库表前缀
        /// </summary>
        public string Default_Tableprefix = "";


    }
}
