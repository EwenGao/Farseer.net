﻿using System;

namespace Qyn.ConfigInfo
{
	/// <summary>
	/// 网站基本设置描述类, 加[Serializable]标记为可序列化
	/// </summary>
	[Serializable]
    public class GeneralConfigInfo
    {
        /// <summary>
        /// 网站名称
        /// </summary>
		public string WebTitle = "SeaGame";

        /// <summary>
        /// 登陆入口页面
        /// </summary>
        public string AdminLoginUrl = "login.aspx";

        /// <summary>
        /// 每页显示记录
        /// </summary>
        public int PageSize = 20;
        
    }
}
