﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

using Qyn.Common.Utils;
using Qyn.Common;
using Qyn.Configs;
using Qyn.Logic;
using Qyn.Entity;
using Qyn.Web.UI;

namespace Qyn.Web.UI
{
    public class WebBasePage : BasePage
    {
        /// <summary>
        /// 用户ID
        /// </summary>
        public int UserId;
        /// <summary>
        /// 用户名称
        /// </summary>
        public string UserName;
        /// <summary>
        /// 用户组ID
        /// </summary>
        public int GroupId;
        /// <summary>
        /// 用户组类型(0、用户组；1、代理商)
        /// </summary>
        public int GroupType;
        /// <summary>
        /// 用户组名称
        /// </summary>
        public string GroupName;
        /// <summary>
        /// 消息数量
        /// </summary>
        public int NewPMCount;
        /// <summary>
        /// 是否允许购物(false:禁止；true:允许)
        /// </summary>
        public bool ShoppingState;
        /// <summary>
        /// 页面伪aspx后缀名
        /// </summary>
        public string PageExtension
        {
            get
            {
                if (BaseConfigs.ConfigInfo.WebPageExtension.Length == 0)
                {
                    return ".aspx";
                }
                return BaseConfigs.ConfigInfo.WebPageExtension;
            }
        }

        public WebBasePage()
        {
            //Templates = BaseConfigs.ConfigInfo.WebTemplates;
            GetUserCookies();
            DeBug();
        }

        /// <summary>
        /// 获取用户信息Cookies
        /// </summary>
        public void GetUserCookies()
        {
            //UserId = ParseCookies.GetCookie(CookiesConfigs.ConfigInfo.Cookies_User_Id, -1);
            //UserName = ParseCookies.GetCookie(CookiesConfigs.ConfigInfo.Cookies_User_Name);
            //GroupId = ParseCookies.GetCookie(CookiesConfigs.ConfigInfo.Cookies_User_GroupId, -1);
           // GroupName = ParseCookies.GetCookie(CookiesConfigs.ConfigInfo.Cookies_User_GroupName);
            //NewPMCount = ParseCookies.GetCookie(CookiesConfigs.ConfigInfo.Cookies_User_NewPMCount, 0);
            //ShoppingState = ParseType.StrToBool(ParseCookies.GetCookie(CookiesConfigs.ConfigInfo.Cookies_User_ShoppingState, 0), false);

            if (UserId > 0)
            {
                #region 更新用户活动时间
                //UserOnline.UpdateActionTime(UserId);
                #endregion
            }
        }

        /// <summary>
        /// 写入用户信息Cookies
        /// </summary>
        /// <param name="userId">用户ID</param>
        public void WriteUserCookies(int userId)
        {
            int timeOut = CookiesConfigs.ConfigInfo.Cookies_User_TimeOut;
            if (timeOut == 0)
            {
                timeOut = 99999;
            }
            //UsersInfo.Get_Info __Get_Info = Users.Get_Info(userId);
            //ParseCookies.WriteCookie(CookiesConfigs.ConfigInfo.Cookies_User_Id, userId.ToString(), timeOut);
            //ParseCookies.WriteCookie(CookiesConfigs.ConfigInfo.Cookies_User_Name, __Get_Info.UserName, timeOut);
            //ParseCookies.WriteCookie(CookiesConfigs.ConfigInfo.Cookies_User_GroupId, __Get_Info.GroupId.ToString(), timeOut);
            //ParseCookies.WriteCookie(CookiesConfigs.ConfigInfo.Cookies_User_GroupName, __Get_Info.UserName, timeOut);
            //ParseCookies.WriteCookie(CookiesConfigs.ConfigInfo.Cookies_User_NewPMCount, __Get_Info.NewPMCount.ToString(), timeOut);
            //ParseCookies.WriteCookie(CookiesConfigs.ConfigInfo.Cookies_User_ShoppingState, __Get_Info.ShoppingState.ToString(), timeOut);
        }

        /// <summary>
        /// 更新Session、Cookies活动时间
        /// </summary>
        public void WriteSession()
        {
            string key = "UserActionTime";
            ParseSession.Set(key, DateTime.Now.ToString());
            //ParseCookies.WriteCookie(key, DateTime.Now.ToString());
        }

    }
}
