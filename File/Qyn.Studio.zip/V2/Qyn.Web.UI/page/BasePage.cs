﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Qyn.Configs;
using Qyn.Common.Tools;

namespace Qyn.Web.UI
{
    public class BasePage : System.Web.UI.Page
    {
        /// <summary>
        /// 网站存放文件夹(相对当前主机的根目录)
        /// </summary>
        public string WebPath;
        /// <summary>
        /// 网站域名
        /// </summary>
        public string DoMain;
        /// <summary>
        /// 网站地址（网站程序根目录,带域名）
        /// </summary>
        public string WebUrl;

        /// <summary>
        /// HttpContext.Current.Request
        /// </summary>
        public HttpRequest BaseRequest = HttpContext.Current.Request;
        /// <summary>
        /// HttpContext.Current.Response
        /// </summary>
        public HttpResponse BaseResponse = HttpContext.Current.Response;

        public BasePage()
        {
            WebPath = BaseConfigs.ConfigInfo.WebPath;
            DoMain = QynRequest.GetUrl(QynRequest.UrlType.Domain);
            WebUrl = DoMain + WebPath;

            DeBug();
        }


        public void DeBug()
        {
            //清空缓存，免登陆等
            if (BaseConfigs.ConfigInfo.DeBug)
            {
                GeneralConfigs.ResetConfig();
                BaseConfigs.ResetConfig();
                CookiesConfigs.ResetConfig();
                DbConfigs.ResetConfig();
                EmailConfigs.ResetConfig();

                //GeneralConfigInfo generalConfig = new GeneralConfigInfo();
                //GeneralConfigs.SaveConfig(generalConfig);

                //BaseConfigInfo baseConfig = new BaseConfigInfo();
                //baseConfig.DeBug = true;
                //BaseConfigs.SaveConfig(baseConfig);

                //CookiesConfigInfo cookiesConfig = new CookiesConfigInfo();
                //CookiesConfigs.SaveConfig(cookiesConfig);

                //DbConfigInfo dbConfig = new DbConfigInfo();
                //DbConfigs.SaveConfig(dbConfig);

                //EmailConfigInfo emailConfig = new EmailConfigInfo();
                //EmailConfigs.SaveConfig(emailConfig);
            }
        }

        public void ShowMsg(string message)
        {
            new Terminator().Throw(message);
        }

        public void ShowMsg(string message, string title, string gotoUrl)
        {
            new Terminator().Throw(message, title, string.Format("Go to Page,{0}", gotoUrl));
        }
    }
}
