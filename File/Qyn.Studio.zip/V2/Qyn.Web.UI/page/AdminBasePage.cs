﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

using Qyn.Common.Utils;
using Qyn.Common;
using Qyn.Configs;
using Qyn.Logic;
using Qyn.Entity;
using Qyn.Web.UI;
using Qyn.ConfigInfo;
using Qyn.Common.Tools;

namespace Qyn.Web.UI
{
    public class AdminBasePage:BasePage
    {
        /// <summary>
        /// 页面伪aspx后缀名
        /// </summary>
        public string PageExtension
        {
            get
            {
                if (BaseConfigs.ConfigInfo.WebPageExtension.Length == 0)
                {
                    return ".aspx";
                }
                return BaseConfigs.ConfigInfo.WebPageExtension;
            }
        }

        /// <summary>
        /// 当前管理员ID
        /// </summary>
        public int AdminID;

        /// <summary>
        /// 当前管理员名
        /// </summary>
        public string AdminName;

        /// <summary>
        /// 权限, true:管理员,false:推广员
        /// </summary>
        public bool IsAdmin;

        /// <summary>
        /// 页面标题
        /// </summary>
        public string webTitle = GeneralConfigs.ConfigInfo.WebTitle;

        /// <summary>
        /// 管理员登陆入口
        /// </summary>
        public string LoginUrl;

        /// <summary>
        /// 指定推广员名称
        /// </summary>
        public string PartnerName
        {
            get { return IsAdmin ? ParseCookies.Get<String>("Partner", string.Empty) : AdminName; }
            set { ParseCookies.Set("Partner", value.ToString()); }
        }

        /// <summary>
        /// 底部刷新时间
        /// </summary>
        public int RefreshTime
        {
            get { return ParseCookies.Get<Int32>("RefreshTime", 60000); }
            set { ParseCookies.Set("RefreshTime", value.ToString()); }
        }

        /// <summary>
        /// 是否开启底部提醒音乐
        /// </summary>
        public bool BackGroundMusic
        {
            get { return ParseCookies.Get<Boolean>("BackGroundMusic", true); }
            set { ParseCookies.Set("BackGroundMusic", value.ToString()); }
        }

        /// <summary>
        /// 获取Cookies信息
        /// </summary>
        private void GetAdminStatus()
        {
            CookiesConfigInfo cookiesInfo = CookiesConfigs.ConfigInfo;

            AdminID = ParseCookies.Get<Int32>(cookiesInfo.Cookies_Admin_Id.ToString(), -1);
            AdminName = ParseCookies.Get<String>(cookiesInfo.Cookies_Admin_Name, "");
            IsAdmin = ParseCookies.Get<Boolean>(cookiesInfo.Cookies_Admin_Purview, false);

            ParseCookies.Set(cookiesInfo.Cookies_Admin_Id, AdminID.ToString(), cookiesInfo.Cookies_Admin_TimeOut);
            ParseCookies.Set(cookiesInfo.Cookies_Admin_Name, AdminName, cookiesInfo.Cookies_Admin_TimeOut);
            ParseCookies.Set(cookiesInfo.Cookies_Admin_Purview, IsAdmin.ToString(), cookiesInfo.Cookies_Admin_TimeOut);
        }

        /// <summary>
        /// 构造函数
        /// </summary>
        public AdminBasePage()
        {
            LoginUrl = WebPath + GeneralConfigs.ConfigInfo.AdminLoginUrl;

            //获取管理权限
            GetAdminStatus();

            //登陆页面时,不检测登陆状态!
            if (string.Compare(QynRequest.GetUrl(QynRequest.UrlType.Path) + QynRequest.GetUrl(QynRequest.UrlType.PageName), LoginUrl, true) != 0)
            {
                if (!IsLogin())
                {
                    ShowMsg("Please Login!", "Tips", LoginUrl);
                    return;
                }
            }
            else
            {
                if (IsLogin())
                {
                    BaseResponse.Redirect("/");
                    return;
                }
            }
        }


        /// <summary>
        /// 判断登陆状态
        /// </summary>
        public bool IsLogin()
        {
            if (BaseConfigs.ConfigInfo.DeBug)
            {
                AdminID = 3;
                AdminName = "admin";
                IsAdmin = true;
                return true;
            }

            if (AdminID != -1 && !string.IsNullOrEmpty(AdminName)) { return true; }

            return false;
        }

    }
}
