﻿using System;
using System.Collections.Generic;
using System.Text;

using Qyn.Cache;
using Qyn.Common.Utils;
using Qyn.Common.Tools;
using Qyn.Configs;

namespace Qyn.Web.Cache
{
    public class PageCache
    {
        private static string WebUrl;

        static PageCache()
        {
            WebUrl = QynRequest.GetUrl(QynRequest.UrlType .Domain) + BaseConfigs.ConfigInfo.WebPath;
        }

        /// <summary>
        /// 获取top.aspx缓存页
        /// </summary>
        /// <returns></returns>
        public static string GetTopPage()
        {
            string key = "Page_Top";
            string page = QynCache.Get<string>(key);

            if (page == null)
            {
                page = Qyn.Common.Utils.ParseHtml.GetUrlToHtml(WebUrl + "aspx/page/Top.aspx", "utf-8");
                QynCache.Add<string>(key, page);
            }

            return page;
        }

        /// <summary>
        /// 清空top.aspx缓存页
        /// </summary>
        /// <returns></returns>
        public static void ClearTopPage()
        {
            string key = "Page_Top";
            QynCache.Clear(key);
        }
    }
}
