﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.IO;

using Qyn.Configs;
using Qyn.ConfigInfo;

namespace Qyn.Web
{
    public class HttpModule : IHttpModule
    {
        public void Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(Qyn_BeginRequest);
        }

        public void Dispose()
        { }

        public void Qyn_BeginRequest(object sender, EventArgs e)
        {
            HttpContext context = ((HttpApplication)sender).Context;

            BaseConfigInfo baseConfig = BaseConfigs.ConfigInfo;

            string webPath = baseConfig.WebPath.ToLower();
            //请求的路径，不带域名
            string requestPath = context.Request.Path.ToLower();
            string pageName = Path.GetFileName(requestPath).ToLower();
            string pageWillNotExtension = Path.GetFileNameWithoutExtension(pageName);
            string pageExtension = Path.GetExtension(requestPath).ToLower();

            string aspxPageExtension = baseConfig.WebPageExtension.ToLower();
            if (aspxPageExtension.Length == 0) { aspxPageExtension = ".aspx"; }

            //当http仿问根目录下的文件时
            if (requestPath == webPath + pageName)
            {
                //if (pageName == "default.aspx")
                //{
                //    context.Response.Redirect("default" + aspxPageExtension);
                //    return;
                //}
                if (pageExtension == aspxPageExtension)
                {
                    context.RewritePath(webPath + "aspx/" + pageWillNotExtension + ".aspx");
                    return;
                }
                if (pageExtension == ".html")
                {
                    context.RewritePath(webPath + "html/" + pageWillNotExtension + ".html");
                    return;
                }

                //context.RewritePath(webPath + "404.html?id=" + pageExtension);
            }
        }
    }
}
