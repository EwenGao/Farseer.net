﻿using System;
using System.Collections.Generic;
using System.Text;

using Qyn.Common.Utils;

namespace Qyn.ExtensionMethods
{
    public static class ObjectExtension
    {
        /// <summary>
        /// 将对像转换为T类型
        /// </summary>
        public static T ConvertType<T>(this object obj, T defValue)
        {
            return ParseType.ConvertType<T>(obj, defValue);
        }


        /// <summary>
        /// 判断是否T类型
        /// </summary>
        public static bool IsType<T>(this object obj)
        {
            return ParseIsType.IsType<T>(obj);
        }
    }
}