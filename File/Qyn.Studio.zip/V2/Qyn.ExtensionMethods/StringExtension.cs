﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

using Qyn.Common.Utils;

namespace Qyn.ExtensionMethods
{
    public static class StringExtension
    {

        /// <summary>
        /// 是否为ip
        /// </summary>
        public static bool IsIP(this string str)
        {
            return ParseIsType.IsIP(str);

        }

        /// <summary>
        /// 将对像转换为数组
        /// </summary>
        public static string[] ToArray(this string str, string sign)
        {
            return ParseString.SplitString(str, sign);
        }

        /// <summary>
        /// 指定清除标签的内容
        /// </summary>
        /// <param name="str">内容</param>
        /// <param name="tag">标签</param>
        /// <returns></returns>
        public static string ClearString(this string str, string tag)
        {
            return ParseString.ClearString(str, tag);
        }

    }
}