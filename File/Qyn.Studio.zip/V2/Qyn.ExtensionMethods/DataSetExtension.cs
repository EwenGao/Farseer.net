﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

using Qyn.Common.Utils;

namespace Qyn.ExtensionMethods
{
    public static class DataSetExtension
    {
        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(this DataSet ds)
        {
            if (ds.Tables.Count == 0) return null;
            return ds.Tables[0].ToList<T>();
        }
    }
}
