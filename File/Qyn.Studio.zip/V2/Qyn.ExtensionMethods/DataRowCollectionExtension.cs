﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Qyn.ExtensionMethods
{
    public static class  DataRowCollectionExtension
    {
        public static List<DataRow> ToRows(this DataRowCollection drc)
        {
            List<DataRow> lstRow = new List<DataRow>();

            if (drc == null) { return lstRow; }

            foreach (DataRow dr in drc)
            {
                lstRow.Add(dr);
            }

            return lstRow;
        }
    }
}
