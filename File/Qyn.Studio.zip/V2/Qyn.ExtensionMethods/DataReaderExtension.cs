﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Qyn.ExtensionMethods
{
    public static class DataReaderExtension
    {
        /// <summary>
        /// 数据填充
        /// </summary>
        public static List<T> ToList<T>(this IDataReader reader)
        {
            List<T> list = new List<T>();
            Type ht = typeof(T);
            while (reader.Read())
            {
                object obj = Activator.CreateInstance(ht, reader);
                list.Add((T)obj);
            }
            reader.Close();
            reader.Dispose();
            return list;
        }
    }
}
