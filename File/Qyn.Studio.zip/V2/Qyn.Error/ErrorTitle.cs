﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Qyn.Error
{
    public class ErrorTitle
    {
        public static string GetTitle(int errorId)
        {
            switch (errorId)
            {
                case 10:
                    return "询问";
                default:
                    return "提示";
            }
        }
    }
}
